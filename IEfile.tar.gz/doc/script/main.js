var g_lxdMain = null;
var g_bIsIPDome = false;        //是否支持PTZ
var g_bIsSupportAudio = false;  //是否支持音频
var g_bIsSupportPTZ = true;
var g_bIsSupportSubStream = true;
var g_bIsSupportPreview = false;
var g_bIsSupportRecordPlan = false;
var g_bIsSupportDoubleNetwork = false;
var g_bIsSupportCustomInterface = false;
var g_alarmOutNum = "";
var g_maxRS485Num = 0;

var g_bIsSupportPersonEnabled = false;

/*************************************************
Function:		getUrlParam
Description:	获取URL属性方法
Input:			name 属性名称
				
Output:			无
return:			属性结果返回			
*************************************************/
function  getUrlParam(name){

	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");   
	var r = window.location.search.substr(1).match(reg);   
	if(r!=null)
	return unescape(r[2]);
	
	return null;
}

/*************************************************
Function:		initMain
Description:	初始化主页面
Input:			无
Output:			无
return:			无				
*************************************************/

function initMain()
{
	var w = $('body').width();
	var h = $('body').height();

	$("#ConfigDivUpdateBlock").css({
		"width":document.body.scrollWidth+"px",
		"height":document.body.scrollHeight+"px",
		"position": "fixed"
	});
	
	$(window).bind("resize", function()
	{
		var w = $('body').width();
		var h = $('body').height();

		$("#ConfigDivUpdateBlock").css({
			"width": document.body.scrollWidth+"px",
			"height":document.body.scrollHeight+"px",
			"position": "fixed"
		});
		if($("#contentframe").attr("src").indexOf("preview") != "-1")
		{
			var curWnd = document.getElementById('contentframe').contentWindow;
			if(curWnd.m_iWndType == 0)
			{
				curWnd.autoSize();
			}
		}
	});

	mainEventBind();
	LatestPage();
	GetDeviceInfo(); //获取设备型号
	getAudioSupport();
    getRecordPlanSupport();//获取录像计划支持。

	if(getUrlParam('isLink') !== null && getUrlParam('isLink')){

		for(var i = 1; i< 6 ; i++){
			if(i != 5){
				document.getElementById('iMenu' + i).style.display = "none";
			}
		}
		//选中菜单
		window.parent.ChangeMenu(5);
		ChangeFrame('paramconfig.asp',5);
	}
    if(!g_bIsSupportPreview){
        document.getElementById('iMenu2').style.display = "none";
    }
    if(!g_bIsSupportPersonEnabled){
    	document.getElementById('iMenu6').style.display = "none";
    }

}

/*************************************************
Function:		LastPage
Description:	主页面加载时，获取cookie，跳转到刷新前的界面
Input:			无
Output:			无
return:			无				
*************************************************/
function LatestPage()
{
	m_szUserPwdValue = g_oWebSession.getItem("userInfo"+m_lHttpPort);
	if(m_szUserPwdValue == null)
	{
		window.location.href="login.asp";
		return;
	}
	translator.initLanguageSelect($.cookie("language"));
	var lxd = translator.getLanguageXmlDoc("Main");
	translator.translatePage($(lxd).children("Main")[0], parent.document);
	g_lxdMain = $(lxd).children("Common")[0];
	translator.translateElements(g_lxdMain, $("#dvChangeSize")[0], "span", "title");
	var curpage = $.cookie('page');
	if(null == curpage)
	{
		ChangeFrame("preview.asp",1);
	}else
	{
		if(curpage.split("%").length == 3) {
			g_lMapRtspPort = curpage.split("%")[2];
			$.cookie("rtspport", g_lMapRtspPort);
		} else {
			g_lMapRtspPort = null;
			$.cookie("rtspport", null);
		}
		ChangeFrame(curpage.split("%")[0],curpage.split("%")[1]);
	}
}

/*************************************************
Function:		ChangeFrame
Description:	主页面加载时，获取cookie，跳转到刷新前的界面
Input:			src:页面路径
				index:ID序号
Output:			无
return:			无				
*************************************************/
function ChangeFrame(src,index)
{
	$("#contentframe").attr("src", "").remove();
	$("#content").html('<iframe frameborder="0" scrolling="no" id="contentframe" name="contentframe" class="contentframe" src="'+src+'"></iframe>');
}
/*************************************************
Function:		restoreSize
Description:	恢复主页面框架各子元素大小
Input:			无
Output:			无
return:			无				
*************************************************/
function restoreSize(iIndex)
{
	if(iIndex == 1)
	{
	    // $('#content').height(689);
	    // $('#contentframe').height(653);
	}
	else
	{
	    $('#content').height(655);
	    // $('#contentframe').height(619);		
	}
	// $('#content').width(974);
	// $('#header').width(974);
	// $('#nav').width(974);
	// $('#contentframe').width(938);
}
/*************************************************
Function:		ChangeMenu
Description:	改变主页菜单栏
Input:			index:ID序号
Output:			无
return:			无				
*************************************************/
function ChangeMenu(index)
{
	for(var i = 1;i < 7;i++)
	{
		if($("#iMenu"+i).hasClass("menuBackground"))
		{
			$("#iMenu"+i).removeClass("menuBackground");
		}
	}
	$("#iMenu"+index).addClass("menuBackground");
	// restoreSize(index);//还原界面大小
}

/*************************************************
Function:		ChangeFrameLanguage
Description:	改变页面语言
Input:			lan:语言
Output:			无
return:			无				
*************************************************/
function ChangeFrameLanguage(lan)
{
	$.cookie('language', lan);
	var lxd = translator.getLanguageXmlDoc("Main", lan);
	translator.translatePage($(lxd).children("Main")[0], parent.document);
	g_lxdMain = $(lxd).children("Common")[0];
	translator.translateElements(g_lxdMain, $("#dvChangeSize")[0], "span", "title");
	var curWnd = document.getElementById('contentframe').contentWindow;
	curWnd.ChangeLanguage(lan);
}
/*************************************************
Function:		GetDeviceInfo
Description:	获取设备名称
Input:			无
Output:			无
return:			无
*************************************************/
function GetDeviceInfo()
{
	$.ajax(
	{
		type: "GET",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/deviceInfo",
		async: false,
		timeout: 15000,
		success: function(xmlDoc, textStatus, xhr) 
		{
			$("#devicetype").html($(xmlDoc).find('model').eq(0).text());
			var szDeviceDes = $(xmlDoc).find('deviceDescription').eq(0).text();
			if("IPDome" == szDeviceDes)
			{
				g_bIsIPDome = true;
			}
			g_bIsSupportPTZ = $(xmlDoc).find('ptzEnabled').eq(0).text()== "true"? true:false;
			g_bIsSupportSubStream = $(xmlDoc).find('subChannelEnabled').eq(0).text()== "true"? true:false;
            g_alarmOutNum = $(xmlDoc).find('alarmOutNum').eq(0).text();
            g_maxRS485Num = $(xmlDoc).find('maxRS485Num').eq(0).text();
            g_bIsSupportCustomInterface = $(xmlDoc).find('transparentEnabled').eq(0).text()== "true"? true:false;
			g_bIsSupportPersonEnabled = $(xmlDoc).find('personEnabled').eq(0).text()== "true"? true:false;
		}
	});
}
/*************************************************
Function:		getAudioSupport
Description:	是否支持音频
Input:			无
Output:			无
return:			无
*************************************************/
function getAudioSupport()
{
	$.ajax(
	{
		type: "GET",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/Audio/channels",
		async: false,
		timeout: 15000,
		success: function(xmlDoc, textStatus, xhr) 
		{
			if($(xmlDoc).find("AudioChannel").length > 0)
			{
				g_bIsSupportAudio = true;
			}
		}
	});
}
/*************************************************
 Function:		getRecordPlanSupport
 Description:	是否支持录音计划 和 是否支持回放菜单功能 和自定义接口 一个方法判断。
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function getRecordPlanSupport(){
	var NetworkInterfaceNum;
    $.ajax(
    {
        type: "GET",
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces",
        async: false,
        timeout: 15000,
        success: function(xmlDoc, textStatus, xhr)
        {
			NetworkInterfaceNum = $(xmlDoc).find("NetworkInterface").length;
			
		}
	});
    $.ajax(
    {
        type: "GET",
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ContentMgmt/Storage",
        async: false,
        timeout: 15000,
        success: function(xmlDoc, textStatus, xhr)
        {
            if($(xmlDoc).find("nas").length > 0)
            {
                var recordEnabled = "true";
                if(recordEnabled == "true"){
                    g_bIsSupportRecordPlan = true;
                    g_bIsSupportPreview = true;
                }
            }       
			if(NetworkInterfaceNum == 2){
				g_bIsSupportDoubleNetwork = true;
			}
        }
    });
}

/*************************************************
Function:		mainEventBind
Description:	事件绑定
Input:			无
Output:			无
return:			无				
*************************************************/
function mainEventBind() {
    //点击语言选择框
	$(".languageshow").bind({
	    click: function (e) {
			e.stopPropagation();
			if($("#divLanguageChoose").css("display") !== "none") {
				$('#divLanguageChoose').hide();
			} else {
				$('#divLanguageChoose').show();
			}
		}
	});
    //点击帮助
	$(".help").bind({
	    click: function (e) {
			e.stopPropagation();
			if($("#SoftwareEdition").css("display") !== "none") {
				$('#SoftwareEdition').hide();
			} else {
				$('#SoftwareEdition').show();
			}
		}
	});	
	//点击语言选择框和帮助以为的地方
    $("body").bind({
	    click: function (e) {
			if($("#divLanguageChoose").css("display") !== "none") {
				$('#divLanguageChoose').hide();
			}
			if($("#SoftwareEdition").css("display") !== "none") {
				$("#SoftwareEdition").hide();
			}			
		}
	});	
	//注销鼠标悬浮
	$(".logout").bind({
	    mouseover: function () {
		    $(this).css("color", "#a73737");
		},
		mouseout: function () {
		    $(this).css("color", "#757575");
		}
	});
	$("#nav").delegate("span","click",function(){
		$("#nav span").css("background-color","#C4B7B7");
		$(this).css("background-color","rgb(145, 27, 27)");
	})
}