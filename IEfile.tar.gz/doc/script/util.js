
/**
 * 处理xml复制
 * @param {[type]} src       [description]
 * @param {[type]} dst       [description]
 * @param {[type]} propArray 数组，里面可以是字符串，也可以是对象。
 * 如果是对象，则为{propName: '', type: 'subNode'}
 */
function SimpleCopyXmlNode (src, dst, propArray) {
	if (!$.isArray(propArray)) {
		return false;
	}
	var $src = $(src);
	var $dst = $(dst);

	$.each(propArray, function (i, n) {
		if (_.isString(n)) {
			$dst.find(n).text($src.find(n).text());
		}else if (n.type == 'subNode' && n.propName) {
			var nd = $src.find(n.propName).eq(0).clone();
			var dp = $dst.find(n.propName).eq(0).parent();
			dp.find(n.propName).remove();
			dp.append(nd);
		}
	});
}

function InitOneSlider (obj) {
    var targetId = obj.targetId;
    var max = obj.max;
    var min = obj.min;
    var tipsId = obj.tipsId
    var valueChanged = obj.valueChanged;
    var defVal = obj.defVal;
    if (typeof defVal == 'undefined') {
    	defVal = min;
    };

    if (!targetId 
            || $('#'+targetId).length == 0 ) {
        return null;
    };

    if(typeof valueChanged != 'function'){
    	valueChanged = $.noop;
    }

    if (typeof max == 'undefined' || max == null) {
        max = 100;
    };
    if (typeof min == 'undefined' || min == null) {
        min = 0;
    };

    $('#'+targetId).html('');

    var slider = new neverModules.modules.slider(
    {
        targetId: targetId,
        sliderCss: "imageslider1",
        barCss: "imageBar2",
        boxCss: "boxBar",
        bBox:true,
        min: min,
        max: max,
        hints:""
    });
    slider.create();
    
    // setTimeout(function() {
    // 	slider.wsetValue(defVal);    
    // }, 500);

    slider.onchange = function ()
    {
    	if (tipsId) {
    		slider.setTitle(getNodeValue(tipsId) + ':' + slider.getValue());	
    	}else{
    		slider.setTitle(slider.getValue());
    	}
    };
    slider.onend = function ()
    {
        valueChanged();
    };

    // var ele = $('#'+targetId);
    // var width = ele.width();
    // ele.width(width - 10);
    
    return slider;
}

var _SliderMap_ = {};

function GetSliderValue (eleId) {
	if (_SliderMap_[eleId]) {
		return _SliderMap_[eleId].getValue();
	}
	return '';
}

function SetSliderValue (eleId, val) {
	if (_SliderMap_[eleId]) {
		_SliderMap_[eleId].wsetValue(val);
		return true;
	}
	return false;
}

function DisableSlider (sel, disabled) {
	if (disabled && $(sel).find('.disablelayer').length == 0) {
		var w = $(sel).width();
		var h = 25;//$(sel).height();
		$(sel).append('<div class="disablelayer" style="position:absolute;width: '+w+'px;height: '+h+'px;"></div>');
		$(sel).find('.boxBar').prop('disabled', true);
	}else if (!disabled) {
		$(sel).find('.disablelayer').remove();
		$(sel).find('.boxBar').prop('disabled', false);
	};
}

function InitSlider2 (sel) {
	if (!sel) {
		_SliderMap_ = {};
		sel = 'div[slider]';
	};

	$(sel).each(function () {
		var $e = $(this);
		var targetId = $e.attr('id');

		var min = parseFloat($e.attr('min'));
		var max = parseFloat($e.attr('max'));
		var step = parseFloat($e.attr('step'));
		var def = parseInt($e.attr('def'));

		var valueChanged = $e.attr('valueChanged');
		var tipsId = $e.attr('tipsId');


		min = min ? min : 0;
		step = step ? step : 1;
		max = max ? max : 100;

		def = def != NaN ? def : min;
		tipsId = tipsId ?  tipsId : '';

		if (valueChanged) {
			var func = window[valueChanged];
			if (!func || typeof func != 'function') {
				func = $.noop;
			};	
		}else{
			func = $.noop;
		}
		
		var opt = {
			targetId: targetId,
			min: min,
			max: max,
			defVal: def,
			tipsId: tipsId,
			valueChanged: func
		};

		var slider = InitOneSlider(opt);
		_SliderMap_[targetId] = slider;
	})
}


function initSlider(){
	$('div.noUiSlider').each(function(){
			var $e = $(this);

			$e.css('display', 'inline-block');
			$e.css('*display', 'inline');

			var min = parseFloat($e.attr('min'));
			var max = parseFloat($e.attr('max'));
			var step = parseFloat($e.attr('step'));
			var swidth = parseInt($e.attr('swidth'));
			var def = parseInt($e.attr('def'));

			min = min ? min : 0;
			step = step ? step : 1;
			max = max ? max : 100;
			swidth = swidth ? swidth : 100;
			def = def != NaN ? def : min;

			var id = $e.attr('id');
			var seid = id+'_sliderBox';

			var opt = {
				range: [min,max],
				step: step,
				handles: 1,
				start: def,
				width: swidth,
				height: 6,
				draggerWidth: 12,
				draggerHeight: 14
			};

			if ($('#'+seid).length) {
			    opt.serialization = {
					to: $('#'+seid),
					resolution: step
				}
			};

			$e.noUiSlider(opt);

			$('#'+seid).width(40).blur(function(){
				var v = $(this).val();
				
				$(this).val(v.replace(/[^\d\.]/g, ''));

				var v = $(this).val();
				if (!v) {
				    v = 0;
				}
				if (step >= 1) {
					v = parseInt(v,10);
				}else{
					v =  parseFloat(v);	
				}
				if (!v) {
				    v = 0;
				}

				$e.val(v);
			});
		});

	$('.noUiSlider').css({background: '#bbb'});
}


function _log (content, level) {
	if (!level) {
		level = "trace: ";
	};

	if (window.console && window.console.log) {
		var msg = level+content;
		window.console.log(msg);
	}
}



(function(){
	function setField(id, value, trigClickForChkbox){
		var $es = $('#'+id);
		if($es.length == 0){
			return;
		}	
		var tagName = $es[0].tagName.toLowerCase();
		if (tagName == 'input' && $es.is(':checkbox')) {
		    if (value && value != '0' && value != 'false' 
		    	&& value != 'FALSE') {
		        $es.prop('checked', true);
		    	if (trigClickForChkbox) {
		    		$es.click().prop('checked', true);
		    	};
		    }else{
		    	$es.prop('checked', false);
		    	if (trigClickForChkbox) {
		    		$es.click().prop('checked', false);
		    	};
		    }
		}else if(tagName == 'input'){
			$es.val(value);
		}else if(tagName == 'td' || tagName=='span'){
			$es.text(value);
		}else if(tagName == 'select'){
			try{
				$es.find('option[value="'+value+'"]').attr('selected', 'selected').prop('selected', true);
			}catch(e){}
		}else if($es.hasClass('noUiSlider')){
			var v = parseFloat(value);
			if (!isNaN(v)) {
				setTimeout(function () {
					//_log('setting '+$es.attr('id')+', oldVal='+$es.val()+', value='+v);
					$es.val(v);		
					//_log('new val='+$es.val())

					//_log('----------');
				},330);
			}
		}
		else{
			_log(' -- '+id+' is not found while setting Field !')
		}
	}

	function setField2(sel, value, trigClickForChkbox){
		var $es = $(sel);
		if($es.length == 0){
			return;
		}	

		var id = $es.attr('id');

		var tagName = $es[0].tagName.toLowerCase();
		if (tagName == 'input' && $es.is(':checkbox')) {
		    if (value && value != '0' && value != 'false' 
		    	&& value != 'flase'
		    	&& value != 'FALSE') {
		        $es.prop('checked', true);
		    	if (trigClickForChkbox) {
		    		$es.click().prop('checked', true);
		    	};
		    }else{
		    	$es.prop('checked', false);
		    	if (trigClickForChkbox) {
		    		$es.click().prop('checked', false);
		    	};
		    }
		}else if(tagName == 'input'){
			$es.val(value);
		}else if(tagName == 'td' || tagName=='span'){
			$es.text(value);
		}else if(tagName == 'select'){
			try{
				$es.find('option[value="'+value+'"]').attr('selected', 'selected').prop('selected', true);
			}catch(e){}
		}else if($es.hasClass('noUiSlider')){
			var v = parseFloat(value);
			if (!isNaN(v)) {
				setTimeout(function () {
					$es.val(parseFloat(value));		
				},330);
			}
		}else if ($es.is("div[slider]") && id) {
			SetSliderValue(id, value);	
		}else{
			_log(' -- '+id+' is not found while setting Field !')
		}
	}


	function getEleVal (sel) {
		var $es = $(sel);
		if($es.length == 0){
			return;
		}	

		var retVal = null;

		var id = $es.attr('id');
		var tagName = $es[0].tagName.toLowerCase();
		if (tagName == 'input' && $es.is(':checkbox')) {
		    retVal = $es.prop('checked') ? "true" : "false";
		}else if ($es.is("div[slider]") && id) {
			retVal = GetSliderValue(id);
		}else{
			retVal = $es.val();
		}
		return retVal;
	}


	function contains(arr, e){
		if(!$.isArray(arr)){
			arr = [arr];
		}
		for (var i = 0; i < arr.length; i++) {
			if(arr[i] == e){
				return true;
			}	
		};
		return false;
	}

	$.g = $.goldway || {};
	$.g.setField = setField;
	$.g.setField2 = setField2;
	$.g.contains = contains;

	$.g.getEleVal = getEleVal;



	function bound (sel, min, max) {
		var v = $(sel).val();
		v = parseFloat(v);
		if (v > max || v < min) {
			return false;
		};
		return true;
	}

	$.g.isInRange = bound;
})($);

function log(msg){
	_log(msg);
}

function getMousePoint(ev) {
    var x = y = 0,
	doc = document.documentElement,
    body = document.body;

    if (!ev) ev = window.event;
    if (window.pageYoffset) { //pageYoffset是Netscape特有
        x = window.pageXOffset;
        y = window.pageYOffset;
    } else {
        x = (doc && doc.scrollLeft || body && body.scrollLeft || 0) - (doc && doc.clientLeft || body && body.clientLeft || 0);
        y = (doc && doc.scrollTop || body && body.scrollTop || 0) - (doc && doc.clientTop || body && body.clientTop || 0);
    }
    x += ev.clientX;
    y += ev.clientY;
    return {
        'x': x,
        'y': y
    };
}

function getPos(evt, obj) {
	var m = getMousePoint(evt);
	var p = $(obj).offset();
	var x = m.x - p.left;
	var y = m.y - p.top;
	return {
		x: x,
		y: y
	};
}


function escapeXmlChars(str) {
	if(typeof(str) == "string")
		return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#x27;').replace(/\//g, '&#x2F;');
	else
		return str;
}

function unescapeXmlChars(str) {
	return str.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#x27;/g, "'").replace(/&#x2F;/g, '\/')
}	


(function () {
	String.prototype.format = function () {
		var a = [].slice.apply(arguments),
	    	s = this.toString();
	    return s.replace(/{[0-9]+}/g, function(d){ 
	    	var t = a[ d.slice( 1, -1 ) ];  
	    	return typeof t == 'undefined' ? d : t;
	    });
	}

	String.prototype.padLeft = function (len, ch) {
		if (this.length >= len) {
			return this;
		};
		var c = len - this.length;
		var s = [];
		s.push(this);

		for (var i = 0; i < c; i++) {
			s.unshift(ch); 
		};
		return s.join('');
	}

	function simpleFormat()
	{
	    var a = [].slice.apply(arguments),
	    	s = a.shift();
	    return s.format.apply(s, a);
	};

	window.simpleFormat = simpleFormat;
})();
