﻿var g_lxdLogin = null; // Login.xml
var szDefaultUser = 'admin';
//登陆页不需要处理401
$.ajaxSetup({
	statusCode: {
		401: function () {}
	}
});
/**********************************
 功能: 初始化界面
 ***********************************/
function InitLogin() {
	var szUrl = decodeURI(document.URL);
	if (szUrl.indexOf("anonymous=true") != -1) {
		$("#divAnonymous").show();
	} else {
		$("#divAnonymous").hide();
	}
	// if(global_config.web_mode === 0) {  //中性标配区分
	// 	$("#laCopyRight").html(Base64.decode(g_szCopyRight));
 //        $("#logoAre").addClass('appLogo_img');
	// }

	var szLanguage = $.cookie('language');
	if (szLanguage === null) // 如果直接到登录界面，也获取一下语言
	{
		if (navigator.appName === "Netscape" || navigator.appName === "Opera") {
			var sysLanguage = navigator.language.toLowerCase();
		} else {
			var sysLanguage = navigator.browserLanguage.toLowerCase();
		}
		szLanguage = sysLanguage.substring(0, 2);

		//直接写死为中文
		szLanguage="zh";
		//end
	
		if (szLanguage == "zh") {  //中文需要区分简体和繁体
			var arSysLan = sysLanguage.split("-");
			if (arSysLan.length === 2) {
				szLanguage = arSysLan[0].toLowerCase() + "_" + arSysLan[1].toUpperCase();
				if (arSysLan[1].toLowerCase() === "cn") {
					$.cookie('language', 'zh');
					szLanguage = 'zh';
				} else {
					$.cookie('language', szLanguage);
				}
			}
		} else {
			$.cookie('language', szLanguage);
		}
		/*var arSysLan = sysLanguage.split("-"); //目前的机制认为不会出现“zh”格式的系统语言标示
		 if (arSysLan.length === 2) {
		 szLanguage = arSysLan[0].toLowerCase() + "_" + arSysLan[1].toUpperCase();
		 if (arSysLan[0].toLowerCase() === "zh") { // 在支持繁体中文前，zh_HK和zh_TW都显示zh_CN
		 szLanguage = "zh_CN";
		 }
		 $.cookie('language', szLanguage);
		 } else {
		 szLanguage = null;
		 }*/
	}

	//直接写死为中文
	szLanguage="zh";
	//end

	translator.initLanguageSelect(szLanguage);
	g_lxdLogin = translator.getLanguageXmlDoc("Login");
	window.parent.document.title = translator.translateNode(g_lxdLogin, "lalogin");

	var _lxdMain = translator.getLanguageXmlDoc(["Main", "Common"]);
	translator.appendLanguageXmlDoc(g_lxdLogin, _lxdMain);
	translator.translatePage(g_lxdLogin, document);

	if (!(document.cookie || navigator.cookieEnabled)) {
		alert(translator.translateNode(g_lxdLogin, "CookieTips"));
		return;
	}
	loginEventBind();
	$('#UserName').focus();
	$("#chAnonymous").click(function () {
		if ($(this).prop("checked")) {
			$("#UserName").prop("disabled", true).val("anonymous");
			$("#Password").prop("disabled", true).val("******");
		} else {
			$("#UserName").prop("disabled", false).val("");
			$("#Password").prop("disabled", false).val("");
		}
	});
	// getDeviceLan();
	 getDeviceActiveStat();
}
/**********************************
 功能: 按回车键登录
 ***********************************/
//document.onkeydown = function (event) {
//	event = event ? event : (window.event ? window.event : null);
//	if (event.keyCode == 13) {
//		DoLogin();
//	}
//}
/**********************************
 功能: 计算字符串的长度
 参数: szString: 输入的字符串
 ***********************************/
function JudgeTextLength(szString) {
	var iLength = 0;
	for (var i = 0; i < szString.length; i++) {
		if (szString.charCodeAt(i) > 255) {
			iLength += 2;
		} else {
			iLength += 1;
		}
	}
	return  iLength;
}
/**********************************
 功能: 登陆
 ***********************************/
function DoLogin() {
	$("#LoginBtn").focus();
	if (!$("#chAnonymous").prop("checked")) {
		//用户名为空时提示
		if ($('#UserName').val().length == 0) {
			$('#UserName').focus();
			alert(translator.translateNode(g_lxdLogin, 'LoginTips1'));
			return false
		}
		//密码为空时提示
		if ($('#Password').val().length == 0) {
			$('#Password').focus();
			alert(translator.translateNode(g_lxdLogin, 'LoginTips5'));
			return false
		}
		if (isChinese($("#UserName").val())) {
			alert(getNodeValue("NotSupportZhUser"));
			return false
		}
		if (JudgeTextLength($('#UserName').val()) > 32) {
			$('#UserName').focus();
			$('#UserName').val('');
			alert(translator.translateNode(g_lxdLogin, 'LoginTips2'));
			return false;
		}
		if (JudgeTextLength($('#Password').val()) > 16) {
			$('#Password').focus();
			$('#Password').val('');
			alert(translator.translateNode(g_lxdLogin, 'LoginTips3'));
			return false;
		}
	}

	$.ajaxSetup({
		username:$("#UserName").val(),
		password:$("#Password").val()

	});

	m_szUserPwdValue = Base64.encode($('#UserName').val() + ":" + $('#Password').val()+":digest");
	var szTimeStamp = new Date().getTime();  //为了解决各个浏览器不带认证请求
	$.ajax({
		type: "GET",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/userCheck?timeStamp=" + szTimeStamp,
		username: $("#UserName").val(),
		password: $("#Password").val(),
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
		},
		success: function (xmlDoc, textStatus, xhr) {
			if ("200" == $(xmlDoc).find('statusValue').eq(0).text()) {  //提示默认密码后跳转
				if("false" == $(xmlDoc).find('isActivated').eq(0).text()) {
					showChangePswd();
				} else if("true" == $(xmlDoc).find('isRiskPassword').eq(0).text()) {
					if(window.confirm(getNodeValue('riskPwdTips'))){
						jumpPage("paramconfig", "2_9", "0")
					} else {
						jumpPage();
					}
				} else {
					jumpPage();
				}
			} else {
				jumpPage();
			}
		},
		error: function (xhr, textStatus, errorThrown) {
			if ("timeout" == textStatus) {
				alert(translator.translateNode(g_lxdLogin, 'ConnectTimeoutTips'));
			} else if (401 === xhr.status) {
				if (!$('#UserName').prop("disabled")) {
					$('#UserName').focus();
				}
				$('#UserName').val('');
				$('#Password').val('');
				alert(translator.translateNode(g_lxdLogin, 'LoginTips4'));
			}
            else if (403 === xhr.status) {
				
                alert(getNodeValue('LoginLocked'));  //输入N次密码错误后，用户被锁定
            }
            else {
				alert(translator.translateNode(g_lxdLogin, 'NetworkErrorTips'));
			}
		}
	});
}

/*************************************************
 Function:        ChangeFrameLanguage
 Description:    改变页面语言
 Input:            lan：语言
 Output:            无
 return:            无
 *************************************************/
function ChangeFrameLanguage(lan) {
	$.cookie('language', lan);
	g_lxdLogin = translator.getLanguageXmlDoc("Login", lan);
	//translator.translatePage(g_lxdLogin, document);
	window.parent.document.title = translator.translateNode(g_lxdLogin, "lalogin");

    var _lxdMain = translator.getLanguageXmlDoc(["Main", "Common"]);
    translator.appendLanguageXmlDoc(g_lxdLogin, _lxdMain);
    translator.translatePage(g_lxdLogin, document);
}
/*************************************************
 Function:        CheckKeyDown
 Description:    输入时按下空格时，不允许输入
 Input:            iSetId: 需要验证表单Id
 iSetValue: 需要验证的值
 Output:            无
 return:            无
 *************************************************/
function CheckKeyDown(event) {
	event = event ? event : (window.event ? window.event : null);
	if (event.keyCode == 32) {
		if (navigator.appName == "Netscape" || navigator.appName == "Opera") {
			event.preventDefault();
		} else {
			event.returnValue = false;    //非ie浏览器event无returnValue属性
		}
		return;
	}
}
/*************************************************
 Function:        loginEventBind
 Description:    事件绑定
 Input:            无
 Output:            无
 return:            无
 *************************************************/
function loginEventBind() {
	//点击语言选择框
	$(".languageshow").bind({
		click: function (e) {
			e.stopPropagation();
			if ($("#divLanguageChoose").css("display") !== "none") {
				$('#divLanguageChoose').hide();
			} else {
				$('#divLanguageChoose').show();
			}
		}
	});
	//点击语言选择框以为的地方
	$("body").bind({
		click: function (e) {
			if ($("#divLanguageChoose").css("display") !== "none") {
				$('#divLanguageChoose').hide();
			}
		},
		keydown: function (e) {
			if(e.keyCode === 13) {
				DoLogin();
			}
        }
	});
}
/*************************************************
 Function:       getDeviceLan
 Description:    获取设备语言类型
 Input:          无
 Output:         无
 return:         无
 *************************************************/
function getDeviceLan() {
	$.ajax({
		type: "GET",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/language",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function (xmlDoc, textStatus, xhr) {
			if ("chinese" == $(xmlDoc).find("Language").eq(0).find("type").eq(0).text()) {
				$("#divLanguageChoose").find("label[id!='zh']").each(function (i) {
					$(this).parent().remove();
				});
				$("#divLanguageChoose").css("height", "auto");
				if ("zh" != $.cookie('language')) {
					chooseLanguage("zh");
				}
			} else {
				$("#divLanguageChoose").find("label[id='zh']").parent().remove();
				if ("zh" == $.cookie('language')) {
					chooseLanguage("en");
				}
			}
            //语言栏做调整
            var iLanNum = $("#divLanguageChoose").find('div').length * 20;
            var iHeight = 20;
            iHeight = iLanNum > 105 ? 105:iLanNum;
            $("#divLanguageChoose").css('height', iHeight+'px');
		},
        error:function (xhr, textStatus, errorThrown) {
             //语言栏做调整
            var iLanNum = $("#divLanguageChoose").find('div').length * 20;
             var iHeight = 20;
            iHeight = iLanNum > 105 ? 105:iLanNum;
             $("#divLanguageChoose").css('height', iHeight+'px');
		 }
	});
}
/*************************************************
 Function:       getDeviceActiveStat
 Description:    获取设备激活状态
 Input:          无
 Output:         无
 return:         无
 *************************************************/
function getDeviceActiveStat() {
	$.ajax({
		type: "GET",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/activateStatus",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
		},
		success: function (xmlDoc, textStatus, xhr) {
			if ($(xmlDoc).find("Activated").text() != "true") {
				showChangePswd();
			}
		}
	});

}
function isChinese(_str) {
	return /[^\x00-\xff]/.test(_str);
}
//显示提示密码登录框，绑定事件
function showChangePswd() {

    $("#defPwsTip").html(getNodeValue('laChangePswdTip'));
	$("#defaultUser").html(szDefaultUser);
    //如果设备返回默认密码，则询问是否需要修改默认密码
    $("#divChangePassword").modal();
    //取消这个绑定，以免回车点击再次发送登录命令
    $("body").unbind("keydown").bind("keydown", function(e){
		if(e.keyCode === 13) {
			doActive();
		}
	});

    //链接到用户配置界面
    $("#btnOK").unbind().bind("click", doActive);
}
//
function doActive() {
	var iLength = 1024;
	if($("#newPassword").val() !== $("#newComfirmPassword").val()) {
		showErrorTips("passwordtips", getNodeValue("jsPasswordDifferenceTips"), false);
		return;
	}
	if(CheckPasswordComplexity($("#newPassword").val(), "passwordtips", szDefaultUser)) {
		if($.browser.msie && parseInt($.browser.version, 10) < 9) {
			iLength = 256;
		} 
		
		Encryption.encryptPassword($("#newPassword").val(), iLength, activeDevice);
	}
}
//页面跳转，有三个参数，都是可选，如果没有参数，表示进入预览界面。
//第一个参数表示主界面（预览，回放，日志，配置）
//第二个参数表示配置界面中的具体菜单
//第三个参数表示配置界面中的具体tab页
function jumpPage() {
    var szPage = "";
    var szParam = "";

    if(0 == arguments.length) {  //默认跳转到预览页面
        var szUrl = decodeURI(document.URL);
        if(szUrl.indexOf("?page=") != -1) {
            szPage = szUrl.substring(szUrl.indexOf("page=") + 5, szUrl.indexOf("&params="));
            if(szPage.indexOf(".asp") == -1) {
                szPage = szPage.concat(".asp");
            }
            szParam = szUrl.substring(szUrl.indexOf("&params=") + 8, szUrl.length);
            $.cookie('page',szPage+"?"+szParam+"%1");
        } else {
            $.cookie('page',null);
        }
    } else {  //需要跳转到用户配置页面
        var szMainPage = arguments[0];
        var szSubPage = arguments[1] == 'undefined' ? "" : arguments[1];
        var szTab = arguments[2] == 'undefined' ? "" : arguments[2];

        if(szMainPage.indexOf(".asp") == -1) {
            szMainPage = szMainPage.concat(".asp");
        }

        szPage = szMainPage;
        $.cookie("menu_twomenu", szSubPage);
        $.cookie('page', szPage+"?"+ szParam +"%1");
        $.cookie('_curTab', szTab);
    }

    g_oWebSession.setItem("userInfo"+m_lHttpPort, m_szUserPwdValue);
    window.location.href = "main.asp";
}

/*************************************************
 Function:       onPswInput
 Description:    处理密码输入事件
 Input:          无
 Output:         无
 return:         无
 *************************************************/
function onPswInput() {
	var szVal = $("#newPassword").val();
	$("#pwdblock").removeClass().addClass("inputRight");
	var oPswStrength = $(".userstrength");
	var oPswStrengthTips = $("#strengthTips");
	switch (CheckPasswordComplexity(szVal, szDefaultUser)) {
		case 1: {
					oPswStrength.eq(0).css("backgroundColor", "#FC657E");
					oPswStrength.eq(1).css("backgroundColor", "");
					oPswStrength.eq(2).css("backgroundColor", "");
					oPswStrengthTips.html(getNodeValue("weakPwd"));
					break;
				}
		case 2: {
					oPswStrength.eq(0).css("backgroundColor", "#FFC85D");
					oPswStrength.eq(1).css("backgroundColor", "#FFC85D");
					oPswStrength.eq(2).css("backgroundColor", "");
					oPswStrengthTips.html(getNodeValue("normalPwd"));
					break;
				}
		case 3: {
					oPswStrength.eq(0).css("backgroundColor", "#65D25D");
					oPswStrength.eq(1).css("backgroundColor", "#65D25D");
					oPswStrength.eq(2).css("backgroundColor", "#65D25D");
					oPswStrengthTips.html(getNodeValue("goodPwd"));
					break;
				}
		default: {
					oPswStrength.css("backgroundColor", "");
					oPswStrengthTips.html('');
					$("#pwdblock").removeClass().addClass("inputWrong");
		}
	}
}

/*************************************************
 Function:       showErrorTips
 Description:   显示错误提示
 Input:            szTipsId:位置
 szTipsStr:提示语
 bFloat:是否浮动
 Output:        无
 Return:        无
 *************************************************/
function showErrorTips(szTipsId, szTipsStr, bFloat) {
	if(typeof g_iShowErrorTipsTimer == "undefined") {
		g_iShowErrorTipsTimer = 0;
	}
	if (0 != g_iShowErrorTipsTimer) {
		window.parent.$("#dvErrorTips").hide().html("");
		$("#" + szTipsId).empty();
		clearTimeout(g_iShowErrorTipsTimer);
		g_iShowErrorTipsTimer = 0;
	}
	if (typeof bFloat == "undefined") {
		bFloat = true;
	}
	if (bFloat) {
		var oTipsPos = $("#" + szTipsId).offset();
		var oFramePos = window.parent.$("#contentframe").offset();
		var iLeft = oTipsPos.left + oFramePos.left;
		var iTop = oTipsPos.top - 18 + oFramePos.top;
		window.parent.$("#dvErrorTips").show().html(szTipsStr).offset({left: iLeft, top: iTop});
	} else {
		szTipsStr = "<img src='../images/config/tips.gif' class='verticalmiddle'>&nbsp;" + szTipsStr;
		$("#" + szTipsId).html(szTipsStr);
	}

	//5秒后自动清除
	g_iShowErrorTipsTimer = setTimeout(function () {
		window.parent.$("#dvErrorTips").hide().html("");
		$("#" + szTipsId).html("");
	}, 5000);
}

/*************************************************
 Function:       activeDevice
 Description:    激活设备
 Input:          无
 Output:         无
 return:         无
 *************************************************/
function activeDevice(szPwd) {
	$.ajax({
		type: "PUT",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/activate",
		processData: false,
		data: xmlToStr($(parseXmlFromStr('<ActivateInfo><password></password></ActivateInfo>')).find("password").text(szPwd).parent().get(0)),
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function (xmlDoc, textStatus, xhr) {
			$("#UserName").val(szDefaultUser);
			$("#Password").val($("#newPassword").val());
			DoLogin();
		},
        error:function (xhr, textStatus, errorThrown) {
			if($(xhr.responseXML).find("subStatusCode").text() == 'hasActivated') {
				alert(getNodeValue('DeviceActived'));
				window.location.reload();
			}
            showErrorTips("passwordtips", getNodeValue('NetworkErrorTips'), false);
		}
	});
}