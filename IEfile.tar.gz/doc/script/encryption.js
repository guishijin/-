function EncryptionFac () {
}
EncryptionFac.prototype.ToHex = function (str) {
	var val = "";
	for(var i = 0; i < str.length; i++) {
		if(val === "") {
			if(str.charCodeAt(i) < 16) {
				val += "0" + str.charCodeAt(i).toString(16);
			} else {
				val += str.charCodeAt(i).toString(16);
			}
		} else {
			if(str.charCodeAt(i) < 16) {
				val += "0" + str.charCodeAt(i).toString(16);
			} else {
				val += str.charCodeAt(i).toString(16);
			}
		}
	}
	return val;
}

EncryptionFac.prototype.encryptPassword = function (password, rsaBits, cbFun) {
	var that = this;
	if(rsaBits) {
		var Bits = rsaBits;
	} else {
		var Bits = 1024;
	}
	var PassPhrase =  new Date() + "";
	var MattsRSAkey = cryptico.generateRSAKey(PassPhrase, Bits);
	var szPublicKeyString = cryptico.publicKeyString(MattsRSAkey);
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><PublicKey><key>" + Base64.encode(szPublicKeyString) + "</key></PublicKey>";
	var xmlDoc = parseXmlFromStr(szXml);
	$.ajax({
		type: "post",
		processData: false,
		data: xmlDoc,
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Security/challenge",
		success: function (xmlDoc, textStatus, xhr) {
			var DecryptionResult = cryptico.decrypt(Base64.decode($(xmlDoc).find("key").eq(0).text()), MattsRSAkey);
			if(DecryptionResult.plaintext != null) {
				if(Bits === 256) {
					var key = that.ToHex(DecryptionResult.plaintext);
				} else {
					var key = DecryptionResult.plaintext;
				}
				var szEncryptPassword = aes_encrypt(DecryptionResult.plaintext.substring(0, 16), key, true) + aes_encrypt(password, key, true);
				if(cbFun) {
					cbFun(Base64.encode(szEncryptPassword));
				}
			}
		}
	});
}
var Encryption = new EncryptionFac();