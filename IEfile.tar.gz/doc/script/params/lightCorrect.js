
function bound(v, min, max) {
	v = v > max ? max: v;
	v = v < min ? min: v;
	return v;
}

function log(msg){
	if (window.console && window.console.log) {
		console.log(msg);
	};
}

/**
 * 信号灯
 * @return 
 */
(function(){
	Raphael.fn.SeLightRegion = function (opts) {
		var paper = this;
		if (opts.isLightRegion) {
			var light = opts;
			light.draw();
			return light;
		};

		if (!_.every(['type', 'region', 'text', 'bkImg'], function(ele){
				var t = typeof opts[ele];
				if (t != 'undefined' && opts[ele] != null) {
					return true;
				}
				return false;
			})
		) {
			log('SeLightRegion parameter is not enough !');
			return;
		};

		var divId = 'paper';
		if (opts.divId) {
			divId = opts.divId;
		};

		var light = {
			uuid: Raphael.createUUID(),
			shapeType: opts.shapeType,
			isLightRegion: true,

			type: opts.type.toLowerCase(),
			region: opts.region,
			text: opts.text,
			color: '#ffffff',//yqw 2014.12.09,由红色改为白色

			bkImg: opts.bkImg,
			divId: divId,

			draw: function () {
				var self = this;
				var color = this.color;
				
				if (self.bkImg.mode == 'full') {
					this._drawInFullMode();
				}else{
					this._drawInDragMode();
				}
			},

			_drawInFullMode: function () {
				var self = this;
				var bkImg = this.bkImg;

				if (bkImg.mode != 'full') {
					return;
				};

				var paperWidth = bkImg.paperWidth;
				var paperHeight = bkImg.paperHeight;

				var il = this.region.left * paperWidth;
				var it = this.region.top * paperHeight;
				var ir = this.region.right * paperWidth;
				var ib = this.region.bottom * paperHeight;

				var iw = ir - il;
				var ih = ib - it;

				self._drawText((il+ir)/2, it-10);

				self._drawInner(il, it, iw, ih);
			},
			_drawText: function(x, y){
				if (!this.txt) {
					this.txt = paper.text(0,0,this.text);
					this.txt.attr({
						//'fill': color,
						'fill': '#ffff00',
						'font-size': 12
					});
				}
				this.txt.attr({
					x: x,
					y: y
				})
			},
			_drawInDragMode: function () {
				var self = this;
				var bkImg = this.bkImg;

				if (bkImg.mode == 'full') {
					return;
				};

				var offsetX = bkImg.offsetX;
				var offsetY = bkImg.offsetY;

				var bkImageWidth = bkImg.imageWidth;
				var bkImageHeight = bkImg.imageHeight;

				var il = this.region.left * bkImageWidth - offsetX;
				var it = this.region.top * bkImageHeight - offsetY;
				var ir = this.region.right * bkImageWidth - offsetX;
				var ib = this.region.bottom * bkImageHeight - offsetY;

				var iw = ir - il;
				var ih = ib - it;

				self._drawText((il+ir)/2, it-10);

				self._drawInner(il, it, iw, ih);
			},

			_drawInner: function (x, y, w, h) {
				
				var self = this;

				if (!this.rect) {
					this.rect = paper.rect(x + 1, y + 1, w - 1, h - 1);
					this.rect.attr({
						'stroke-width': 1,
						'stroke': '#ffffff',
						'fill': '#ffffff',
						'fill-opacity': 0 
					});
					this.rect.drag(function(dx, dy, mx, my) {
						if (!self.selected) {
							return;
						};

						if (self.bkImg.mode == 'full') {
							return;
						}

						var tx = dx - this.odx;
						var ty = dy - this.ody;
						
						this.ody = dy;
						this.odx = dx;

						var imageWidth = self.bkImg.imageWidth;
						var imageHeight = self.bkImg.imageHeight;

						var ftx = tx/imageWidth;
						var fty = ty/imageHeight;

						self.region.left += ftx;
						self.region.right += ftx;
						self.region.top += fty;
						self.region.bottom += fty;

						self.draw();
					},
					function(x, y) {
						this.ody = 0;
						this.odx = 0;
					},
					function() {

					}).hover(function(){
						if (self.selected 
							&& self.bkImg.mode == 'drag') {
							self.rect.attr({
								'cursor': 'move'
							});
						};
					}, function(){
						self.rect.attr({
							'cursor': 'default'
						});
					});
				}else{
					this.rect.attr({
						'x': x + 1,
						'y': y + 1,
						'width': w - 1,
						'height': h - 1
					});
				}

				this._drawCircles(x, y, w, h);

			},

			_drawCircles: function (x, y, w, h) {
				if (!this.selected 
					|| this.bkImg.mode == 'full') {
					if (this.circles) {
						_.each(this.circles, function(ele){
							ele.remove();
						});
						this.circles = false;
					};
					return;
				};

				var self = this;
				var bkImageWidth = self.bkImg.imageWidth;
				var bkImageHeight = self.bkImg.imageHeight;

				if (!this.circles) {
					this.circles = [];
					var leftTopCC = paper.circle(x, 
							y, 3).attr({
								'fill': self.color,
								'stroke-width': 0,
								'cursor': 'nw-resize'
							});
					leftTopCC.drag(function(dx, dy, mx, my){
						if (self.bkImg.mode == 'full') {
							return;
						};
						var tx = dx - this.odx;
						var ty = dy - this.ody;		

						var left = self.region.left	* bkImageWidth;
						var right = self.region.right * bkImageWidth;
						var top = self.region.top * bkImageHeight;
						var bottom = self.region.bottom * bkImageHeight;

						if (tx >= right-left) {
							tx = right-left-1;
						};		
						if (ty >= bottom-top) {
							ty = bottom-top-1;
						};		

						var rleft = left + tx;
						var rtop = top + ty;

						self.region.left = rleft/bkImageWidth;
						self.region.top = rtop/bkImageHeight;

						this.odx = tx+this.odx;
						this.ody = ty+this.ody;

						self.draw();
					}, function(x,y){
						this.odx = 0;
						this.ody = 0;
					}, function(evt){
					
					});

					this.circles[0] = leftTopCC;

					var color = self.color;
					var rightTopCC = paper.circle(x+w, 
							y, 3).attr({
								'fill': color,
								'stroke-width': 0,
								'cursor': 'ne-resize'
							});
					rightTopCC.drag(function(dx, dy, mx, my){
						var tx = dx - this.odx;
						var ty = dy - this.ody;			

						var left = self.region.left	* bkImageWidth;
						var right = self.region.right * bkImageWidth;
						var top = self.region.top * bkImageHeight;
						var bottom = self.region.bottom * bkImageHeight;

						if (-tx >= right-left) {
							tx = left-right+1;
						};		
						if (ty >= bottom-top) {
							ty = bottom-top-1;
						};		

						var rtop = top + ty;
						var rright = right + tx;
						
						self.region.right = rright/bkImageWidth;
						self.region.top = rtop/bkImageHeight;

						this.odx = tx+this.odx;
						this.ody = ty+this.ody;

						self.draw();
					}, function(x,y){
						this.odx = 0;
						this.ody = 0;
					}, function(evt){
					
					});
					this.circles[1] = rightTopCC;

					var rightBottomCC = paper.circle(x+w, 
							y+h, 3).attr({
								'fill': color,
								'stroke-width': 0,
								'cursor': 'nw-resize'
							});
					rightBottomCC.drag(function(dx, dy, mx, my){
						var tx = dx - this.odx;
						var ty = dy - this.ody;			

						var left = self.region.left	* bkImageWidth;
						var right = self.region.right * bkImageWidth;
						var top = self.region.top * bkImageHeight;
						var bottom = self.region.bottom * bkImageHeight;

						if (-tx >= right-left) {
							tx = left-right+1;
						};		
						if (-ty >= bottom-top) {
							ty = top-bottom+1;
						};		

						var rright = right + tx;
						var rbottom = bottom + ty;

						self.region.right = rright/bkImageWidth;
						self.region.bottom = rbottom/bkImageHeight;
						
						this.odx = tx+this.odx;
						this.ody = ty+this.ody;

						self.draw();
					}, function(x,y){
						this.odx = 0;
						this.ody = 0;
					}, function(evt){
					
					});
					this.circles[2] = rightBottomCC;

					var leftBottomCC = paper.circle(x, 
							y+h, 3).attr({
								'fill': color,
								'stroke-width': 0,
								'cursor': 'ne-resize'
							});
					leftBottomCC.drag(function(dx, dy, mx, my){
						var tx = dx - this.odx;
						var ty = dy - this.ody;			

						var left = self.region.left	* bkImageWidth;
						var right = self.region.right * bkImageWidth;
						var top = self.region.top * bkImageHeight;
						var bottom = self.region.bottom * bkImageHeight;

						if (tx >= right-left) {
							tx = right-left-1;
						};		
						if (-ty >= bottom-top) {
							ty = top-bottom+1;
						};		
						var rleft = left + tx;
						var rbottom = bottom + ty;

						self.region.left = rleft/bkImageWidth;
						self.region.bottom = rbottom/bkImageHeight;
						
						this.odx = tx+this.odx;
						this.ody = ty+this.ody;

						self.draw();
					}, function(x,y){
						this.odx = 0;
						this.ody = 0;
					}, function(evt){
					
					});

					this.circles[3] = leftBottomCC;
				}else{
					var left = x, right = x+w, top=y, bottom=y+h;
					this.circles[0].attr({
						cx: left,
						cy: top
					});
					this.circles[1].attr({
						cx: right,
						cy: top
					});
					this.circles[2].attr({
						cx: right,
						cy: bottom
					});
					this.circles[3].attr({
						cx: left,
						cy: bottom
					});
				}
			},
			remove: function () {
				if (this.circles) {
					_.each(this.circles, function(ele){
						ele.remove();
					});
					delete this.circles;	
				};

				if (this.txt) {
					this.txt.remove();
					this.txt = false;
				};
				
				if (this.rect) {
					this.rect.remove();
					this.rect = false;
				};
				
			},
			select: function  () {
				this.selected = true;
				this.draw();
			}, 
			unselect: function () {
				this.selected = false;
				this.draw();
			}
		}

		return light;
	}


	/****************************************************************/
	
})();

/*
	绘图
 */
(function(){
	Raphael.fn.SeVD2 = function(opts){
		var paper = this;
		if (opts.isVD) {
			var light = opts;
			light.draw();
			return light;
		}

		var params = [
			'src'  		// 图片路径
			,'mode'			// 背景模式
		];
		if (!_.every(params, function(ele){
			var t = typeof opts[ele];
			if (t != 'undefined' && opts[ele] != null) {
				return true;
			}
			return false;
		})) {
			log('SeVD2 parameter is not enough !!!');
			return;
		};

		var divId = 'paper';
		if (opts.divId) {
			divId = opts.divId;
		};

		return {
			isVD: true,
			type: 'vd',

			divId: divId,

			Lights:{},
			img: null,
			mode: opts.mode,
			src: opts.src,

			offsetX: opts.offsetX ? opts.offsetX : 0,
			offsetY: opts.offsetY ? opts.offsetY : 0,
			loadComplete: opts.loadComplete ? opts.loadComplete : function(){},


			draw: function(){
				var paperWidth = paper.width;
				var paperHeight = paper.height;

				this.paperWidth = paperWidth;
				this.paperHeight = paperHeight;

				var self = this;

				this._loadImage(function(imgObj){					
					var fullWidth = imgObj.width;
					var fullHeight = imgObj.height;

					self.imageWidth = fullWidth;
					self.imageHeight = fullHeight;

					self._drawBkImage();
					self.drawLights();
				})

			},

			_initImgEvt: function(){
				var img = this.img;
				var self = this;

				var fullWidth = this.imageWidth;
				var fullHeight = this.imageHeight;

				var maxWidth = this.paperWidth;
				var maxHeight = this.paperHeight;

				img.toBack().drag(function(dx, dy, mx, my) {
					if (self.mode =='full') {
						return;
					};
					var tx = dx - this.odx;
					var ty = dy - this.ody;
					
					if (tx>self.offsetX) {
						tx = self.offsetX;
					}else if(fullWidth - self.offsetX - maxWidth + tx < 0){
						tx = maxWidth + self.offsetX - fullWidth;
					}
					if (ty > self.offsetY) {
						ty = self.offsetY;
					}else if(fullHeight - self.offsetY - maxHeight + ty < 0){
						ty = maxHeight + self.offsetY - fullHeight;
					}

					self.offsetX -= tx;
					self.offsetY -= ty;

					//log('tx='+tx+', ty='+ty+', offsetX='+
					//	self.offsetX+', offsetY='+self.offsetY);

					this.odx = tx + this.odx;
					this.ody = ty + this.ody;
					
					self._dragBkImage(tx, ty);

					self.draw();
				}, function(x, y) {
					if (self.mode == 'full') {
						return;
					};
					this.ody = 0;
					this.odx = 0;
				}, function() {

				}).mousemove(function(evt){
					if (!self.readyToDrag) {
						return;
					}

					var pos = getPos(evt, '#'+self.divId);

					var rw = self.paperWidth*self.paperWidth/self.imageWidth;
					var rh = self.paperHeight*self.paperHeight/self.imageHeight;

					var rx = pos.x - rw/2;
					var ry = pos.y - rh/2;


					if (!self.zoomRange) {
						self.zoomRange = paper.rect(rx, ry, rw, rh);
						self.zoomRange.attr({
							'stroke': '#ffffff',
							'stroke-width': 1,
							'stroke-dasharray': "."
						});
					}else{
						self.zoomRange.attr({
							x: rx,
							y: ry,
							width: rw,
							height: rh
						});
					}					
				}).click(function(evt){
					var pos = getPos(evt, '#'+self.divId);
					var rx = pos.x;
					var ry = pos.y;

					if (self.readyToDrag) {
						var rw = self.paperWidth*self.paperWidth/self.imageWidth;
						var rh = self.paperHeight*self.paperHeight/self.imageHeight;

						self.offsetX = (rx-rw/2)/self.paperWidth*self.imageWidth;
						self.offsetY = (ry-rh/2)/self.paperHeight*self.imageHeight;

						if (self.zoomRange) {
							self.zoomRange.remove();
							delete self.zoomRange;
						};

						self.mode = 'drag';
						self.readyToDrag = false;

						if (self.changeToDragModeCallback) {
							self.changeToDragModeCallback();
						};

						self.draw();
					}
					
				});
			},

			_loadImage: function(callback){
				var imgObj = this.imgObj;

				var self = this;

				if (!this.imgLoaded || !imgObj) {
					this.imgLoaded = false;
				};

				if (!this.imgLoaded) {
					imgObj = new Image();					

					if (imgObj.loadComplete) {
						//callback(imgObj);
						//self.loadComplete(true);	
					};

					imgObj.onload = function(){
						callback(imgObj);
						self.loadComplete(true);	
						self.imgLoaded = true;		
						self.imgObj = imgObj;	
						
					};

					imgObj.onerror = function(){
						self.loadComplete(false);
						self.imgLoaded = false;		
					}

					imgObj.src = this.src;
				}else{
					callback(imgObj);
				}
			},

			_drawBkImage: function(){
				var self = this;
				
				var fullWidth = this.imageWidth;
				var fullHeight = this.imageHeight;

				var maxWidth = this.paperWidth;
				var maxHeight = this.paperHeight;

				if (self.mode == 'full') {
					if (!self.img) {
						self.img = paper.image(self.src, 0, 0, self.paperWidth, self.paperHeight);
						self._initImgEvt();
					}else{
						self.img.attr({
							x:0,
							y:0,
							width: self.paperWidth,
							height: self.paperHeight
						});
					}

					self.imageScaleW = self.paperWidth/fullWidth;
					self.imageScaleH = self.paperHeight/fullHeight;		
				}else {
					var offsetX = self.offsetX;
					var offsetY = self.offsetY;

					//log("offsetY="+offsetY)

					if (!self.img) {
						self.img = paper.image(self.src, -offsetX, 
							-offsetY, fullWidth, fullHeight);
						// self.img.attr({
						// 	'cursor': 'pointer'
						// });
						self._initImgEvt();
					}else{
						self.img.attr({
							x: -offsetX,
							y: -offsetY,
							width: fullWidth,
							height: fullHeight
						});
					}
				};

			},

			_dragBkImage: function(dx, dy){

			},

			reset: function(){

			},

			changeMode: function(tMode, callback){
				if (this.mode == tMode) {
					return;
				}
				if (tMode == 'full') {
					this.mode = 'full';
					this.draw();
				}

				if (tMode == 'drag') {
					if (callback) {
						this.changeToDragModeCallback = callback;
					}else{
						this.changeToDragModeCallback = null;
					}
					this.readyToDrag = true;
				}
			},

			remove: function(){
				if (this.img) {
					this.img.remove();
					this.img = null;
				};
			},

			//新增信号灯
			//lightIdx:1,
				// region: {
				// 	left:,   // 0.xxx
				// 	right:
				// 	top:
				// 	bottom:
				// }，
				// isVertical: false,
				// lightCount: 3,
				// directionCount: 1
			addLights: function(arr){
				var self = this;
				_.each(arr, function (ele) {
					var lightIdx = ele.lightIdx;
					if (self.Lights[lightIdx]) {
						self.Lights[lightIdx].remove();
					}
					var light =  paper.SeLightRegion({
						type: 'light',
						region: ele.region,
						text: '区域'+ele.lightIdx,
						bkImg: self
					});
					self.Lights[lightIdx] = light;
				});
			},

			selectLight: function(idx){
				this.unselectLights();
				if (this.Lights[idx]) {
					this.Lights[idx].select();
				};
			},

			unselectLights: function(){
				_.each(this.Lights, function (v, k) {
					if (v && v.unselect) {
						v.unselect();
					};
				});
			},

			removeLight: function(idx){
				var l = this.Lights[idx];
				if (l && l.remove) {
					l.remove();
				};
				this.Lights[idx] = undefined;
			},

			changeLight:function (idx, info){
				
			},

			drawLight: function(idx){
				var light = this.Lights[idx];
				if (light) {
					light.draw();
				};
			},
			drawLights: function () {
				_.each(this.Lights, function (v, k) {
					if (v && v.draw) {
						v.draw();
					};
				});
			}
		}

	}
})();


var lastSelIdx = -1;
(function (window) {
	var LightCorrect = {};
	var paper;
	var vd;


	var lightsArrayTemp = {};


	function initPage(){
		if (!lightsArrayTemp) {
			return;
		};

		// $('#lightIdx').find('option').remove();
		// $xml.find('videoDetectLight').each(function (i, n) {
		// 	var $light = $(n);
		// 	var lightId = $light.find('videoDetectLightId').eq(0).text();

		// 	$('#lightIdx').append('<option value="'+lightId+'">区域'+' '+lightId+'</option>');	
		// });		

		$('#addLightBtn').prop('disabled', true).addClass('btnDisabled');
	}

	function initLights(){
		var lightArr = [];

		$.each(lightsArrayTemp, function (i, n) {
			var $light = n;

			var lightId = n.idx;

			var left =$light.left;			
			var top = $light.top;
			var right = $light.right;
			var bottom = $light.bottom;

			if (_.every([left, right, top, bottom], function(ele){
				return ele == 0;
			})) {

			}else{
				var vd = LightCorrect.vd;
				var imgWidth = vd.imageWidth;
				var imgHeight = vd.imageHeight;

				var lt = {
					lightIdx:lightId,
					region: {
						left: left,
						right: right,
						top: top,
						bottom: bottom
					}
				};

				lightArr.push(lt);
			}			
		});	

		LightCorrect.vd.addLights(lightArr);	
	}

	
	function initEvt(){
		$('#lightIdx').unbind().change(function(){
			if (lastSelIdx>0) {
				storeLastLight(lastSelIdx);
			};
			var v = $(this).val();
			dispLight(v);
		});
	}

	/**
	 * 显示一个灯的信息
	 * @param  {[type]} idx [description]
	 * @return {[type]}     [description]
	 */
	function dispLight(idx){
		var found = false;

		// _log('dispLight  '+idx);
		$.each(lightsArrayTemp, function (i, n) {
			var $light = n;
			var lightId = n.idx;
			if (lightId == idx) {
				LightCorrect.vd.selectLight(idx);

				// 2015.7.18 yqw
				if($light.bDigLight){
					$("#bDigLight").prop("checked",$light.bDigLight=="true"?true:false);
				}
				if($light.yellowDelLight){
					$("#yellowDelLight").val($light.yellowDelLight);
				}
				

				lastSelIdx = lightId;
				found = true;

				// _log('dispLight  found  lastSelIdx='+lastSelIdx);
				return;
			}
		});		

		if (!found) {
			lastSelIdx = -1;
		};
	}

	function storeLastLight(lastIdx){
		// _log("storeLastLight lastIdx="+lastIdx);
		$.each(lightsArrayTemp, function (i, n) {
			var $light = n;
			var lightId = n.idx;
			if (lightId == lastIdx) {
				
				// _log("storeLast found lastIdx="+lastIdx);
				var vd = LightCorrect.vd;
				var light = vd.Lights[lightId];
				if (light) {
					var imgWidth = vd.imageWidth;
					var imgHeight = vd.imageHeight;
					
					$light.left = (light.region.left);
					$light.right = (light.region.right);
					$light.top = (light.region.top);
					$light.bottom = (light.region.bottom);

					// 2015.7.18 yqw
					$light.bDigLight=($("#bDigLight").prop("checked").toString());
					$light.yellowDelLight=($("#yellowDelLight").val()==""?"0":$("#yellowDelLight").val());
				}
				return;
			};
		});
	}

	LightCorrect.init = function (arr,lightCorrentVersion) {
		lightsArrayTemp = [];

		for (var i = 0; i < arr.length; i++) {
			var lt = arr[i];
			var left = parseInt(lt.lightCorrentAreaXStart);
			var top = parseInt(lt.lightCorrentAreaYStart);
			var width = parseInt(lt.lightCorrentAreaWidth);
			var height = parseInt(lt.lightCorrentAreaHeight);

			// 2015.7.18 yqw 
			var bDigLight="false";
			if(lt.bDigLight){
				bDigLight=lt.bDigLight;
			}
			var yellowDelLight="0";
			if(lt.yellowDelLight){
				yellowDelLight=lt.yellowDelLight;
			}

			if (_.every([left, top, width, height], function(ele){
				return ele == 0;
			})) {
				continue;
			}
			if("2"==lightCorrentVersion){
				lightsArrayTemp.push({
					idx: i+1,
					left: left / 10000,
					top: top / 10000,
					right: (left + width)/10000,
					bottom: (top + height)/10000,
					bDigLight:bDigLight,
					yellowDelLight:yellowDelLight
				});
			}else{
				lightsArrayTemp.push({
					idx: i+1,
					left: left / 1000,
					top: top / 1000,
					right: (left + width)/1000,
					bottom: (top + height)/1000,
					bDigLight:bDigLight,
					yellowDelLight:yellowDelLight
				});
			};
			
		};

		$('#paper').find('*').remove();

		var width = $('#paper').width();
		var height = $('#paper').height();
		paper = Raphael('paper', width, height);

		initPage();

		vd = paper.SeVD2({
			type: 'vd',
			src: m_lHttp + m_szHostName + ":" + m_lHttpPort + '/PSIA/Streaming/channels/1/picture?authInfo='+m_szUserPwdValue+"&OSDType=0&_="+(new Date().getTime()),
			mode: 'full',
			offsetX: 0,
			offsetY: 0,
			loadComplete: function(res){
				if(!res){
					alert("加载图片失败，请刷新页面后重试！");
				}else{
					initLights();
					initEvt();
					dispLight(1);
				}
			}
		});

		LightCorrect.vd = vd;
		LightCorrect.paper = paper;
		
		vd.draw();
	}

	LightCorrect.storeLast= function(){
		storeLastLight(lastSelIdx);
	}

	LightCorrect.addLights = function (arr) {
		LightCorrect.vd.addLights(arr);
		var firstIdx = -1;
		for (var i = 0; i < arr.length; i++) {
			var a = arr[i];

			firstIdx = a.lightIdx;

			lightsArrayTemp.push({
				idx: a.lightIdx,
				left: a.region.left,
				top: a.region.top,
				right: a.region.right,
				bottom: a.region.bottom
			});
		};

		if (firstIdx >= 0) {
			dispLight(firstIdx);
		};

	}

	LightCorrect.removeLight = function (lightIdx) {
		LightCorrect.vd.removeLight(lightIdx);

		var idx = -1;
		for (var i = 0; i < lightsArrayTemp.length; i++) {
			var lt = lightsArrayTemp[i];
			if (lt.idx == lightIdx) {
				idx = i;
				break;
			};
		};

		if (idx >= 0) {
			lightsArrayTemp.splice(idx, 1);	
		};
	}

	LightCorrect.getResultArray = function () {
		storeLastLight(lastSelIdx);
		return lightsArrayTemp;
	}

	LightCorrect.dispLight = dispLight;

	window.VD2 = LightCorrect;
})(window);


function showVd2Region() {
	var vd = window.VD2.vd;
	if (vd.mode == 'full') {
		vd.changeMode('drag', function () {
			$('#showVd2RegionBtn').val('取消放大');	
			$('#addLightBtn').prop('disabled', false).removeClass('btnDisabled');
		});
	}else{
		$('#showVd2RegionBtn').val("区域放大");
		vd.changeMode('full');

		$('#addLightBtn').prop('disabled', true).addClass('btnDisabled');
	}
}

function addLightRegionToCanvas(){
	if (window.VD2.vd.mode == 'full') {
		return;
	};

	var lightIdx = $('#lightIdx').val(); 

	var $light = window.VD2.vd.Lights[lightIdx];
	if ($light) {
		return;
	};


	var vd = window.VD2.vd;
	
	var centerX = (vd.offsetX*2+vd.paperWidth)/2;
	var centerY = (vd.offsetY*2+vd.paperHeight)/2;

	var iw = vd.imageWidth;
	var ih = vd.imageHeight;

	var v = {
		w: 32,
		h: 32
	};

	var left = centerX-v.w/2;
	var right = centerX+v.w/2;
	var top = centerY-v.h/2;
	var bottom = centerY+v.h/2;

	

	var light = {
		lightIdx: lightIdx,
		region: {
			left: left/iw,
			right: right/iw,
			top: top/ih,
			bottom: bottom/ih
		}
	};

	window.VD2.addLights([light]);
	vd.selectLight(lightIdx);
}


function deleteCurLightRegion () {
	var lightIdx = $('#lightIdx').val(); 
	
	window.VD2.removeLight(lightIdx);

	window.VD2.dispLight(lightIdx);
}