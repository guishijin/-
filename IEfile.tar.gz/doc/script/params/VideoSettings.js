// JavaScript Document

var VideoSettings = {
	tabs: null	// 保存VideoSettings配置页面的tabs对象引用
}
var m_PicOSDXmlDoc=null;

/*************************************************
 抓图叠加类
 *************************************************/
function SnapOverlay() {
    SingletonInheritor.implement(this);
    this.m_iPosX = 0;
    this.m_iPosY = 0;
    this.m_iSelFileIndex = -1;
    this.m_iLastSelFileIndex = -1;
    this.m_strItemType = new Array();
    this.m_strSpaceNum = new Array();
    this.m_strOverlayInfo = new Array();
    // this.m_PicOSDXmlDoc = null;
	this.m_iPicHeight = "1200";
	this.m_iPicWidth = "1600";
}
SingletonInheritor.declare(SnapOverlay);

SnapOverlay.changeOverLayWordInfo = function(){
    if($('#isUseOverLaySnapEnable').prop('checked')){
        $('#OverLayWordContentDiv').css("visibility","visible");
        $('#OverLayInfoListDiv').css("display","block");
		$('#MergeOverLayInfoListDiv').css("display","block");
    }else{
        $('#OverLayWordContentDiv').css("visibility","hidden");
        $('#OverLayInfoListDiv').css("display","none");
		$('#MergeOverLayInfoListDiv').css("display","none");
    }
    $('#dvSnapTest').css("display","block");
    $('#dvSnapTestTips').css("display","block");

    autoResizeIframe();
}
/*************************************************
 Function:		update
 Description:	更新抓图叠加配置信息
 Input:			iType:0 抓图叠加  1::合成图叠加
 Output:			无
 return:			无
 *************************************************/
pr(SnapOverlay).update = function (iType) {
	$('#SetResultTips').html('');
    $("#SaveConfigBtn").show();

    $('#videoOverLayTitleDiv').hide();
    $('#snapOverLayTitleDiv').show();

    window._g_isComposite = iType == 1;
   
    HWP.Stop(0);
    g_transStack.clear();
    var that = this;
    g_transStack.push(function () {
        that.setLxd(parent.translator.getLanguageXmlDoc(["VideoSettings", "SnapOverlay"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);

    PicOverlap_InitItems($('#picOverlayItemsDiv'), $('#SingleOverlayInfoList'));
	ia(SnapOverlay).ClearOSDOverlayInfo();

    ia(SnapOverlay).InitSnapOverlay();
    $('#OverLayWordContentDiv').css("visibility","hidden");

    if(iType == 0) {
        var szUrl = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Snapshot/channels/1/ITCPicOSD";
	} else {
		var szUrl = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Snapshot/channels/1/ITCMergePicOSD";
	}
    $.ajax({
        type: "GET",
        url: szUrl,
        async: false,
        timeout: 15000,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {
            m_PicOSDXmlDoc = xmlDoc;
             
             var ena = $(xmlDoc).find("overlayInfoEnabled").eq(0).text() === "true" ? true : false;
             $("#isUseOverLaySnapEnable").prop("checked", ena).click().prop('checked', ena);
            if(iType == 0) {
				$("#linePercent").val($(xmlDoc).find("linePercent").eq(0).text());
				$("#itemsStlye").val($(xmlDoc).find("itemsStlye").eq(0).text());
				$("#charStyle").val($(xmlDoc).find("charStyle").eq(0).text());
				$("#charSize").val($(xmlDoc).find("charSize").eq(0).text());
				$("#charInterval").val($(xmlDoc).find("charInterval").eq(0).text());
				var foreColor = parseInt($(xmlDoc).find("foreClor").eq(0).text()).toString(16);
				$("#foreClor").val("#" + padLeft(foreColor, 6));
				$("#foreClor").css("backgroundColor", $("#foreClor").val());
				var backClor = parseInt($(xmlDoc).find("backClor").eq(0).text()).toString(16);
				$("#backClor").val("#" + padLeft(backClor, 6));
				$("#backClor").css("backgroundColor", $("#backClor").val());
				$("#IscolorAdapt").prop("checked", $(xmlDoc).find("colorAdapt").eq(0).text() === "true" ? true : false);
			   
				var onBottom = $(xmlDoc).find("charPosition").eq(0).text();
				if(onBottom == "0") {
					$("#AtPhotoOutButtom").prop("checked", false);
                     $('#AtPhotoOutTop').prop('checked', false);
					$('#AtPhotoTop').prop('checked', true);
				}
                else if(onBottom == "1") {
                    $("#AtPhotoOutButtom").prop("checked", false);
                     $('#AtPhotoOutTop').prop('checked', true);
                    $('#AtPhotoTop').prop('checked', false);
                }else if(onBottom == "2") {
					$("#AtPhotoOutButtom").prop("checked", true);
                     $('#AtPhotoOutTop').prop('checked', false);
					$('#AtPhotoTop').prop('checked', false);
				}
				
				//叠加补零和车牌小图
				$("#IszeroizeEnable").prop("checked",$(xmlDoc).find("zeroizeEnable").eq(0).text() === "true" ? true : false);
				$("#IsplatePicOverlayEnable").prop("checked",$(xmlDoc).find("platePicOverlay").eq(0).text() === "true" ? true : false);
				ia(SnapOverlay).m_iPosX = $(xmlDoc).find("platePicPosLeft").eq(0).text()*704/ia(SnapOverlay).m_iPicWidth;
				ia(SnapOverlay).m_iPosY = $(xmlDoc).find("platePicPosTop").eq(0).text()*576/ia(SnapOverlay).m_iPicHeight;
			} else {
				$("#mergelinePercent").val($(xmlDoc).find("linePercent").eq(0).text());
				$("#mergecharSize").val($(xmlDoc).find("charSize").eq(0).text());
				var foreColor = parseInt($(xmlDoc).find("foreClor").eq(0).text()).toString(16);
				$("#mergeforeClor").val("#" + padLeft(foreColor, 6));
				$("#mergeforeClor").css("backgroundColor", $("#mergeforeClor").val());
				var backClor = parseInt($(xmlDoc).find("backClor").eq(0).text()).toString(16);
				$("#mergebackClor").val("#" + padLeft(backClor, 6));
				$("#mergebackClor").css("backgroundColor", $("#mergebackClor").val());
				var onBottom = $(xmlDoc).find("charPosition").eq(0).text();
				if(onBottom == "1") {
				    $("#MergeAtPhotoTop").prop("checked", true);
					$('#MergeAtPhotoOutButtom').prop('checked', false);
				} else {
				    $('#MergeAtPhotoOutButtom').prop('checked', true);
					$("#MergeAtPhotoTop").prop("checked", false);
				}
			}

            PicOverlap_Clear($('#picOverlayItemsDiv'),$('#SingleOverlayInfoList'));

            var $container = $('#picOverlayItemsDiv');
            $(xmlDoc).find('overlayInfo').each(function (i, n) {
                var $n = $(n);
                var itemType = $n.find('itemType').text();
                var spaceNum = $n.find('spaceNum').text();
                var changeLineNum = $n.find('changeLineNum').text();
                var overlayInfoText = $n.find('overlayInfoText').text();
                var overlayInfoText2 = $n.find('overlayInfoText2').text();
				var startPosEnable = $n.find('startPosEnable').text() == "true"?true:false;
				var startPosTop = $n.find('startPosTop').text()*576/ia(SnapOverlay).m_iPicHeight;
				if(startPosTop == "") {
					startPosTop = 0;
				}
				var startPosLeft = $n.find('startPosLeft').text()*704/ia(SnapOverlay).m_iPicWidth;
				if(startPosLeft == "") {
					startPosLeft = 0;
				}

                var useMs = false;
                if (itemType == '9') {
                    itemType = '8';
                    useMs = true;
                };
                if (itemType == '37') {
                    itemType = '21';
                    useMs = true;
                };
                if (itemType == '38') {
                    itemType = '22';
                    useMs = true;
                };
                if (itemType == '39') {
                    itemType = '23';
                    useMs = true;
                };
				var useMD5 = $(xmlDoc).find("MD5Enable").eq(0).text() == "true"?true:false;
                var item = GetPicOverlapItem(itemType);
                if (item) {
                    $container.find('#picOverlapType_'+itemType).prop('checked', true);

                    //yqw 解决全选取消后，再次勾选叠加字符，后缀叠加信息为空现象
                    item.overlayInfoText=overlayInfoText;
                    item.overlayInfoText2=overlayInfoText2;
                    //end

                    PicOverlap_SelectedItems.push({
                        itemType: itemType,
                        itemName: item.itemName,
                        useMs: useMs,
						useMD5: useMD5,
                        editable: item.editable,
                        changeLineNum: changeLineNum,
                        spaceNum: spaceNum,
                        overlayInfoText: overlayInfoText,
                        overlayInfoText2: overlayInfoText2,
                        startPosEnable: startPosEnable,
						startPosTop: startPosTop,
						startPosLeft: startPosLeft,
                        maxlength: item.maxlength,
                        maxlength1: item.maxlength1,
                        maxlength2: item.maxlength2
                    });    
                };
            });

            var allChecked = true;
            $container.find('input.picOverlapItemChkbox').each(function () {
                if (!$(this).prop('checked')) {
                    allChecked = false;
                    return;
                }
            });
            if (allChecked) {
                $('#selectAllPicItems').prop('checked', true);
            }else{
                $('#selectAllPicItems').prop('checked', false);
            }

            PicOverlap_RenderAll($('#SingleOverlayInfoList'));
            SnapOverlay.changeOverLayWordInfo();
        }
    });
	
    ia(SnapOverlay).InitEditEvent();
	if(iType == 1) {
		ia(SnapOverlay).ClearOSDOverlayInfo();
	}
    if(iType==0){
        ia(SnapOverlay).setCharPositionTop();
        ia(SnapOverlay).setPlatePicPos();
    }
    
    autoResizeIframe();
}
/************************************************
 Function:		InsertSingleInfoList
 Description:	插入单条字符信息
 Input:
 Output:			无
 return:			无
 ************************************************/
pr(SnapOverlay).InsertSingleInfoList = function (strNo, strType, strSpaceNum, strOverlayInfo) {
    var ObjTr;
    var ObjTd;
    ObjTr = document.getElementById("SingleOverlayInfoList").insertRow(document.getElementById("SingleOverlayInfoList").rows.length);
    ObjTr.style.height = 22 + 'px';
    ObjTr.style.cursor = "pointer";
	var iLength = document.getElementById("SingleOverlayInfoList").rows[0].cells.length;
    for(j = 0;j < iLength;j++){
        ObjTd = ObjTr.insertCell(j);
        $(ObjTd).css({border:"1px solid #d7d7d7",background:"#ffffff",padding:"0 0 0 5px"});
		 ObjTd.style.color = "#39414A";
        switch(j)
        {
            case 0:
                ObjTd.innerHTML = strNo;
                ObjTd.id = "itemtdA"+ strNo;
                break;
            case 1:
                ObjTd.innerHTML = strType;
                ObjTd.id = "itemtdB"+ strNo;
                break;
            case 2:
                ObjTd.innerHTML = strSpaceNum;
                ObjTd.id = "itemtdC"+ strNo;
                break;
            case 3:
                ObjTd.innerHTML = strOverlayInfo;
                ObjTd.id = "itemtdD"+ strNo;
                break;
            default:
                break;
        }
    }
}
/************************************************
 Function:		InitEditEvent
 Description:	绑定事件
 Input:			无
 Output:			无
 return:			无
 ************************************************/
pr(SnapOverlay).InitEditEvent = function() {
    var that = this;
    $("#SingleOverlayInfoList").find("td").each(function(i) {
        var iRow = parseInt(i/4,10);
        var j = i%4;
        if(iRow != 0) {
            switch(j) {
                case 1:
                    $(this).bind({
                        click:function(event){
                            if(that.m_iLastSelFileIndex != -1 && $("#itemTypeSel").css("display") != "none") {
                                $("#itemtdB" + (parseInt(that.m_iLastSelFileIndex) + 1)).html(getNodeValue("itemTypeOpt" + $("#itemType").val()));
                                that.m_strItemType[that.m_iLastSelFileIndex] = $("#itemType").val();
                                $("#itemTypeSel").hide();
                            }
                            that.m_iLastSelFileIndex = that.m_iSelFileIndex;
                            ia(SnapOverlay).SelectSingleInfoRow(event);
                            $("#itemTypeSel").show();
                            $("#itemTypeSel").css({"left":$(this).offset().left+"px", "top":$(this).offset().top+"px",width:$(this).width()+"px",height:$(this).height()+"px"});
                            $("#itemType").val(that.m_strItemType[that.m_iSelFileIndex]);
                        }
                    });
                    break;
                case 2:
                    $(this).addClass("width100");
                    $(this).bind( {
                        click:function(){
                            if($("#itemTypeSel").css("display") != "none") {
                                if(that.m_iLastSelFileIndex != -1 && that.m_iLastSelFileIndex != that.m_iSelFileIndex) {   //从其他行切换到当前行的空格处
                                    $("#itemtdB" + (parseInt(that.m_iLastSelFileIndex) + 1)).html(getNodeValue("itemTypeOpt" + $("#itemType").val()));
                                    that.m_strItemType[that.m_iLastSelFileIndex] = $("#itemType").val();
                                    $("#itemTypeSel").hide();
                                    that.m_iLastSelFileIndex = that.m_iSelFileIndex;
                                } else if(that.m_iSelFileIndex != -1) {       //从当前行的类型切换到当前行
                                    $("#itemtdB" + (parseInt(that.m_iSelFileIndex) + 1)).html(getNodeValue("itemTypeOpt" + $("#itemType").val()));
                                    that.m_strItemType[that.m_iSelFileIndex] = $("#itemType").val();
                                    $("#itemTypeSel").hide();
                                }
                            }

                            $("#editText").show();
                            $("#editText").css({"left":$(this).offset().left+"px", "top":$(this).offset().top+"px",width:$(this).width()+"px",height:$(this).height()+"px"});
                            $("#inputText").css({width:$(this).width()-4+"px",height:$(this).height()+"px","padding-left":"5px"});
                            $("#inputText").focus();
                            $("#inputText").val($(this).html().replace(/&amp;/g, '&'));
                            var self = this;
                            $("#inputText").unbind().bind({
                                blur:function(){
                                    $(self).html(this.value.replace(/\&/g, '&amp;')).attr("title", this.value);
                                    $("#editText").hide();
                                },
                                keydown:function(event){
                                    if(13 == event.keyCode){
                                        $(this).blur();
                                    }
                                }
                            });
                        }
                    });
                    break;
                case 3:
                    $(this).bind( {
                        click:function() {
                            if($("#itemTypeSel").css("display") != "none") {
                                if(that.m_iLastSelFileIndex != -1 && that.m_iLastSelFileIndex != that.m_iSelFileIndex) {   //从其他行切换到当前行的空格处
                                    $("#itemtdB" + (parseInt(that.m_iLastSelFileIndex) + 1)).html(getNodeValue("itemTypeOpt" + $("#itemType").val()));
                                    that.m_strItemType[that.m_iLastSelFileIndex] = $("#itemType").val();
                                    $("#itemTypeSel").hide();
                                    that.m_iLastSelFileIndex = that.m_iSelFileIndex;
                                } else if(that.m_iSelFileIndex != -1) {       //从当前行的类型切换到当前行
                                    $("#itemtdB" + (parseInt(that.m_iSelFileIndex) + 1)).html(getNodeValue("itemTypeOpt" + $("#itemType").val()));
                                    that.m_strItemType[that.m_iSelFileIndex] = $("#itemType").val();
                                    $("#itemTypeSel").hide();
                                }
                            }
                            if(that.m_strItemType[iRow - 1] == 1 ||  that.m_strItemType[iRow - 1] == 2 || that.m_strItemType[iRow - 1] == 3 ||  that.m_strItemType[iRow - 1] == 4 || that.m_strItemType[iRow - 1] == 5 ||  that.m_strItemType[iRow - 1] == 7 || that.m_strItemType[iRow - 1] == 18) {//叠加类型为地点、路口等需配叠加信息
                                $("#editText").show();
                                $("#editText").css({"left":$(this).offset().left+"px", "top":$(this).offset().top+"px",width:$(this).width()+"px",height:$(this).height()+"px"});
                                $("#inputText").css({width:$(this).width()-4+"px",height:$(this).height()+"px","padding-left":"5px"});
                                $("#inputText").focus();
                                $("#inputText").val($(this).html().replace(/&amp;/g, '&'));
                                var self = this;
                                $("#inputText").unbind().bind( {
                                    blur:function(){
                                        $(self).html(this.value.replace(/\&/g, '&amp;')).attr("title", this.value);
                                        $("#editText").hide();
                                        autoResizeIframe();
                                    },
                                    keydown:function(event) {
                                        if(13 == event.keyCode){
                                            $(this).blur();
                                        }
                                    }
                                });
                            }
                        }
                    });
                    break;
                default:
                    break;
            }
        }
    });
}
//0 叠加在图片上  1 叠加在图片上边缘 2 叠加在图片下边缘
pr(SnapOverlay).setCharPositionTop = function(iNo){
    if($('#AtPhotoOutTop').prop('checked')||$('#AtPhotoOutButtom').prop('checked')){
        var strOSDTextInfo = HWP.GetTextOverlay();
	    var XmlTempDoc = parseXmlFromStr(strOSDTextInfo);
		for(var i = 0; i < $(XmlTempDoc).find("TextOverlay").length; i++) {
		    if($(XmlTempDoc).find("TextOverlay").eq(i).find("id").text() != "1000")
			$(XmlTempDoc).find("TextOverlay").eq(i).find("enabled").text("false");
	    }
	    HWP.SetTextOverlay(xmlToStr(XmlTempDoc));
    }else{
        ia(SnapOverlay).createSnapOSDTextInfo();
    }
}
//使能车牌小图叠加 0 网页选中叠加 1 脚本指定叠加位置
pr(SnapOverlay).setPlatePicPos = function(iType) {
	var strOSDTextInfo = HWP.GetTextOverlay();
	var XmlTempDoc = parseXmlFromStr(strOSDTextInfo);
	if($('#IsplatePicOverlayEnable').prop('checked')){
		for(var i = 0; i < $(XmlTempDoc).find("TextOverlay").length; i++){
			if($(XmlTempDoc).find("TextOverlay").eq(i).find("id").text() == "1000") { //id为1000认为是车牌小图OSD的位置
			    $(XmlTempDoc).find("TextOverlay").eq(i).find("enabled").text("true");
				break;
			}
		}
	} else {
		for(var i = 0; i < $(XmlTempDoc).find("TextOverlay").length; i++){
			if($(XmlTempDoc).find("TextOverlay").eq(i).find("id").text() == "1000") { //id为1000认为是车牌小图OSD的位置
			    $(XmlTempDoc).find("TextOverlay").eq(i).find("enabled").text("false");
				break;
			}
		}
	}
	HWP.SetTextOverlay(xmlToStr(XmlTempDoc));
}
/************************************************
 Function:		SelectSingleInfoRow
 Description:	选中某行单条字符信息
 Input:			无
 Output:			无
 return:			无
 ************************************************/
pr(SnapOverlay).SelectSingleInfoRow = function (event) {
    event = event?event:(window.event?window.event:null);
    var ObjTable = event.srcElement?event.srcElement:event.target;
    if(ObjTable.tagName == "TD"){
        while(ObjTable.tagName != "TR"){
            ObjTable = ObjTable.parentNode;
        }
        ObjParent = ObjTable.parentNode;
        var iSelFileIndex = ObjTable.rowIndex - 1;
        if(iSelFileIndex == -1){
            return;
        }
        while(ObjParent.tagName!="TABLE"){
            ObjParent = ObjParent.parentNode;
            if(this.m_iSelFileIndex >=  0){
                $("#itemtdA" + (this.m_iSelFileIndex + 1)).css({ color: "#39414A", background: "#ffffff" });
                $("#itemtdB" + (this.m_iSelFileIndex + 1)).css({ color: "#39414A", background: "#ffffff" });
                $("#itemtdC" + (this.m_iSelFileIndex + 1)).css({ color: "#39414A", background: "#ffffff" });
                $("#itemtdD" + (this.m_iSelFileIndex + 1)).css({ color: "#39414A", background: "#ffffff" });
            }

            for(var i = 1;i < ObjParent.rows.length;i ++){
                if(ObjTable.rowIndex == i){
                    $("#itemtdA" + i).css({ color: "#ffffff", background: "#316ac5" });
                    $("#itemtdB" + i).css({ color: "#ffffff", background: "#316ac5" });
                    $("#itemtdC" + i).css({ color: "#ffffff", background: "#316ac5" });
                    $("#itemtdD" + i).css({ color: "#ffffff", background: "#316ac5" });

                    this.m_iSelFileIndex = i - 1;
                    $("#DelSingleInfoBtn").prop("disabled", false);  //选择用户后删除按钮可用
                }
            }
        }
    }
}
/************************************************
 Function:		DelSingleInfo
 Description:	删除某行单条字符信息
 Input:			无
 Output:			无
 return:			无
 ************************************************/
pr(SnapOverlay).DelSingleInfo = function() {
    if(this.m_iSelFileIndex == -1){
        return;
    }
    if($("#itemTypeSel").css("display") != "none") {
        $("#itemtdB" + (parseInt(this.m_iSelFileIndex) + 1)).html(getNodeValue("itemTypeOpt" + $("#itemType").val()));
        this.m_strItemType[this.m_iSelFileIndex] = $("#itemType").val();
        $("#itemTypeSel").hide();
    }
    var iSingleInfoNum = document.getElementById("SingleOverlayInfoList").rows.length - 1;
    for(var i = 0; i < iSingleInfoNum; i++) {
        this.m_strSpaceNum[i] = $("#itemtdC" + (i+1)).html();
        this.m_strOverlayInfo[i] = $("#itemtdD" + (i+1)).html();
    }
    for(var i = this.m_iSelFileIndex; i < iSingleInfoNum; i ++){
        this.m_strSpaceNum[i] = this.m_strSpaceNum[i + 1];
        this.m_strOverlayInfo[i] = this.m_strOverlayInfo[i + 1];
        this.m_strItemType[i] = this.m_strItemType[i+1];
    }
    for(var i = 1; i <= iSingleInfoNum; i++){
        document.getElementById("SingleOverlayInfoList").deleteRow(1);
    }
    iSingleInfoNum --;
    for(var i = 1; i <= iSingleInfoNum; i++) {
        ia(SnapOverlay).InsertSingleInfoList(i, getNodeValue("itemTypeOpt" + this.m_strItemType[i-1]), this.m_strSpaceNum[i-1], this.m_strOverlayInfo[i-1]);
    }
    ia(SnapOverlay).InitEditEvent();
    autoResizeIframe();
    $("#DelSingleInfoBtn").prop("disabled", true);  //删除后删除按钮不可用
}
/************************************************
 Function:		tC
 Description:	转换颜色值
 Input:			无
 Output:			无
 return:			无
 ************************************************/
function tC(c){
    if(!c){
        return '';
    }
    c = c.replace('#', '');
    var cc = c;
    if(c.length == 3){
        cc = c.charAt(0)+c.charAt(0)+c.charAt(1)+c.charAt(1)+c.charAt(2)+c.charAt(2);
    }
    return cc;
}
function padLeft(str,length){
    if(str.length >= length) {
        return str;
	} else {
        return padLeft("0" +str,length);
	}
}

/************************************************
 Function:		setPicRegionToPlugin
 Description:	设置图片叠加区域
 Input:			无
 Output:			无
 return:			无
 ************************************************/
function setPicRegionToPlugin(iX, iY)
{
    iX= iX*704/1000;
    iY= iY*((m_iVideoOutNP=='PAL'?576:480))/1000;

    var szXml = "<?xml version='1.0' encoding='utf-8' ?><DetectionRegionInfo><videoFormat>"+m_iVideoOutNP+"</videoFormat><RegionType>roi</RegionType><ROI><HorizontalResolution>704</HorizontalResolution><VerticalResolution>"+(m_iVideoOutNP=='PAL'?576:480)+"</VerticalResolution></ROI><DisplayMode>transparent</DisplayMode><MaxRegionNum>1</MaxRegionNum><DetectionRegionList><DetectionRegion><RegionCoordinatesList><RegionCoordinates><positionX>"+iX+"</positionX><positionY>"+((m_iVideoOutNP=='PAL'?576:480) - (iY + 30))+"</positionY></RegionCoordinates><RegionCoordinates><positionX>"+(iX + 100)+"</positionX><positionY>"+((m_iVideoOutNP=='PAL'?576:480) - (iY + 30))+"</positionY></RegionCoordinates><RegionCoordinates><positionX>"+(iX + 100)+"</positionX><positionY>"+((m_iVideoOutNP=='PAL'?576:480) - iY)+"</positionY></RegionCoordinates><RegionCoordinates><positionX>"+iX+"</positionX><positionY>"+((m_iVideoOutNP=='PAL'?576:480) - iY)+"</positionY></RegionCoordinates></RegionCoordinatesList></DetectionRegion></DetectionRegionList></DetectionRegionInfo>";

    HWP.SetRegionInfo(szXml);
}
/*************************************************
 Function:		submit
 Description:	设置抓图叠加配置信息
 Input:			iType 0: 抓图叠加  1:合成图叠加
 Output:			无
 return:			无
 *************************************************/
 pr(SnapOverlay).submit=function(iType){
    setITCPicOSDType(iType);
 }

function submitPicOSD (iType) {
    var infos = GetOverlayInfos();

    var msgObj = ValidateInfos();
    if (msgObj.msg.length > 0) {
        $("#SetResultTips").html(m_szErrorState+msgObj.msg);
        var item = msgObj.errItem;       
        setTimeout(function(){
            $("#SetResultTips").html("");
            if (item) {
                $('#SingleOverlayInfoList').find('td').removeClass('error');    
            };
        },10000);  //10秒后自动清除
        return;
    };

    var xmlDoc = parseXmlFromStr(xmlToStr(m_PicOSDXmlDoc));
	$(xmlDoc).find("overlayInfoEnabled").eq(0).text($("#isUseOverLaySnapEnable").prop("checked").toString());
	if(iType == 0) {  
		  $(xmlDoc).find("linePercent").eq(0).text($("#linePercent").val());
		  $(xmlDoc).find("itemsStlye").eq(0).text($("#itemsStlye").val());
		  $(xmlDoc).find("charStyle").eq(0).text($("#charStyle").val());
		  $(xmlDoc).find("charSize").eq(0).text($("#charSize").val());
		  $(xmlDoc).find("charInterval").eq(0).text($("#charInterval").val());   //字体间距 页面去掉 20130822 by Feng lingfang
		  var forecolor = tC($("#foreClor").val());
		  var backClor = tC($("#backClor").val());
		  $(xmlDoc).find("foreClor").eq(0).text(parseInt(forecolor,16));
		  $(xmlDoc).find("backClor").eq(0).text(parseInt(backClor,16));
		  $(xmlDoc).find("colorAdapt").eq(0).text($("#IscolorAdapt").prop("checked").toString());
		  if($("#AtPhotoOutButtom").prop("checked")) {
			  $(xmlDoc).find("charPosition").eq(0).text("2");  
		  } else if($("#AtPhotoOutTop").prop("checked")){
			  $(xmlDoc).find("charPosition").eq(0).text("1");
		  }else{
            $(xmlDoc).find("charPosition").eq(0).text("0");
          }
		  $(xmlDoc).find("colorAdapt").eq(0).text($('#IscolorAdapt').prop('checked').toString());
		  $(xmlDoc).find("zeroizeEnable").eq(0).text($("#IszeroizeEnable").prop("checked").toString());
		  $(xmlDoc).find("platePicOverlay").eq(0).text($("#IsplatePicOverlayEnable").prop("checked").toString());
		  if($("#IsplatePicOverlayEnable").prop("checked")) {
			  var strOSDTextInfo = HWP.GetTextOverlay();
	          var XmlTempDoc = parseXmlFromStr(strOSDTextInfo);
			  
			  var iLength = $(XmlTempDoc).find("TextOverlay").length;
			  for(var i = 0; i < iLength; i++) {
				  if($(XmlTempDoc).find("TextOverlay").eq(i).find("id").text() == "1000" && $(XmlTempDoc).find("TextOverlay").eq(i).find("enabled").text() == "true") {
			          var iPosX = $(XmlTempDoc).find("TextOverlay").eq(i).find("positionX").text()*ia(SnapOverlay).m_iPicWidth/704;
			          var iPosY = $(XmlTempDoc).find("TextOverlay").eq(i).find("positionY").text()*ia(SnapOverlay).m_iPicHeight/576;
					  break;
				  }
			  }
	
			  $(xmlDoc).find("platePicPosTop").eq(0).text(iPosY);
			  $(xmlDoc).find("platePicPosLeft").eq(0).text(iPosX);
		  }
	} else {
		  $(xmlDoc).find("linePercent").eq(0).text($("#mergelinePercent").val());
		  $(xmlDoc).find("charSize").eq(0).text($("#mergecharSize").val());
		  var forecolor = tC($("#mergeforeClor").val());
		  var backClor = tC($("#mergebackClor").val());
		  $(xmlDoc).find("foreClor").eq(0).text(parseInt(forecolor,16));
		  $(xmlDoc).find("backClor").eq(0).text(parseInt(backClor,16));
		  if($("#MergeAtPhotoTop").prop("checked")) {
			  $(xmlDoc).find("charPosition").eq(0).text("1");  
		  } else {
			  $(xmlDoc).find("charPosition").eq(0).text("2");
		  }
	}
    var szInfo = "<?xml version='1.0' encoding='UTF-8'?><Temp><overlayInfoList>";
    
    $.each(infos, function (i, v) {
        var arr = [
            "<overlayInfo>",
                 "<Id>",i+1,"</Id>",
                 "<itemType>", v.itemType, "</itemType>",
                 "<spaceNum>", v.spaceNum, "</spaceNum>",
                 "<changeLineNum>", v.changeLineNum, "</changeLineNum>",
				 "<startPosEnable>", v.startPosEnable, "</startPosEnable>",
				 "<startPosTop>", v.startPosTop*ia(SnapOverlay).m_iPicHeight/576+1, "</startPosTop>",
				 "<startPosLeft>", v.startPosLeft*ia(SnapOverlay).m_iPicWidth/704+1, "</startPosLeft>",
                 "<overlayInfoText>",escapeXmlChars(v.overlayInfoText),"</overlayInfoText>"];
        if (v.itemType == '18') {
            arr.push("<overlayInfoText2>"+escapeXmlChars(v.overlayInfoText2)+"</overlayInfoText2>");
        }
		if (v.itemType == '24') {
            arr.push("<MD5Enable>"+v.useMD5.toString()+"</MD5Enable>");
        }
        arr.push("</overlayInfo>");

        szInfo += arr.join('');
    });

    szInfo += "</overlayInfoList></Temp>";
    $(xmlDoc).find("overlayInfoList").eq(0).remove();
	if(iType == 0) {
         $(xmlDoc).find("OSDPictureNew").append($(parseXmlFromStr(szInfo)).find("Temp").eq(0).clone().children());
	} else {
		$(xmlDoc).find("mergeOSDPicture").append($(parseXmlFromStr(szInfo)).find("Temp").eq(0).clone().children());
	}

    var xmlObj = parseXmlFromStr(xmlToStr(xmlDoc));
	if(iType == 0) {
		var szUrl = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Snapshot/channels/1/ITCPicOSD";
	} else {
		var szUrl = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Snapshot/channels/1/ITCMergePicOSD";
	}
    $.ajax({
        type: "put",
        url: szUrl,
        timeout: 15000,
        processData: false,
        data: xmlObj,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        complete:function(xhr, textStatus) {
             SaveState(xhr);
        }
    });
}
/*************************************************
 Function:		InitSnapOverlay
 Description:	初始化字符叠加界面
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(SnapOverlay).InitSnapOverlay = function () {
    var szInfo = getNodeValue('laPlugin');
    if(!checkPlugin('1', szInfo, 1, 'textoverlay')){
        return;
    }

    if(!CompareFileVersion()){
        UpdateTips();
   }
    m_PreviewOCX = document.getElementById("PreviewActiveX");
    ia(DeviceInfo).queryChannelInfo(); //用于获取视频制式
    m_iPicinform = 1;
    setTimeout(function() {
        if (HWP.Play() !== 0) {
            alert(getNodeValue("previewfailed"));
        }
    }, 10);
	$.ajax({
		   type: 'GET',
		   async: false,
		   url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/ITCStatus",
		   beforeSend: function(xhr) {
			   xhr.setRequestHeader("If-Modified-Since", "0"); 
			   
			   xhr.setRequestHeader("Content-Type", "text/xml");
		   },
		   success: function(xmlDoc, textStatus, xhr) {
			   ia(SnapOverlay).m_iPicHeight = $(xmlDoc).find("snapResolutionHeight").eq(0).text();
			   ia(SnapOverlay).m_iPicWidth = $(xmlDoc).find("snapResolutionWidth").eq(0).text();
		   }
	});
}
//清空OSD叠加信息
pr(SnapOverlay).ClearOSDOverlayInfo = function () {
	//先清空之前的叠加信息
	var strOSDTextInfo = HWP.GetTextOverlay();
	var XmlTempDoc = parseXmlFromStr(strOSDTextInfo);
	for(var i = 0; i < $(XmlTempDoc).find("TextOverlay").length; i++) {
		$(XmlTempDoc).find("TextOverlay").eq(i).find("enabled").text("false");
	}
	if($(XmlTempDoc).find("channelNameOverlay").length > 0) {
		$(XmlTempDoc).find("channelNameOverlay").eq(0).find("enabled").text("false");
	}
	if($(XmlTempDoc).find("DateTimeOverlay").length > 0) {
		$(XmlTempDoc).find("DateTimeOverlay").eq(0).find("enabled").text("false");
	}
	HWP.SetTextOverlay(xmlToStr(XmlTempDoc));
}
/*************************************************
Function:		createSnapOSDTextInfo
Description:	创建传送给插件的xml信息
Input:			无		
Output:			无
return:			bool				
*************************************************/
pr(SnapOverlay).createSnapOSDTextInfo = function (){
	ia(SnapOverlay).ClearOSDOverlayInfo();
	var szXml = "<?xml version='1.0' encoding='utf-8' ?><OSD><videoResolutionWidth>704</videoResolutionWidth><videoResolutionHeight>576</videoResolutionHeight><fontSize>0</fontSize><TextOverlayList>";
	var szPositionSame = [];
	var szPositinSameType = [];
	var j = 0;
	$.each(PicOverlap_SelectedItems, function (i, item) {
		if(item.startPosEnable == true) {
			j++;
			szXml += "<TextOverlay><id>";
			szXml += j + "</id>";
            if($('#AtPhotoOutTop').prop('checked')||$('#AtPhotoOutButtom').prop('checked')){
                szXml += "<enabled>false</enabled>";
            }else{
                szXml += "<enabled>true</enabled>";
            }
			
			szXml += "<positionX>" + item.startPosLeft + "</positionX>";
			szXml += "<positionY>" + item.startPosTop + "</positionY>";
            if(item.itemType == 40){
                szXml += "<displayText>" + "挂件" + "</displayText></TextOverlay>";
            }else if(item.itemType == 41){
                szXml += "<displayText>" + "衣着颜色" + "</displayText></TextOverlay>";
            }else {
                szXml += "<displayText>" + getNodeValue("itemTypeOpt" + item.itemType) + "</displayText></TextOverlay>";
            }
		} else {
			if(j > 0) {
			    szPositionSame.push(j-1);
                if(item.itemType == 40){
                    szPositinSameType.push("挂件");
                }else if(item.itemType == 41){
                    szPositinSameType.push("衣着颜色");
                }else {
                    szPositinSameType.push(getNodeValue("itemTypeOpt"+item.itemType));
                }
			}
		}
	})
	szXml += "<TextOverlay><id>1000</id><enabled>true</enabled><positionX>" + ia(SnapOverlay).m_iPosX + "</positionX><positionY>" + ia(SnapOverlay).m_iPosY + "</positionY><displayText>" + getNodeValue("laplatePicOverlay") +"</displayText></TextOverlay>";
	
	szXml += "</TextOverlayList></OSD>";
	var xmlDoc = parseXmlFromStr(szXml);
	for(var i = 0; i < szPositionSame.length; i++) {
		var szText = $(xmlDoc).find("displayText").eq(szPositionSame[i]).text();
		$(xmlDoc).find("displayText").eq(szPositionSame[i]).text(szText + " + " + szPositinSameType[i]);
	}
	var iLength = $(xmlDoc).find("TextOverlay").length;
	if($("#IsplatePicOverlayEnable").prop("checked")) {
		$(xmlDoc).find("TextOverlay").eq(iLength - 1).find("enabled").text("true");
	} else {
		$(xmlDoc).find("TextOverlay").eq(iLength - 1).find("enabled").text("false");
	}
    
	// if($('#AtPhotoOutTop').prop('checked')||$('#AtPhotoOutButtom').prop('checked')){
 //        $(xmlDoc).find("TextOverlay").eq(iLength - 1).find("enabled").text("false");
 //    }else{
 //        (xmlDoc).find("TextOverlay").eq(iLength - 1).find("enabled").text("true");
 //    }
	HWP.SetTextOverlay(xmlToStr(xmlDoc));
}
/*************************************************
Function:		OSDSettings
Description:	构造函数，Singleton派生类
Input:			无			
Output:			无
return:			无				
*************************************************/
function OSDSettings() {
	SingletonInheritor.implement(this);
    this.m_arrTextX = [-1, -1, -1, -1];
    this.m_arrTextY = [-1, -1, -1, -1];
    this.m_szOSDXmlStr = null;
}
SingletonInheritor.declare(OSDSettings);

(function() { // OSDSettings implementation

    $('#OverLayWordContentDiv').css("display","block");
    $('#OverLayInfoListDiv').css("display","none");
    $('#dvSnapTest').css("display","none");
    $('#dvSnapTestTips').css("display","none");


    OSDSettings.showDateContentInfo = function(){
        if($('#IsShowOSD').prop("checked")){
            $('#dateDetailContentDiv').css("display","block");
        }else{
            $('#dateDetailContentDiv').css("display","none");
        }
    }

	OSDSettings.prototype.initCSS = function()
	{
		$("#taOSDSettings :text").addClass("text");
		$("#taOSDSettings :checkbox").addClass("checkbox");

        $("#taTextOverlay :text").addClass("text");
        $("#taTextOverlay :checkbox").addClass("checkbox");
	}

	OSDSettings.prototype.update = function()
	{
        $('#OverLayWordContentDiv').css("visibility","visible");
        if($.browser.msie && parseInt($.browser.version, 10) == 6)
		{
		    $("#taBaseVideoSettings select").hide();
		}
        HWP.Stop(0);
		$("#SaveConfigBtn").show();
		$("#SetResultTips").html("");
        $('#snapOverLayTitleDiv').hide();
        $('#videoOverLayTitleDiv').show();
		
		ia(SnapOverlay).ClearOSDOverlayInfo();

		g_transStack.clear();
		var that = this;
		g_transStack.push(function() {
			that.setLxd(parent.translator.getLanguageXmlDoc(["VideoSettings", "OSDSettings"]));
			parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		}, true);
		RecordDisplayInit();
        RecordOverlayInit();
		g_transStack.push(function() {
			parent.translator.translatePage(that.getLxd(), document);
		}, true);

//        $('#laOverLayWordDiv').html(getNodeValue("laOverLayVideoWordName"));
//        OSDSettings.changeOverLayWordInfo();
        $('#OverLayWordContentDiv').css("display","block");
        $('#OverLayInfoListDiv').css("display","none");
        $('#dvSnapTest').css("display","none");
        $('#dvSnapTestTips').css("display","none");

        OSDSettings.showDateContentInfo();

        //自适应高度
        autoResizeIframe();
	}
	
	OSDSettings.prototype.submit = function()
	{
		if(!CheckDeviceName($("#ChannelName").val(),'SetResultTips',1))
		{
			$("#ChannelName").focus();
			return;
		}
		$("#ThisCharTips").html("");
	
		for(var k = 1; k <= 8; k ++)
		{
			if($("#IsShowString"+k).prop("checked"))
			{
				var szTipsId = "ThisCharTips";
			
				var szStr = $("#String" + k).val();	
				if(CheckCharName(szStr,szTipsId) == false)
				{
					$("#String" + k).focus().val(szStr);
					return;
				}
			}
		}
		if ($("#IsShowChanNme")[0].checked)
		{
			SetChannelName();
		}
		SetOverlayInfo(); //TextOverLay
		SetOSDInfoAll();
	}
	
	OSDSettings.prototype.beforeLeave = function()
	{
		var szTextOverlay = HWP.GetTextOverlay();
		if (szTextOverlay ==="")
		{
			return;
		}
		var xmlDoc = parseXmlFromStr(szTextOverlay);
		try
		{
			xmlDoc.documentElement.getElementsByTagName('channelNameOverlay')[0].getElementsByTagName('enabled')[0].childNodes[0].nodeValue = "false";
			xmlDoc.documentElement.getElementsByTagName('DateTimeOverlay')[0].getElementsByTagName('enabled')[0].childNodes[0].nodeValue = "false";

            var arrTextOverlay = xmlDoc.documentElement.getElementsByTagName('TextOverlayList')[0].getElementsByTagName("TextOverlay");
            for (var i = 0, len = arrTextOverlay.length; i != len; ++i)
            {
                arrTextOverlay[i].getElementsByTagName('enabled')[0].childNodes[0].nodeValue = "false";
            }
		}
		catch (e)
		{
			return;
		}
		HWP.SetTextOverlay(xmlToStr(xmlDoc));
	}

})(); // OSDSettings implementation