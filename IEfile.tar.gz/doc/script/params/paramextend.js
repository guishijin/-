
function DelAll() {
	try{
		iRes = HWP.ClearSnapInfo(4); //0-矩形 1-多边形 2-线  3-多边形和矩形 4-All
	}
	catch (e){}
}

function GetPolygonInfo() {
	var szInfo = HWP.GetSnapPolygonInfo();
	if (szInfo == -1) {
		return;
	};
	szInfo = parseXmlFromStr(szInfo);
	$(szInfo).find("y").each(function(){
		$(this).text((1-parseFloat($(this).text())).toString().substr(0,8));
	})
	return szInfo;
}

function SetSelectMode(iMode) {
	try{
		iRes = HWP.SetSnapDrawMode(iMode);  //设置为选择模式
	}
	catch (e){}
}

function SetMultiLine(szName, noArrow)
{
	if(typeof noArrow != "boolean") {
		noArrow = false;
	}
	var iNowPoly = $(GetLineInfo()).find("id").length;
	if(iNowPoly >= 8) {
		return;
	}
	AddLines(iNowPoly+1, szName, "<?xml version='1.0' encoding='utf-8'?><SnapLineList><SnapLine><id>" + (iNowPoly + 1) + "</id><LineType>0</LineType>" + (noArrow ? "" : "<ArrowType>1</ArrowType>") + "<color><r>255</r><g>0</g><b>0</b></color><Tips>" + szName + (iNowPoly + 1) + "</Tips><StartPos><x>0.2</x><y>0.2</y></StartPos><EndPos><x>0.2</x><y>0.5</y></EndPos></SnapLine></SnapLineList>");
}

function SetMultiPolygon(szName)
{
	var iNowPoly = $(GetPolygonInfo()).find("isClosed:contains('true')").length;
	if(iNowPoly >= 8) {
		return;
	}
	szName = szName + (iNowPoly + 1);
	AddPolygon(iNowPoly+1, szName);
	SetSelectMode(2);
}

function AddPolygon(iIndex, szName, xmlDoc) {
	if(typeof iIndex == "undefined" || (typeof iIndex != "number" && isNaN(parseInt(iIndex, 10)))) {
		iIndex = 1;
	}
	if(typeof szName == "undefined") {
		szName = "";
	}
	var szInfo = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>" + iIndex + "</id><polygonType>1</polygonType><PointNumMax>11</PointNumMax><MinClosed>5</MinClosed><tips>" + szName + "</tips><isClosed>false</isClosed><color><r>0</r><g>255</g><b>0</b></color><pointList/></SnapPolygon></SnapPolygonList>";
	if(typeof xmlDoc == "string") {
		szInfo = xmlDoc;
	}
	var origin = szInfo;
	
	// var CoordsSwitch = parseXmlFromStr(szInfo);
	// // $(CoordsSwitch).find("y").each(function() {
	// // 	$(this).text((1-parseFloat($(this).text())).toString().substr(0,8));
	// // })
	// szInfo = xmlToStr(CoordsSwitch);
	
	if(HWP.SetSnapPolygonInfo(szInfo)) {
		SetSelectMode(2);
		//setTimeout(function(){AddPolygon(1, 1, origin)}, 100);
	}
	//SetSelectMode(2); 
}


function SetWHPolygon()
{
	DelPolygon();
	AddPolygon(1, '', '<?xml version="1.0" encoding="utf-8"?><SnapPolygonList><SnapPolygon><id>1</id><polygonType>1</polygonType><color><r>0</r><g>255</g><b>0</b></color><tips/><PointNumMax>5</PointNumMax><MinClosed>5</MinClosed><showWH>true</showWH><isClosed>false</isClosed></SnapPolygon></SnapPolygonList>');
	SetSelectMode(2);
}

function AddLines(iIndex, szName, xmlDoc) {
	if(typeof iIndex == "undefined" || (typeof iIndex != "number" && isNaN(parseInt(iIndex, 10)))) {
		iIndex = 1;
	}
	if(typeof szName == "undefined") {
		szName = '';
	}
	szLineINfo = "<?xml version='1.0' encoding='utf-8'?><SnapLineList><SnapLine><id>" + iIndex + "</id><LineType>0</LineType><color><r>255</r><g>0</g><b>0</b></color><Tips>" + szName + "</Tips><StartPos><x>0.2</x><y>0.5</y></StartPos><EndPos><x>0.5</x><y>0.5</y></EndPos></SnapLine></SnapLineList>";
	if(typeof xmlDoc == "string") {
		szLineINfo = xmlDoc;
	}
	
	
	// var origin = szLineINfo;
	// var CoordsSwitch = parseXmlFromStr(szLineINfo);
	// $(CoordsSwitch).find("y").each(function(){
	// 	$(this).text((1-parseFloat($(this).text())).toString().substr(0,8));
	// })
	// szLineINfo = xmlToStr(CoordsSwitch);

	if(HWP.SetSnapLineInfo(szLineINfo)) {
		//setTimeout(function(){AddLines(1, 1, origin)}, 100);
	}
}

function DelPolygon() {
	HWP.ClearSnapInfo(3);; //0-矩形 1-多边形 2-线  3-多边形和矩形 4-All
}


var itsModeTips_timer = null;
function ITSCheckNum (strInfo, tipsId, szName, iMin, iMax, Unit) {
	if (itsModeTips_timer) {
		$('#SetResultTips').html('')
		clearTimeout(itsModeTips_timer);
		itsModeTips_timer = null;
	};

	var bRes = true;
	var szTipsInfo = "";
	if (strInfo == "") {
		szTipsInfo = getNodeValue("InputTips") + getNodeValue(szName);
		bRes = false;
	} else if(!strInfo.match(/^\d+\.?\d*$/)) {
		if (!Unit) {
			Unit = "";
		}
		szTipsInfo = getNodeValue(szName) + getNodeValue("RangeTips") + iMin + "-" + iMax + " " + Unit;
		bRes = false;
	} else if (parseFloat(strInfo) > parseFloat(iMax) || parseFloat(strInfo) < parseFloat(iMin)) {
		if (!Unit) {
			Unit = "";
		}
		szTipsInfo = getNodeValue(szName) + getNodeValue("RangeTips") + iMin + "-" + iMax + " " + Unit;
		bRes = false;
	}
	if (!bRes) {
		$('#SetResultTips').text(szTipsInfo);
		itsModeTips_timer = setTimeout(function(){
			$('#SetResultTips').html('');
		}, 5000);
	}
	return bRes;
}

function GetLineInfo() {
	var szInfo = HWP.GetSnapLineInfo();
	szInfo = parseXmlFromStr(szInfo);
	$(szInfo).find("y").each(function(){
		$(this).text((1-parseFloat($(this).text())).toString().substr(0,8));
	})
	return szInfo;
}

function SetOnePolygon(){
	DelPolygon();
	AddPolygon(1);
	SetSelectMode(2);
}

function SetOneBreakLine() {
	HWP.ClearSnapInfo(2);
	AddLines(1, 1, "<?xml version='1.0' encoding='utf-8'?><SnapLineList><SnapLine><id>2</id><LineType>9</LineType><LineTypeEx>2</LineTypeEx><color><r>255</r><g>0</g><b>0</b></color><Tips></Tips><StartPos><x></x><y></y></StartPos><EndPos><x></x><y></y></EndPos><BreakLine><isClosed>false</isClosed><MinClosed>2</MinClosed><PointNumMax>10</PointNumMax></BreakLine></SnapLine></SnapLineList>");
}

function SetDirection() {
	var xmlEdited = GetPolygonInfo();
	if($(xmlEdited).find("isClosed").text() == "false") {
		return;
	}
	HWP.ClearSnapInfo(2);
	AddLines(1, 1, "<?xml version='1.0' encoding='utf-8'?><SnapLineList><SnapLine><id>1</id><LineType>1</LineType><LineTypeEx>1</LineTypeEx><color><r>255</r><g>0</g><b>0</b></color><Tips></Tips><StartPos><x>0.2</x><y>0.2</y></StartPos><EndPos><x>0.2</x><y>0.5</y></EndPos><ArrowType>1</ArrowType></SnapLine></SnapLineList>");
}