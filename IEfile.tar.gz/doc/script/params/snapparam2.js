function SnapResolution () {
    SingletonInheritor.implement(this);

    this.capResolutionWidth =  0;
    this.capResolutionHeight = 0;

    this.capRAbility = [];

    this.srXml = null;
}
SingletonInheritor.declare(SnapResolution);

pr(SnapResolution).update = function () {
    if($.browser.msie && parseInt($.browser.version, 10) == 6){
        $('#tabSnapParam a[id^=a]').find('select').hide();
        $('#aSnapResolution').find('select').show();
    }
    $('#SetResultTips').html('');
    $("#SaveConfigBtn").show();

    HWP.Stop(0);
    g_transStack.clear();
    var that = this;
    g_transStack.push(function() {
        that.setLxd(parent.translator.getLanguageXmlDoc(["Storage", "SnapResolution"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);


    var getparam = $.ajax({
        type: 'GET',
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Snapshot/channels/1/capResInfo",
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        }
    });
    var getCap = $.ajax({
        type: 'GET',
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Snapshot/channels/1/capabilities",
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        }
    });

    $.when(getparam, getCap).done(function (args1, args2) {
        var xmlDoc1 = args1[0];
        var xmlDoc2 = args2[0];

        that.srXml = xmlDoc1;

        var widthstr = $(xmlDoc2).find('capResolutionWidth').attr('opt');
        var heightstr = $(xmlDoc2).find('capResolutionHeight').attr('opt');

        if (!widthstr || !heightstr) {
            return;
        };

        var arr1 = widthstr.split(/,\s*/g);
        var arr2 = heightstr.split(/,\s*/g);

        var $pair = $('#capResolutionPair');
        $pair.find('option').remove();

        var len = Math.min(arr1.length, arr2.length);
        for (var i = 0; i < len; i++) {
            var str = arr1[i]+'*'+arr2[i];
            $pair.append('<option value="'+ str +'">'+ str + '</option>');
        };

        var w =  $(xmlDoc1).find('capResolutionWidth').eq(0).text();
        var h =  $(xmlDoc1).find('capResolutionHeight').eq(0).text();
        $.g.setField2('#capResolutionPair', w+'*'+h);

        if($(xmlDoc1).find('jpegQua').length){
            $('#jpegQuaWrapper').show();
            $.g.setField2('#jpegQua', $(xmlDoc1).find('jpegQua').eq(0).text());
        }else{
            $('#jpegQuaWrapper').remove();
        }
        
    });
}

var charSizeMap = {
    '0': 32,
    '1': 48,
    '2': 64,
    '3': 128
};

function checkPicOSD(curRes){
    var res = true;

    var tmp = curRes.split("*");
    if (tmp.length != 2) {
        return true;
    };

    var newWidth = parseInt(tmp[0], 10);
    var newHeight = parseInt(tmp[1], 10);

    var szUrl = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Snapshot/channels/1/ITCPicOSD";

    var self = this;
    $.ajax({
        type: "GET",
        url: szUrl,
        async: false,
        timeout: 15000,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {
            var $xmlDoc = $(xmlDoc);
            var cs = $xmlDoc.find('charSize').eq(0).text();
            var charSize = charSizeMap[cs];
            if (!charSize) {
                charSize = 64;
            };

            var found = false;

            $xmlDoc.find('overlayInfo').each(function(i, n){
                var $over = $(n);

                if ($over.find('startPosEnable').eq(0).text() == 'true') {
                    found = true;

                    var startPosTop = $over.find('startPosTop').eq(0).text();
                    var startPosLeft = $over.find('startPosLeft').eq(0).text();

                    startPosTop = Number(startPosTop);
                    startPosLeft = Number(startPosLeft);

                    if (startPosLeft > newWidth - charSize) {
                        res = false;
                        return;
                    };
                    if (startPosTop > newHeight - charSize) {
                        res = false;
                        return;
                    };
                };
            });

            if (!found) {
                var $over = $xmlDoc.find('overlayInfo').eq(0);
                
                var startPosTop = $over.find('startPosTop').eq(0).text();
                var startPosLeft = $over.find('startPosLeft').eq(0).text();

                startPosTop = Number(startPosTop);
                startPosLeft = Number(startPosLeft);

                if (startPosTop == 0 && startPosLeft == 0) {

                }else if (startPosLeft > newWidth - charSize) {
                    res = false;
                }else if (startPosTop > newHeight - charSize) {
                    res = false;
                };
            };
        }
    });

    return res;
}

pr(SnapResolution).submit = function () {
    if (!this.srXml) {
        return;
    }

    var r = $('#capResolutionPair').val();
    if (!r) {
        ErrorTips(getNodeValue("RefreshPage"));
        return;
    }

    var res = checkPicOSD(r);
    if (!res) {
        var cfRes = confirm("改变抓拍分辨率后，叠加的字符超出图片范围，需重新调整OSD字符叠加。\n是否确定保存？");
        if (!cfRes) {
            return;
        };
    };

    var v = r.split('*');
    var $xmlDoc = $(this.srXml);
    $xmlDoc.find('capResolutionWidth').eq(0).text(v[0]);
    $xmlDoc.find('capResolutionHeight').eq(0).text(v[1]);

    if ($('#jpegQua').length && !$('#jpegQua').is(":hidden")) {
        $xmlDoc.find('jpegQua').eq(0).text($('#jpegQua').val());
    }

    var that = this;

    var url = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Snapshot/channels/1/capResInfo";
    $.ajax({
        type: "PUT",
        url : url,
        data: xmlToStr(that.srXml),
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        }      
    }).done(function(data, error, xhr) {
        SaveState(xhr);
    }).fail(function (xhr) {
        SaveState(xhr);
    });
}