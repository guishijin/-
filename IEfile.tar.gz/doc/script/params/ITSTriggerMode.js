
function ITSTriggerModeS () {
	SingletonInheritor.implement(this);	
}

SingletonInheritor.declare(ITSTriggerModeS);

ITSTriggerModeS.prototype.updateLang = function () {
	$('#CommendParamBtn').hide();

	g_transStack.clear();
	var that = ia(ITSTriggerModeS);
	g_transStack.push(function() {
		var itsModeDoc = parent.translator.getLanguageXmlDoc("ITSTriggerMode");
		that.setLxd(itsModeDoc);
		// parent.translator.appendLanguageXmlDoc(that.getLxd(), itsModeDoc);

		var tModeDoc = parent.translator.getLanguageXmlDoc("TriggerMode");
		parent.translator.appendLanguageXmlDoc(that.getLxd(), tModeDoc);

		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
		$("#FullScreenbutton").attr("title", getNodeValue("FullScreenExitTips"));
	}, true);
};


(function() {
	var ITSTriggerMode = window.ITSTriggerMode || {};

	var m_bPlay = false;

	ITSTriggerMode.changeUrban = function () {
		var urban = $('#bUrban').val();
		if (urban == '0') {  // 高速
			itsModeTabs.hideTabs([3]);
			itsModeTabs.showTabs([4,5]);
		}else{
			itsModeTabs.showTabs([3]);
			itsModeTabs.hideTabs([4,5]);
		}
	}

	function PlayView(ele){
		if (HWP.wnds[0].isPlaying) {
			StopPlay(ele);
			return;
		}
		setTimeout(function()
		{
			try {
				if(typeof ele == "undefined") {
					ele = $(".ConfigBtn :button:visible")[0];
				}
				iRes = HWP.Play();
				if (iRes != 0) {
					m_bPlay = false;
					$(ele).attr("name", "btnPlay");
					$(ele).attr("title", getNodeValue("btnPlay"));
					$(ele).val(getNodeValue("btnPlay"));
					return;	
				} else {
					m_bPlay = true;
					$(ele).attr("name", "btnStop");
					$(ele).attr("title", getNodeValue("btnStop"));
					$(ele).val(getNodeValue("btnStop"));
				}
			} catch(e){
			}
		},10);	
	}


	function StopPlay(ele) {
		if (!m_bPlay) {
			return;	
		} else {
			try {
				if (HWP.Stop(0) != 0) {
					return;	
				} else {
					m_bPlay = false;
					$(ele).attr("name", "btnPlay");
					$(ele).attr("title", getNodeValue("btnPlay"));
					$(ele).val(getNodeValue("btnPlay"));	
				}
			} catch(e){
				m_bPlay = false;
				$(ele).attr("name", "btnStop");
				$(ele).attr("title", getNodeValue("btnStop"));
				$(ele).val(getNodeValue("btnStop"));		
			}
		}
	}

	function  BtnName() {
		var PlayName = m_bPlay ? "btnStop" : "btnPlay";
		var SaveName = $("#aCameraDemarcate").hasClass("current") ? "btnVerify":"laSaveBtn";
		$(".ConfigBtn :button:visible").eq(0).attr("name", PlayName);
		$(".ConfigSave :button").eq(1).attr("name", SaveName);
		if($("#aSceneBasic").hasClass("current")) {
			HWP.SetPlayModeType(3);
		} else {
			HWP.SetPlayModeType(6);
		}
	}

	var originalXml = null;
	var $xml = null;

	function GetParam(cmd){
		ParamLoaded = false;

		var tail = '';
		if (cmd) {
			tail = '/recommendation'
		};

		$.ajax({
	        type: "GET",
	        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/ITS"+tail,
	        timeout: 15000,
	        dataType: 'text', 
	        beforeSend: function(xhr) {
	            xhr.setRequestHeader("If-Modified-Since", "0");
	            
	        },
	        success: function(xmlDoc, textStatus, xhr) {
	            originalXml = parseXmlFromStr(xmlDoc);
	            $xml = $(originalXml);

	            ParamLoaded = true;
	            
	            ITSTriggerMode.updateBasic();

	            itsModeTabs.selectCurTab();
	        },
	        error: function(xhr, textStatus, errorThrown) {
	            
	        }
	    });
	}

	function SetParam(){

		var minW=minH=maxW=maxH = 0;

		if ($('#sizeFilterMode').val() == '1') {
			minW = parseFloat($('#filterMode1_Min input:eq(0)').val());
			minH = parseFloat($('#filterMode1_Min input:eq(1)').val());
			maxW = parseFloat($('#filterMode1_Max input:eq(0)').val());
			maxH = parseFloat($('#filterMode1_Max input:eq(1)').val());
			if(minW> 50 || minH>50 || maxW>50 || maxH>50)
			{
				alert('过滤尺寸的宽和高不能超过50！');
				return;
			}			
		};
		
		var tabIdx = itsModeTabs.curTab;
		ITSTriggerMode.restoreLastTab(tabIdx);

		$.ajax({
	        type: "PUT",
	        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/ITS",
	        timeout: 15000,
	        beforeSend: function(xhr) {
	            xhr.setRequestHeader("If-Modified-Since", "0");
	            
	        },
	        data: xmlToStr(originalXml),
			processData: false,
			complete:function(xhr, textStatus) {
				if(xhr.status != 200) {
					if(xhr.status == 403) {
						var szErrorInfo = m_szError8;
						szRetInfo = m_szErrorState + szErrorInfo;
					} else {
						var xmlDoc =xhr.responseXML;
						if($(xmlDoc).find("detailedStatusCode").eq(0).text() != "") {
							var szErrorInfo = getNodeValue("Error" + $(xmlDoc).find("detailedStatusCode").eq(0).text());
						} else {
							var szErrorInfo = m_szError13;
						}
						szRetInfo = m_szErrorState + szErrorInfo;
					}
		            $("#SetResultTips").html(szRetInfo); 
			        setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			        return;	
				} else {
					var m_bRebootRequired = false;
					if($(xhr.responseXML).find("statusCode").eq(0).text() == "7") {
						m_bRebootRequired = true;
					}

					$("#CurTriggerMode").html(getNodeValue("a" + $("#selTriggerMode").val()));

					if(m_bRebootRequired) {
						szRetInfo = m_szSuccessState + m_szSuccess5;
					} else {
						szRetInfo = m_szSuccessState + m_szSuccess1;
					}

					$("#SetResultTips").html(szRetInfo); 
				    setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
				}
			}
	    });
	}

	ITSTriggerMode.updateLang = function () {
		ia(ITSTriggerModeS).updateLang();
	}

	var cities = [	{"index":0,"prov":"安徽"},{"index":1,"prov":"澳门"},
					{"index":2,"prov":"北京"},{"index":3,"prov":"重庆"},
					{"index":4,"prov":"福建"},{"index":5,"prov":"甘肃"},
					{"index":6,"prov":"广东"},{"index":7,"prov":"广西"},
					{"index":8,"prov":"贵州"},{"index":9,"prov":"海南"},
					{"index":10,"prov":"河北"},{"index":11,"prov":"河南"},
					{"index":12,"prov":"黑龙江"},{"index":13,"prov":"湖北"},
					{"index":14,"prov":"湖南"},{"index":15,"prov":"吉林"},
					{"index":16,"prov":"江苏"},{"index":17,"prov":"江西"},
					{"index":18,"prov":"辽宁"},{"index":19,"prov":"内蒙古"},
					{"index":20,"prov":"宁夏"},{"index":21,"prov":"青海"},
					{"index":22,"prov":"山东"},{"index":23,"prov":"山西"},
					{"index":24,"prov":"陕西"},{"index":25,"prov":"上海"},
					{"index":26,"prov":"四川"},{"index":27,"prov":"台湾"},
					{"index":28,"prov":"天津"},{"index":29,"prov":"西藏"},
					{"index":30,"prov":"香港"},{"index":31,"prov":"新疆"},
					{"index":32,"prov":"云南"},{"index":33,"prov":"浙江"}];

	function initCities(){
		var ele = $('#locationIndex');
		ele.find('option').remove();

		for (var i = 0; i < cities.length; i++) {
			var c = cities[i];
			ele.append('<option value="'+c.index+'" >'+c.prov+'</option>');
		};
	}

	var itsModeTabs = null;
	var ParamLoaded = false;

	ITSTriggerMode.restoreLastTab = function(lastTabIdx) {
		if (!lastTabIdx && lastTabIdx != 0) {
			return;
		};

		if (!ParamLoaded) {
			return;
		};

		var aele = itsModeTabs.tabs.eq(lastTabIdx);
		if (aele && aele.data('updated')) {
			var funcStr = aele.attr('restoreFunc');
			if (funcStr && ITSTriggerMode[funcStr]) {
				ITSTriggerMode[funcStr]();
			};
		};
	}

	ITSTriggerMode.setTabUpdated = function(){
		var curIdx = itsModeTabs.curTab;
		var aele = itsModeTabs.tabs.eq(curIdx);
		if (aele) {
			aele.data('updated', true);
		}
	}

	
	ITSTriggerMode.update = function () {
		itsModeTabs = $(".tabs.itstab").tabs(".pane.itstab", {
			remember : false,
			markCurrent: false, 
			beforeLeave: function (lastIdx){
				ITSTriggerMode.restoreLastTab(lastIdx);
			}
		});

		if ($("#main_plugin").html() == "") {
			if (checkPlugin('2', getNodeValue('laPlugin'), 1, 'snapdraw', 0)) {
				if (!CompareFileVersion()) {
					UpdateTips();
				}
			}
		}

		initCities();

		if ($.browser.msie) {
			var iIEVersion = parseInt($.browser.version, 10);
			if (iIEVersion == 6) {
				$("#ptzCfg").find("select").hide();
				$("#homePos").find("select").show();
			}
		} else {
			StopPlay();
		}

		InitSlider2('#OneRuleSet div[slider]');

		PlayView();

		GetParam();
	}

	function initTabPage (btnDivSel) {
		$('.ptzOpe').hide();
		$(btnDivSel).show();

		DelAll();

		$('#SetResultTips').html('');
		$("#SaveConfigBtn").hide();
		var self = this;
		BtnName();

		$(".ConfigBtn :button").each(function(){
			$(this).attr("title", $(this).val());
		})
		$("#laCarSizeTips").attr("title", $("#laCarSizeTips").text());

		$(".ConfigSave :button").eq(0).show();
	}

	ITSTriggerMode.updateBasic = function () {
		initTabPage('#SceneBasicDraw');
		hideErrorTips();

		if (ParamLoaded) {
			$.each(['locationIndex', 'bInTunel', 'bUrban', 'bLamps', 'bTrack','bDrawObjBlobCap'], function(i, n){
				$.g.setField2('#'+n, $xml.find(n).eq(0).text());
			});

			this.setTabUpdated();

			ITSTriggerMode.changeUrban();
		}

		autoResizeIframe();
	}

	ITSTriggerMode.restoreBasic = function () {
		$.each(['locationIndex', 'bInTunel', 'bUrban', 'bLamps', 'bTrack','bDrawObjBlobCap'], function(i, n){
			var v;
			var ele = $('#'+n);
			if (ele.length) {
				if (ele.is(":checkbox")) {
					v = ele.prop('checked') ? "1":"0";
				}else{
					v = ele.val();
				}
				$xml.find(n).eq(0).text(v);	
			};
		});
	}

	ITSTriggerMode.updateReferenceArea = function () {
		initTabPage('#ReferenceAreaDraw');

		if (!ParamLoaded) {
			return;
		}

		this.setTabUpdated();

		var obj = {
			SnapPolygonList:{
				SnapPolygon: []
			}
		};

		this.jsonParam = x2js.xml_str2json(xmlToStr(originalXml));
		var jsonParam = this.jsonParam;

		var referenceAeras = jsonParam.ITS.ItsReferenceAeraList.referenceAera_asArray;
		if (!referenceAeras || !referenceAeras.length) {
			return;
		};

		for (var i = 0; i < referenceAeras.length; i++) {
			var s = referenceAeras[i];

			var ptArr = [];

			var id = parseInt(s.referenceAeraId);

			if (s.referenceAeraEnable == '0'
				|| !s.referenceAeraCoordinatesList
				|| !s.referenceAeraCoordinatesList.referenceAeraCoordinates_asArray
				|| s.referenceAeraCoordinatesList.referenceAeraCoordinates_asArray.length < 3) {
				continue;
			};

			var sac = s.referenceAeraCoordinatesList.referenceAeraCoordinates_asArray;
			for (var j = 0; j < sac.length; j++) {
				var s = sac[j];
				var x = (parseInt(s.positionX, 10)/1000).toFixed(3);
				var y = (parseInt(s.positionY, 10)/1000).toFixed(3);
				ptArr.push({
					x: x,
					y: y
				});
			};

			obj.SnapPolygonList.SnapPolygon.push({
				id: id+1,
				polygonType: 1,
				color: {r: 0, g: 255, b: 0},
				tips: (id+1)+'',
				isClosed: "true",
				PointNumMax:11,
				MinClosed:5,
				pointList: {
					point: ptArr
				}
			})
		};

		if (obj.SnapPolygonList.SnapPolygon.length) {
			try{	
				var xml = x2js.json2xml_str(obj, true);
				HWP.SetSnapPolygonInfo(xml);

				HWP.SetSnapDrawMode(0, 4);
			}catch(e){}
		};

		autoResizeIframe();
	}

	ITSTriggerMode.restoreReference = function () {
		var jsonParam = this.jsonParam;

		var xmlStr = HWP.GetSnapPolygonInfo();
		
		var xml=parseXmlFromStr(xmlStr);

		var tmpPolys = {};
		$(xml).find('SnapPolygon').each(function(i, n){
			var $poly = $(n);
			var id = $poly.find('id').text();
			var $points = $poly.find('point');

			var tmpPts = [];
			$points.each(function(i, n){
				var x = $(n).find('x').text();
				var y = $(n).find('y').text();

				tmpPts.push({
					positionX: Math.round(parseFloat(x)*1000),
					positionY: Math.round(parseFloat(y)*1000)
				});
			});

			var tmp = {
				referenceAeraEnable: "1",
				referenceAeraCoordinatesList:{
					referenceAeraCoordinates:tmpPts
				}
			};

			tmpPolys[id] = tmp;
		});

		var tmpreferenceAeras = [];
		for (var i = 1; i <= 8; i++) {
			if (tmpPolys[i]) {
				tmpreferenceAeras.push({
					referenceAeraId: i-1,
					referenceAeraEnable: '1',
					referenceAeraCoordinatesList: tmpPolys[i]['referenceAeraCoordinatesList']
				});
			}else{
				tmpreferenceAeras.push({
					referenceAeraId: i-1,
					referenceAeraEnable: '0',
					referenceAeraCoordinatesList: ''
				});
			}
		};

		jsonParam.ITS.ItsReferenceAeraList = {
			referenceAera: tmpreferenceAeras
		};

		originalXml = x2js.json2xml(jsonParam);
		$xml = $(originalXml);		
	}


	ITSTriggerMode.updateShieldAera = function () {
		initTabPage('#BlockAreaDraw');

		if (!ParamLoaded) {
			return;
		}

		this.setTabUpdated();

		var obj = {
			SnapPolygonList:{
				SnapPolygon: []
			}
		};

		this.jsonParam = x2js.xml_str2json(xmlToStr(originalXml));
		var jsonParam = this.jsonParam;

		var shieldAeras = jsonParam.ITS.ItsShieldAeraList.shieldAera_asArray;
		if (!shieldAeras || !shieldAeras.length) {
			return;
		};

		for (var i = 0; i < shieldAeras.length; i++) {
			var s = shieldAeras[i];

			var ptArr = [];

			var id = parseInt(s.shieldAeraId);

			if (s.shieldAeraEnable == '0'
				|| !s.shieldAeraCoordinatesList
				|| !s.shieldAeraCoordinatesList.shieldAeraCoordinates_asArray
				|| s.shieldAeraCoordinatesList.shieldAeraCoordinates_asArray.length < 3) {
				continue;
			};

			var sac = s.shieldAeraCoordinatesList.shieldAeraCoordinates_asArray;
			for (var j = 0; j < sac.length; j++) {
				var s = sac[j];
				var x = (parseInt(s.positionX, 10)/1000).toFixed(3);
				var y = (parseInt(s.positionY, 10)/1000).toFixed(3);
				ptArr.push({
					x: x,
					y: y
				});
			};

			obj.SnapPolygonList.SnapPolygon.push({
				id: id+1,
				polygonType: 1,
				color: {r: 0, g: 255, b: 0},
				tips: (id+1)+'',
				isClosed: "true",
				PointNumMax:11,
				MinClosed:5,
				pointList: {
					point: ptArr
				}
			})
		};

		if (obj.SnapPolygonList.SnapPolygon.length) {
			try{	
				var xml = x2js.json2xml_str(obj, true);
				HWP.SetSnapPolygonInfo(xml);

				HWP.SetSnapDrawMode(0, 4);
			}catch(e){}
		};

		autoResizeIframe();
	}

	ITSTriggerMode.restoreShield = function () {
		var jsonParam = this.jsonParam;

		var xmlStr = HWP.GetSnapPolygonInfo();
		var xml=parseXmlFromStr(xmlStr);
		
		var tmpPolys = {};
		$(xml).find('SnapPolygon').each(function(i, n){
			var $poly = $(n);
			var id = $poly.find('id').text();
			var $points = $poly.find('point');

			var tmpPts = [];
			$points.each(function(i, n){
				var x = $(n).find('x').text();
				var y = $(n).find('y').text();

				tmpPts.push({
					positionX: Math.round(parseFloat(x)*1000),
					positionY: Math.round(parseFloat(y)*1000)
				});
			});

			var tmp = {
				shieldAeraEnable: "1",
				shieldAeraCoordinatesList:{
					shieldAeraCoordinates:tmpPts
				}
			};

			tmpPolys[id] = tmp;
		});

		var tmpShieldAeras = [];
		for (var i = 1; i <= 8; i++) {
			if (tmpPolys[i]) {
				tmpShieldAeras.push({
					shieldAeraId: i-1,
					shieldAeraEnable: '1',
					shieldAeraCoordinatesList: tmpPolys[i]['shieldAeraCoordinatesList']
				});
			}else{
				tmpShieldAeras.push({
					shieldAeraId: i-1,
					shieldAeraEnable: '0',
					shieldAeraCoordinatesList: ''
				});
			}
		};

		jsonParam.ITS.ItsShieldAeraList = {
			shieldAera: tmpShieldAeras
		};

		originalXml = x2js.json2xml(jsonParam);
		$xml = $(originalXml);		
	}

	ITSTriggerMode.updateDemarcate = function () {
		initTabPage('#CameraDemarcate');

		if (!ParamLoaded) {
			return;
		}

		$.each(['calibrationWidth', 'calibrationLength'], function(i, n){
			var v = (parseInt($xml.find(n).text())/1000).toFixed(2);
			if (!v) {
				v = '';
			};
			$.g.setField2('#'+n, v);
		});
		
		var acs = $xml.find('calibrationAeraCoordinates');
		if (acs.length != 4) {
			return;
		}
		var ptArr = [];

		acs.each(function(i, n){
			var $pt = $(n);
			var x = parseInt($pt.find('positionX').text());
			var y = parseInt($pt.find('positionY').text());

			ptArr.push({
				x:(x/1000).toFixed(3),
				y:(y/1000).toFixed(3)
			});
		});	

		var obj = {
			SnapPolygonList:{
				SnapPolygon: [{
					id: 1,
					polygonType: 1,
					color: {r: 0, g: 255, b: 0},
					tips: '',
					showWH: "true",
					isClosed: "true",
					PointNumMax:5,
					MinClosed:5,
					pointList: {
						point: ptArr
					}
				}]
			}
		};

		try{	
			var xml = x2js.json2xml_str(obj, true);
			HWP.SetSnapPolygonInfo(xml);

			HWP.SetSnapDrawMode(0, 4);
		}catch(e){}

		this.setTabUpdated();
		
		autoResizeIframe();
	}

	ITSTriggerMode.restoreDemarcate = function () {
		$.each(['calibrationWidth', 'calibrationLength'], function(i, n){
			var v = $('#'+n).val();
			v = Math.round(parseFloat(v)*1000);
			$xml.find(n).eq(0).text(v);
		});

		var $pts = $xml.find('calibrationAeraCoordinates');

		var xmlStr = HWP.GetSnapPolygonInfo();
		var xml=parseXmlFromStr(xmlStr);
		$(xml).find('point').each(function(i, n){
			var $p = $(n);

			var x = $p.find('x').text();
			x = Math.round(parseFloat(x)*1000);
			var y = $p.find('y').text();
			y = Math.round(parseFloat(y)*1000);

			$pts.eq(i).find('positionX').text(x);
			$pts.eq(i).find('positionY').text(y);
		});
	}

	ITSTriggerMode.updateLane = function () {
		
		initTabPage('#LaneConfig');
		
		if (!ParamLoaded) {
			return;
		}

		this.setTabUpdated();

		var obj = {
			SnapPolygonList:{
				SnapPolygon: []
			}
		};

		var snapLines = {
			SnapLineList: {
				SnapLine:[]
			}
		};

		this.jsonParam = x2js.xml_str2json(xmlToStr(originalXml));
		var jsonParam = this.jsonParam;

		var ItsLanes = jsonParam.ITS.ItsLaneList.ItsLane_asArray;
		if (!ItsLanes || !ItsLanes.length) {
			return;
		};

		for (var i = 0; i < ItsLanes.length; i++) {
			var s = ItsLanes[i];

			var ptArr = [];

			var id = parseInt(s.laneId);

			if (s.laneEnable == '0'
				|| !s.lanePolygonCoordinatesList
				|| !s.lanePolygonCoordinatesList.lanePolygonCoordinates_asArray
				|| s.lanePolygonCoordinatesList.lanePolygonCoordinates_asArray.length < 3) {
				continue;
			};

			var sLane = s.lanePolygonCoordinatesList.lanePolygonCoordinates_asArray;
			for (var j = 0; j < sLane.length; j++) {
				var sl = sLane[j];
				var x = (parseInt(sl.positionX, 10)/1000).toFixed(3);
				var y = (parseInt(sl.positionY, 10)/1000).toFixed(3);
				ptArr.push({
					x: x,
					y: y
				});
			};

			obj.SnapPolygonList.SnapPolygon.push({
				id: id+1,
				polygonType: 1,
				color: {r: 0, g: 255, b: 0},
				tips: '车道'+(id+1),
				isClosed: "true",
				PointNumMax:11,
				MinClosed:5,
				pointList: {
					point: ptArr
				}
			});

			var startX = startY = endX = endY = 0;
			if (s.laneFlowDirection && s.laneFlowDirection.laneFlowCoordinates) {
				var lf = s.laneFlowDirection.laneFlowCoordinates;

				startX = (parseInt(lf.laneFlowStartX, 10)/1000).toFixed(3);
				startY = (parseInt(lf.laneFlowStartY, 10)/1000).toFixed(3);
				endX = (parseInt(lf.laneFlowEndX, 10)/1000).toFixed(3);
				endY = (parseInt(lf.laneFlowEndY, 10)/1000).toFixed(3);
			};
			
			if (startY == 0 && startX == 0 && endX == 0 && endY == 0) {

			}else{
				snapLines.SnapLineList.SnapLine.push({
					id: id+1,
					LineType: 1,
					LineTypeEx: 1,
					ArrowType: 1,
					Tips:  '方向'+(id+1),
					StartPos: {
						x: startX,
						y: startY
					},
					EndPos: {
						x: endX,
						y: endY
					},
					color:  {r: 255, g: 0, b: 0}
				});
			}
		};

		if (snapLines.SnapLineList.SnapLine.length) {
			try{
				var szLineInfo = x2js.json2xml_str(snapLines);
				HWP.SetSnapLineInfo(szLineInfo);
			}catch(e){}
		};

		if (obj.SnapPolygonList.SnapPolygon.length) {
			try{	
				var xml = x2js.json2xml_str(obj, true);
				HWP.SetSnapPolygonInfo(xml);

				HWP.SetSnapDrawMode(0, 4);
			}catch(e){}
		};

		autoResizeIframe();
	}

	ITSTriggerMode.restoreLane = function () {
		var jsonParam = this.jsonParam;

		var xmlStr = HWP.GetSnapPolygonInfo();
		var xml=parseXmlFromStr(xmlStr);
		
		var tmpPolys = {};
		$(xml).find('SnapPolygon').each(function(i, n){
			var $poly = $(n);
			var id = $poly.find('id').text();
			var $points = $poly.find('point');

			var tmpPts = [];
			$points.each(function(i, n){
				var x = $(n).find('x').text();
				var y = $(n).find('y').text();

				tmpPts.push({
					positionX: Math.round(parseFloat(x)*1000),
					positionY: Math.round(parseFloat(y)*1000)
				});
			});

			var tmp = {
				laneEnable: "1",
				lanePolygonCoordinatesList:{
					lanePolygonCoordinates:tmpPts
				}
			};

			tmpPolys[id] = tmp;
		});

		var lineXml = HWP.GetSnapLineInfo();
		lineXml=parseXmlFromStr(lineXml);
		var tmpLines = {};
		$(lineXml).find('SnapLine').each(function(i, n){
			var $line = $(n);
			var id = $line.find('id').text();

			var sx = $line.find('StartPos').find('x').text();
			var sy = $line.find('StartPos').find('y').text();
			var ex = $line.find('EndPos').find('x').text();
			var ey = $line.find('EndPos').find('y').text();

			var tmp = {
				laneFlowStartX: Math.round(parseFloat(sx)*1000),
				laneFlowStartY: Math.round(parseFloat(sy)*1000),
				laneFlowEndX: Math.round(parseFloat(ex)*1000),
				laneFlowEndY: Math.round(parseFloat(ey)*1000)
			};

			tmpLines[id] = tmp;
		});

		var tmpLaneAeras = [];
		for (var i = 1; i <= 8; i++) {
			var tmp = {
				laneId: i-1,
				laneEnable: '0',
				laneFlowDirection: {
					laneFlowCoordinates: {
						laneFlowStartX: 0,
						laneFlowStartY: 0,
						laneFlowEndX: 0,
						laneFlowEndY: 0
					}
				},
				lanePolygonCoordinatesList: ''
			};

			if (tmpPolys[i]) {
				tmp.laneEnable = '1';
				tmp.lanePolygonCoordinatesList = tmpPolys[i]['lanePolygonCoordinatesList'];
			};

			if (tmpLines[i]) {
				tmp.laneFlowDirection = {
					laneFlowCoordinates: tmpLines[i]
				};
			};

			tmpLaneAeras.push(tmp);
		};

		jsonParam.ITS.ItsLaneList = {
			ItsLane: tmpLaneAeras
		};

		originalXml = x2js.json2xml(jsonParam);
		$xml = $(originalXml);	
	}

	function initRuleTable(isHightWay){
		$("#RuleList").html("");

		for(var i=1; i<=8; i++) {
			var str = ''+
					'<li ruleIdx="'+(i-1)+'">'+
						'<div class="SceneNo">'+i+'</div>'+
						'<div class="SceneEnable">'+
							'<input type="checkbox">'+
						'</div>'+
						'<div class="SceneIndex">'+
							'<input type="text" value="'+i+'" />'+
							// '<label>' + i + '</label>'+
						'</div>'+
						'<div class="RuleType">';
			// if (isHightWay) {
			// 	str +=	'<select disabled="true" class="bodyRuleType" ruleIdx="'+(i-1)+'">'+
			// 					'<option value="1" name="opRuleArea">'+getNodeValue('opRuleArea')+'</option>'+
			// 				'</select>'+
			// 			'</div>';
			// }else{
				str +=		'<select class="bodyRuleType" ruleIdx="'+(i-1)+'">'+
								'<option value="1" name="opRuleArea">'+getNodeValue('opRuleArea')+'</option>'+
								'<option value="2" name="opRuleBreakLine">'+getNodeValue('opRuleBreakLine')+'</option>'+
							'</select>'+
						'</div>';
			// }

				

				str +=	'<div class="RuleSet">'+
							'<label name="laSetSceneRule" onclick="ITSTriggerMode.setRules(' + (i-1) + ')">'+
								getNodeValue('laSetSceneRule')+
							'</label>'+
						'</div>';

			if (isHightWay) {
				str +=	'<div class="FilterEnable">'+
							'<input type="checkbox">'+
						'</div>'+
					'</li>'
				$('#RuleTitle .SceneFilter').show();
			}else{
				$('#RuleTitle .SceneFilter').hide();
			}
				
			$("#RuleList").append(str);
		}

		$('#RuleList li').unbind().click(function () {
			var ruleIdx = $(this).attr('ruleIdx');
			if (ruleIdx == ITSTriggerMode.selectedRuleIdx) {
				return;
			}

			$('#RuleList li').removeClass('CurrentSel');

			ITSTriggerMode.restoreOneRule();
			ITSTriggerMode.selectedRuleIdx = ruleIdx;

			$(this).addClass('CurrentSel');
			ITSTriggerMode.updateOneRule();

			initCurRulePage();
		});

		$("#RuleList select.bodyRuleType").each(function (i, n) {
			var $sel = $(n);
			
			$sel.unbind('change').change(function () {
				var ruleIdx = $(this).attr('ruleIdx');

				var thisRule = getRuleObject(ruleIdx);
				var regionType = $(this).val();

				if (thisRule) {
					thisRule.itsAidRuleType = regionType;

					initCurRulePage();
				};
			});
		});		

		$('#RuleList .FilterEnable').find(':checkbox').unbind().click(function () {
			var ruleIdx = $(this).parents("li:eq(0)").attr('ruleIdx');

			var thisRule = getRuleObject(ruleIdx);
			if (thisRule) {
				var p = $(this).prop('checked');
				thisRule.sizeFilterEnable = p ? '1':'0';	

				initCurRulePage();
			};
		});
	}

	function getRuleObject (ruleIdx) {
		if (!ruleIdx) {
			var $curLi = $('#RuleList li.CurrentSel');
			var ruleIdx = $curLi.attr('ruleIdx');	
		};
		
		if (ruleIdx == '' || typeof(ruleIdx) == 'undefined') {
			return;
		};

		var jsonParam = ITSTriggerMode.jsonParam;
		var rules = jsonParam.ITS.ItsAidRuleList.ItsAidRule;

		var thisRule;
		for (var i = 0; i < rules.length; i++) {
			var r = rules[i];
			if(r && r.itsAidRuleId == ruleIdx){
				thisRule = r;
			}
		};

		return thisRule;
	}

	function initCurRulePage () {
		var curRule = getRuleObject();
		if (!curRule) {
			return;
		};

		var regionType = curRule.itsAidRuleType;

		if (regionType == '2') {  // region
			$('#btnDrawRuleArea, #btnDrawDirection').prop('disabled', true);
			$('#btnDrawBreakLine').prop('disabled', false);
		}else{
			$('#btnDrawRuleArea, #btnDrawDirection').prop('disabled', false);
			$('#btnDrawBreakLine').prop('disabled', true);
		}

		var jsonParam = ITSTriggerMode.jsonParam;
		if (!jsonParam) {
			$('#filterDiv').hide();	
		};

		var isHightWay = jsonParam.ITS.ItsSceneDescription.bUrban == '0';

		var filterEnabled = curRule.sizeFilterEnable;
		if (filterEnabled == '1' && isHightWay) {
			$('#filterDiv').show();	

			var mode = curRule.sizeFilterMode;
			dispFilterMode(mode, curRule);
		}else{
			$('#filterDiv').hide();	
		}
	}

	ITSTriggerMode.updateRule = function () {
		hideErrorTips();

		if (!ParamLoaded) {
			return;
		}

		this.jsonParam = x2js.xml_str2json(xmlToStr(originalXml));
		var jsonParam = this.jsonParam;

		initTabPage('#RuleSetting');

		var isHightWay = jsonParam.ITS.ItsSceneDescription.bUrban == '0';
		initRuleTable(isHightWay);

		this.selectedRuleIdx = undefined;

		var rules = jsonParam.ITS.ItsAidRuleList.ItsAidRule;

		for (var i = 0; i < rules.length; i++) {
			var curRule = rules[i];
		
			var liSel = '#RuleList li[ruleIdx="'+i+'"]';
			$.g.setField2(liSel + ' .SceneEnable input:checkbox', curRule.itsAidRuleEnable);
			$.g.setField2(liSel + ' .SceneIndex input', curRule.itsAidRuleName);
			$.g.setField2(liSel + ' select.bodyRuleType', curRule.itsAidRuleType);
			$.g.setField2(liSel + ' .FilterEnable input', curRule.sizeFilterEnable);	
		};

		$('#RuleList li:eq(0)').click();

		this.setTabUpdated();

		autoResizeIframe();
	}

	ITSTriggerMode.restoreOneRule = function () {
		var curRuleIdx = this.selectedRuleIdx;
		if (typeof curRuleIdx == 'undefined' || curRuleIdx == '' || curRuleIdx == null) {
			return;
		};

		var curRule = getRuleObject(curRuleIdx);
		if (!curRule) {
			return;
		};

		var jsonParam = ITSTriggerMode.jsonParam;
		var isHightWay = jsonParam.ITS.ItsSceneDescription.bUrban == '0';

		if (isHightWay) {
			curRule.sizeFilterMode = $('#filterDiv #sizeFilterMode').val();
			restoreFilterSize(curRule);	
		};

		if (curRule.itsAidRuleType == '1'||curRule.itsAidRuleType == '0') {
			this._restoreRuleRegion(curRule);
		}else{
			this._restoreBreakLine(curRule);
		}
	}

	ITSTriggerMode.updateOneRule = function () {
		var curRuleIdx = this.selectedRuleIdx;
		if (typeof curRuleIdx == 'undefined' || curRuleIdx == '' || curRuleIdx == null) {
			return;
		};

		var curRule = getRuleObject(curRuleIdx);
		if (!curRule) {
			return;
		};

		$.g.setField2('#filterDiv #sizeFilterMode', curRule.sizeFilterMode);
		this.changeFilterMode();

		DelAll();

		if (curRule.itsAidRuleType == '1'||curRule.itsAidRuleType == '0') {
			this._drawRuleRegion(curRule);
		}else{
			this._drawBreakLine(curRule);
		}
	}

	ITSTriggerMode._restoreBreakLine = function (curRule) {
		var lineXml = HWP.GetSnapLineInfo();
		lineXml = parseXmlFromStr(lineXml);

		var tmpPts = [];
		$(lineXml).find('SnapLine').each(function(i, n){
			var $line = $(n);
			var id = $line.find('id').text();

			if (id == '2') {				
				var $points = $line.find('point');

				
				$points.each(function(i, n){
					var x = $(n).find('x').text();
					var y = $(n).find('y').text();

					tmpPts.push({
						positionX: Math.round(parseFloat(x)*1000),
						positionY: Math.round(parseFloat(y)*1000)
					});
				});
				return;
			};
		});

		curRule.itsAidRulePolygon = {
			itsAidRulePolygonCoordinatesList:{
				itsAidRulePolygonCoordinates: tmpPts
			}	
		}
	}

	ITSTriggerMode._drawBreakLine = function (curRule) {
		var ptArr = this._ruleRegionPoints(curRule);
		if (!ptArr.length) {
			return;
		};

		var snapLines = {
			SnapLineList: {
				SnapLine:[{
					id:2,
					LineType: 9,
					LineTypeEx: 2,
					// StartPos: {
					// 	x: ptArr[0].x,
					// 	y: ptArr[0].y
					// },
					// EndPos: {
					// 	x: ptArr[ptArr.length-1].x,
					// 	y: ptArr[ptArr.length-1].y
					// },
					color:{r:255,g:0,b:0},
					BreakLine: {
						isClosed: "true",
						pointList: {
							point: ptArr
						}
					}
				}]
			}
		};

		if (snapLines.SnapLineList.SnapLine.length) {
			try{
				var szLineInfo = x2js.json2xml_str(snapLines);
				HWP.SetSnapLineInfo(szLineInfo);
			}catch(e){}
		}
	}

	ITSTriggerMode._restoreRuleRegion = function (curRule) {
		this._restoreRuleDirection(curRule);

		var xml = HWP.GetSnapPolygonInfo();
		xml = parseXmlFromStr(xml);

		var tmp = false;
		var $poly = $(xml).find('SnapPolygon').eq(0);
		var $points = $poly.find('point');

		var tmpPts = [];
		$points.each(function(i, n){
			var x = $(n).find('x').text();
			var y = $(n).find('y').text();

			tmpPts.push({
				positionX: Math.round(parseFloat(x)*1000),
				positionY: Math.round(parseFloat(y)*1000)
			});
		});

		curRule.itsAidRulePolygon = {
			itsAidRulePolygonCoordinatesList:{
				itsAidRulePolygonCoordinates: tmpPts
			}	
		}
	}

	ITSTriggerMode._restoreRuleDirection = function (curRule) {
		var lineXml = HWP.GetSnapLineInfo();
		lineXml=parseXmlFromStr(lineXml);
		var tmp = false;
		$(lineXml).find('SnapLine').each(function(i, n){
			var $line = $(n);
			var id = $line.find('id').text();

			if (id == '1') {
				var sx = $line.find('StartPos').find('x').text();
				var sy = $line.find('StartPos').find('y').text();
				var ex = $line.find('EndPos').find('x').text();
				var ey = $line.find('EndPos').find('y').text();	
				
				tmp = {
					itsAidRuleFlowStartX: Math.round(parseFloat(sx)*1000),
					itsAidRuleFlowStartY: Math.round(parseFloat(sy)*1000),
					itsAidRuleFlowEndX: Math.round(parseFloat(ex)*1000),
					itsAidRuleFlowEndY: Math.round(parseFloat(ey)*1000)
				};

				return;
			};
		});

		if (tmp) {
			curRule.itsAidRuleFlowDirection = {
				itsAidRuleFlowDirEnable: "1",
				itsAidRuleFlowCoordinates: tmp
			};
		}else{
			curRule.itsAidRuleFlowDirection = {
				itsAidRuleFlowDirEnable: "0",
				itsAidRuleFlowCoordinates: {
					itsAidRuleFlowStartX: 0,
					itsAidRuleFlowStartY: 0,
					itsAidRuleFlowEndX: 0,
					itsAidRuleFlowEndY: 0
				}
			};
		}
	}

	ITSTriggerMode._drawRuleDirection = function (curRule) {
		var dir = curRule.itsAidRuleFlowDirection;
		if (!dir || !dir.itsAidRuleFlowDirEnable 
			|| dir.itsAidRuleFlowDirEnable == '0'
			|| !dir.itsAidRuleFlowCoordinates) {
			return;
		};

		var startX = startY = endX = endY = 0;
		var lf = dir.itsAidRuleFlowCoordinates;

		startX = parseInt(lf.itsAidRuleFlowStartX, 10);
		startY = parseInt(lf.itsAidRuleFlowStartY, 10);
		endX = parseInt(lf.itsAidRuleFlowEndX, 10);
		endY = parseInt(lf.itsAidRuleFlowEndY, 10);

		if (startY == 0 && startX == 0 && endX == 0 && endY == 0) {
			return;
		}

		var snapLines = {
			SnapLineList: {
				SnapLine:[]
			}
		};

		startX = (startX/1000).toFixed(3);
		startY = (startY/1000).toFixed(3);
		endX = (endX/1000).toFixed(3);
		endY = (endY/1000).toFixed(3);
		
		snapLines.SnapLineList.SnapLine.push({
			id: 1,
			LineType: 1,
			LineTypeEx: 1,
			ArrowType: 1,
			Tips:  '方向',
			StartPos: {
				x: startX,
				y: startY
			},
			EndPos: {
				x: endX,
				y: endY
			},
			color:  {r: 255, g: 0, b: 0}
		});

		if (snapLines.SnapLineList.SnapLine.length) {
			try{
				var szLineInfo = x2js.json2xml_str(snapLines);
				HWP.SetSnapLineInfo(szLineInfo);
			}catch(e){}
		}
	}

	ITSTriggerMode._ruleRegionPoints = function (curRule) {
		var pts = curRule.itsAidRulePolygon.itsAidRulePolygonCoordinatesList;
		if (!pts || !pts.itsAidRulePolygonCoordinates || !pts.itsAidRulePolygonCoordinates.length) {
			return [];
		};

		pts = pts.itsAidRulePolygonCoordinates;

		var ptArr = [];

		for (var i = 0; i < pts.length; i++) {
			var $p = pts[i];
			var x = parseInt($p.positionX, 10);
			var y = parseInt($p.positionY, 10);

			ptArr.push({
				x:(x/1000).toFixed(3),
				y:(y/1000).toFixed(3)
			});
		};

		return ptArr;
	}

	ITSTriggerMode._drawRuleRegion = function(curRule){
		this._drawRuleDirection(curRule);

		var ptArr = this._ruleRegionPoints(curRule);
		if (!ptArr.length) {
			return;
		};

		var obj = {
			SnapPolygonList:{
				SnapPolygon: [{
					id: 1,
					polygonType: 1,
					color: {r: 0, g: 255, b: 0},
					tips: '',
					isClosed: "true",
					PointNumMax:11,
					MinClosed:5,
					pointList: {
						point: ptArr
					}
				}]
			}
		};

		try{	
			var xml = x2js.json2xml_str(obj, true);
			HWP.SetSnapPolygonInfo(xml);

			HWP.SetSnapDrawMode(0, 4);
		}catch(e){}
	}



	ITSTriggerMode.restoreRule = function () {
		this.restoreOneRule();

		$('#RuleList li').each(function (i, n) {
			var $li = $(n);
			var ruleIdx = $li.attr('ruleIdx');
			var curRule = getRuleObject(ruleIdx);
			if (curRule) {
				curRule.itsAidRuleEnable = $li.find('.SceneEnable input:checkbox').prop('checked')?'1':'0';
				curRule.itsAidRuleName = $li.find(' .SceneIndex input').val();
				curRule.itsAidRuleType = $li.find(' select.bodyRuleType').val();

				if ($li.find(' .FilterEnable input').length) {
					curRule.sizeFilterEnable = $li.find(' .FilterEnable input').prop('checked') ? "1":"0";	
				};
			};
		});

		if (!this.jsonParam) {
			return;
		};

		originalXml = x2js.json2xml(this.jsonParam);
		$xml = $(originalXml);	
	}

	function changeRuleDetail (isHightWay, isRegion) {

		$('#OneRuleSet li[class$=List]').hide();
		if (isHightWay) {
			if (isRegion) {  // 多边形
				if($("#bInTunel").prop('checked')){
					$('#OneRuleSet').find('li.SmokeList').show();
				}
				$('#OneRuleSet').find('li.parkingList, li.wrongDirectionList, '+
					'li.trafficJamList, li.PersonThingList, li.ThrowThingList').show();
			}else{
				if(!$("#bInTunel").prop('checked')){
					$('#OneRuleSet').find('li.laneChangeList').show();
				}else{
					$("#dvRuleHead").hide();
				}
			}
		}else{
			if (isRegion) {  // 城市道路，多边形区域
				$('#OneRuleSet').find('li.parkingList, li.wrongDirectionList,li.DetectionVehicleList, '+
						'li.turnRoundList, li.trafficJamList,li.MachineForNonList').show();
			}else{
				$('#OneRuleSet').find('li.crossLaneList, li.laneChangeList,li.jumpQueueList').show();
			}
		}
	}

	function initRuleDetail (iIndex) {
		$("#laRuleNo").html(getNodeValue("laRuleNo").replace(/\[id\]/, iIndex));
		$("#laRuleNoCopy").html(getNodeValue("laRuleNoCopy").replace(/\[id\]/, iIndex));
		$("#laCopyRuleTo").html(getNodeValue("laCopyRuleTo").replace(/\[id\]/, iIndex));
		$("#main_plugin").hide();

		$("#RuleNumber").html("");
		var RuleLists = '';
		for(var i=0;i<8;i++) {
			var msg = '';
			if (i+1 == iIndex) {
				msg = ' checked="true" disabled="true" ';	
			};
			
			RuleLists += '<div><input type="checkbox" '+ msg +' ruleIdx="'+i+'" onclick="ITSTriggerMode.checkRuleSel()">' + 
							getNodeValue("laRule") + (i + 1) + '</div>';	
		}

		$("#RuleNumber").html(RuleLists);

		InitSlider2();
	}

	ITSTriggerMode.setRules = function (ruleIdx) {
		var rule = getRuleObject(ruleIdx);
		if (!rule) {
			return;
		};

		this.restoreOneRule();
		StopPlay();

		initRuleDetail(parseInt(ruleIdx)+1);

		var isRegion = $('#RuleList li[ruleIdx='+ruleIdx+'] select.bodyRuleType').val() == '1';

		var jsonParam = ITSTriggerMode.jsonParam;
		var isHightWay = jsonParam.ITS.ItsSceneDescription.bUrban == '0';

		changeRuleDetail(isHightWay, isRegion);		

		$("#OneRuleSet").data('ruleIdx', ruleIdx);

		$.each(["congestionDuration","parkingDuration","inverseDuration",
			"inverseAngleTolerance","inverseDistance","pedestrianDuration",
			"debrisDuration","overlineSensitive","overlineDuration",
			"crosslineSensitive","turnroundAngle", "forensicNum",
			"existDuration","triggerSensitive","jumpQueue","jumpQueueSensitive"], function (i, n) {
				var v = parseInt(rule[n]);
				$.g.setField2('#OneRuleSet #'+n, v);
			});

		var ruleTypes = rule.itsAidRuleEventType;
		if (!ruleTypes) {
			ruleTypes = 0;
		};

		$.each(["0x1","0x2","0x4","0x8","0x10","0x20","0x40","0x80","0x100","0x200","0x400","0x800"], function(i, n) {
			var v = parseInt(n, 16);
			$.g.setField2('input[vio-type='+n+']', ruleTypes & v ? "true" : "false");
		});

		initCheckboxStates();

		$("#OneRuleSet").modal();
	}

	ITSTriggerMode.changeVioType = function () {
		initCheckboxStates();
	}

	function initCheckboxStates () {
		$('input[vio-type]').each(function () {
			var t = $(this).attr('vio-type');

			var ch = !$(this).prop('checked');
			DisableSlider('li[rel-vio='+t+'] div[slider]', ch);
		});
	}

	ITSTriggerMode.setCopyAll = function () {
		$('#RuleNumber input[ruleIdx]').prop('checked', $("#SelectRule").prop('checked'));
	}

	ITSTriggerMode.checkRuleSel = function () {
		var allChecked = true;

		$('#RuleNumber input[ruleIdx]').each(function () {
			if (!$(this).prop('checked')) {
				allChecked = false;
				return;
			};
		});

		$('#SelectRule').prop('checked', allChecked);
	}

	ITSTriggerMode.setRulesCancel = function () {
		$("#main_plugin").show();
		PlayView();
		this.updateOneRule();
		$.modal.impl.close();
	}

	ITSTriggerMode._setOneRuleOk = function (ruleIdx) {
		var rule = getRuleObject(ruleIdx);
		if (!rule) {
			return;
		};

		$.each(["congestionDuration","parkingDuration","inverseDuration",
			"inverseAngleTolerance","inverseDistance","pedestrianDuration",
			"debrisDuration","overlineSensitive","overlineDuration",
			"crosslineSensitive","turnroundAngle", "forensicNum",
			"existDuration","triggerSensitive","jumpQueue","jumpQueueSensitive"], function (i, n) {
				if($('#OneRuleSet #'+n).is(":hidden")){

				}else{
					var v = GetSliderValue(n);
					if (v != '') {
						rule[n] = v;	
					};	
				}
			});

		var ruleTypes = 0;

		$.each(["0x1","0x2","0x4","0x8","0x10","0x20","0x40","0x80","0x100","0x200","0x400","0x800"], function(i, n) {
			var ele = $('input[vio-type='+n+']');
			if (ele.prop('checked') && !ele.is(":hidden")) {
				var v = parseInt(n, 16);
				ruleTypes |= v;
			};
		});

		rule.itsAidRuleEventType = ruleTypes;
	}

	ITSTriggerMode.setRulesOk = function () {
		var self = this;
		$('#RuleNumber input[ruleIdx]:checked').each(function (i, n) {
			var ruleIdx = $(this).attr('ruleIdx');
			if (typeof ruleIdx != 'undefined') {
				self._setOneRuleOk(ruleIdx);	
			};
		});

		$("#main_plugin").show();
		PlayView();
		this.updateOneRule();
		$.modal.impl.close();
	}

	ITSTriggerMode.SetDirection = function () {
		HWP.ClearSnapInfo(2);
		SetDirection();
	}

	ITSTriggerMode.SetOnePolygon = function () {
		HWP.ClearSnapInfo(2);
		SetOnePolygon();
	}

	ITSTriggerMode.SetOneBreakLine = function () {
		HWP.ClearSnapInfo(2);
		SetOneBreakLine();
	}

	ITSTriggerMode.SetParam = function () {
		SetParam();
	}

	ITSTriggerMode.GetCmdParam = function () {
		GetParam(true);
	}

	ITSTriggerMode.changeFilterMode = function () {
		var mode = $('#sizeFilterMode').val();

		var rule = getRuleObject();
		if (!rule) {
			return;
		};
		rule.sizeFilterMode = mode;

		dispFilterMode(mode, rule);
	}

	function dispFilterMode (mode, rule) {
		$('#filterDiv  .filterDiv').hide();

		if (mode == '0') {// px
			$('#filterMode0Size').show();
			drawFilterRect(rule);

		}else if (mode == '1') { // real
			$('#filterMode1Size').show();
			clearFilterRect(rule);

			if (rule) {
				$.g.setField2('#filterMode1_Min input:eq(0)', (rule.sizeFilterMinRect.sizeFilterMinRectW/1000).toFixed(2));
				$.g.setField2('#filterMode1_Min input:eq(1)', (rule.sizeFilterMinRect.sizeFilterMinRectH/1000).toFixed(2));
				$.g.setField2('#filterMode1_Max input:eq(0)', (rule.sizeFilterMaxRect.sizeFilterMaxRectW/1000).toFixed(2));
				$.g.setField2('#filterMode1_Max input:eq(1)', (rule.sizeFilterMaxRect.sizeFilterMaxRectH/1000).toFixed(2));	
			};
		};
	}

	function restoreFilterSize (curRule) {
		if ($('#filterDiv').is(":hidden") || !curRule) {
			return;
		};

		if (curRule.sizeFilterMode == '1') { // real
			var minW = parseFloat($('#filterMode1_Min input:eq(0)').val())*1000;
			var minH = parseFloat($('#filterMode1_Min input:eq(1)').val())*1000;
			var maxW = parseFloat($('#filterMode1_Max input:eq(0)').val())*1000;
			var maxH = parseFloat($('#filterMode1_Max input:eq(1)').val())*1000;

			minW = minW ? minW : 0;
			minH = minH ? minH : 0;
			maxW = maxW ? maxW : 0;
			maxH = maxH ? maxH : 0;

			// if (_.some([minW, minH, maxW, maxH], function (n) {
			// 	return (!n && n != 0);
			// })) {
			// 	return;
			// };
			
			curRule.sizeFilterMinRect.sizeFilterMinRectW = minW;//.toFixed(2);
			curRule.sizeFilterMinRect.sizeFilterMinRectH = minH;//.toFixed(2);
			curRule.sizeFilterMaxRect.sizeFilterMaxRectW = maxW;//.toFixed(2);
			curRule.sizeFilterMaxRect.sizeFilterMaxRectH = maxH;//.toFixed(2);
			return;	
		};

		if (curRule.sizeFilterMode == '0') { // px
			
			var xml = HWP.GetSnapPolygonInfo();
			xml=parseXmlFromStr(xml);
			$(xml).find('SnapPolygon').each(function (i, n) {
				var $p = $(n);
				var id = $p.find('id').eq(0).text();

				if (id != '1001' && id != '1002') {
					return true;
				};

				var pts = [];
				$p.find('point').each(function (ii, nn) {
					var $pt = $(nn);
					pts.push({
						x: parseFloat($pt.find('x').text())*1000,
						y: parseFloat($pt.find('y').text())*1000
					});
				});

				if (pts.length != 4) {
					return true;
				};
	
				var sx = Math.min(pts[0].x, pts[1].x, pts[2].x);
				var sy = Math.min(pts[0].y, pts[1].y, pts[2].y);

				var ex = Math.max(pts[0].x, pts[1].x, pts[2].x);
				var ey = Math.max(pts[0].y, pts[1].y, pts[2].y);

				var width = ex - sx;
				var height = ey - sy;

				if (id == '1001') {
					curRule.sizeFilterMinRect = {
						sizeFilterMinRectX: sx,
						sizeFilterMinRectY: sy,
						sizeFilterMinRectW: width,
						sizeFilterMinRectH: height
					};
				}else if (id == '1002') {
					curRule.sizeFilterMaxRect = {
						sizeFilterMaxRectX: sx,
						sizeFilterMaxRectY: sy,
						sizeFilterMaxRectW: width,
						sizeFilterMaxRectH: height
					};
				};
			});

			return;	
		}
	}

	function drawFilterRect (rule) {
		clearFilterRect();

		var ptArr1 = [];
		var ptArr2 = [];

		if (rule.sizeFilterMinRect) {
			var left = parseInt(rule.sizeFilterMinRect.sizeFilterMinRectX, 10);
			var top = parseInt(rule.sizeFilterMinRect.sizeFilterMinRectY, 10);
			var w = parseInt(rule.sizeFilterMinRect.sizeFilterMinRectW, 10);
			var h = parseInt(rule.sizeFilterMinRect.sizeFilterMinRectH, 10);
			var cLeft = (left/1000).toFixed(3);
			var cTop = (top/1000).toFixed(3);
			var cRight = ((left + w)/1000).toFixed(3);
			var cBottom = ((top+h)/1000).toFixed(3);
			ptArr1 = [{
				x: cLeft,
				y: cTop
			},{
				x: cRight,
				y: cTop
			},{
				x: cRight,
				y: cBottom
			},{
				x: cLeft,
				y: cBottom
			}];	
		};

		if (rule.sizeFilterMaxRect) {
			var left = parseInt(rule.sizeFilterMaxRect.sizeFilterMaxRectX, 10);
			var top = parseInt(rule.sizeFilterMaxRect.sizeFilterMaxRectY, 10);
			var w = parseInt(rule.sizeFilterMaxRect.sizeFilterMaxRectW, 10);
			var h = parseInt(rule.sizeFilterMaxRect.sizeFilterMaxRectH, 10);

			var cLeft = (left/1000).toFixed(3);
			var cTop = (top/1000).toFixed(3);
			var cRight = ((left + w)/1000).toFixed(3);
			var cBottom = ((top+h)/1000).toFixed(3);
			
			ptArr2 = [{
				x: cLeft,
				y: cTop
			},{
				x: cRight,
				y: cTop
			},{
				x: cRight,
				y: cBottom
			},{
				x: cLeft,
				y: cBottom
			}];	
		};

		var obj = {
			SnapPolygonList:{
				SnapPolygon: []
			}
		};

		if (ptArr1.length == 4) {
			obj.SnapPolygonList.SnapPolygon.push({
				id: 1001,
				polygonType: 0,
				color: {r: 255, g: 0, b: 0},
				tips: '小',
				isClosed: "true",
				pointList: {
					point: ptArr1
				}
			});
		}

		if (ptArr2.length == 4) {
			obj.SnapPolygonList.SnapPolygon.push({
				id: 1002,
				polygonType: 0,
				color: {r: 255, g: 0, b: 0},
				tips: '大',
				isClosed: "true",
				pointList: {
					point: ptArr2
				}
			});
		}

		try{	
			var xml = x2js.json2xml_str(obj, true);
			HWP.SetSnapPolygonInfo(xml);

			HWP.SetSnapDrawMode(0, 4);
		}catch(e){}
	}

	function clearFilterRect () {
		HWP.ClearSnapInfo(0);
		HWP.SetSnapDrawMode(0, 4);
	}


	window.ITSTriggerMode = ITSTriggerMode;
	window.PlayView = PlayView;
	
})();

function DrawMinFilter  () {
	var obj = {
		SnapPolygonList:{
			SnapPolygon: [{
				id: 1001,
				polygonType: 0,
				color: {r: 255, g: 0, b: 0},
				tips: '小',
				isClosed: "false",
				pointList: {}
			}]
		}
	};

	try{	
		var xml = x2js.json2xml_str(obj, true);
		HWP.SetSnapPolygonInfo(xml);

		HWP.SetSnapDrawMode(1);
	}catch(e){}

}

function DrawMaxFilter () {
	var obj = {
		SnapPolygonList:{
			SnapPolygon: [{
				id: 1002,
				polygonType: 0,
				color: {r: 255, g: 0, b: 0},
				tips: '大',
				isClosed: "false",
				pointList: {}
			}]
		}
	};


	try{	
		var xml = x2js.json2xml_str(obj, true);
		HWP.SetSnapPolygonInfo(xml);

		HWP.SetSnapDrawMode(1);
	}catch(e){}
}








