var m_iCurSelIONum = 1;
var m_iLastSelIONum = 0;
var m_iCurSelDetectIONum = 1;
var m_iLastSelDetectIONum = 1;
var m_iMainWndWidth = 704;
var m_iMainWndHeight = 576;
var m_szVideoEpoliceXmlDoc = null;
var VEPRadarSupport = false;

//var sliderRadarSensitivity = null;

var dontSave = true;
function insertOption2Select(szCapabilitySet, szOptionalSet, szOptionIds, szSelectId) {
	$.each(szCapabilitySet, function(i, szCapability) {
		var index = $.inArray(szCapability, szOptionalSet);
		if (index !== -1) {
			$("<option id='" + szOptionIds[index] + "' name='" + szOptionIds[index] + "' value='" + szCapability +"'></option>").appendTo("#" + szSelectId);
		}
		else {
			if (szOptionalSet[szOptionalSet.length - 1] === "*") {
				$("<option id='" + szOptionIds[szOptionalSet.length - 1] + "' name='" + szOptionIds[szOptionalSet.length - 1] + "' value='" + szCapability +"'></option>").appendTo("#" + szSelectId);
			}
		}
	});
}
/*************************************************
触发模式类
*************************************************/
function TriggerMode() {
	this.m_CurTriggerMode = 0;
	this.m_CurEnabledMode = 0;

	this.m_iTriggerIONum = 0;
	this.m_iSyncOutNum = 0;
	this.m_PostSingleIOXml = null;
	this.m_PlateRecognitionXml = null;
	this.m_epoliceIOTLXml = null;
	this.m_Post485Xml = null;
	this.m_epoliceIOTLXml = null; 
	this.m_epoliceRS485Xml = null;
	this.m_PostVTCoilXml = null;
	this.m_VideoEpoliceXml = null;
	this.m_PostMprXml = null;
	this.m_videoMonitorXml = null;
	this.m_postHVTXml = null;

	this.m_bSetTriggerMode = false;
	this.m_bRebootRequired = false;
	this.m_iLastSignalNum = 1;
	this.m_strSelLineNum = "";
	this.m_strLineType = new Array();
    this.m_ioSpeedSyncCount = 0;
	this.m_strCommonLineType = new Array("white","white","white");
    this.m_CurBackUpMode = -1;
    this.radarRS485Num=0;
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(TriggerMode);

(function() { // 触发模式配置

    pr(TriggerMode).initCSS = function(){
    }
    
    TriggerMode.prototype.updateLang = function () {
    	g_transStack.clear();
		var that = this;
		g_transStack.push(function() {
			that.setLxd(parent.translator.getLanguageXmlDoc("TriggerMode"));
			parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
			parent.translator.translatePage(that.getLxd(), document);
			$("#FullScreenbutton").attr("title", getNodeValue("FullScreenExitTips"));
		}, true);
    }

	TriggerMode.prototype.update = function () {
		$('#SetResultTips').html('');
		$("#SaveConfigBtn").show();
		HWP.Stop(0);
		g_transStack.clear();
		var that = this;
		g_transStack.push(function() {
			that.setLxd(parent.translator.getLanguageXmlDoc("TriggerMode"));
			parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
			parent.translator.translatePage(that.getLxd(), document);
			$("#FullScreenbutton").attr("title", getNodeValue("FullScreenExitTips"));
		}, true);

        pr(TriggerMode).initCSS();

		var szInfo = getNodeValue('laPlugin');
		if(!checkPlugin('1', szInfo, 1, 'snapdraw')) {
			return;
		}
		
		if(!CompareFileVersion()) {
			UpdateTips();
		}
		
		ia(DeviceInfo).queryChannelInfo(); //用于获取通道信息
		m_iPicinform = 1;
	
		//setTimeout(function() {
			if (HWP.Play() !== 0) {
				alert(getNodeValue("previewfailed"));
			}
		//}, 10);
		//获取支持的触发模式及当前触发模式
		pr(TriggerMode).GetSupportTriggerMode();
		
		//获取IO输入及输出个数
		this.m_iTriggerIONum = pr(DeviceInfo).queryAlarmInNum();
		this.m_iSyncOutNum = pr(DeviceInfo).queryAlarmOutNum();
		
		pr(TriggerMode).changeTriggerMode(this.m_CurTriggerMode);
        ia(TriggerMode).changeSnapTime();
        
		autoResizeIframe();
	}
	/*************************************************
	Function:		GetSupportTriggerMode
	Description:	获取设备支持的触发模式及当前模式
     Input:			无
     Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.GetSupportTriggerMode = function () {
		// $.ajax({
		// 	type: "GET",
		// 	url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/TriggerMode/capabilities",
		// 	async: false,
		// 	timeout: 15000,
		// 	beforeSend: function(xhr) {
		// 		xhr.setRequestHeader("If-Modified-Since", "0");
		// 		
		// 	},
		// 	success: function(xmlDoc, textStatus, xhr){
		// 		var szTriggerModeOptions = $(xmlDoc).find('usedTriggerMode').eq(0).attr("opt").split(",");

		// 		// test
		// 		// szTriggerModeOptions = ["postIOSpeed","postSingleIO","postRS485","postRadar",
		// 		// 		"postVTCoil","epoliceIOTL","epoliceRS485","postEpoliceRS485",
		// 		// 		"videoEpolice","PostMpr", "videoMonitor", "postHVT"];

		// 		insertOption2Select(szTriggerModeOptions, 
		// 			["postIOSpeed","postSingleIO","postRS485","postRadar",
		// 				"postVTCoil","epoliceIOTL","epoliceRS485","postEpoliceRS485",
		// 				"videoEpolice","PostMpr", "videoMonitor", "postHVT"], 
		// 			["apostIOSpeed","apostSingleIO","apostRS485","apostRadar",
		// 				"apostVTCoil","aepoliceIOTL","aepoliceRS485","apostEpoliceRS485",
		// 				"avideoEpolice","aPostMpr", "avideoMonitor", "apostHVT"], 
		// 			"selTriggerMode");

		// 		if (!_.contains(szTriggerModeOptions, "postVTCoil")) {
		// 			$('#backupModeOpts').find('option[value=1]').remove();
		// 			if ($('#backupModeOpts').find('option').length == 1) {
		// 				$('#triggerBackupModelDiv').hide();
		// 				$('#postRS485_switchModeTime_Wrapper').hide();
		// 			};
		// 		};

		// 		setValueDelayIE6("selTriggerMode", xmlDoc, "usedTriggerMode");
		// 		ia(TriggerMode).m_CurTriggerMode = $(xmlDoc).find("usedTriggerMode").eq(0).text();
		// 		$("#CurTriggerMode").html(getNodeValue("a" + ia(TriggerMode).m_CurTriggerMode));
		// 		g_transStack.translate();
		// 	}
		// });
	}

	/**
	 *  生成单IO触发的checkbox
	 */
	function genSingleIoCheckBoxes (alarmInNum) {
		if (alarmInNum < 0) {
			return;
		}
		var $d = $('#singleIoCheckBoxesDiv');
		$d.find('div.singleIo_checkbox_div').remove();
		for (var i = 0; i < alarmInNum; i++) {
			var nodev = getNodeValue('lasingleIocheckbox'+(i+1));
			var arr = ["<div class='singleIo_checkbox_div'>",
                "<input id='singleIo_checkbox_"+(i+1)+"' ioIdx='"+(i+1)+"' type='checkbox' class='singleIo_checkbox'/>",
                "<label for='singleIo_checkbox_"+(i+1)+"' id='lasingleIocheckbox"+(i+1)+"' class='singleIo_checkbox'>"+nodev+"</label>",
            "</div>"];
            $d.append(arr.join(''));
		};
	}

	/**
	 * 初始化单IO触发CheckBox的事件
	 * @return 
	 */
	function initSingleIoCheckBoxEvent() {
		$('#singleIoCheckBoxesDiv').find('input.singleIo_checkbox').click(function () {
			var chk = $(this).prop('checked');
			var ioIdx = $(this).attr('ioIdx');
			
			if (chk) {
				//var nodev = getNodeValue('lasingleIocheckbox'+ioIdx);
				var nodev = 'T'+ioIdx;
				$('#tabTriggerIO').append([
					'<li ioIdx="'+ioIdx+'" id="liT'+ioIdx+'">',
					'<a onclick="pr(TriggerMode).selectPostSingleIO('+(ioIdx-1)+')">'+nodev+'</a></li>'
				].join(''));
			}else{
				$('#tabTriggerIO').find('li[ioIdx="'+ioIdx+'"]').remove();
			}

			var l = $('#singleIoCheckBoxesDiv input.singleIo_checkbox:checked').length;
			if (l >= 4){
				$('#singleIoCheckBoxesDiv input.singleIo_checkbox').not(':checked').attr('disabled', true);
			}else{
				$('#singleIoCheckBoxesDiv input.singleIo_checkbox').not(':checked').removeAttr('disabled');
			}
			if (l == 0) {
				$('#dvTriggerParam').find('div.triggerpanes').css('display', 'none');
			}else{
				$('#dvTriggerParam').find('div.triggerpanes').css('display', 'block');
			}

			SortSingleIoDom();

			if ($('#tabTriggerIO li').find('a:not(:hidden)').filter('.current').length == 0) {
				var idx = $('#tabTriggerIO li').first().attr('ioIdx')-1;
				pr(TriggerMode).selectPostSingleIO(idx, dontSave);
			}else{
				ResetSingleIoCopy();
			}			

			SingleIoReDisplay();
		});
	}



	/**
	 * Dom 排序
	 */
	function SortSingleIoDom () {
		var $tabs = $('#tabTriggerIO li');
		
		$tabs.detach();

		var tabArr = $tabs.toArray();
		tabArr.sort(function (a, b) {
			var ai = $(a).attr('ioIdx');
			var bi = $(b).attr('ioIdx');
			return ai - bi;
		});

		for (var i = 0; i < tabArr.length; i++) {
			$('#tabTriggerIO').append(tabArr[i]);
		};
	}

	function ResetSingleIoCopy () {
		$('#singleIoCopyDiv').find('div.singleIo_checkbox_copy_div').remove();
		$('#tabTriggerIO li').each(function () {
			var disStr = "";
			if ($(this).find('a').first().is('.current')) {
				disStr = ' disabled="disabled" checked="checked" ';
			}

			var ioIdx = $(this).attr('ioIdx');
			var arr =  [
			'<div class="singleIo_checkbox_copy_div">',
				'<input id="singleIo_copy_checkbox_'+ioIdx+'" ioIdx="'+ioIdx+'" type="checkbox" ',
				disStr,
				'class="singleIo_checkbox"><label for="singleIo_copy_checkbox_'+ioIdx+'" ',
				' class="singleIo_checkbox">'+("T"+ioIdx)+'</label></div>'];

			$('#singleIoCopyDiv').append(arr.join(''));	
		});
	}

	
	/*************************************************
	Function:		changeTriggerMode
	Description:	切换触发模式
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.changeTriggerMode = function (strTriggerMode) {
		ia(TriggerMode).m_CurTriggerMode = strTriggerMode;
		if(!strTriggerMode){
			return;
		}
		if(TriggerModeExt.changeTriggerModeExt(strTriggerMode)){
			return;
		}
		
		$("#CurTriggerMode").html(getNodeValue("a" + ia(TriggerMode).m_CurEnabledMode));

		var showPlateRegionbtnValue;
		if (strTriggerMode == 'postHVT') {
			$('#showPlateRegionbtn').hide();
			$('#showPlateRegionbtnHVT').show();	
		}else{
			$('#showPlateRegionbtnHVT').hide();
			$('#showPlateRegionbtn').show();
		}

		if (showPlateRegionbtnValue) {
			$('#showPlateRegionbtn').val(showPlateRegionbtnValue);
		}

		$("#DrawVTCoilRegionbtn").css("display", "none");
        $('#drawRightRegionContent').css("display","none");
        $('#relatedLaneCountContentDiv').show();
        $('#showAllPicSpan').show();

        if(strTriggerMode == 'postRS485'){
        	if ($('#backupModeOpts').find('option').length > 1) {
				$('#triggerBackupModelDiv, #postRS485_switchModeTime_Wrapper').show();
			}else{
				$('#triggerBackupModelDiv, #postRS485_switchModeTime_Wrapper').hide();	
			}
        }else{
            $('#triggerBackupModelDiv, #postRS485_switchModeTime_Wrapper').hide();
        }
		var szInfo = "dv" + strTriggerMode;
		if(strTriggerMode == "postEpoliceRS485") {
			szInfo = "dvepoliceRS485";
		}
		if(strTriggerMode == "postRadar") {
			szInfo = "dvpostRS485";
		}

		$("#dvTriggerParam").html($("#" + szInfo).html());
		$("#laTriggerParam").html(getNodeValue(strTriggerMode + "Title"));

		var szDivInfo = "";
		for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
            if(i == 3 || i == 6){
                szDivInfo += "<br>";
            }
			szDivInfo += "<div style='display:inline-block;margin-bottom:7px;'><input class='checkbox' name='AlarmOutputCheckbox' id='AlarmOutputCheckboxChanO-"+ (i + 1)+"' type='checkbox'>&nbsp;"+"F" + (i + 1) + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>";
		}
		$("#DisPlayLinkageList").html(szDivInfo); 
		$("#IsDispalyRegion").prop("checked", false);
		
		if(strTriggerMode == "postRadar" || strTriggerMode == "postVTCoil") {
			$("#dvRadar").css("display", "block");
		} else {
			$("#dvRadar").css("display", "none");
		}
		if(strTriggerMode == "videoEpolice") {
			$("#dvSignalLight").css("display", "block");
			$("#dvDrawLineBtn1").css("display", "block");
			$("#dvDrawLineBtn2").css("display", "block");
			$("#dvLineType").css("display", "inline-block");
			$("#CommendParamBtn").css("display", "none");
		} else {
			$("#dvSignalLight").css("display", "none");
			$("#dvDrawLineBtn1").css("display", "none");
			$("#dvDrawLineBtn2").css("display", "none");
			$("#dvLineType").css("display", "none");
			$("#lineType").css("display", "none");
			$("#CommendParamBtn").css("display", "inline-block");
		}
		pr(TriggerMode).GetPlateRecognition(strTriggerMode, 0);

		if (strTriggerMode == 'videoEpolice') {
			$('#videoep_g_params_div').show();
			$("#posting_videoEpolice").show();
		}else{
			$('#videoep_g_params_div').hide();
			$("#posting_videoEpolice").hide();
		}

		if (strTriggerMode == 'postHVT') {
			$('#postHVT_g_params_div').show();
		}else{
			$('#postHVT_g_params_div').hide();
		}
		
		switch(strTriggerMode) {
			case "postSingleIO":
				var tn =  parseInt(ia(TriggerMode).m_iTriggerIONum);
				genSingleIoCheckBoxes(tn);
				initSingleIoCheckBoxEvent();
			    var iIndex = tn + 1;
                $('#relatedLaneCountContentDiv').hide();
				pr(TriggerMode).GetPostSingleIOParam(0);
				autoResizeIframe();
			    break;
			case "postIOSpeed": //卡口IO测速
				$("#firstCoilIO").empty();
				$("#secondCoilIO").empty();
                $('#relatedLaneCountContentDiv').hide();
                $('#drawRightRegionContent').show();
                $('#drawRightRegionContent').html($('#carSpeedException_IOSpeed').html());
				for(var i = 1;i <= ia(TriggerMode).m_iTriggerIONum; i++) {
				    $("<option value='IO"+ i +"'>T"+ i +"</option>").appendTo("#firstCoilIO");
					$("<option value='IO"+ i +"'>T"+ i +"</option>").appendTo("#secondCoilIO");
			    }
			    pr(TriggerMode).GetpostIOSpeedParam(0);
			    autoResizeIframe();
			    break;
			case "postRS485": //卡口车检器

			     $("#dvOSDDriveWay").show();
                 $("#dvnormalTrigger_post485").show();
				 $("#dvmaxSwitchTime").show();
				 $("#dvbigCarSignSpeed").show();
				 $("#dvbigCarSpeedLimit").show();
                 $('#advanceSetting_post485').show();
                 $('#radarConfigDetail').hide();
                 $('#laneDistanceDetail').hide();
                 $('#delayTimeDetail').hide();
                 $('#delayDistanceDetail').hide();
                $('#drawRightRegionContent').show();
                $('#drawRightRegionContent').html($('#carSpeedException_485').html());

                ia(TriggerMode).m_CurBackUpMode = 0;
				pr(TriggerMode).Getpost485Param(strTriggerMode, 0);
                TriggerMode.prototype.changeBackupMode($('#backupModeOpts').val());
                autoResizeIframe();
				 break;
			case "postRadar": //卡口RS485雷达
                $("#dvOSDDriveWay").hide();
				$("#dvbackupMode").hide();
                $("#dvnormalTrigger_post485").hide();
				$("#dvmaxSwitchTime").hide();
                $('#advanceSetting_post485').hide();
				$("#dvbigCarSignSpeed").show();
				$("#dvbigCarSpeedLimit").show();
                $('#radarConfigDetail').show();
                $('#laneDistanceDetail').show();
                $('#delayTimeDetail').show();
                $('#delayDistanceDetail').show();
                $('#drawRightRegionContent').show();
                $('#drawRightRegionContent').html($('#carSpeedException_485').html());
				pr(TriggerMode).Getpost485ParamCap();
			    pr(TriggerMode).Getpost485Param(strTriggerMode, 0);
                autoResizeIframe();
				break;
			case "epoliceIOTL":
			    $("#lightIO").empty();
				$("#triggerIO").empty();
				for(var i = 1;i <= ia(TriggerMode).m_iTriggerIONum; i++) {
				    $("<option value='IO"+ i +"'>T"+ i +"</option>").appendTo("#lightIO");
					$("<option value='IO"+ i +"'>T"+ i +"</option>").appendTo("#triggerIO");
			    }
			    pr(TriggerMode).GetepoliceIOTLParam(0);
				break;
			case "epoliceRS485": //电警车检器
				 pr(TriggerMode).GetepoliceRS485Param(strTriggerMode, 0);
				 break;
			case "postEpoliceRS485":
                // $('#drawRightRegionContent').show();
                $('#drawRightRegionContent').html($('#carSpeedException_epolice').html());
			    pr(TriggerMode).GetepoliceRS485Param(strTriggerMode, 0);
				break;
			case "postVTCoil": //虚拟线圈
			    $("#DrawVTCoilRegionbtn").css("display", "");
                $('#drawRightRegionContent').css("display","block");
                $('#drawRightRegionContent').html($('#rightPostVTContent').html());

				pr(TriggerMode).GetVTCoilParamCap();
			    pr(TriggerMode).GetVTCoilParam(0);
				break;
			case "videoEpolice": //视频电警
				$("#relatedIO_1, #relatedIO_2, #relatedIO_3").empty();
				$("#relatedIO_1, #relatedIO_2, #relatedIO_3").each(function () {
					$(this).append("<option value='NON_IO'>无</option>");
					for(var i = 1;i <= ia(TriggerMode).m_iTriggerIONum; i++) {
						$(this).append("<option value='IO"+ i +"'>IO"+ i +"</option>");
				    }	
				});
				
			    pr(TriggerMode).GetVideoEpoliceLaneCount();
			    pr(TriggerMode).GetvideoEpoliceParam(0);
				break;
			case "PostMpr": //出入口视频
				pr(TriggerMode).GetPostMprParamCap();
			     pr(TriggerMode).GetPostMprParam(strTriggerMode, 0);
				 pr(TriggerMode).selectLaneCount(0);
				 break;
			case "videoMonitor":
				pr(TriggerMode).GetVideoMonitorParam(strTriggerMode, 0);
				$('#relatedLaneCountContentDiv').hide();	
				$('#showAllPicSpan').hide();	
				break;
			// case "postHVT":
   //              $('#drawRightRegionContent').css("display","block");
   //              $('#drawRightRegionContent').html($('#rightPostHVTContent').html());

			// 	pr(TriggerMode).GetPostHVTParamCap();
			//     pr(TriggerMode).GetPostHVTParam(0);
			//     break;
			default:
			    break;
		}

		if (strTriggerMode == 'postRadar') {
			$('#dvTriggerParam #laRelatedDriveWay1').text(getNodeValue("laRelatedDriveWay1"));
		}else{
			$('#dvTriggerParam #laRelatedDriveWay1').text(getNodeValue("laRelatedDriveWay"));
		};

		autoResizeIframe();
	}
	/*************************************************
	Function:		GetPostSingleIOParam
	Description:	获取单IO触发参数
	Input:			iValueType: 0 实际值 1 推荐值			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.GetPostSingleIOParam = function (iValueType) {
		var szUrl = "/PSIA/Custom/SelfExt/ITC/postSingleIO";
		if(iValueType == 1) {
			szUrl += "/recommendation";
		}
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + szUrl,
			timeout: 15000,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				ia(TriggerMode).m_PostSingleIOXml = xmlDoc;

				dontSave = true;

				$('#singleIoCheckBoxesDiv input[ioIdx]').prop('checked', false);//.click().prop('checked', false);
				$('#tabTriggerIO').find('li[ioIdx]').remove();
				$('#dvTriggerParam').find('div.triggerpanes').css('display', 'none');

				m_iCurSelIONum = 0;
				m_iLastSelIONum = 1;

				var firstIdx = -1;
				var checkedCount = 0;
				$(xmlDoc).find('PostSingleIO').each(function(i,n) {
					var $p = $(n);
					var ioIn = $p.find('relatedIOIn').text();
					var idx = ioIn.replace('IO', "");
					if ($p.find('enable').text().toLowerCase() == 'true') {
						$('#singleIoCheckBoxesDiv input[ioIdx='+idx+']').prop('checked', true).click().prop('checked', true);
						checkedCount++;

						firstIdx = parseInt(idx);

						if (checkedCount >= 4) {
							return;
						}
					}
				});
				dontSave = false;

				autoResizeIframe();
				// $("#DefaultStatus").val($(xmlDoc).find("defaultStatus").eq(0).text());
				// $("#RelatedDriveWay").val($(xmlDoc).find("relatedDriveWay").eq(0).text());
				// $("#SnapTimes").val($(xmlDoc).find("snapTimes").eq(0).text());
				// $("#IntervalType").val($(xmlDoc).find("intervalType").eq(0).text());
				// changeIntervalType($("#IntervalType").val());
				// for(var i = 1; i < 5; i++){
				// 	$("#Interval" + i).val("0");
				// }
				// for(var i = 2; i <= $("#SnapTimes").val(); i++) {
				// 	$("#Interval" + (i-1)).val($(xmlDoc).find("PostSingleIO").eq(0).find("value").eq(i - 2).text());
				// }
				// for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
				// 	$("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked",$(xmlDoc).find("PostSingleIO").eq(0).find("enabled").eq(i).text() === "true" ? true : false);
				// }
				// $("#FlashMode").val($(xmlDoc).find("flashMode").eq(0).text());
				
			}
		});

		autoResizeIframe();
	}
	/*************************************************
	Function:		SetPostSingleIOParam
	Description:	设置触发模式
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.SetPostSingleIOParam = function () {
        ia(TriggerMode).m_bSetTriggerMode = false;
	    //保存当前tab页的值
	    var $xmlDoc = $(ia(TriggerMode).m_PostSingleIOXml);

	    var $trigDiv = $('#taTriggerMode #postSingleIoTriggerPanes');

		var iIndex = parseInt(m_iCurSelIONum) - 1;
		var iLastSnapTime = $xmlDoc.find("snapTimes").eq(iIndex).text();
		//$xmlDoc.find("laneDirectionType").eq(iIndex).text($trigDiv.find("#laneDirectionType_postSingleIO").val());
		$xmlDoc.find("defaultStatus").eq(iIndex).text($trigDiv.find("#DefaultStatus").val());
		$xmlDoc.find("relatedDriveWay").eq(iIndex).text($trigDiv.find("#RelatedDriveWay").val());
		$xmlDoc.find("snapTimes").eq(iIndex).text($trigDiv.find("#SnapTimes").val());
		$xmlDoc.find("intervalType").eq(iIndex).text($trigDiv.find("#IntervalType").val());
		
		$xmlDoc.find("laneUsage").eq(iIndex).text($trigDiv.find("#useageType").val());

		if(iLastSnapTime == 0) {
			iLastSnapTime = 1;
		}
		

		var tmpObj = x2js.xml_str2json(xmlToStr(ia(TriggerMode).m_PostSingleIOXml));

		if (tmpObj) {
			var theLaneArr = tmpObj['PostSingleIOList']['PostSingleIO_asArray'];
			var theLane = null;
			for (var i = 0; i < theLaneArr.length; i++) {
				var lane = theLaneArr[i];
				if (lane['relatedIOIn'] == "IO"+(iIndex+1)) {
					theLane = lane;
				};
			};
			if (theLane) {
				theLane.IntervalList = {
					Interval: []
				}

				for(var i = 1; i < $("#SnapTimes").val(); i++) {
					var v = $trigDiv.find("#Interval" + i).val();
					theLane.IntervalList.Interval.push({
						value: v
					});
				}	
			};
			
			ia(TriggerMode).m_PostSingleIOXml = x2js.json2xml(tmpObj);
		};

		// for(var i = 1; i < iLastSnapTime; i++) {
		// 	$(ia(TriggerMode).m_PostSingleIOXml).find("PostSingleIO").eq(iIndex).find("value").eq(i - 1).text($trigDiv.find("#Interval" + i).val());
		// }

		// for(var i = iLastSnapTime; i < $("#SnapTimes").val(); i++) {
		// 	$(ia(TriggerMode).m_PostSingleIOXml).find("PostSingleIO").eq(iIndex).
		// 			find("IntervalList").eq(0).
		// 			append(
		// 				$(parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><Tmp><Interval><value>'+
		// 						$trigDiv.find("#Interval" + i).val()+'</value></Interval></Tmp>')
		// 				).find("Tmp").eq(0).clone().children()
		// 			);
		// }
		
		for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
			$(ia(TriggerMode).m_PostSingleIOXml).find("PostSingleIO").eq(iIndex).find("enabled").eq(i).text($trigDiv.find("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked").toString());
		}
		$(ia(TriggerMode).m_PostSingleIOXml).find("flashMode").eq(iIndex).text($trigDiv.find("#FlashMode_singleIO").val());

		var copySrc;
		var copyDstArr = [];
		$('#singleIoCopyDiv input[ioIdx]').each(function (i, n) {
			if ($(n).prop('checked') && $(n).is(':enabled')) {
				copyDstArr.push($(n).attr('ioIdx'));
			}
		});

		$(ia(TriggerMode).m_PostSingleIOXml).find('PostSingleIO').each(function (i,n) {
			var $p = $(n);
			var idx = $p.find('relatedIOIn').text().replace('IO', "");
			if ($('#singleIoCheckBoxesDiv input[ioIdx='+idx+']').prop('checked')) {
				$p.find('enable').text('true');
			}else{
				$p.find('enable').text('false');
			}

			if (idx == m_iCurSelIONum) {
				copySrc = $p;
			}
		});

		//处理复制操作
		if (copySrc && copyDstArr.length) {
			$(ia(TriggerMode).m_PostSingleIOXml).find('PostSingleIO').each(function (i,n) {
				var $p = $(n);
				var idx = $p.find('relatedIOIn').text().replace('IO', "");
				
				if (_.contains(copyDstArr, idx)) {
					SimpleCopyXmlNode(copySrc[0], $p[0], 
						['laneDirectionType','laneUsage','defaultStatus', 'snapTimes', 'intervalType', 'laneUsage', 
						{propName: 'IntervalList', type: 'subNode'}, 
						{propName: 'IOOutList', type: 'subNode'}, 
						'flashMode']);
				}
			});
		}

		$.ajax({
			type: "put",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/postSingleIO",
			timeout: 15000,
			processData: false,
		    data: xmlToStr(ia(TriggerMode).m_PostSingleIOXml),
			async:false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			complete:function(xhr, textStatus) {
				if(xhr.status != 200) {
					if(xhr.status == 403) {
						var szErrorInfo = m_szError8;
						szRetInfo = m_szErrorState + szErrorInfo;
					} else {
						var xmlDoc =xhr.responseXML;
						if($(xmlDoc).find("detailedStatusCode").eq(0).text() != "") {
							var szErrorInfo = getNodeValue("Error" + $(xmlDoc).find("detailedStatusCode").eq(0).text());
						} else {
							var szErrorInfo = m_szError13;
						}
						szRetInfo = m_szErrorState + szErrorInfo;
					}
		            $("#SetResultTips").html(szRetInfo); 
			        setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			        return;	
				} else {
					if($(xhr.responseXML).find("statusCode").eq(0).text() == "7") {
						ia(TriggerMode).m_bRebootRequired = true;
					}
					ia(TriggerMode).m_bSetTriggerMode = true;
				    pr(TriggerMode).SetPlateRecognition("postSingleIO");
				}
			}
		});
	}
	/*************************************************
	Function:		selectPostSingleIO
	Description:	获取单IO触发每个IO的参数
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.selectPostSingleIO = function (iSingleIONum, dontSave) {
		var iLastIndex = parseInt(m_iCurSelIONum) - 1;  
		if(iSingleIONum == iLastIndex) {
			return;
		}
		$("#tabTriggerIO").find("li a").removeClass('current');
		$("#tabTriggerIO").find("li[ioIdx="+(iSingleIONum+1)+"]").find("a").eq(0).addClass("current");
		
		ResetSingleIoCopy();

		if(ia(TriggerMode).m_PostSingleIOXml !== null) {
			var $xmlDoc = $(ia(TriggerMode).m_PostSingleIOXml);
			var $trigDiv = $('#taTriggerMode #postSingleIoTriggerPanes');
			
			if (!dontSave) {
				//先保存之前的tab页的值
				
				var iLastSnapTime = $xmlDoc.find("snapTimes").eq(iLastIndex).text();
				//$xmlDoc.find("laneDirectionType").eq(iLastIndex).text($trigDiv.find("#laneDirectionType_postSingleIO").val());
				$xmlDoc.find("defaultStatus").eq(iLastIndex).text($trigDiv.find("#DefaultStatus").val());
				$xmlDoc.find("relatedDriveWay").eq(iLastIndex).text($trigDiv.find("#RelatedDriveWay").val());
				$xmlDoc.find("snapTimes").eq(iLastIndex).text($trigDiv.find("#SnapTimes").val());
				$xmlDoc.find("intervalType").eq(iLastIndex).text($trigDiv.find("#IntervalType").val());
				$xmlDoc.find("laneUsage").eq(iLastIndex).text($trigDiv.find("#useageType").val());

				if(iLastSnapTime == 0) {
				    iLastSnapTime = 1;
			    }
				for(var i = 1; i < iLastSnapTime; i++) {
					$xmlDoc.find("PostSingleIO").eq(iLastIndex).find("value").eq(i - 1).text($trigDiv.find("#Interval" + i).val());
				}
				for(var i = iLastSnapTime; i < $trigDiv.find("#SnapTimes").val(); i++) {
					$xmlDoc.find("PostSingleIO").eq(iLastIndex).find("IntervalList").eq(0).append($(parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><Interval><value>'+$trigDiv.find("#Interval" + i).val()+'</value></Interval>')).find("Interval").eq(0).clone());
				}
				for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
					$xmlDoc.find("PostSingleIO").eq(iLastIndex).find("enabled").eq(i).text($trigDiv.find("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked").toString());
				}
				$xmlDoc.find("flashMode").eq(iLastIndex).text($trigDiv.find("#FlashMode_singleIO").val());
			}
			

			//获取当前Tab值
			for(var i = 1; i < 5; i++){
				$trigDiv.find("#Interval" + i).val("0");
			}

			m_iCurSelIONum = iSingleIONum + 1;
			//$trigDiv.find("#laneDirectionType_postSingleIO").val($xmlDoc.find("laneDirectionType").eq(iSingleIONum).text());
			$trigDiv.find("#DefaultStatus").val($xmlDoc.find("defaultStatus").eq(iSingleIONum).text());
			$trigDiv.find("#RelatedDriveWay").val($xmlDoc.find("relatedDriveWay").eq(iSingleIONum).text());
			$trigDiv.find("#useageType").val($xmlDoc.find("laneUsage").eq(iSingleIONum).text());

			$trigDiv.find("#SnapTimes").val($xmlDoc.find("snapTimes").eq(iSingleIONum).text());
			$trigDiv.find("#IntervalType").val($xmlDoc.find("intervalType").eq(iSingleIONum).text());

			changeIntervalType($trigDiv.find("#IntervalType").val());
			for(var i = 2; i <= $trigDiv.find("#SnapTimes").val(); i++) {
				var v = $xmlDoc.find("PostSingleIO").eq(iSingleIONum).find("value").eq(i - 2).text();
				if (!v) {
					v = 0;
				};
				$trigDiv.find("#Interval" + (i-1)).val(v);
			}

			for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
				$trigDiv.find("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked",$xmlDoc.find("PostSingleIO").eq(iSingleIONum).find("enabled").eq(i).text() === "true" ? true : false);
			}
			$trigDiv.find("#FlashMode_singleIO").val($xmlDoc.find("flashMode").eq(iSingleIONum).text());
		}
		//DisplayPlateRegionEx([iSingleIONum+1]);
		SingleIoReDisplay();
		m_iLastSelIONum = m_iCurSelIONum;
	}

	
	/*************************************************
	Function:		submit
	Description:	设置单IO触发参数
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.submit = function () {
		ia(TriggerMode).m_bRebootRequired = false;
		var curTriggerMode = $("#selTriggerMode").val();

		if($("#selTriggerMode").val() == "postIOSpeed") {
		    ia(TriggerMode).SetPostIOSpeedParam();
		} else if($("#selTriggerMode").val() == "postSingleIO") {
			ia(TriggerMode).SetPostSingleIOParam();
		} else if($("#selTriggerMode").val() == "postRS485" || $("#selTriggerMode").val() == "postRadar") {
//            if($('#liBackUpModal2').css('display') != 'none'){
//                ia(TriggerMode).SetVTCoilParam();
//            }
//            if($('#liBackUpModal3').css('display') != 'none'){
//                ia(TriggerMode).SetepoliceIOTLParam();
//            }
            if($('#triggerBackupModelDiv').css('display') != 'none'){

                if($('#tabBackUpModel .current').attr("name") == "aBackUpModel1"){ //卡口车检器
                    ia(TriggerMode).Setpost485Param($("#selTriggerMode").val());
                }else if($('#tabBackUpModel .current').attr("name") == "aBackUpModel2"){ //虚拟线圈

                    $(ia(TriggerMode).m_PostVTCoilXml).find("backupType").eq(0).text(0);   //!!!新增参数判断该模式是主要模式还是备用模式 1代表主要模式，0代表备用模式
                    $(ia(TriggerMode).m_PlateRecognitionXml).find("backupType").eq(0).text(0);
                    ia(TriggerMode).SetVTCoilParam();
                }else if($('#tabBackUpModel .current').attr("name") == "aBackUpModel3"){ //混卡
                    ia(TriggerMode).SetepoliceIOTLParam();
                }
            }else{
                ia(TriggerMode).Setpost485Param($("#selTriggerMode").val());
            }

		} else if($("#selTriggerMode").val() == "epoliceIOTL") {
		    ia(TriggerMode).SetepoliceIOTLParam();
		} else if($("#selTriggerMode").val() == "epoliceRS485" || $("#selTriggerMode").val() == "postEpoliceRS485") {
			ia(TriggerMode).SetepoliceRS485Param($("#selTriggerMode").val());
		} else if($("#selTriggerMode").val() == "postVTCoil") {
            $(ia(TriggerMode).m_PostVTCoilXml).find("backupType").eq(0).text(1);   //!!!新增参数判断该模式是主要模式还是备用模式 1代表主要模式，0代表备用模式
            $(ia(TriggerMode).m_PlateRecognitionXml).find("backupType").eq(0).text(1);
			ia(TriggerMode).SetVTCoilParam();
		} else  if($("#selTriggerMode").val() == "videoEpolice"){
			ia(TriggerMode).SetvideoEpoliceParam();
		} else if($("#selTriggerMode").val() == "PostMpr"){
			ia(TriggerMode).SetPostMprParam();
		}else if (curTriggerMode == 'videoMonitor') {
			ia(TriggerMode).SetVideoMonitorParam();
		}else if (curTriggerMode == 'postHVT') {
			ia(TriggerMode).SetPostHVTParam();
		}
	}
	/*************************************************
	Function:		GetPlateRecognition
	Description:	获取牌识参数
	Input:			strType: 触发类型	
					iValueType: 0 实际值 1 推荐值
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.GetPlateRecognition = function (strType, iValueType) {
		if (strType == 'videoMonitor') {
			return;
		};
		var szUrl = "";
		if(iValueType == 1) {
			szUrl = "/PSIA/Custom/SelfExt/ITC/PlateRecognition/" + strType + "/recommendation";
		} else {
			szUrl = "/PSIA/Custom/SelfExt/ITC/PlateRecognition/" + strType;
		}
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + szUrl,
			timeout: 15000,
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				ia(TriggerMode).m_PlateRecognitionXml = xmlDoc;
				$("#defaultCHN").val($(xmlDoc).find("defaultCHN").eq(0).text());
				$("#PlateRecogEnabled").prop("checked", $(xmlDoc).find("plateRecogEnabled").eq(0).text() === "true" ? true : false);
				$("#colorEnabled").prop("checked", $(xmlDoc).find("colorEnabled").eq(0).text() === "true" ? true : false);
				$("#farmVehicleEnabled").prop("checked", $(xmlDoc).find("farmVehicleEnabled").eq(0).text() === "true" ? true : false);
				$("#fuzzyDiscEnabled").prop("checked", $(xmlDoc).find("fuzzyDiscEnabled").eq(0).text() === "true" ? true : false);
				if($(xmlDoc).find("frontPlateRecoEnabled").eq(0).text() === "true") {
					$(document.getElementsByName("PlateRecoDirection")).eq(0).prop("checked", true);
					$(document.getElementsByName("PlateRecoDirection")).eq(1).prop("checked", false);
				}
				else
				{
					$(document.getElementsByName("PlateRecoDirection")).eq(0).prop("checked", false);
					$(document.getElementsByName("PlateRecoDirection")).eq(1).prop("checked", true);
				}
				if($(xmlDoc).find("smallPlateRecoEnabled").eq(0).text() === "true") {
					$(document.getElementsByName("PlateRecoType")).eq(0).prop("checked", true);
					$(document.getElementsByName("PlateRecoType")).eq(1).prop("checked", false);
				}
				else
				{
					$(document.getElementsByName("PlateRecoType")).eq(0).prop("checked", false);
					$(document.getElementsByName("PlateRecoType")).eq(1).prop("checked", true);
				}

				ClearPolygon(4);
				switch(strType) {
					case "postSingleIO":
					   	SingleIoReDisplay();
					    break;
					case "postIOSpeed":
					    PostSpeedReDisplay();
					    break;
					case "postRS485":
						PostRS485ReDisplay();
						break;
					case "postRadar":
						PostRadarReDisplay();
						break;
					case "epoliceIOTL":
						//pr(TriggerMode).selectepoliceIOTL(0);
					    //pr(TriggerMode).GetepoliceIOTLParam(1);
						break;
					case "epoliceRS485":
						EpoliceRS485ReDisplay();
						break;
					case "postEpoliceRS485":
						PostEpoliceRS485ReDisplay();
						break;
					case "postVTCoil":
						PostVTCoilReDisplay();
						break;
					case "PostMpr":
					    PostMprReDisplay();
						break;
					case "postHVT":
						PostHVTReDisplay();
						break;
					default:
					    break;
				}

				//显示区域
				// var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>1</id><polygonType>1</polygonType><tips>" + getNodeValue("PlateRegion") +"1</tips><isClosed>true</isClosed><color><r>255</r><g>255</g><b>0</b></color><pointList>";
				// for(var i = 0; i < $(xmlDoc).find("PlateRegion").eq(0).find("RegionCoordinates").length; i++) {
				// 	var positionX= parseFloat($(xmlDoc).find("PlateRegion").eq(0).find("positionX").eq(i).text())/1000;
				// 	var positionY= parseFloat($(xmlDoc).find("PlateRegion").eq(0).find("positionY").eq(i).text())/1000;
				// 	szInfo3 += "<point><x>" + positionX + "</x><y>" +  positionY + "</y></point>";
				// }
				// szInfo3 += "</pointList></SnapPolygon></SnapPolygonList>";
				// try{
				// 	ClearPolygon();
				// 	var iRet = HWP.SetSnapPolygonInfo(szInfo3);
				// }
				// catch(e){
				// }
			}
		});
	}
	/*************************************************
	Function:		SetPlateRecognition
	Description:	设置牌识参数
	Input:			strType: 触发类型			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.SetPlateRecognition = function (strType) {
		//触发模式保存失败则返回
		if(!ia(TriggerMode).m_bSetTriggerMode) {
			szRetInfo = m_szErrorState + m_szError1;
		    $("#SetResultTips").html(szRetInfo); 
			setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			return;
		}
		var xmlDoc = ia(TriggerMode).m_PlateRecognitionXml;
		if(strType == "postRS485" || strType == "postRadar" || strType == "epoliceRS485" || strType == "postEpoliceRS485") {
			$(xmlDoc).find("PlateRegionCount").eq(0).text($("#RelatedLaneCount_videoEp").val());
		}
		// $(xmlDoc).find("defaultCHN").eq(0).text($("#defaultCHN").val());
		// $(xmlDoc).find("plateRecogEnabled").eq(0).text($("#PlateRecogEnabled").prop("checked").toString());
		// $(xmlDoc).find("colorEnabled").eq(0).text($("#colorEnabled").prop("checked").toString());
		// $(xmlDoc).find("farmVehicleEnabled").eq(0).text($("#farmVehicleEnabled").prop("checked").toString());
		// $(xmlDoc).find("fuzzyDiscEnabled").eq(0).text($("#fuzzyDiscEnabled").prop("checked").toString());
		// $(xmlDoc).find("frontPlateRecoEnabled").eq(0).text($(document.getElementsByName("PlateRecoDirection")).eq(0).prop("checked").toString());
		// $(xmlDoc).find("rearPlateRecoEnabled").eq(0).text($(document.getElementsByName("PlateRecoDirection")).eq(1).prop("checked").toString());
		// $(xmlDoc).find("smallPlateRecoEnabled").eq(0).text($(document.getElementsByName("PlateRecoType")).eq(0).prop("checked").toString());
		// $(xmlDoc).find("largePlateRecoEnabled").eq(0).text($(document.getElementsByName("PlateRecoType")).eq(1).prop("checked").toString());
		var iIndex = m_iCurSelIONum - 1; 
		//获取区域
		// try{
		// 	var szInfo = HWP.GetSnapPolygonInfo();
		// 	var szTempXmlDoc = $(parseXmlFromStr(szInfo));
		// 	$(ia(TriggerMode).m_PlateRecognitionXml).find("regionId").each( function() {
		// 		if($(this).text() == m_iCurSelIONum) {
		// 			$(this).parent().remove();
		// 		}
		// 	});
		// 	var szInfo1 = "<?xml version='1.0' encoding='UTF-8'?><PlateRegion><regionId>" + m_iCurSelIONum + "</regionId><RegionCoordinatesList>";
		// 	var iIndex = 0;
		// 	$(szTempXmlDoc).find("id").each( function(i) {
		// 		if($(this).text() == m_iCurSelIONum && $(szTempXmlDoc).find("polygonType").eq(i).text() == 1) {
		// 			iIndex = i;
		// 		}
		// 	});
		// 	for(var i = 0; i < szTempXmlDoc.find("SnapPolygon").eq(iIndex).find("point").length; i++) {
		// 		szInfo1 += "<RegionCoordinates><positionX>" + parseInt(szTempXmlDoc.find("SnapPolygon").eq(iIndex).find("x").eq(i).text()*1000) + "</positionX><positionY>" + parseInt(szTempXmlDoc.find("SnapPolygon").eq(iIndex).find("y").eq(i).text()*1000) + "</positionY></RegionCoordinates>";
		// 	}
		// 	szInfo1 += "</RegionCoordinatesList></PlateRegion>";
		// 	$(xmlDoc).find("PlateRegionList").eq(0).append($(parseXmlFromStr(szInfo1)).find("PlateRegion").eq(0).clone());
		// }
		// catch(e){
		// }
		$.ajax({
			type: "put",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/PlateRecognition/" + strType,
			timeout: 15000,
			async: false,
			data: xmlToStr(xmlDoc),
			processData: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				// $("#CurTriggerMode").html(getNodeValue("a" + $("#selTriggerMode").val()));
				if(ia(TriggerMode).m_bRebootRequired) {
					szRetInfo = m_szSuccessState + m_szSuccess5;
				} else {
					szRetInfo = m_szSuccessState + m_szSuccess1;
				}
				$("#SetResultTips").html(szRetInfo); 
			    setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			},
			error:function(xmlDoc, textStatus, xhr){
				szRetInfo = m_szErrorState + m_szError1;
		        $("#SetResultTips").html(szRetInfo); 
			    setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			}
		});
	}
	//卡口IO测速相关
	/*************************************************
	Function:		GetpostIOSpeedParam
	Description:	获取卡口IO测速参数
	Input:			iValueType: 0 实际值 1 推荐值			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.GetpostIOSpeedParam = function (iValueType) {

        var szUrl = "/PSIA/Custom/SelfExt/ITC/postIOSpeed";
		if(iValueType == 1) {
			szUrl += "/recommendation";
		}
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + szUrl,
			timeout: 15000,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				ia(TriggerMode).m_epoliceIOTLXml = parseXmlFromStr(xmlToStr(xmlDoc));
				if($(xmlDoc).find("IoSpeedGroup").length < 2) {
					$("#liSpeedGroup2").css("display", "none");
				}
				var $trigDiv = $('#taTriggerMode');

                getTriggerIOSpeedCopyInfo();
                $trigDiv.find("#laneDirectionType_postIOSpeed").val($(xmlDoc).find("laneDirectionType").eq(0).text());
				$trigDiv.find("#groupEnabled").prop("checked", $(xmlDoc).find("groupEnabled").eq(0).text() === "true" ? true : false);
				$trigDiv.find("#firstCoilIO").val($(xmlDoc).find("firstCoilIO").eq(0).text());
				$trigDiv.find("#firstCoilIOStatus").val($(xmlDoc).find("firstCoilIOStatus").eq(0).text());
				$trigDiv.find("#secondCoilIO").val($(xmlDoc).find("secondCoilIO").eq(0).text());
				$trigDiv.find("#secondCoilIOStatus").val($(xmlDoc).find("secondCoilIOStatus").eq(0).text());
				$trigDiv.find("#RelatedDriveWay").val($(xmlDoc).find("relatedDriveWay").eq(0).text());
				$trigDiv.find("#laneDirectionType_epoliceIOTL").val($(xmlDoc).find("laneDirectionType").eq(0).text());
				$trigDiv.find("#timeOut").val($(xmlDoc).find("timeOut").eq(0).text());
				$trigDiv.find("#distance").val($(xmlDoc).find("distance").eq(0).text());
				$trigDiv.find("#speedCapEnable_ioSpeed").prop("checked", $(xmlDoc).find("speedCapEnable").eq(0).text() === "true" ? true : false);
				$trigDiv.find("#lowSpeedCapEnable_ioSpeed").prop("checked", $(xmlDoc).find("lowSpeedCapEnable").eq(0).text() === "true" ? true : false);
				$trigDiv.find("#capSpeed").val($(xmlDoc).find("capSpeed").eq(0).text());
				$trigDiv.find("#speedLimit").val($(xmlDoc).find("speedLimit").eq(0).text());
				$trigDiv.find("#signSpeed").val($(xmlDoc).find("signSpeed").eq(0).text());
				$trigDiv.find("#bigCarSignSpeed").val($(xmlDoc).find("bigCarSignSpeed").eq(0).text());
				$trigDiv.find("#byLowSpeedLimit").val($(xmlDoc).find("byLowSpeedLimit").eq(0).text());
				$trigDiv.find("#byBigCarLowSpeedLimit").val($(xmlDoc).find("byBigCarLowSpeedLimit").eq(0).text());

				$trigDiv.find("#firstCoilSnapTimes").val($(xmlDoc).find("firstCoilSnapTimes").eq(0).text());
				$trigDiv.find("#secondCoilSnapTimes").val($(xmlDoc).find("secondCoilSnapTimes").eq(0).text());
                $trigDiv.find("#bigCarSpeedLimit_IOSpeed").val($(xmlDoc).find("bigCarSpeedLimit").eq(0).text());

                $trigDiv.find("#drawRightRegionContent #carHighSpeed_IOSpeed").val($(xmlDoc).find("carHighSpeed").eq(0).text());
                $trigDiv.find("#drawRightRegionContent #carLowSpeed_IOSpeed").val($(xmlDoc).find("carLowSpeed").eq(0).text());
                $trigDiv.find("#drawRightRegionContent #bigCarHighSpeed_IOSpeed").val($(xmlDoc).find("bigCarHighSpeed").eq(0).text());
                $trigDiv.find("#drawRightRegionContent #bigCarLowSpeed_IOSpeed").val($(xmlDoc).find("bigCarLowSpeed").eq(0).text());

                $trigDiv.find("#laneType").val($(xmlDoc).find("laneType").eq(0).text());
                $trigDiv.find("#useageType").val($(xmlDoc).find("laneUsage").eq(0).text());

				$trigDiv.find("#IntervalType").val($(xmlDoc).find("intervalType").eq(0).text());
				changeIntervalType($("#IntervalType").val());
                ia(TriggerMode).changeSnapTime();
				for(var i = 1; i < 5; i++){
					$("#firstCoilInterval" + i).val("0");
					$("#secondCoilInterval" + i).val("0");
				}
				for(var i = 2; i <= $("#firstCoilSnapTimes").val(); i++) {
					$("#firstCoilInterval" + (i-1)).val($(xmlDoc).find("CoilInterval").eq(0).find("value").eq(i - 2).text());
				}
				for(var i = 2; i <= $("#secondCoilSnapTimes").val(); i++) {
					$("#secondCoilInterval" + (i-1)).val($(xmlDoc).find("CoilInterval").eq(1).find("value").eq(i - 2).text());
				}
				if($("#speedCapEnable_ioSpeed").prop("checked") && $("#secondCoilSnapTimes").val() < 5) {
					var iIndex = $("#secondCoilSnapTimes").val();
					$("#secondCoilInterval" + iIndex).val($(ia(TriggerMode).m_epoliceIOTLXml).find("CoilIntervalList").eq(0).find("CoilInterval").eq(1).find("value").eq(iIndex - 1).text());
				}

                var speedGroupLength = $(xmlDoc).find("IoSpeedGroup").eq(0).find('IOOut').length;
                var divInfo = "";
                for(var i = 0; i < speedGroupLength; i++) {
                    if(i == 3 || i == 6){
                        divInfo += "<br>";
                    }
                    divInfo += "<div style='display:inline-block;margin-bottom:7px;'><input class='checkbox' name='AlarmOutputCheckbox' id='AlarmOutputCheckboxChanO-"+ (i + 1)+"' type='checkbox'>&nbsp;"+"F" + (i + 1) + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>";
                }
                $("#DisPlayLinkageList").html(divInfo);
                if(speedGroupLength > 3 ){
                    $("#DisPlayLinkageList").css("height","66px");
                }else{
                    $("#DisPlayLinkageList").css("height","30px");
                }

				for(var i = 0; i < speedGroupLength; i++) {
					$("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked",$(xmlDoc).find("IoSpeedGroup").eq(0).find("enabled").eq(i).text() === "true" ? true : false);
				}
				$("#FlashMode").val($(xmlDoc).find("flashMode").eq(0).text());
				m_iCurSelIONum = 1;
				m_iLastSelIONum = 1;
			}
		});
	}

    function getTriggerIOSpeedCopyInfo(){

        $('#TriggerIOSpeedCopyDiv').find('div.singleIo_checkbox_copy_div').remove();
        var $IOSpeed = $(ia(TriggerMode).m_epoliceIOTLXml);
        var len = $IOSpeed.find("IoSpeedGroup").length;

        for(var i=0; i < len; i++){

            var disStr = '';
            if($('#tabSpeedIO #liSpeedGroup' + (i+1)).find('a').first().is('.current')){
                disStr = 'disabled="disabled" checked="checked" ';
            }
            var arr = ['<div class="singleIo_checkbox_copy_div">',
                '<input id="ioSpeed_copy_checkbox_'+(i+1)+'" ioIdx="'+(i+1)+'" type="checkbox" ',
                disStr,
                'class="singleIo_checkbox"><label for="ioSpeed_copy_checkbox_'+(i+1)+'" ',
                ' class="singleIo_checkbox">'+getNodeValue('aSpeedGroup'+(i+1))+'</label></div>'];

            $('#TriggerIOSpeedCopyDiv').append(arr.join(' '));
        }
    }
	/*************************************************
	Function:		SetPostIOSpeedParam
	Description:	设置卡口IO测速值
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.SetPostIOSpeedParam = function () {
		ia(TriggerMode).m_bSetTriggerMode = false;
		//保存当前tab页的值
		var iIndex = parseInt(m_iCurSelIONum) - 1;

		var $trigDiv = $('#taTriggerMode');
		
		$(ia(TriggerMode).m_epoliceIOTLXml).find("laneDirectionType").eq(iIndex).text($trigDiv.find("#laneDirectionType_postIOSpeed").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("groupEnabled").eq(iIndex).text($trigDiv.find("#groupEnabled").prop("checked").toString());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("firstCoilIO").eq(iIndex).text($trigDiv.find("#firstCoilIO").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("firstCoilIOStatus").eq(iIndex).text($trigDiv.find("#firstCoilIOStatus").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("secondCoilIO").eq(iIndex).text($trigDiv.find("#secondCoilIO").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("secondCoilIOStatus").eq(iIndex).text($trigDiv.find("#secondCoilIOStatus").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("laneDirectionType").eq(iIndex).text($trigDiv.find("#laneDirectionType_epoliceIOTL").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("relatedDriveWay").eq(iIndex).text($trigDiv.find("#RelatedDriveWay").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("timeOut").eq(iIndex).text($trigDiv.find("#timeOut").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("distance").eq(iIndex).text($trigDiv.find("#distance").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("speedCapEnable").eq(iIndex).text($trigDiv.find("#speedCapEnable_ioSpeed").prop("checked").toString());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("lowSpeedCapEnable").eq(iIndex).text($trigDiv.find("#lowSpeedCapEnable_ioSpeed").prop("checked").toString());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("capSpeed").eq(iIndex).text($trigDiv.find("#capSpeed").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("speedLimit").eq(iIndex).text($trigDiv.find("#speedLimit").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("signSpeed").eq(iIndex).text($trigDiv.find("#signSpeed").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("bigCarSignSpeed").eq(iIndex).text($trigDiv.find("#bigCarSignSpeed").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("byLowSpeedLimit").eq(iIndex).text($trigDiv.find("#byLowSpeedLimit").val());
        $(ia(TriggerMode).m_epoliceIOTLXml).find("byBigCarLowSpeedLimit").eq(iIndex).text($trigDiv.find("#byBigCarLowSpeedLimit").val());

		$(ia(TriggerMode).m_epoliceIOTLXml).find("firstCoilSnapTimes").eq(iIndex).text($trigDiv.find("#firstCoilSnapTimes").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("secondCoilSnapTimes").eq(iIndex).text($trigDiv.find("#secondCoilSnapTimes").val());
        $(ia(TriggerMode).m_epoliceIOTLXml).find("bigCarSpeedLimit").eq(iIndex).text($trigDiv.find("#bigCarSpeedLimit_IOSpeed").val());
        $(ia(TriggerMode).m_epoliceIOTLXml).find("laneType").eq(iIndex).text($trigDiv.find("#laneType").val());
        $(ia(TriggerMode).m_epoliceIOTLXml).find("laneUsage").eq(iIndex).text($trigDiv.find("#useageType").val());

		$(ia(TriggerMode).m_epoliceIOTLXml).find("intervalType").eq(iIndex).text($trigDiv.find("#IntervalType").val());

        $(ia(TriggerMode).m_epoliceIOTLXml).find("carHighSpeed").eq(0).text($("#drawRightRegionContent #carHighSpeed_IOSpeed").val());
        $(ia(TriggerMode).m_epoliceIOTLXml).find("carLowSpeed").eq(0).text($("#drawRightRegionContent #carLowSpeed_IOSpeed").val());
        $(ia(TriggerMode).m_epoliceIOTLXml).find("bigCarHighSpeed").eq(0).text($("#drawRightRegionContent #bigCarHighSpeed_IOSpeed").val());
        $(ia(TriggerMode).m_epoliceIOTLXml).find("bigCarLowSpeed").eq(0).text($("#drawRightRegionContent #bigCarLowSpeed_IOSpeed").val());
		
		$(ia(TriggerMode).m_epoliceIOTLXml).find("CoilIntervalList").eq(iIndex).find("IntervalList").each( function() {
			$(this).remove();
		});
		var szInfo = "<?xml version='1.0' encoding='UTF-8'?><Temp><IntervalList>";
		for(var i = 1; i < $("#firstCoilSnapTimes").val(); i++) {
			szInfo += "<Interval><value>" + $("#firstCoilInterval" + i).val() + "</value></Interval>";
		}
		szInfo += "</IntervalList></Temp>";
		$(ia(TriggerMode).m_epoliceIOTLXml).find("CoilIntervalList").eq(iIndex).find("CoilInterval").eq(0).append($(parseXmlFromStr(szInfo)).find("Temp").eq(0).clone().children());
		
		var iSecondLastSnapTime = parseInt($("#secondCoilSnapTimes").val());
		if($("#speedCapEnable_ioSpeed").prop("checked") && $("#secondCoilSnapTimes").val() < 5) {
			iSecondLastSnapTime += 1;
		}
		szInfo = "<?xml version='1.0' encoding='UTF-8'?><Temp><IntervalList>";
		for(var i = 1; i < iSecondLastSnapTime; i++) {
			szInfo += "<Interval><value>" + $("#secondCoilInterval" + i).val() + "</value></Interval>";
		}
		szInfo += "</IntervalList></Temp>";
		$(ia(TriggerMode).m_epoliceIOTLXml).find("CoilIntervalList").eq(iIndex).find("CoilInterval").eq(1).append($(parseXmlFromStr(szInfo)).find("Temp").eq(0).clone().children());

        var speedGroupLength = $(ia(TriggerMode).m_epoliceIOTLXml).find("IoSpeedGroup").eq(iIndex).find('IOOut').length;
		for(var i = 0; i < speedGroupLength; i++) {
			$(ia(TriggerMode).m_epoliceIOTLXml).find("IoSpeedGroup").eq(iIndex).find("enabled").eq(i).text($("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked").toString());
		}
		$(ia(TriggerMode).m_epoliceIOTLXml).find("flashMode").eq(iIndex).text($("#FlashMode").val());

        var idxs = [];
        var curIoInfo;
        $('#TriggerIOSpeedCopyDiv input[ioIdx]').each(function(i, n){
				
            if($(n).prop('checked') && !$(n).prop('disabled')){
                idxs.push($(n).attr('ioIdx'));
            }
        });

        $(ia(TriggerMode).m_epoliceIOTLXml).find('IoSpeedGroup').each(function(i, n){
            var id = $(n).find('groupId').eq(0).text();
            if(id == m_iCurSelIONum){
                curIoInfo = $(n);
            }
        });

        if(curIoInfo && idxs.length > 0){
            $(ia(TriggerMode).m_epoliceIOTLXml).find('IoSpeedGroup').each(function(i, n){
				$p = $(n);
                var idx = $(n).find('groupId').eq(0).text();
                if (_.contains(idxs, idx)){
                    SimpleCopyXmlNode(curIoInfo[0],$p[0],['groupEnabled','timeOut',
                    	'distance','laneDirectionType','laneUsage',
                    	'capSpeed','speedLimit', 'signSpeed', 'carLowSpeed',
                    	'speedCapEnable','lowSpeedCapEnable','firstCoilIOStatus',
                    	'secondCoilIOStatus', 
                        'firstCoilSnapTimes','secondCoilSnapTimes',
                        'laneType','intervalType',
                        'bigCarSpeedLimit','byLowSpeedLimit','byBigCarLowSpeedLimit', 'bigCarSignSpeed','byLowSpeedLimit','byBigCarLowSpeedLimit', 'bigCarHighSpeed', 'bigCarLowSpeed',
                        {propName: 'CoilIntervalList', type: 'subNode'},
                        {propName: 'IOOutList', type: 'subNode'},
                        'flashMode', 'laneUsage']);
                }
            });
        }

		$.ajax({
			type: "put",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/PostIOSpeed",
			timeout: 15000,
			processData: false,
		    data: xmlToStr(ia(TriggerMode).m_epoliceIOTLXml),
			async:false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			complete:function(xhr, textStatus) {
                if(xhr.status != 200) {
					if(xhr.status == 403) {
						var szErrorInfo = m_szError8;
						szRetInfo = m_szErrorState + szErrorInfo;
					} else {
						var xmlDoc =xhr.responseXML;
						if($(xmlDoc).find("detailedStatusCode").eq(0).text() != "") {
							var szErrorInfo = getNodeValue("Error" + $(xmlDoc).find("detailedStatusCode").eq(0).text());
						} else {
							var szErrorInfo = m_szError13;
						}
						szRetInfo = m_szErrorState + szErrorInfo;
					}
		            $("#SetResultTips").html(szRetInfo); 
			        setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			        return;	
				} else {
					if($(xhr.responseXML).find("statusCode").eq(0).text() == "7") {
						ia(TriggerMode).m_bRebootRequired = true;
					}
					ia(TriggerMode).m_bSetTriggerMode = true;
				    pr(TriggerMode).SetPlateRecognition("postIOSpeed");
				}
			}
		});
	}
	/*************************************************
	Function:		selectPostIOSpeed
	Description:	获取每个测速组的参数
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.selectPostIOSpeed = function (iSpeedIONum) {
		var iLastIndex = parseInt(m_iCurSelIONum) - 1;
		if(iSpeedIONum == iLastIndex) {
			return;
		}
		$("#tabSpeedIO").find("li").each(function() {
			 if($(this).children().hasClass("current")) {
				 $(this).children().removeClass();
			 }
		});
		$("#tabSpeedIO").find("li").eq(iSpeedIONum).find("a").eq(0).addClass("current");
		
		var $xmlDoc = $(ia(TriggerMode).m_epoliceIOTLXml);

		var $trigDiv = $('#taTriggerMode');
		
		if(ia(TriggerMode).m_epoliceIOTLXml !== null) {
			$xmlDoc.find("laneDirectionType").eq(iLastIndex).text($trigDiv.find("#laneDirectionType_postIOSpeed").val());
			$xmlDoc.find("groupEnabled").eq(iLastIndex).text($trigDiv.find("#groupEnabled").prop("checked").toString());
			$xmlDoc.find("firstCoilIO").eq(iLastIndex).text($trigDiv.find("#firstCoilIO").val());
			$xmlDoc.find("firstCoilIOStatus").eq(iLastIndex).text($trigDiv.find("#firstCoilIOStatus").val());
			$xmlDoc.find("secondCoilIO").eq(iLastIndex).text($trigDiv.find("#secondCoilIO").val());
			$xmlDoc.find("secondCoilIOStatus").eq(iLastIndex).text($trigDiv.find("#secondCoilIOStatus").val());
			$xmlDoc.find("relatedDriveWay").eq(iLastIndex).text($trigDiv.find("#RelatedDriveWay").val());
			$xmlDoc.find("laneDirectionType").eq(iLastIndex).text($trigDiv.find("#laneDirectionType_epoliceIOTL").val());
			$xmlDoc.find("timeOut").eq(iLastIndex).text($trigDiv.find("#timeOut").val());
			$xmlDoc.find("distance").eq(iLastIndex).text($trigDiv.find("#distance").val());
			$xmlDoc.find("speedCapEnable").eq(iLastIndex).text($trigDiv.find("#speedCapEnable_ioSpeed").prop("checked").toString());
			$xmlDoc.find("lowSpeedCapEnable").eq(iLastIndex).text($trigDiv.find("#lowSpeedCapEnable_ioSpeed").prop("checked").toString());
			$xmlDoc.find("capSpeed").eq(iLastIndex).text($trigDiv.find("#capSpeed").val());
			$xmlDoc.find("speedLimit").eq(iLastIndex).text($trigDiv.find("#speedLimit").val());
			$xmlDoc.find("signSpeed").eq(iLastIndex).text($trigDiv.find("#signSpeed").val());
		    $xmlDoc.find("bigCarSignSpeed").eq(iLastIndex).text($trigDiv.find("#bigCarSignSpeed").val());
			$xmlDoc.find("byLowSpeedLimit").eq(iLastIndex).text($trigDiv.find("#byLowSpeedLimit").val());
		    $xmlDoc.find("byBigCarLowSpeedLimit").eq(iLastIndex).text($trigDiv.find("#byBigCarLowSpeedLimit").val());

			$xmlDoc.find("firstCoilSnapTimes").eq(iLastIndex).text($trigDiv.find("#firstCoilSnapTimes").val());
			$xmlDoc.find("secondCoilSnapTimes").eq(iLastIndex).text($trigDiv.find("#secondCoilSnapTimes").val());
            $xmlDoc.find("bigCarSpeedLimit").eq(iIndex).text($trigDiv.find("#bigCarSpeedLimit_IOSpeed").val());
            $xmlDoc.find("laneType").eq(iLastIndex).text($trigDiv.find("#laneType").val());
			$xmlDoc.find("laneUsage").eq(iLastIndex).text($trigDiv.find("#useageType").val());

			$xmlDoc.find("intervalType").eq(iLastIndex).text($trigDiv.find("#IntervalType").val());
			
			$xmlDoc.find("CoilIntervalList").eq(iLastIndex).find("IntervalList").each( function() {
				$(this).remove();
			});
			var szInfo = "<?xml version='1.0' encoding='UTF-8'?><Temp><IntervalList>";
			for(var i = 1; i < $("#firstCoilSnapTimes").val(); i++) {
				szInfo += "<Interval><value>" + $trigDiv.find("#firstCoilInterval" + i).val() + "</value></Interval>";
			}
			szInfo += "</IntervalList></Temp>";
			$xmlDoc.find("CoilIntervalList").eq(iLastIndex).find("CoilInterval").eq(0).append($(parseXmlFromStr(szInfo)).find("Temp").eq(0).clone().children());
			
			var iSecondLastSnapTime = parseInt($trigDiv.find("#secondCoilSnapTimes").val());
			if($trigDiv.find("#speedCapEnable_ioSpeed").prop("checked") && $trigDiv.find("#secondCoilSnapTimes").val() < 5) {
				iSecondLastSnapTime += 1;
			}
			szInfo = "<?xml version='1.0' encoding='UTF-8'?><Temp><IntervalList>";
			for(var i = 1; i < iSecondLastSnapTime; i++) {
				szInfo += "<Interval><value>" + $trigDiv.find("#secondCoilInterval" + i).val() + "</value></Interval>";
			}
			szInfo += "</IntervalList></Temp>";
			$xmlDoc.find("CoilIntervalList").eq(iLastIndex).find("CoilInterval").eq(1).append($(parseXmlFromStr(szInfo)).find("Temp").eq(0).clone().children());
			
			for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
				$xmlDoc.find("IoSpeedGroup").eq(iLastIndex).find("enabled").eq(i).text($trigDiv.find("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked").toString());
			}
			$xmlDoc.find("flashMode").eq(iLastIndex).text($trigDiv.find("#FlashMode").val());
			
			//获取当前Tab值
			for(var i = 1; i < 5; i++){
				$trigDiv.find("#firstCoilInterval" + i).val("0");
				$trigDiv.find("#secondCoilInterval" + i).val("0");
			}
			

			m_iCurSelIONum = iSpeedIONum + 1;
			$trigDiv.find("#laneDirectionType_postIOSpeed").val($xmlDoc.find("laneDirectionType").eq(iSpeedIONum).text());
			$trigDiv.find("#groupEnabled").prop("checked", $xmlDoc.find("groupEnabled").eq(iSpeedIONum).text() === "true" ? true : false);
			$trigDiv.find("#firstCoilIO").val($xmlDoc.find("firstCoilIO").eq(iSpeedIONum).text());
			$trigDiv.find("#firstCoilIOStatus").val($xmlDoc.find("firstCoilIOStatus").eq(iSpeedIONum).text());
			$trigDiv.find("#secondCoilIO").val($xmlDoc.find("secondCoilIO").eq(iSpeedIONum).text());
			$trigDiv.find("#secondCoilIOStatus").val($xmlDoc.find("secondCoilIOStatus").eq(iSpeedIONum).text());
			$trigDiv.find("#RelatedDriveWay").val($xmlDoc.find("relatedDriveWay").eq(iSpeedIONum).text());
			$trigDiv.find("#laneDirectionType_epoliceIOTL").val($xmlDoc.find("laneDirectionType").eq(iSpeedIONum).text());
			$trigDiv.find("#timeOut").val($xmlDoc.find("timeOut").eq(iSpeedIONum).text());
			$trigDiv.find("#distance").val($xmlDoc.find("distance").eq(iSpeedIONum).text());
			$trigDiv.find("#speedCapEnable_ioSpeed").prop("checked", $xmlDoc.find("speedCapEnable").eq(iSpeedIONum).text() === "true" ? true : false);
			$trigDiv.find("#lowSpeedCapEnable_ioSpeed").prop("checked", $xmlDoc.find("lowSpeedCapEnable").eq(iSpeedIONum).text() === "true" ? true : false);
			$trigDiv.find("#capSpeed").val($xmlDoc.find("capSpeed").eq(iSpeedIONum).text());
			$trigDiv.find("#speedLimit").val($xmlDoc.find("speedLimit").eq(iSpeedIONum).text());
			$trigDiv.find("#signSpeed").val($xmlDoc.find("signSpeed").eq(iSpeedIONum).text());
			$trigDiv.find("#bigCarSignSpeed").val($xmlDoc.find("bigCarSignSpeed").eq(iSpeedIONum).text());
			$trigDiv.find("#byLowSpeedLimit").val($xmlDoc.find("byLowSpeedLimit").eq(iSpeedIONum).text());
			$trigDiv.find("#byBigCarLowSpeedLimit").val($xmlDoc.find("byBigCarLowSpeedLimit").eq(iSpeedIONum).text());

			$trigDiv.find("#firstCoilSnapTimes").val($xmlDoc.find("firstCoilSnapTimes").eq(iSpeedIONum).text());
			$trigDiv.find("#secondCoilSnapTimes").val($xmlDoc.find("secondCoilSnapTimes").eq(iSpeedIONum).text());
            $trigDiv.find("#bigCarSpeedLimit_IOSpeed").val($xmlDoc.find("bigCarSpeedLimit").eq(iSpeedIONum).text());
            $trigDiv.find("#laneType").val($xmlDoc.find("laneType").eq(iSpeedIONum).text());
            $trigDiv.find("#useageType").val($xmlDoc.find("laneUsage").eq(iSpeedIONum).text());

			$trigDiv.find("#IntervalType").val($xmlDoc.find("intervalType").eq(iSpeedIONum).text());
			changeIntervalType($trigDiv.find("#IntervalType").val());
			for(var i = 1; i < 5; i++){
				$trigDiv.find("#firstCoilInterval" + i).val("0");
				$trigDiv.find("#secondCoilInterval" + i).val("0");
			}
			for(var i = 2; i <= $trigDiv.find("#firstCoilSnapTimes").val(); i++) {
				$trigDiv.find("#firstCoilInterval" + (i-1)).val($xmlDoc.find("CoilIntervalList").eq(iSpeedIONum).find("CoilInterval").eq(0).find("value").eq(i - 2).text());
			}
			for(var i = 2; i <= $trigDiv.find("#secondCoilSnapTimes").val(); i++) {
				$trigDiv.find("#secondCoilInterval" + (i-1)).val($xmlDoc.find("CoilIntervalList").eq(iSpeedIONum).find("CoilInterval").eq(1).find("value").eq(i - 2).text());
			}
			if($trigDiv.find("#speedCapEnable_ioSpeed").prop("checked") && $trigDiv.find("#secondCoilSnapTimes").val() < 5) {
				var iIndex = $trigDiv.find("#secondCoilSnapTimes").val();
				$trigDiv.find("#secondCoilInterval" + iIndex).val($xmlDoc.find("CoilIntervalList").eq(iSpeedIONum).find("CoilInterval").eq(1).find("value").eq(iIndex - 1).text());
			}

            var speedGroupLength = $xmlDoc.find("IoSpeedGroup").eq(iSpeedIONum).find('IOOut').length;
			for(var i = 0; i < speedGroupLength; i++) {
				$trigDiv.find("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked",$xmlDoc.find("IoSpeedGroup").eq(iSpeedIONum).find("enabled").eq(i).text() === "true" ? true : false);
			}
			$trigDiv.find("#FlashMode").val($xmlDoc.find("flashMode").eq(iSpeedIONum).text());
		}
        getTriggerIOSpeedCopyInfo();
		PostSpeedReDisplay();
		m_iLastSelIONum = m_iCurSelIONum;
	}
	//卡口485相关
	/*************************************************
	Function:		Getpost485ParamCap
	Description:	获取卡口485参数能力
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.Getpost485ParamCap = function () {
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/PostRadar/capabilities",
			timeout: 15000,
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				fillLaneCountOptions(1, $(xmlDoc).find("RelatedLaneCount").eq(0).attr("max"), null);
				g_transStack.translate();
			}
		});		
	}

	TriggerMode.prototype.GetPostMprParamCap = function () {
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/PostMpr/capabilities",
			timeout: 15000,
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				var min = $(xmlDoc).find("laneCount").eq(0).attr("min");
				var max = $(xmlDoc).find("laneCount").eq(0).attr("max");
				min = parseInt(min);
				min = min ? min : 1;
				max = parseInt(max);
				max = max ? max : 3;
				fillLaneCountOptions(min, max, null);

				if (min == max == 1) {
					$('#relatedLaneCountContentDiv').hide();
				};
				g_transStack.translate();
			}
		});	
	}

	/*************************************************
	Function:		Getpost485Param
	Description:	获取卡口485参数
	Input:			strTriggerMode:触发模式		
	                iTypeValue: 0 实际值 1 推荐值
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.Getpost485Param = function (strTriggerMode, iValueType) {
		var that=this;
		var szUrl = "/PSIA/Custom/SelfExt/ITC/" + strTriggerMode;
		if(iValueType == 1) {
			szUrl += "/recommendation";
		}
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + szUrl,
			timeout: 15000,
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				ia(TriggerMode).m_Post485Xml = parseXmlFromStr(xmlToStr(xmlDoc));
				$.ajax(
                    {
                        type: "GET",
                        async: false,
                        url:  m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/deviceInfo",
                        beforeSend: function(xhr) {
                            xhr.setRequestHeader("If-Modified-Since", "0");
                            
                        },
                        success: function(xmlDoc, textStatus, xhr) {
                            that.radarRS485Num = $(xmlDoc).find('maxRS485Num').eq(0).text();
                        }
                });

                var $sel = $('#radarEnablePost485Div').find('#radarRS485_post485');
            	$sel.find('option').each(function(i, n){
            		var v = $(this).attr('value');
            		if (parseInt(v) > that.radarRS485Num) {
            			$(this).remove();
            		}
            	});

                if(that.radarRS485Num == 1){
                    $('#radarEnablePost485Div').css('display','none');
                }else{                	
                    $('#radarEnablePost485Div').css('display','block');
					var rsidx = $(xmlDoc).find("radarRS485").eq(0).text();
                    $.g.setField2('#radarRS485_post485', rsidx);
                }
				
				if(strTriggerMode == "postRadar") {
                    fillLaneCountOptions(1, $(xmlDoc).find("PostRadarLane").length, $(xmlDoc).find("RelatedLaneCount").eq(0).text());
				} else {
                    fillLaneCountOptions(1, $(xmlDoc).find("RS485Lane").length, $(xmlDoc).find("RelatedLaneCount").eq(0).text());
				}

				for(var i = 1; i <= 6; i++) {
					if(i > parseInt($(xmlDoc).find("RelatedLaneCount").eq(0).text())) {
					    $("#liRelatedLane" + i).css("display", "none");
					} else {
						$("#liRelatedLane" + i).css("display", "block");
					}
				}
                getTriggerIOCopyInfoForPost485();

                var $trigDiv = $('#taTriggerMode');

                $trigDiv.find("#laneDirectionType_postRS485").val($(xmlDoc).find("laneDirectionType").eq(0).text());
				$trigDiv.find("#RelatedDriveWay").val($(xmlDoc).find("relatedDriveWay").eq(0).text());
				$trigDiv.find("#OSDDriveWay").val($(xmlDoc).find("OSDDriveWay").eq(0).text());

				$trigDiv.find("#useageType").val($(xmlDoc).find("laneUsage").eq(0).text());

				$trigDiv.find("#speedCapEnable_post485").prop("checked", $(xmlDoc).find("speedCapEnabled").eq(0).text() === "true" ? true : false);
				$trigDiv.find("#lowSpeedCapEnable_post485").prop("checked", $(xmlDoc).find("lowSpeedCapEnable").eq(0).text() === "true" ? true : false);
				$trigDiv.find("#signSpeed").val($(xmlDoc).find("signSpeed").eq(0).text());
				$trigDiv.find("#speedLimit").val($(xmlDoc).find("speedLimit").eq(0).text());
				$trigDiv.find("#SnapTimes").val($(xmlDoc).find("snapTimes").eq(0).text());
                $trigDiv.find("#laneType_post485").val($(xmlDoc).find("laneType").eq(0).text());
				$trigDiv.find("#IntervalType_post485").val($(xmlDoc).find("intervalType").eq(0).text());

                $trigDiv.find("#bigCarSignSpeed").val($(xmlDoc).find("bigCarSignSpeed").eq(0).text());
                $trigDiv.find("#bigCarSpeedLimit").val($(xmlDoc).find("bigCarSpeedLimit").eq(0).text());
                $trigDiv.find("#byLowSpeedLimit").val($(xmlDoc).find("byLowSpeedLimit").eq(0).text());
                $trigDiv.find("#byBigCarLowSpeedLimit").val($(xmlDoc).find("byBigCarLowSpeedLimit").eq(0).text());

                $trigDiv.find("#drawRightRegionContent #carHighSpeed").val($(xmlDoc).find("carHighSpeed").eq(0).text());
                $trigDiv.find("#drawRightRegionContent #carLowSpeed").val($(xmlDoc).find("carLowSpeed").eq(0).text());
                $trigDiv.find("#drawRightRegionContent #bigCarHighSpeed").val($(xmlDoc).find("bigCarHighSpeed").eq(0).text());
                $trigDiv.find("#drawRightRegionContent #bigCarLowSpeed").val($(xmlDoc).find("bigCarLowSpeed").eq(0).text());
				changeIntervalType($trigDiv.find("#IntervalType_post485").val());
				for(var i = 1; i < 5; i++){
					$trigDiv.find("#Interval" + i).val("0");
				}

				for(var i = 2; i <= $trigDiv.find("#SnapTimes").val(); i++) {
					$trigDiv.find("#Interval" + (i-1)).val($(xmlDoc).find("IntervalList").eq(0).find("value").eq(i - 2).text());
				}
				
				if($trigDiv.find("#speedCapEnable_post485").prop("checked") && $trigDiv.find("#SnapTimes").val() < 5) {
                    var iIndex = $trigDiv.find("#SnapTimes").val();
                    $trigDiv.find("#Interval" + iIndex).val($(xmlDoc).find("IntervalList").eq(0).find("value").eq(iIndex - 1).text());
				}
				for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
					$trigDiv.find("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked",$(xmlDoc).find("IOOutList").eq(0).find("enabled").eq(i).text() === "true" ? true : false);
				}
				$trigDiv.find("#FlashMode").val($(xmlDoc).find("flashMode").eq(0).text());
				m_iCurSelIONum = 1;
				m_iLastSelIONum = 1;

				if(strTriggerMode == "postRadar") {
					$trigDiv.find("#RadarType_postRadar").val($(xmlDoc).find("radarType").eq(0).text());
                    $('#radarRS485_post485').val($(xmlDoc).find("radarRS485").eq(0).text());
                    $trigDiv.find("#radarSensitivityInfo_post485").val(parseInt($(xmlDoc).find("radarSensitivity").eq(0).text()));  //雷达灵敏度
                    $trigDiv.find("#radarAngle_post485").val($(xmlDoc).find("radarAngle").eq(0).text());
                    $trigDiv.find("#radarLinearCorrection_post485").val($(xmlDoc).find("radarLinearCorrection").eq(0).text());
                    $trigDiv.find("#radarConstantCorrection_post485").val($(xmlDoc).find("radarConstantCorrection").eq(0).text());
                    $trigDiv.find("#delayTime").val($(xmlDoc).find("delayTime").eq(0).text());
                    $trigDiv.find("#delayDistance").val($(xmlDoc).find("delayDistance").eq(0).text());
                    $trigDiv.find("#distance").val($(xmlDoc).find("distance").eq(0).text());

				}
				if(strTriggerMode == "postRS485") {
				    $trigDiv.find("#backupModeOpts").val($(xmlDoc).find("backupMode").eq(0).text());    //备用模式
                    $trigDiv.find("#maxSwitchTime").val($(xmlDoc).find("maxSwitchTime").eq(0).text());
                    $('#delayTime_post485').val($(xmlDoc).find("delayTime").eq(0).text());
                    $trigDiv.find("#delayDistance_post485").val($(xmlDoc).find("delayDistance").eq(0).text());
                    $trigDiv.find("#distance_post485").val($(xmlDoc).find("distance").eq(0).text());
                    $trigDiv.find("#normalTrigger_post485").val($(xmlDoc).find("normalTrigger").eq(0).text());
                    PostRS485ReDisplay();
				}
			}
		});
	}
   
	
    function getTriggerIOCopyInfoForPost485(){

        $('#TriggerIOCopyDiv_post485').find('div.singleIo_checkbox_copy_div').remove();
        var len = $('#RelatedLaneCount_videoEp').val();

        for(var i=0; i < len; i++){

            var disStr = '';
            if($('#tabRelatedLane_post485 #liRelatedLane' + (i+1)).find('a').first().is('.current')){
                disStr = 'disabled="disabled" checked="checked" ';
            }
            var arr = ['<div class="singleIo_checkbox_copy_div">',
                '<input id="post485_copy_checkbox_'+(i+1)+'" ioIdx="'+(i+1)+'" type="checkbox" ',
                disStr,
                'class="singleIo_checkbox"><label for="post485_copy_checkbox_'+(i+1)+'" ',
                ' class="singleIo_checkbox">'+getNodeValue('aRelatedLane'+(i+1))+'</label></div>'];

            $('#TriggerIOCopyDiv_post485').append(arr.join(' '));
        }
    }
	/*************************************************
	Function:		Setpost485Param
	Description:	设置卡口485参数
	Input:			strTriggerMode:触发模式			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.Setpost485Param = function (strTriggerMode) {
		ia(TriggerMode).m_bSetTriggerMode = false;
		//保存当前Tab值
		var iIndex = parseInt(m_iCurSelIONum) - 1;
		$(ia(TriggerMode).m_Post485Xml).find("RelatedLaneCount").eq(0).text($("#RelatedLaneCount_videoEp").val());
		
		$(ia(TriggerMode).m_Post485Xml).find("OSDDriveWay").eq(iIndex).text($("#OSDDriveWay").val());
		$(ia(TriggerMode).m_Post485Xml).find("laneDirectionType").eq(iIndex).text($("#laneDirectionType_postRS485").val());
		$(ia(TriggerMode).m_Post485Xml).find("relatedDriveWay").eq(iIndex).text($("#RelatedDriveWay").val());
		$(ia(TriggerMode).m_Post485Xml).find("speedCapEnabled").eq(iIndex).text($("#speedCapEnable_post485").prop("checked").toString());
		$(ia(TriggerMode).m_Post485Xml).find("lowSpeedCapEnable").eq(iIndex).text($("#lowSpeedCapEnable_post485").prop("checked").toString());
		$(ia(TriggerMode).m_Post485Xml).find("signSpeed").eq(iIndex).text($("#signSpeed").val());
		$(ia(TriggerMode).m_Post485Xml).find("speedLimit").eq(iIndex).text($("#speedLimit").val());
		$(ia(TriggerMode).m_Post485Xml).find("snapTimes").eq(iIndex).text($("#SnapTimes").val());
		$(ia(TriggerMode).m_Post485Xml).find("intervalType").eq(iIndex).text($("#IntervalType_post485").val());
        $(ia(TriggerMode).m_Post485Xml).find("laneType").eq(iIndex).text($("#laneType_post485").val());
        $(ia(TriggerMode).m_Post485Xml).find("laneUsage").eq(iIndex).text($("#useageType").val());

		$(ia(TriggerMode).m_Post485Xml).find("IntervalList").eq(iIndex).remove();
		
		var szInfo = "<?xml version='1.0' encoding='UTF-8'?><IntervalList>";		
		var iSnapTime = parseInt($("#SnapTimes").val());
		if($("#speedCapEnable_post485").prop("checked") && $("#SnapTimes").val() < 5) {    //超速抓拍
			iSnapTime += 1;
		}
		szInfo = "<?xml version='1.0' encoding='UTF-8'?><Temp><IntervalList>";
		for(var i = 1; i < iSnapTime; i++) {
			szInfo += "<Interval><value>" + $("#Interval" + i).val() + "</value></Interval>";
		}
		szInfo += "</IntervalList></Temp>";
		if(strTriggerMode == "postRadar") {
		    $(ia(TriggerMode).m_Post485Xml).find("PostRadarLane").eq(iIndex).append($(parseXmlFromStr(szInfo)).find("Temp").eq(0).clone().children());
		} else {
			$(ia(TriggerMode).m_Post485Xml).find("RS485Lane").eq(iIndex).append($(parseXmlFromStr(szInfo)).find("Temp").eq(0).clone().children());
		}
		
		for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
			$(ia(TriggerMode).m_Post485Xml).find("IOOutList").eq(iIndex).find("enabled").eq(i).text($("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked").toString());
		}
		$(ia(TriggerMode).m_Post485Xml).find("flashMode").eq(iIndex).text($("#FlashMode").val());

        $(ia(TriggerMode).m_Post485Xml).find("bigCarSignSpeed").eq(iIndex).text($("#bigCarSignSpeed").val());
        $(ia(TriggerMode).m_Post485Xml).find("bigCarSpeedLimit").eq(iIndex).text($("#bigCarSpeedLimit").val());
        $(ia(TriggerMode).m_Post485Xml).find("byLowSpeedLimit").eq(iIndex).text($("#byLowSpeedLimit").val());
        $(ia(TriggerMode).m_Post485Xml).find("byBigCarLowSpeedLimit").eq(iIndex).text($("#byBigCarLowSpeedLimit").val());

        $(ia(TriggerMode).m_Post485Xml).find("carHighSpeed").eq(0).text($("#drawRightRegionContent #carHighSpeed").val());
        $(ia(TriggerMode).m_Post485Xml).find("carLowSpeed").eq(0).text($("#drawRightRegionContent #carLowSpeed").val());
        $(ia(TriggerMode).m_Post485Xml).find("bigCarHighSpeed").eq(0).text($("#drawRightRegionContent #bigCarHighSpeed").val());
        $(ia(TriggerMode).m_Post485Xml).find("bigCarLowSpeed").eq(0).text($("#drawRightRegionContent #bigCarLowSpeed").val());

		if(strTriggerMode == "postRadar") {

            $(ia(TriggerMode).m_Post485Xml).find("distance").eq(iIndex).text($("#distance").val());
            $(ia(TriggerMode).m_Post485Xml).find("delayTime").eq(iIndex).text($("#delayTime").val());
            $(ia(TriggerMode).m_Post485Xml).find("delayDistance").eq(iIndex).text($("#delayDistance").val());
			$(ia(TriggerMode).m_Post485Xml).find("radarType").eq(iIndex).text($("#RadarType_postRadar").val());
            $(ia(TriggerMode).m_Post485Xml).find("radarRS485").eq(iIndex).text($("#radarRS485_post485").val());
            $(ia(TriggerMode).m_Post485Xml).find('radarSensitivity').eq(iIndex).text($('#radarSensitivityInfo_post485').val());
            $(ia(TriggerMode).m_Post485Xml).find("radarAngle").eq(iIndex).text($("#radarAngle_post485").val());
            $(ia(TriggerMode).m_Post485Xml).find("validRadarSpeedTime").eq(iIndex).text($("#validRadarSpeedTime_post485").val());   //雷达速度有效时间
            $(ia(TriggerMode).m_Post485Xml).find("radarLinearCorrection").eq(iIndex).text($("#radarLinearCorrection_post485").val());
            $(ia(TriggerMode).m_Post485Xml).find("radarConstantCorrection").eq(iIndex).text($("#radarConstantCorrection_post485").val());
		}
		if(strTriggerMode == "postRS485") {
			$(ia(TriggerMode).m_Post485Xml).find("backupMode").eq(iIndex).text($("#backupModeOpts").val());
			$(ia(TriggerMode).m_Post485Xml).find("maxSwitchTime").eq(iIndex).text($("#maxSwitchTime").val());
            $(ia(TriggerMode).m_Post485Xml).find("normalTrigger").eq(iIndex).text($("#normalTrigger_post485").val());
            $(ia(TriggerMode).m_Post485Xml).find("distance").eq(iIndex).text($("#distance_post485").val());
            $(ia(TriggerMode).m_Post485Xml).find("delayTime").eq(iIndex).text($("#delayTime_post485").val());
            $(ia(TriggerMode).m_Post485Xml).find("delayDistance").eq(iIndex).text($("#delayDistance_post485").val());
		}
//		$(ia(TriggerMode).m_Post485Xml).find("RelatedLaneCount").eq(0).text($("#RelatedLaneCount_videoEp").val());

        var idxs = [];
        var curIoInfo;
        $('#TriggerIOCopyDiv_post485 input[ioIdx]').each(function(i, n){
            if($(n).prop('checked') && !$(n).prop('disabled')){
                idxs.push($(n).attr('ioIdx'));
            }
        });

        if(strTriggerMode == "postRadar") {  //485雷达

            $(ia(TriggerMode).m_Post485Xml).find('PostRadarLane').each(function(i, n){
                var id = $(n).find('laneId').eq(0).text();
                if(id == m_iCurSelIONum){
                    curIoInfo = $(n);
                }
            });

            if(curIoInfo && idxs.length > 0){
                $(ia(TriggerMode).m_Post485Xml).find('PostRadarLane').each(function(i, n){
					$p = $(n);
                    var idx = $(n).find('laneId').eq(0).text();
                    if (_.contains(idxs, idx)){
                        SimpleCopyXmlNode(curIoInfo[0],$p[0],['delayTime','distance','delayDistance','laneType','snapTimes','speedCapEnabled','lowSpeedCapEnable','intervalType',
                            'capSpeed','laneDirectionType','laneUsage','speedLimit','signSpeed','bigCarSpeedLimit','bigCarSignSpeed','byLowSpeedLimit','byBigCarLowSpeedLimit',
                            {propName: 'IntervalList', type: 'subNode'},{propName: 'IOOutList', type: 'subNode'},'flashMode']);
                    }
                });
            }
        }
        if(strTriggerMode == "postRS485"){ //卡口车检器

            $(ia(TriggerMode).m_Post485Xml).find('RS485Lane').each(function(i, n){
                var id = $(n).find('laneId').eq(0).text();
                if(id == m_iCurSelIONum){
                    curIoInfo = $(n);
                }
            });

            if(curIoInfo && idxs.length > 0){
                $(ia(TriggerMode).m_Post485Xml).find('RS485Lane').each(function(i, n){
					$p = $(n);
                    var idx = $(n).find('laneId').eq(0).text();
                    if (_.contains(idxs, idx)){
                        SimpleCopyXmlNode(curIoInfo[0],$p[0],['laneType','lowSpeedCapEnable','snapTimes','speedCapEnabled','intervalType','laneDirectionType','laneUsage',
                            'speedLimit','signSpeed','bigCarSpeedLimit','bigCarSignSpeed','byLowSpeedLimit','byBigCarLowSpeedLimit','flashMode','distance','delayTime','delayDistance',
                            {propName: 'IntervalList', type: 'subNode'},
                            {propName: 'IOOutList', type: 'subNode'}]);
                    }
                });
            }
        }

        $.ajax({
			type: "put",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/" + strTriggerMode,
			timeout: 15000,
			processData: false,
		    data: ia(TriggerMode).m_Post485Xml,
			async:false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			complete:function(xhr, textStatus) {
				if(xhr.status != 200) {
					if(xhr.status == 403) {
						var szErrorInfo = m_szError8;
						szRetInfo = m_szErrorState + szErrorInfo;
					} else {
						var xmlDoc =xhr.responseXML;
						if($(xmlDoc).find("detailedStatusCode").eq(0).text() != "") {
							var szErrorInfo = getNodeValue("Error" + $(xmlDoc).find("detailedStatusCode").eq(0).text());
						} else {
							var szErrorInfo = m_szError13;
						}
						szRetInfo = m_szErrorState + szErrorInfo;
					}
		            $("#SetResultTips").html(szRetInfo); 
			        setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			        return;	
				} else {
					if($(xhr.responseXML).find("statusCode").eq(0).text() == "7") {
						ia(TriggerMode).m_bRebootRequired = true;
					}
					ia(TriggerMode).m_bSetTriggerMode = true;
				    pr(TriggerMode).SetPlateRecognition(strTriggerMode);
				}
			}
		});	
	}

    TriggerMode.prototype.setPost485AdvanceInfo = function(){

        if($('#post485AdvanceContent').css('display') =='none'){
            $('#post485AdvanceContent').css('display','block');
        }else{
            $('#post485AdvanceContent').css('display','none');
        }
//        ia(TriggerMode).enableDelaySetting();
        autoResizeIframe();
    }

    /*TriggerMode.prototype.enableDelaySetting = function(){

        if($('#delayTrigger_post485').prop('checked')){

            $('#delayTime_post485Div').css('color','black');
            $('#delayDistance_post485Div').css('color','black');
            $('#delayTime_post485Div input').prop('disabled',false);
            $('#delayDistance_post485Div input').attr('disabled',false);

        }else{
            $('#delayTime_post485Div').css('color','gray');
            $('#delayDistance_post485Div').css('color','gray');
            $('#delayTime_post485Div input').prop('disabled',true);
            $('#delayDistance_post485Div input').attr('disabled',true);
        }
    }*/
    /*************************************************
     Function:		changeBackupMode
     Description:	改变备用模式函数
     Input:			modeId: 备用模式ID
     Output:			无
     return:			无
     *************************************************/
    TriggerMode.prototype.changeBackupMode = function(modeId){
    	$('#backupInfoTip').html('');
        if(modeId == 0){
			$('#backupInfoTip').html('');
            $("#liBackUpModal2").css('display','none');
            $("#liBackUpModal3").css('display','none');
            if($('#tabBackUpModel .current').attr("name") != "aBackUpModel1"){ //当由 有备用模式切换到无备用模式时，页面需要回归到主要模式。

                $("#tabBackUpModel").find("li").each(function() {
                    if($(this).children().hasClass("current")) {
                        $(this).children().removeClass();
                    }
                });
                $("#tabBackUpModel").find("li").eq(0).find("a").eq(0).addClass("current");
                ia(TriggerMode).changeTriggerMode("postRS485");
//                ia(TriggerMode).selectBackUpMode(0);
            }
        }else if(modeId == 1){
			$('#backupInfoTip').html('&nbsp;'+getNodeValue('backupInfoTip'));
            $("#liBackUpModal2").css('display','block');
            $("#liBackUpModal3").css('display','none');

        }else if(modeId==2){
        	$('#backupInfoTip').html('&nbsp;'+getNodeValue('backupInfoTip'));
        	$("#liBackUpModal2").css('display','none');
        	$("#liBackUpModal3").css('display','block');
        }
    }

    /*************************************************
     Function:		selectBackUpMode
     Description:	选择备用模式函数
     Input:			modeId: 备用模式ID
     Output:			无
     return:			无
     *************************************************/
    TriggerMode.prototype.selectBackUpMode = function(modeId){
        var iLastIndex = parseInt(ia(TriggerMode).m_CurBackUpMode);
        if(modeId == iLastIndex) {
            return;
        }
        $("#tabBackUpModel").find("li").each(function() {
            if($(this).children().hasClass("current")) {
                $(this).children().removeClass();
            }
        });
        $("#tabBackUpModel").find("li").eq(modeId).find("a").eq(0).addClass("current");
        
        if(modeId == 0){
            ia(TriggerMode).changeTriggerMode("postRS485");
            $('#backupModeOpts').val(iLastIndex);
            ia(TriggerMode).changeBackupMode(iLastIndex);

        }else if(modeId == 1){
            ia(TriggerMode).changeTriggerMode("postVTCoil");
            $('#triggerBackupModelDiv').show();
        }else if(modeId == 2){
        	// TriggerModeExt.changeToExtendTriggerMode_backupMode("postHVT");
        	$("#divTriggerModeParams").html("");
        	$.ajax({
	            url:"params/postHVTTriggerMode.asp",
	            type:"GET",
	            dataType:"html",
	            error:function(){
	                showmenuconfig(szMenu,iMode,szMainMenu);
	            },
	            success:function(msg){
	                $("#divTriggerModeParams").html(msg);

	                $("#tabs_postHVT,#triggerMode_postHVT").hide();

	                var objstr="postHVT"+'TriggerMode';
	                if(window[objstr]&&window[objstr].updateLang){
	                    window[objstr].updateLang();
	                };

	                g_oCurrentTab=$(".tabs.tm").tabs(".pane.tm",{remember:false,markCurrent:false});

	                if(window[objstr]&&window[objstr].initPage){
	                    window[objstr].initPage();
	                };
	                postHVTTriggerMode.updateParam();
	                // //TriggerModeExt.initTriggerModeOptions('selTriggerMode','#CurTriggerMode');
	                // $.g.setField2('#selTriggerMode',"postRS485");
	                // $("#CurTriggerMode").html(getNodeValue("apostRS485"));
	            }
	        });
        }
        ia(TriggerMode).m_CurBackUpMode = modeId;
    }
	/*************************************************
	Function:		selectRelatedLane
	Description:	切换车道
	Input:			iLaneNum: 车道号			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.selectRelatedLane = function (iLaneNum) {
		var iLastIndex = parseInt(m_iCurSelIONum) - 1;
		if(iLaneNum == iLastIndex) {
			return;
		}
		$("#tabRelatedLane_post485").find("li").each(function() {
			 if($(this).children().hasClass("current")) {
				 $(this).children().removeClass();
			 }
		});
		$("#tabRelatedLane_post485").find("li").eq(iLaneNum).find("a").eq(0).addClass("current");
		
		var $trigDiv = $('#taTriggerMode');
		var $xmlDoc =  $(ia(TriggerMode).m_Post485Xml);
		//保存之前Tab的值
		var iLastSnapTime = $xmlDoc.find("snapTimes").eq(iLastIndex).text();
		$xmlDoc.find("distance").eq(iLastIndex).text($trigDiv.find("#distance").val());
		$xmlDoc.find("laneDirectionType").eq(iLastIndex).text($trigDiv.find("#laneDirectionType_postRS485").val());
		$xmlDoc.find("relatedDriveWay").eq(iLastIndex).text($trigDiv.find("#RelatedDriveWay").val());
		$xmlDoc.find("OSDDriveWay").eq(iLastIndex).text($trigDiv.find("#OSDDriveWay").val());
		$xmlDoc.find("delayTime").eq(iLastIndex).text($trigDiv.find("#delayTime").val());
		$xmlDoc.find("delayDistance").eq(iLastIndex).text($trigDiv.find("#delayDistance").val());
		$xmlDoc.find("speedCapEnabled").eq(iLastIndex).text($trigDiv.find("#speedCapEnable_post485").prop("checked").toString());
		$xmlDoc.find("lowSpeedCapEnable").eq(iLastIndex).text($trigDiv.find("#lowSpeedCapEnable_post485").prop("checked").toString());
		$xmlDoc.find("signSpeed").eq(iLastIndex).text($trigDiv.find("#signSpeed").val());
		$xmlDoc.find("speedLimit").eq(iLastIndex).text($trigDiv.find("#speedLimit").val());
		$xmlDoc.find("snapTimes").eq(iLastIndex).text($trigDiv.find("#SnapTimes").val());
		$xmlDoc.find("intervalType").eq(iLastIndex).text($trigDiv.find("#IntervalType_post485").val());
        $xmlDoc.find("laneType").eq(iLastIndex).text($trigDiv.find("#laneType_post485").val());

        $xmlDoc.find("bigCarSignSpeed").eq(iLastIndex).text($trigDiv.find("#bigCarSignSpeed").val());
        $xmlDoc.find("bigCarSpeedLimit").eq(iLastIndex).text($trigDiv.find("#bigCarSpeedLimit").val());
         $xmlDoc.find("byLowSpeedLimit").eq(iLastIndex).text($trigDiv.find("#byLowSpeedLimit").val());
        $xmlDoc.find("byBigCarLowSpeedLimit").eq(iLastIndex).text($trigDiv.find("#byBigCarLowSpeedLimit").val());

        $xmlDoc.find("laneUsage").eq(iLastIndex).text($trigDiv.find("#useageType").val());

		$xmlDoc.find("IntervalList").eq(iLastIndex).remove();
			
		var iSnapTime = parseInt($trigDiv.find("#SnapTimes").val());
		if($trigDiv.find("#speedCapEnable_post485").prop("checked") && $trigDiv.find("#SnapTimes").val() < 5) {
			iSnapTime += 1;
		}
		var szInfo = "<?xml version='1.0' encoding='UTF-8'?><Temp><IntervalList>";
		for(var i = 1; i < iSnapTime; i++) {
			szInfo += "<Interval><value>" + $trigDiv.find("#Interval" + i).val() + "</value></Interval>";
		}
		szInfo += "</IntervalList></Temp>";
		if($trigDiv.find("#selTriggerMode").val() == "postRadar") {
		    $xmlDoc.find("PostRadarLane").eq(iLastIndex).append($(parseXmlFromStr(szInfo)).find("Temp").eq(0).clone().children());
		} else {
			$xmlDoc.find("RS485Lane").eq(iLastIndex).append($(parseXmlFromStr(szInfo)).find("Temp").eq(0).clone().children());
		}
		if($trigDiv.find("#selTriggerMode").val() == "postRS485") {
			$xmlDoc.find("backupMode").eq(0).text($trigDiv.find("#backupModeOpts").val());
			$xmlDoc.find("maxSwitchTime").eq(0).text($trigDiv.find("#maxSwitchTime").val());

            $xmlDoc.find("delayTime").eq(iLastIndex).text($trigDiv.find("#delayTime_post485").val());
            $xmlDoc.find("delayDistance").eq(iLastIndex).text($trigDiv.find("#delayDistance_post485").val());
            $xmlDoc.find("distance").eq(iLastIndex).text($trigDiv.find("#distance_post485").val());
		}
		
		for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
			$xmlDoc.find("IOOutList").eq(iLastIndex).find("enabled").eq(i).text($trigDiv.find("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked").toString());
		}
		$xmlDoc.find("flashMode").eq(iLastIndex).text($trigDiv.find("#FlashMode").val());
		if($trigDiv.find("#selTriggerMode").val() == "postRadar") {
			if (this.radarRS485Num == 1 && iLastIndex > 0) {
			
			}else{
				$xmlDoc.find("radarType").eq(iLastIndex).text($trigDiv.find("#RadarType_postRadar").val());
				$xmlDoc.find("radarRS485").eq(iLastIndex).text($trigDiv.find("#radarRS485_post485").val());
				$xmlDoc.find('radarSensitivity').eq(iLastIndex).text($('#radarSensitivityInfo_post485').val());
				$xmlDoc.find("radarAngle").eq(iLastIndex).text($trigDiv.find("#radarAngle_post485").val());
				$xmlDoc.find("validRadarSpeedTime").eq(iLastIndex).text($trigDiv.find("#validRadarSpeedTime_post485").val());
				$xmlDoc.find("radarLinearCorrection").eq(iLastIndex).text($trigDiv.find("#radarLinearCorrection_post485").val());
				$xmlDoc.find("radarConstantCorrection").eq(iLastIndex).text($trigDiv.find("#radarConstantCorrection_post485").val());
			}
		}
		
		//获取当前Tab值
		m_iCurSelIONum = iLaneNum + 1;
		$trigDiv.find("#laneDirectionType_postRS485").val($xmlDoc.find("laneDirectionType").eq(iLaneNum).text());
		$trigDiv.find("#RelatedDriveWay").val($xmlDoc.find("relatedDriveWay").eq(iLaneNum).text());
		$trigDiv.find("#OSDDriveWay").val($xmlDoc.find("OSDDriveWay").eq(iLaneNum).text());
		$trigDiv.find("#distance").val($xmlDoc.find("distance").eq(iLaneNum).text());
		$trigDiv.find("#delayTime").val($xmlDoc.find("delayTime").eq(iLaneNum).text());
		$trigDiv.find("#delayDistance").val($xmlDoc.find("delayDistance").eq(iLaneNum).text());
		$trigDiv.find("#speedCapEnable_post485").prop("checked", $xmlDoc.find("speedCapEnabled").eq(iLaneNum).text() === "true" ? true : false);
		$trigDiv.find("#lowSpeedCapEnable_post485").prop("checked", $xmlDoc.find("lowSpeedCapEnable").eq(iLaneNum).text() === "true" ? true : false);
		$trigDiv.find("#signSpeed").val($xmlDoc.find("signSpeed").eq(iLaneNum).text());
		$trigDiv.find("#speedLimit").val($xmlDoc.find("speedLimit").eq(iLaneNum).text());
		$trigDiv.find("#SnapTimes").val($xmlDoc.find("snapTimes").eq(iLaneNum).text());
		$trigDiv.find("#IntervalType_post485").val($xmlDoc.find("intervalType").eq(iLaneNum).text());
        $trigDiv.find("#laneType_post485").val($xmlDoc.find("laneType").eq(iLaneNum).text());

        $trigDiv.find("#bigCarSignSpeed").val($xmlDoc.find("bigCarSignSpeed").eq(iLaneNum).text());
        $trigDiv.find("#bigCarSpeedLimit").val($xmlDoc.find("bigCarSpeedLimit").eq(iLaneNum).text());
        $trigDiv.find("#byLowSpeedLimit").val($xmlDoc.find("byLowSpeedLimit").eq(iLaneNum).text());
        $trigDiv.find("#byBigCarLowSpeedLimit").val($xmlDoc.find("byBigCarLowSpeedLimit").eq(iLaneNum).text());

        $trigDiv.find("#useageType").val($xmlDoc.find("laneUsage").eq(iLaneNum).text());

        if ($trigDiv.find('#IntervalType_post485').length) {
        	changeIntervalType($trigDiv.find("#IntervalType_post485").val());
        }else{
        	changeIntervalType($trigDiv.find("#IntervalType").val());	
        }

		for(var i = 1; i < 5; i++){
			$trigDiv.find("#Interval" + i).val("0");
		}
		for(var i = 2; i <= $trigDiv.find("#SnapTimes").val(); i++) {
			$trigDiv.find("#Interval" + (i-1)).val($xmlDoc.find("IntervalList").eq(iLaneNum).find("value").eq(i - 2).text());
		}
		if($trigDiv.find("#speedCapEnable_post485").prop("checked") && $trigDiv.find("#SnapTimes").val() < 5) {
			var iIndex = $trigDiv.find("#SnapTimes").val();
			$trigDiv.find("#Interval" + iIndex).val($xmlDoc.find("IntervalList").eq(iLaneNum).find("value").eq(iIndex - 1).text());
		}
		for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
			$trigDiv.find("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked",$xmlDoc.find("IOOutList").eq(iLaneNum).find("enabled").eq(i).text() === "true" ? true : false);
		}
		$trigDiv.find("#FlashMode").val($xmlDoc.find("flashMode").eq(iLaneNum).text());
		if($trigDiv.find("#selTriggerMode").val() == "postRadar") {
			$trigDiv.find("#RadarType_postRadar").val($xmlDoc.find("radarType").eq(iLaneNum).text());
            $trigDiv.find("#radarRS485_post485").val($xmlDoc.find("radarRS485").eq(iLaneNum).text());
            $('#radarSensitivityInfo_post485').val($xmlDoc.find('radarSensitivity').eq(iLaneNum).text());
            $trigDiv.find("#radarAngle_post485").val($xmlDoc.find("radarAngle").eq(iLaneNum).text());
            $trigDiv.find("#validRadarSpeedTime_post485").val($xmlDoc.find("validRadarSpeedTime").eq(iLaneNum).text());
            $trigDiv.find("#radarLinearCorrection_post485").val($xmlDoc.find("radarLinearCorrection").eq(iLaneNum).text());
            $trigDiv.find("#radarConstantCorrection_post485").val($xmlDoc.find("radarConstantCorrection").eq(iLaneNum).text());
		}
		if($trigDiv.find("#selTriggerMode").val() == "postRS485") {

			$trigDiv.find("#backupModeOpts").val($xmlDoc.find("backupMode").eq(0).text());
			$trigDiv.find("#maxSwitchTime").val($xmlDoc.find("maxSwitchTime").eq(0).text());
            $('#delayTime_post485').val($xmlDoc.find("delayTime").eq(iLaneNum).text());
            $trigDiv.find("#delayDistance_post485").val($xmlDoc.find("delayDistance").eq(iLaneNum).text());
            $trigDiv.find("#distance_post485").val($xmlDoc.find("distance").eq(iLaneNum).text());
            $trigDiv.find("#normalTrigger_post485").val($xmlDoc.find("normalTrigger").eq(iLaneNum).text());
		}
		
		var tm = ia(TriggerMode).m_CurTriggerMode;
		if (tm == 'postRadar') {
			PostRadarReDisplay();
		}else if (tm == 'postRS485') {
			PostRS485ReDisplay();
		}else{
			DisplayRegion();	
		}
        getTriggerIOCopyInfoForPost485();

		m_iLastSelIONum = m_iCurSelIONum;
	}
	/*************************************************
	Function:		changeRelatedLane
	Description:	切换车道号
	Input:			iLaneNum:车道数
	                iMaxNum:最大车道数 
	Output:			无
	return:			无				
	*************************************************/
	pr(TriggerMode).changeRelatedLane = function (obj,iLaneNum, iMaxNum) {

		if(!CheackTriggerIntNum(obj, iLaneNum,'laRelatedLaneCount',1,iMaxNum)) {
			return;	
		}
		for(var i = 1; i <= iLaneNum; i++) {
			$("#liRelatedLane" + i).css("display", "block");
		}
		for(var i = (parseInt(iLaneNum) + 1); i <= iMaxNum; i++) {
		   $("#liRelatedLane" + i).css("display", "none");
		}
		if($("#selTriggerMode").val() == "epoliceRS485" || $("#selTriggerMode").val() == "postEpoliceRS485") {
			var szDivInfo = "";
			for(var i = 0; i < iLaneNum; i++) {
				szDivInfo = szDivInfo + "<input class='checkbox' name='LaneCheckbox' id='LaneCheckbox"+ (i + 1)+"' type='checkbox'>&nbsp;"+getNodeValue("aRelatedLane" + (i+1))+ "&nbsp;";	
			}
			$("#DisLaneList").html(szDivInfo);
			$("#LaneCheckbox" + m_iCurSelIONum).prop("disabled", true).prop("checked", true);
		}
	}
	//电警IO红绿灯
	/*************************************************
	Function:		GetepoliceIOTLParam
	Description:	获取电警IO红绿灯参数
	Input:			iValueType: 0 实际值 1 推荐值				
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.GetepoliceIOTLParam = function (iValueType) {
		var szUrl = "/PSIA/Custom/SelfExt/ITC/epoliceIOTL";
		if(iValueType == 1) {
			szUrl += "/recommendation";
		}
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + szUrl,
			timeout: 15000,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				ia(TriggerMode).m_epoliceIOTLXml = parseXmlFromStr(xmlToStr(xmlDoc));
				if($(xmlDoc).find("EpoliceIOTL").length < 2) {
					$("#lilightIO2").css("display", "none");
				}
				$("#LightEnabled").prop("checked", $(xmlDoc).find("enabled").eq(0).text() === "true" ? true : false);
				$("#lightIO").val($(xmlDoc).find("lightIO").eq(0).text());
				$("#trafficLightStatus").val($(xmlDoc).find("trafficLightStatus").eq(0).text());
				$("#triggerIO").val($(xmlDoc).find("triggerIO").eq(0).text());
				$("#triggerIOStatus").val($(xmlDoc).find("triggerIOStatus").eq(0).text());
				$("#RelatedDriveWay").val($(xmlDoc).find("relatedDriveWay").eq(0).text());
				$("#laneDirectionType_epoliceIOTL").val($(xmlDoc).find("laneDirectionType").eq(0).text());
				$("#recordEnable").prop("checked", $(xmlDoc).find("recordEnable").eq(0).text() === "true" ? true : false);
				$("#recordType").val($(xmlDoc).find("recordType").eq(0).text());
				$("#preRecordTime").val($(xmlDoc).find("preRecordTime").eq(0).text());		
				$("#recordDelayTime").val($(xmlDoc).find("recordDelayTime").eq(0).text());			
				$("#recordTimeOut").val($(xmlDoc).find("recordTimeOut").eq(0).text());				
				$("#redSnapTimes").val($(xmlDoc).find("redSnapTimes").eq(0).text());
				$("#greenSnapTimes").val($(xmlDoc).find("greenSnapTimes").eq(0).text());
				$("#IntervalType").val($(xmlDoc).find("intervalType").eq(0).text());
				changeIntervalType($("#IntervalType").val());
				for(var i = 1; i < 5; i++){
					$("#redInterval" + i).val("0");
					$("#greenInterval" + i).val("0");
				}
				$(xmlDoc).find("EpoliceIOTL").eq(0).find("trafficLightTpye").each( function() {
					if($(this).text() == "red") {
						for(var i = 2; i <= $("#redSnapTimes").val(); i++) {
						   $("#redInterval" + (i-1)).val($(this).parent().find("IntervalList").eq(0).find("value").eq(i - 2).text());
						}
					} else if($(this).text() == "green") {
						for(var i = 2; i <= $("#greenSnapTimes").val(); i++) {
							$("#greenInterval" + (i-1)).val($(this).parent().find("IntervalList").eq(0).find("value").eq(i - 2).text());
						}
					}
				});
				
				for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
					$("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked",$(xmlDoc).find("IOOutList").eq(0).find("enabled").eq(i).text() === "true" ? true : false);
				}
				$("#FlashMode").val($(xmlDoc).find("flashMode").eq(0).text());
				m_iCurSelIONum = 1;
				m_iLastSelIONum = 1;
			}
		});
	}
	/*************************************************
	Function:		SetepoliceIOTLParam
	Description:	设置电警IO红绿灯
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.SetepoliceIOTLParam = function () {
		ia(TriggerMode).m_bSetTriggerMode = false;
		//保存当前tab页的值
		var iIndex = parseInt(m_iCurSelIONum) - 1;
		
		$(ia(TriggerMode).m_epoliceIOTLXml).find("EpoliceIOTL").eq(iIndex).find("enabled").eq(0).text($("#LightEnabled").prop("checked").toString());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("lightIO").eq(iIndex).text($("#lightIO").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("trafficLightStatus").eq(iIndex).text($("#trafficLightStatus").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("triggerIO").eq(iIndex).text($("#triggerIO").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("triggerIOStatus").eq(iIndex).text($("#triggerIOStatus").val());		
		$(ia(TriggerMode).m_epoliceIOTLXml).find("relatedDriveWay").eq(iIndex).text($("#RelatedDriveWay").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("laneDirectionType").eq(iIndex).text($("#laneDirectionType_epoliceIOTL").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("recordEnable").eq(iIndex).text($("#recordEnable").prop("checked").toString());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("recordType").eq(iIndex).text($("#recordType").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("preRecordTime").eq(iIndex).text($("#preRecordTime").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("recordDelayTime").eq(iIndex).text($("#recordDelayTime").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("recordTimeOut").eq(iIndex).text($("#recordTimeOut").val());		
		$(ia(TriggerMode).m_epoliceIOTLXml).find("redSnapTimes").eq(iIndex).text($("#redSnapTimes").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("greenSnapTimes").eq(iIndex).text($("#greenSnapTimes").val());
		$(ia(TriggerMode).m_epoliceIOTLXml).find("intervalType").eq(iIndex).text($("#IntervalType").val());
		
		$(ia(TriggerMode).m_epoliceIOTLXml).find("TrafficLightIntervalList").eq(iIndex).find("TrafficLightInterval").each( function()        {
			$(this).remove();
		});
		var szInfo = "<?xml version='1.0' encoding='UTF-8'?><TrafficLightInterval><trafficLightTpye>red</trafficLightTpye><IntervalList>";
		for(var i = 1; i < $("#redSnapTimes").val(); i++) {
			szInfo += "<Interval><value>" + $("#redInterval" + i).val() + "</value></Interval>";
		}
		szInfo += "</IntervalList></TrafficLightInterval>";
		$(ia(TriggerMode).m_epoliceIOTLXml).find("TrafficLightIntervalList").eq(iIndex).append($(parseXmlFromStr(szInfo)).find("TrafficLightInterval").eq(0).clone().children());
		
		szInfo = "<?xml version='1.0' encoding='UTF-8'?><TrafficLightInterval><trafficLightTpye>green</trafficLightTpye><IntervalList>";
		for(var i = 1; i < $("#greenSnapTimes").val(); i++) {
			szInfo += "<Interval><value>" + $("#greenInterval" + i).val() + "</value></Interval>";
		}
		szInfo += "</IntervalList></TrafficLightInterval>";
		$(ia(TriggerMode).m_epoliceIOTLXml).find("TrafficLightIntervalList").eq(iIndex).append($(parseXmlFromStr(szInfo)).find("TrafficLightInterval").eq(0).clone().children());
		
		for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
			$(ia(TriggerMode).m_epoliceIOTLXml).find("IOOutList").eq(iIndex).find("enabled").eq(i).text($("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked").toString());
		}
		$(ia(TriggerMode).m_epoliceIOTLXml).find("flashMode").eq(iIndex).text($("#FlashMode").val());
		$.ajax({
			type: "put",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/epoliceIOTL",
			timeout: 15000,
			processData: false,
		    data: ia(TriggerMode).m_epoliceIOTLXml,
			async:false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			complete:function(xhr, textStatus) {
				if(xhr.status != 200) {
					if(xhr.status == 403) {
						var szErrorInfo = m_szError8;
						szRetInfo = m_szErrorState + szErrorInfo;
					} else {
						var xmlDoc =xhr.responseXML;
						if($(xmlDoc).find("detailedStatusCode").eq(0).text() != "") {
							var szErrorInfo = getNodeValue("Error" + $(xmlDoc).find("detailedStatusCode").eq(0).text());
						} else {
							var szErrorInfo = m_szError13;
						}
						szRetInfo = m_szErrorState + szErrorInfo;
					}
		            $("#SetResultTips").html(szRetInfo); 
			        setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			        return;	
				} else {
					if($(xhr.responseXML).find("statusCode").eq(0).text() == "7") {
						ia(TriggerMode).m_bRebootRequired = true;
					}
					ia(TriggerMode).m_bSetTriggerMode = true;
				    pr(TriggerMode).SetPlateRecognition("epoliceIOTL");
				}
			}
		});
	}
	/*************************************************
	Function:		selectepoliceIOTL
	Description:	获取每个红绿灯组的参数
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.selectepoliceIOTL = function (iEpoliceIONum) {
		var iLastIndex = parseInt(m_iCurSelIONum) - 1;
		if(iEpoliceIONum == iLastIndex) {
			return;
		}
		$("#tabepoliceIOTL").find("li").each(function() {
			 if($(this).children().hasClass("current")) {
				 $(this).children().removeClass();
			 }
		});
		$("#tabepoliceIOTL").find("li").eq(iEpoliceIONum).find("a").eq(0).addClass("current");
		//保存当前Tab值
		if(ia(TriggerMode).m_epoliceIOTLXml !== null) {
			
			$(ia(TriggerMode).m_epoliceIOTLXml).find("EpoliceIOTL").eq(iLastIndex).find("enabled").eq(0).text($("#LightEnabled").prop("checked").toString());
			$(ia(TriggerMode).m_epoliceIOTLXml).find("lightIO").eq(iLastIndex).text($("#lightIO").val());
			$(ia(TriggerMode).m_epoliceIOTLXml).find("trafficLightStatus").eq(iLastIndex).text($("#trafficLightStatus").val());
			$(ia(TriggerMode).m_epoliceIOTLXml).find("triggerIO").eq(iLastIndex).text($("#triggerIO").val());
			$(ia(TriggerMode).m_epoliceIOTLXml).find("triggerIOStatus").eq(iLastIndex).text($("#triggerIOStatus").val());		
			$(ia(TriggerMode).m_epoliceIOTLXml).find("relatedDriveWay").eq(iLastIndex).text($("#RelatedDriveWay").val());
			$(ia(TriggerMode).m_epoliceIOTLXml).find("laneDirectionType").eq(iLastIndex).text($("#laneDirectionType_epoliceIOTL").val());
			$(ia(TriggerMode).m_epoliceIOTLXml).find("recordEnable").eq(iLastIndex).text($("#recordEnable").prop("checked").toString());
			$(ia(TriggerMode).m_epoliceIOTLXml).find("recordType").eq(iLastIndex).text($("#recordType").val());
			$(ia(TriggerMode).m_epoliceIOTLXml).find("preRecordTime").eq(iLastIndex).text($("#preRecordTime").val());
			$(ia(TriggerMode).m_epoliceIOTLXml).find("recordDelayTime").eq(iLastIndex).text($("#recordDelayTime").val());
			$(ia(TriggerMode).m_epoliceIOTLXml).find("recordTimeOut").eq(iLastIndex).text($("#recordTimeOut").val());		
			$(ia(TriggerMode).m_epoliceIOTLXml).find("redSnapTimes").eq(iLastIndex).text($("#redSnapTimes").val());
			$(ia(TriggerMode).m_epoliceIOTLXml).find("greenSnapTimes").eq(iLastIndex).text($("#greenSnapTimes").val());
			$(ia(TriggerMode).m_epoliceIOTLXml).find("intervalType").eq(iLastIndex).text($("#IntervalType").val());
			
			$(ia(TriggerMode).m_epoliceIOTLXml).find("TrafficLightIntervalList").eq(iLastIndex).find("TrafficLightInterval").each( function() {
				$(this).remove();
			});
			var szInfo = "<?xml version='1.0' encoding='UTF-8'?><TrafficLightInterval><trafficLightTpye>red</trafficLightTpye><IntervalList>";
			for(var i = 1; i < $("#redSnapTimes").val(); i++) {
				szInfo += "<Interval><value>" + $("#redInterval" + i).val() + "</value></Interval>";
			}
			szInfo += "</IntervalList></TrafficLightInterval>";
			$(ia(TriggerMode).m_epoliceIOTLXml).find("TrafficLightIntervalList").eq(iLastIndex).append($(parseXmlFromStr(szInfo)).find("TrafficLightInterval").eq(0).clone().children());
			
			szInfo = "<?xml version='1.0' encoding='UTF-8'?><TrafficLightInterval><trafficLightTpye>green</trafficLightTpye><IntervalList>";
			for(var i = 1; i < $("#greenSnapTimes").val(); i++) {
				szInfo += "<Interval><value>" + $("#greenInterval" + i).val() + "</value></Interval>";
			}
			szInfo += "</IntervalList></TrafficLightInterval>";
			$(ia(TriggerMode).m_epoliceIOTLXml).find("TrafficLightIntervalList").eq(iLastIndex).append($(parseXmlFromStr(szInfo)).find("TrafficLightInterval").eq(0).clone().children());
			
			for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
				$(ia(TriggerMode).m_epoliceIOTLXml).find("IOOutList").eq(iLastIndex).find("enabled").eq(i).text($("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked").toString());
			}
			$(ia(TriggerMode).m_epoliceIOTLXml).find("flashMode").eq(iLastIndex).text($("#FlashMode").val());
			
			//获取当前Tab值
			m_iCurSelIONum = parseInt(iEpoliceIONum) + 1;
			$("#LightEnabled").prop("checked", $(ia(TriggerMode).m_epoliceIOTLXml).find("EpoliceIOTL").eq(iEpoliceIONum).find("enabled").eq(0).text() === "true" ? true : false);
			$("#lightIO").val($(ia(TriggerMode).m_epoliceIOTLXml).find("lightIO").eq(iEpoliceIONum).text());
			$("#trafficLightStatus").val($(ia(TriggerMode).m_epoliceIOTLXml).find("trafficLightStatus").eq(iEpoliceIONum).text());
			$("#triggerIO").val($(ia(TriggerMode).m_epoliceIOTLXml).find("triggerIO").eq(iEpoliceIONum).text());
			$("#triggerIOStatus").val($(ia(TriggerMode).m_epoliceIOTLXml).find("triggerIOStatus").eq(iEpoliceIONum).text());
			$("#RelatedDriveWay").val($(ia(TriggerMode).m_epoliceIOTLXml).find("relatedDriveWay").eq(iEpoliceIONum).text());
			$("#laneDirectionType_epoliceIOTL").val($(ia(TriggerMode).m_epoliceIOTLXml).find("laneDirectionType").eq(iEpoliceIONum).text());
			$("#recordEnable").prop("checked", $(ia(TriggerMode).m_epoliceIOTLXml).find("recordEnable").eq(iEpoliceIONum).text() === "true" ? true : false);
			$("#recordType").val($(ia(TriggerMode).m_epoliceIOTLXml).find("recordType").eq(iEpoliceIONum).text());
			$("#preRecordTime").val($(ia(TriggerMode).m_epoliceIOTLXml).find("preRecordTime").eq(iEpoliceIONum).text());		
			$("#recordDelayTime").val($(ia(TriggerMode).m_epoliceIOTLXml).find("recordDelayTime").eq(iEpoliceIONum).text());			
			$("#recordTimeOut").val($(ia(TriggerMode).m_epoliceIOTLXml).find("recordTimeOut").eq(iEpoliceIONum).text());				
			$("#redSnapTimes").val($(ia(TriggerMode).m_epoliceIOTLXml).find("redSnapTimes").eq(iEpoliceIONum).text());
			$("#greenSnapTimes").val($(ia(TriggerMode).m_epoliceIOTLXml).find("greenSnapTimes").eq(iEpoliceIONum).text());
			$("#IntervalType").val($(ia(TriggerMode).m_epoliceIOTLXml).find("intervalType").eq(iEpoliceIONum).text());
			changeIntervalType($("#IntervalType").val());
			for(var i = 1; i < 5; i++){
				$("#redInterval" + i).val("0");
				$("#greenInterval" + i).val("0");
			}
			$(ia(TriggerMode).m_epoliceIOTLXml).find("EpoliceIOTL").eq(iEpoliceIONum).find("trafficLightTpye").each( function() {
				if($(this).text() == "red") {
					for(var i = 2; i <= $("#redSnapTimes").val(); i++) {
					   $("#redInterval" + (i-1)).val($(this).parent().find("IntervalList").eq(0).find("value").eq(i - 2).text());
					}
				} else if($(this).text() == "green") {
					for(var i = 2; i <= $("#greenSnapTimes").val(); i++) {
						$("#greenInterval" + (i-1)).val($(this).parent().find("IntervalList").eq(0).find("value").eq(i - 2).text());
					}
				}
			});
			
			for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
				$("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked",$(ia(TriggerMode).m_epoliceIOTLXml).find("IOOutList").eq(iEpoliceIONum).find("enabled").eq(i).text() === "true" ? true : false);
			}
			$("#FlashMode").val($(ia(TriggerMode).m_epoliceIOTLXml).find("flashMode").eq(iEpoliceIONum).text());
		}
		
		DisplayRegion();
		m_iLastSelIONum = m_iCurSelIONum;
	}
	//电警车检器相关
	/*************************************************
	Function:		GetepoliceRS485Param
	Description:	获取电警车检器参数
	Input:			iValueType: 0 实际值 1 推荐值				
	Output:			无
	return:			无				
	*************************************************/
    TriggerMode.prototype.GetepoliceRS485Param = function (strTriggerMode, iValueType) {
		if(strTriggerMode == "epoliceRS485") {
			$("#dvsignSpeed").css("display", "none");
			$("#dvspeedLimit").css("display", "none");
            $("#dvbigCarSpeedLimit_epolice").css("display", "none");
            $("#dvbigCarSignSpeed_epolice").css("display", "none");
		} else {
			$("#dvsignSpeed").css("display", "block");
			$("#dvspeedLimit").css("display", "block");
            $("#dvbigCarSpeedLimit_epolice").css("display", "block");
            $("#dvbigCarSignSpeed_epolice").css("display", "block");
		}
		var szUrl = "/PSIA/Custom/SelfExt/ITC/" + strTriggerMode;
		if(iValueType == 1) {
			szUrl += "/recommendation";
		}
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + szUrl,
			timeout: 15000,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {

				ia(TriggerMode).m_epoliceRS485Xml = parseXmlFromStr(xmlToStr(xmlDoc));
				if(strTriggerMode == "epoliceRS485") {  //设备关联的车道总数需从返回的xml中获取，xml中返回设备支持的最大个数个节点
                    fillLaneCountOptions(1,$(xmlDoc).find("EpoliceRS485Lane").length,$(xmlDoc).find("RelatedLaneCount").eq(0).text());
				} else {
                    fillLaneCountOptions(1,$(xmlDoc).find("PostEpoliceRS485Lane").length,$(xmlDoc).find("RelatedLaneCount").eq(0).text());
				}
				for(var i = 1; i <= 6; i++) {
					if(i > parseInt($(xmlDoc).find("RelatedLaneCount").eq(0).text())) {
					    $("#liRelatedLane" + i).css("display", "none");
					} else {
						$("#liRelatedLane" + i).css("display", "block");
					}
				}

				$("#laneDirectionType_epoliceRS485").val($(xmlDoc).find("laneDirectionType").eq(0).text());
				$("#RelatedDriveWay").val($(xmlDoc).find("relatedDriveWay").eq(0).text());
                $("#redLightDriveWay").val($(xmlDoc).find("redLightDriveWay").eq(0).text());
                $("#yellowLightDriveWay").val($(xmlDoc).find("yellowLightDriveWay").eq(0).text());
				$("#OSDDriveWay").val($(xmlDoc).find("OSDDriveWay").eq(0).text());
				$("#distance").val($(xmlDoc).find("distance").eq(0).text());
				$("#recordEnable").prop("checked", $(xmlDoc).find("recordEnable").eq(0).text() === "true" ? true : false);
				$("#recordType").val($(xmlDoc).find("recordType").eq(0).text());
				$("#preRecordTime").val($(xmlDoc).find("preRecordTime").eq(0).text());		
				$("#recordDelayTime").val($(xmlDoc).find("recordDelayTime").eq(0).text());			
				$("#recordTimeOut").val($(xmlDoc).find("recordTimeOut").eq(0).text());	
				if(strTriggerMode == "postEpoliceRS485") {
					$("#signSpeed").val($(xmlDoc).find("signSpeed").eq(0).text());			
				    $("#speedLimit").val($(xmlDoc).find("speedLimit").eq(0).text());
                    $('#bigCarSpeedLimit_epolice').val($(xmlDoc).find("bigCarSpeedLimit").eq(0).text());
                    $('#bigCarSignSpeed_epolice').val($(xmlDoc).find("bigCarSignSpeed").eq(0).text());
                   
                    $('#drawRightRegionContent #carHighSpeed_epolice').val($(xmlDoc).find("carHighSpeed").eq(0).text());
                    $('#drawRightRegionContent #carLowSpeed_epolice').val($(xmlDoc).find("carLowSpeed").eq(0).text());
                    $('#drawRightRegionContent #bigCarHighSpeed_epolice').val($(xmlDoc).find("bigCarHighSpeed").eq(0).text());
                    $('#drawRightRegionContent #bigCarLowSpeed_epolice').val($(xmlDoc).find("bigCarLowSpeed").eq(0).text());
				}
				
				$("#IntervalType").val($(xmlDoc).find("intervalType").eq(0).text());
				changeIntervalType($("#IntervalType").val());
				$("#interval").val($(xmlDoc).find("interval").eq(0).text());				
				for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
					$("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked",$(xmlDoc).find("IOOutList").eq(0).find("enabled").eq(i).text() === "true" ? true : false);
				}
				$("#FlashMode").val($(xmlDoc).find("flashMode").eq(0).text());
				
				$("#serialProtocol").val($(xmlDoc).find("serialProtocol").eq(0).text());
				ia(TriggerMode).changeSerialProtocol($("#serialProtocol").val());
				$("#LaneCheckbox1").prop("disabled", true).prop("checked", true);
				 
				$("#redLightSerialProtocol").val($(xmlDoc).find("redLightSerialProtocol").eq(0).text());
				$("#reverseSerialProtocol").val($(xmlDoc).find("reverseSerialProtocol").eq(0).text());
				$("#normalSpeedSerialProtocol").val($(xmlDoc).find("normalSpeedSerialProtocol").eq(0).text());
				$("#overSpeedSerialProtocol").val($(xmlDoc).find("overSpeedSerialProtocol").eq(0).text());

                $("#trafficLightSource").val($(xmlDoc).find("trafficLightSource").eq(0).text());
                pr(TriggerMode).changeLightType();
                getTriggerIOCopyInfoForEpolice485();

				m_iCurSelIONum = 1;
				m_iLastSelIONum = 1;

				if(strTriggerMode == "epoliceRS485") {
					EpoliceRS485ReDisplay();
				} else {
					PostEpoliceRS485ReDisplay();
				}
			}
		});		
	}

    function getTriggerIOCopyInfoForEpolice485(){

        $('#TriggerIOCopyDiv_epolice').find('div.singleIo_checkbox_copy_div').remove();
        var len = $('#RelatedLaneCount_videoEp').val();

        for(var i=0; i < len; i++){

            var disStr = '';
            if($('#tabRelatedLane #liRelatedLane' + (i+1)).find('a').first().is('.current')){
                disStr = 'disabled="disabled" checked="checked" ';
            }
            var arr = ['<div class="singleIo_checkbox_copy_div">',
                '<input id="epolice485_copy_checkbox_'+(i+1)+'" ioIdx="'+(i+1)+'" type="checkbox" ',
                disStr,
                'class="singleIo_checkbox"><label for="epolice485_copy_checkbox_'+(i+1)+'" ',
                ' class="singleIo_checkbox">'+getNodeValue('aRelatedLane'+(i+1))+'</label></div>'];

            $('#TriggerIOCopyDiv_epolice').append(arr.join(' '));
        }
    }
	/*************************************************
	Function:		changeSerialProtocol
	Description:	切换车检器协议
	Input:			strSerialProtocol:车检器协议类型		
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.changeSerialProtocol = function (strSerialProtocol) {
		var szDivInfo = "";
		for(var i = 0; i < parseInt($(ia(TriggerMode).m_epoliceRS485Xml).find("RelatedLaneCount").eq(0).text()); i++) {
			szDivInfo = szDivInfo + "<input class='checkbox' name='LaneCheckbox' id='LaneCheckbox"+ (i + 1)+"' type='checkbox'>&nbsp;"+getNodeValue("aRelatedLane" + (i+1))+ "&nbsp;";	
		}
		$("#DisLaneList").html(szDivInfo);
		$("#LaneCheckbox" + m_iCurSelIONum).prop("disabled", true).prop("checked", true);
			
		if(strSerialProtocol == "0") {
			if($("#selTriggerMode").val() == "epoliceRS485") {
				$("#dvredLightSerialProtocol").show();
				$("#dvreverseSerialProtocol").show();
				$("#dvNormalSpeedProtocol").hide();
				$("#dvOverSpeedProtocol").hide();
			} else {
				$("#dvredLightSerialProtocol").show();
				$("#dvreverseSerialProtocol").show();
				$("#dvNormalSpeedProtocol").show();
				$("#dvOverSpeedProtocol").show();
			}
            $('#delayIntervalTypeDiv').show();
            $('#delayIntervalDiv').show();
			autoResizeIframe();
		} else {
			$("#dvredLightSerialProtocol").hide();
			$("#dvreverseSerialProtocol").hide();
			$("#dvNormalSpeedProtocol").hide();
			$("#dvOverSpeedProtocol").hide();
            $('#delayIntervalTypeDiv').hide();
            $('#delayIntervalDiv').hide();
		}
	}
	/*************************************************
	Function:		SetepoliceRS485Param
	Description:	设置电警车检器
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.SetepoliceRS485Param = function (strTriggerMode) {
		ia(TriggerMode).m_bSetTriggerMode = false;
		$(ia(TriggerMode).m_epoliceRS485Xml).find("RelatedLaneCount").eq(0).text($("#RelatedLaneCount_videoEp").val());
		//保存当前tab页的值
		var iIndex = parseInt(m_iCurSelIONum) - 1;
		
		$(ia(TriggerMode).m_epoliceRS485Xml).find("relatedDriveWay").eq(iIndex).text($("#RelatedDriveWay").val());
		$(ia(TriggerMode).m_epoliceRS485Xml).find("laneDirectionType").eq(iIndex).text($("#laneDirectionType_epoliceRS485").val());
        $(ia(TriggerMode).m_epoliceRS485Xml).find("OSDDriveWay").eq(iIndex).text($("#OSDDriveWay").val());
        $(ia(TriggerMode).m_epoliceRS485Xml).find("redLightDriveWay").eq(iIndex).text($("#redLightDriveWay").val());
		$(ia(TriggerMode).m_epoliceRS485Xml).find("yellowLightDriveWay").eq(iIndex).text($("#yellowLightDriveWay").val());
		$(ia(TriggerMode).m_epoliceRS485Xml).find("distance").eq(iIndex).text($("#distance").val());
		$(ia(TriggerMode).m_epoliceRS485Xml).find("recordEnable").eq(iIndex).text($("#recordEnable").prop("checked").toString());
		$(ia(TriggerMode).m_epoliceRS485Xml).find("recordType").eq(iIndex).text($("#recordType").val());
		$(ia(TriggerMode).m_epoliceRS485Xml).find("preRecordTime").eq(iIndex).text($("#preRecordTime").val());
		$(ia(TriggerMode).m_epoliceRS485Xml).find("recordDelayTime").eq(iIndex).text($("#recordDelayTime").val());
		$(ia(TriggerMode).m_epoliceRS485Xml).find("recordTimeOut").eq(iIndex).text($("#recordTimeOut").val());	
		$(ia(TriggerMode).m_epoliceRS485Xml).find("intervalType").eq(iIndex).text($("#IntervalType").val());	
		$(ia(TriggerMode).m_epoliceRS485Xml).find("interval").eq(iIndex).text($("#interval").val());

        $(ia(TriggerMode).m_epoliceRS485Xml).find("trafficLightSource").eq(0).text($("#trafficLightSource").val());
		
		for(var i = 0; i < $("#RelatedLaneCount_videoEp").val(); i++) {
			if($("#LaneCheckbox" + (i+1)).prop("checked")) {
				$(ia(TriggerMode).m_epoliceRS485Xml).find("serialProtocol").eq(i).text($("#serialProtocol").val());
		        $(ia(TriggerMode).m_epoliceRS485Xml).find("redLightSerialProtocol").eq(i).text($("#redLightSerialProtocol").val());
		        $(ia(TriggerMode).m_epoliceRS485Xml).find("reverseSerialProtocol").eq(i).text($("#reverseSerialProtocol").val());
		        $(ia(TriggerMode).m_epoliceRS485Xml).find("normalSpeedSerialProtocol").eq(i).text($("#normalSpeedSerialProtocol").val());
		        $(ia(TriggerMode).m_epoliceRS485Xml).find("overSpeedSerialProtocol").eq(i).text($("#overSpeedSerialProtocol").val());
			}
		}
		
		for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
			$(ia(TriggerMode).m_epoliceRS485Xml).find("IOOutList").eq(iIndex).find("enabled").eq(i).text($("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked").toString());
		}
		$(ia(TriggerMode).m_epoliceRS485Xml).find("flashMode").eq(iIndex).text($("#FlashMode").val());
		if(strTriggerMode == "postEpoliceRS485") {
			$(ia(TriggerMode).m_epoliceRS485Xml).find("signSpeed").eq(iIndex).text($("#signSpeed").val());
			$(ia(TriggerMode).m_epoliceRS485Xml).find("speedLimit").eq(iIndex).text($("#speedLimit").val());

            $(ia(TriggerMode).m_epoliceRS485Xml).find("bigCarSpeedLimit").eq(iIndex).text($("#bigCarSpeedLimit_epolice").val());
            $(ia(TriggerMode).m_epoliceRS485Xml).find("bigCarSignSpeed").eq(iIndex).text($("#bigCarSignSpeed_epolice").val());
            
            $(ia(TriggerMode).m_epoliceRS485Xml).find("carHighSpeed").eq(0).text($("#drawRightRegionContent #carHighSpeed_epolice").val());
            $(ia(TriggerMode).m_epoliceRS485Xml).find("carLowSpeed").eq(0).text($("#drawRightRegionContent #carLowSpeed_epolice").val());
            $(ia(TriggerMode).m_epoliceRS485Xml).find("bigCarHighSpeed").eq(0).text($("#drawRightRegionContent #bigCarHighSpeed_epolice").val());
            $(ia(TriggerMode).m_epoliceRS485Xml).find("bigCarLowSpeed").eq(0).text($("#drawRightRegionContent #bigCarLowSpeed_epolice").val());
		}

        var idxs = [];
        var curIoInfo;
        $('#TriggerIOCopyDiv_epolice input[ioIdx]').each(function(i, n){
            if($(n).prop('checked') && !$(n).prop('disabled')){
                idxs.push($(n).attr('ioIdx'));
            }
        });

        if(strTriggerMode == "epoliceRS485") {
            $(ia(TriggerMode).m_epoliceRS485Xml).find('EpoliceRS485Lane').each(function(i, n){
                var id = $(n).find('laneId').eq(0).text();
                if(id == m_iCurSelIONum){
                    curIoInfo = $(n);
                }
            });

            if(curIoInfo && idxs.length > 0){
                $(ia(TriggerMode).m_epoliceRS485Xml).find('EpoliceRS485Lane').each(function(i, n){
					$p = $(n);
                    var idx = $(n).find('laneId').eq(0).text();
                    if (_.contains(idxs, idx)){
                        SimpleCopyXmlNode(curIoInfo[0],$p[0],['laneDirectionType','serialProtocol','redLightSerialProtocol','laneUsage','lowSpeedCapEnable','reverseSerialProtocol',
                            'distance','intervalType','interval','recordEnable','recordType','recordTimeOut','preRecordTime','flashMode',
                            {propName: 'IOOutList', type: 'subNode'}]);
                    }
                });
            }
        }

        if(strTriggerMode == "postEpoliceRS485") {

            $(ia(TriggerMode).m_epoliceRS485Xml).find('PostEpoliceRS485Lane').each(function(i, n){
                var id = $(n).find('laneId').eq(0).text();
                if(id == m_iCurSelIONum){
                    curIoInfo = $(n);
                }
            });

            if(curIoInfo && idxs.length > 0){
                $(ia(TriggerMode).m_epoliceRS485Xml).find('PostEpoliceRS485Lane').each(function(i, n){
					$p = $(n);
                    var idx = $(n).find('laneId').eq(0).text();
                    if (_.contains(idxs, idx)){
                        SimpleCopyXmlNode(curIoInfo[0],$p[0],['laneDirectionType','laneUsage','lowSpeedCapEnable','serialProtocol','redLightSerialProtocol','normalSpeedSerialProtocol','reverseSerialProtocol',
                            'overSpeedSerialProtocol','speedLimit','signSpeed','bigCarSpeedLimit','bigCarSignSpeed','byLowSpeedLimit','byBigCarLowSpeedLimit','distance','intervalType','interval',
                            'recordEnable','recordType','recordTimeOut','preRecordTime','flashMode',
                            {propName: 'IOOutList', type: 'subNode'}]);
                    }
                });
            }
        }

		$.ajax({
			type: "put",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/" + strTriggerMode,
			timeout: 15000,
			processData: false,
		    data: xmlToStr(ia(TriggerMode).m_epoliceRS485Xml),
			async:false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			complete:function(xhr, textStatus) {
				if(xhr.status != 200) {
					if(xhr.status == 403) {
						var szErrorInfo = m_szError8;
						szRetInfo = m_szErrorState + szErrorInfo;
					} else {
						var xmlDoc =xhr.responseXML;
						if($(xmlDoc).find("detailedStatusCode").eq(0).text() != "") {
							var szErrorInfo = getNodeValue("Error" + $(xmlDoc).find("detailedStatusCode").eq(0).text());
						} else {
							var szErrorInfo = m_szError13;
						}
						szRetInfo = m_szErrorState + szErrorInfo;
					}
		            $("#SetResultTips").html(szRetInfo); 
			        setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			        return;	
				} else {
					if($(xhr.responseXML).find("statusCode").eq(0).text() == "7") {
						ia(TriggerMode).m_bRebootRequired = true;
					}
					ia(TriggerMode).m_bSetTriggerMode = true;
				    pr(TriggerMode).SetPlateRecognition(strTriggerMode);
				}
			}
		});
	}
	/*************************************************
	Function:		selectEpoliceLane
	Description:	切换车道
	Input:			iLaneNum: 车道号			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.selectEpoliceLane = function (iLaneNum) {
		var iLastIndex = parseInt(m_iCurSelIONum) - 1;
		if(iLaneNum == iLastIndex) {
			return;
		}
		$("#tabRelatedLane").find("li").each(function() {
			 if($(this).children().hasClass("current")) {
				 $(this).children().removeClass();
			 }
		});
		$("#tabRelatedLane").find("li").eq(iLaneNum).find("a").eq(0).addClass("current");
		
		//保存之前Tab的值
		$(ia(TriggerMode).m_epoliceRS485Xml).find("relatedDriveWay").eq(iLastIndex).text($("#RelatedDriveWay").val());
		$(ia(TriggerMode).m_epoliceRS485Xml).find("laneDirectionType").eq(iLastIndex).text($("#laneDirectionType_epoliceRS485").val());
		$(ia(TriggerMode).m_epoliceRS485Xml).find("OSDDriveWay").eq(iLastIndex).text($("#OSDDriveWay").val());
        $(ia(TriggerMode).m_epoliceRS485Xml).find("redLightDriveWay").eq(iLastIndex).text($("#redLightDriveWay").val());
        $(ia(TriggerMode).m_epoliceRS485Xml).find("yellowLightDriveWay").eq(iLastIndex).text($("#yellowLightDriveWay").val());
		$(ia(TriggerMode).m_epoliceRS485Xml).find("distance").eq(iLastIndex).text($("#distance").val());
		$(ia(TriggerMode).m_epoliceRS485Xml).find("recordEnable").eq(iLastIndex).text($("#recordEnable").prop("checked").toString());
		$(ia(TriggerMode).m_epoliceRS485Xml).find("recordType").eq(iLastIndex).text($("#recordType").val());
		$(ia(TriggerMode).m_epoliceRS485Xml).find("preRecordTime").eq(iLastIndex).text($("#preRecordTime").val());
		$(ia(TriggerMode).m_epoliceRS485Xml).find("recordDelayTime").eq(iLastIndex).text($("#recordDelayTime").val());
		$(ia(TriggerMode).m_epoliceRS485Xml).find("recordTimeOut").eq(iLastIndex).text($("#recordTimeOut").val());	
		$(ia(TriggerMode).m_epoliceRS485Xml).find("intervalType").eq(iLastIndex).text($("#IntervalType").val());	
		$(ia(TriggerMode).m_epoliceRS485Xml).find("interval").eq(iLastIndex).text($("#interval").val());
        
   //     $(ia(TriggerMode).m_epoliceRS485Xml).find("trafficLightSource").eq(0).text($("#trafficLightSource").val());
		
		for(var i = 0; i < $("#RelatedLaneCount_videoEp").val(); i++) {
			if($("#LaneCheckbox" + (i+1)).prop("checked")) {
                $(ia(TriggerMode).m_epoliceRS485Xml).find("serialProtocol").eq(i).text($("#serialProtocol").val());
                $(ia(TriggerMode).m_epoliceRS485Xml).find("redLightSerialProtocol").eq(i).text($("#redLightSerialProtocol").val());
                $(ia(TriggerMode).m_epoliceRS485Xml).find("reverseSerialProtocol").eq(i).text($("#reverseSerialProtocol").val());
                $(ia(TriggerMode).m_epoliceRS485Xml).find("normalSpeedSerialProtocol").eq(i).text($("#normalSpeedSerialProtocol").val());
                $(ia(TriggerMode).m_epoliceRS485Xml).find("overSpeedSerialProtocol").eq(i).text($("#overSpeedSerialProtocol").val());
			}
		}
		for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
			$(ia(TriggerMode).m_epoliceRS485Xml).find("IOOutList").eq(iLastIndex).find("enabled").eq(i).text($("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked").toString());
		}
		$(ia(TriggerMode).m_epoliceRS485Xml).find("flashMode").eq(iLastIndex).text($("#FlashMode").val());
		if($("#selTriggerMode").val() == "postEpoliceRS485") {
			$(ia(TriggerMode).m_epoliceRS485Xml).find("signSpeed").eq(iLastIndex).text($("#signSpeed").val());
			$(ia(TriggerMode).m_epoliceRS485Xml).find("speedLimit").eq(iLastIndex).text($("#speedLimit").val());
            $(ia(TriggerMode).m_epoliceRS485Xml).find("bigCarSpeedLimit").eq(iLastIndex).text($("#bigCarSpeedLimit_epolice").val());
            $(ia(TriggerMode).m_epoliceRS485Xml).find("bigCarSignSpeed").eq(iLastIndex).text($("#bigCarSignSpeed_epolice").val());
			
		}
		
		//获取当前Tab值
		m_iCurSelIONum = iLaneNum + 1;
		$("#laneDirectionType_epoliceRS485").val($(ia(TriggerMode).m_epoliceRS485Xml).find("laneDirectionType").eq(iLaneNum).text());
		$("#RelatedDriveWay").val($(ia(TriggerMode).m_epoliceRS485Xml).find("relatedDriveWay").eq(iLaneNum).text());
        //$("#trafficLightSource").val($(ia(TriggerMode).m_epoliceRS485Xml).find("trafficLightSource").eq(0).text());
		$("#OSDDriveWay").val($(ia(TriggerMode).m_epoliceRS485Xml).find("OSDDriveWay").eq(iLaneNum).text());
        $("#redLightDriveWay").val($(ia(TriggerMode).m_epoliceRS485Xml).find("redLightDriveWay").eq(iLaneNum).text());
        $("#yellowLightDriveWay").val($(ia(TriggerMode).m_epoliceRS485Xml).find("yellowLightDriveWay").eq(iLaneNum).text());
		$("#distance").val($(ia(TriggerMode).m_epoliceRS485Xml).find("distance").eq(iLaneNum).text());
		$("#recordEnable").prop("checked", $(ia(TriggerMode).m_epoliceRS485Xml).find("recordEnable").eq(iLaneNum).text() === "true" ? true : false);
		$("#recordType").val($(ia(TriggerMode).m_epoliceRS485Xml).find("recordType").eq(iLaneNum).text());
		$("#preRecordTime").val($(ia(TriggerMode).m_epoliceRS485Xml).find("preRecordTime").eq(iLaneNum).text());		
		$("#recordDelayTime").val($(ia(TriggerMode).m_epoliceRS485Xml).find("recordDelayTime").eq(iLaneNum).text());			
		$("#recordTimeOut").val($(ia(TriggerMode).m_epoliceRS485Xml).find("recordTimeOut").eq(iLaneNum).text());
		if($("#selTriggerMode").val() == "postEpoliceRS485") {
			$("#signSpeed").val($(ia(TriggerMode).m_epoliceRS485Xml).find("signSpeed").eq(iLaneNum).text());			
			$("#speedLimit").val($(ia(TriggerMode).m_epoliceRS485Xml).find("speedLimit").eq(iLaneNum).text());
            $("#bigCarSpeedLimit_epolice").val($(ia(TriggerMode).m_epoliceRS485Xml).find("bigCarSpeedLimit").eq(iLaneNum).text());
            $("#bigCarSignSpeed_epolice").val($(ia(TriggerMode).m_epoliceRS485Xml).find("bigCarSignSpeed").eq(iLaneNum).text())
			
		}
		$("#serialProtocol").val($(ia(TriggerMode).m_epoliceRS485Xml).find("serialProtocol").eq(iLaneNum).text());
		ia(TriggerMode).changeSerialProtocol($("#serialProtocol").val());
		
		$("#redLightSerialProtocol").val($(ia(TriggerMode).m_epoliceRS485Xml).find("redLightSerialProtocol").eq(iLaneNum).text());
		$("#reverseSerialProtocol").val($(ia(TriggerMode).m_epoliceRS485Xml).find("reverseSerialProtocol").eq(iLaneNum).text());
		$("#normalSpeedSerialProtocol").val($(ia(TriggerMode).m_epoliceRS485Xml).find("normalSpeedSerialProtocol").eq(iLaneNum).text());
		$("#overSpeedSerialProtocol").val($(ia(TriggerMode).m_epoliceRS485Xml).find("overSpeedSerialProtocol").eq(iLaneNum).text());		
				
		$("#IntervalType").val($(ia(TriggerMode).m_epoliceRS485Xml).find("intervalType").eq(iLaneNum).text());
		changeIntervalType($("#IntervalType").val());
		$("#interval").val($(ia(TriggerMode).m_epoliceRS485Xml).find("interval").eq(iLaneNum).text());				
		for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
			$("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked",$(ia(TriggerMode).m_epoliceRS485Xml).find("IOOutList").eq(iLaneNum).find("enabled").eq(i).text() === "true" ? true : false);
		}
		$("#FlashMode").val($(ia(TriggerMode).m_epoliceRS485Xml).find("flashMode").eq(iLaneNum).text());
		
		//DisplayRegion();
		EpoliceRS485ReDisplay();
        getTriggerIOCopyInfoForEpolice485();

		m_iLastSelIONum = m_iCurSelIONum;
	}
   
	

    /*************************************************
     Function:		changeLightType
     Description:	改变交通灯类别
     Input:			    无
     Output:			无
     return:			无
     *************************************************/
    TriggerMode.prototype.changeLightType = function(){
        if($('#trafficLightSource').val() == '1'){
            $('#redLightDriveWayDiv').css('display','block');
            $('#yellowLightDriveWayDiv').css('display','block');
        }else if($('#trafficLightSource').val() == '0'){
            $('#redLightDriveWayDiv').css('display','none');
            $('#yellowLightDriveWayDiv').css('display','none');
        }
        autoResizeIframe();
    }

    /*************************************************
     Function:		setLaneAdvanceInfo
     Description:	设置车道高级配置
     Input:			    无
     Output:			无
     return:			无
     *************************************************/
    TriggerMode.prototype.setLaneAdvanceInfo = function(){
        if($('#epoliceLightAdvanceContent').css('display') == 'none'){
            $('#epoliceLightAdvanceContent').css('display','block');
        }else{
            $('#epoliceLightAdvanceContent').css('display','none');
        }
        ia(TriggerMode).enableRecordDetail();
        autoResizeIframe();
    }

    /*************************************************
     Function:		enableRecordDetail
     Description:   设置红灯录像使能
     Input:			    无
     Output:			无
     return:			无
     *************************************************/
    TriggerMode.prototype.enableRecordDetail = function(){
        if($('#recordEnable').prop('checked')){
            $('#recordContentDiv').css('display','block');
        }else{
            $('#recordContentDiv').css('display','none');
        }
        ia(TriggerMode).recordDelayChanged();
        autoResizeIframe();
    }

    /*************************************************
     Function:		recordDelayChanged
     Description:	红灯录像类型改变函数
     Input:			    无
     Output:			无
     return:			无
     *************************************************/
    TriggerMode.prototype.recordDelayChanged = function(){
        if($('#recordType').val() == 'delayRecord'){
            $('#delayTime_epolice').css('display','block');
            $('#preRecord_epolice').css('display','none');
        }else if($('#recordType').val() == 'preRecord'){
            $('#delayTime_epolice').css('display','none');
            $('#preRecord_epolice').css('display','block');
        }
        autoResizeIframe();
    }

    //卡口混合车道
	/*************************************************
	Function:		GetPostHVTParamCap
	Description:	获取虚拟线圈参数能力
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.GetPostHVTParamCap = function () {
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/PostHVT/capabilities",
			timeout: 15000,
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				var min =  $(xmlDoc).find("RelatedLaneCount").eq(0).attr("min");
				var max =  $(xmlDoc).find("RelatedLaneCount").eq(0).attr("max");

				min = parseInt(min, 10);
				max = parseInt(max, 10);
				fillLaneCountOptions(min, max, null);
				g_transStack.translate();
			},
			error: function (xmlDoc) {
				var min = 1;
				var max = 3;
				fillLaneCountOptions(min, max, null);
				g_transStack.translate();
			}
		});
	}

	TriggerMode.prototype.setPostHVTModelAdvanceInfo = function(){
		var $dv = $('#advanceSetting_HVTModel #postHVTAdvanceContent');
		if ($dv.is(":hidden")) {
			$dv.show();
		}else{
			$dv.hide();
		}
        //autoResizeIframe();
	}

	TriggerMode.prototype.StoreHVTGParam = function (laneIndex) {
		var $xmlDoc = $(ia(TriggerMode).m_postHVTXml);

		$.each(['sceneMode', 'capMode', 'speedDetector', 'snapType'], function(i,n){
        		var sel = '#taTriggerMode *[x-model='+n+'] ';
        		var v = $(sel).val();
        		$xmlDoc.find(n).eq(0).text(v);
        });

        $.each(['eCarHighSpeed','eCarLowSpeed','eBigCarHighSpeed','eBigCarLowSpeed'], function(i,n){
        		var sel = '#taTriggerMode #drawRightRegionContent *[x-model='+n+'] ';
        		var v = $(sel).val();
        		$xmlDoc.find(n).eq(0).text(v);
        });

		var lc = $('#RelatedLaneCount_videoEp').val();
		$xmlDoc.find("RelatedLaneCount").eq(0).text(lc);
	}
	TriggerMode.prototype.StoreHVTLaneParam = function (laneIndex) {
		laneIndex = parseInt(laneIndex, 10);
		var xmlDoc = ia(TriggerMode).m_postHVTXml;

		var $firstLaneXmlDoc = $(xmlDoc).find('HvtLane').eq(laneIndex);
		$.each(['relatedDriveWay', 'laneUsage', 'carDriveDirect', 'signSpeed', 'highSpeedLimit',
				 'lowSpeedLimit', 'bigCarSignSpeed', 'bigCarHighSpeedLimit', 'bigCarLowSpeedLimit',
				 'radarType', 'radarRS485', 'radarSensitivity', 'radarAngle', 'validRadarSpeedTime', 
				 'radarLinearCorrection', 'radarConstantCorrection',
				 'flashMode' ], function  (i, n) {
			var sel = '#dvTriggerParam *[x-model='+n+']';
    		
    		var $d = $(sel);
    		if ($d.length) {
    			var v = $d.val();
	    		if ($d.is(":checkbox")) {
	    			v = $d.prop('checked') ? "true":"false";
	    		}
	    		$firstLaneXmlDoc.find(n).eq(0).text(v);
    		};
    		
		});

		function _pi(v) {
			var v = parseInt(v, 10);
			if (!v && v != '0') {
				v = 0;
			};
			return v;
		}

		//大车禁行时间段
		$bTTList = $firstLaneXmlDoc.find('banTrucksTimeSwitch');
		var $bttdom = $('#dvTriggerParam #dvbanTrucksTimeSwitch');
		var arr = [];
		for (var i = 0; i < 4; i++) {
			var $n = $bTTList.eq(i);
			
			var startTime = $bttdom.find('*[x-model=time'+(i+1)+'Start]').val();
			var endTime = $bttdom.find('*[x-model=time'+(i+1)+'End]').val();

			var startTimeArr = startTime.split(':');
			var endTimeArr = endTime.split(":")

			$n.find("startHour").text(_pi(startTimeArr[0]));
			$n.find("startMinute").text(_pi(startTimeArr[1]));
			$n.find("endHour").text(_pi(endTimeArr[0]));
			$n.find("endMinute").text(_pi(endTimeArr[1]));
		};

		$firstLaneXmlDoc.find('IOOut').each(function (i, n) {
			var id = $(n).find('id').text();	
			var v = $('#dvTriggerParam #AlarmOutputCheckboxChanO-'+id).prop('checked') ? "true" : "false";
			
			$(n).find('enabled').text(v);
		});
	}
	

	TriggerMode.prototype.DisplayHVTLaneParamInner = function (laneIndex) {
		laneIndex = parseInt(laneIndex, 10);
		var xmlDoc = ia(TriggerMode).m_postHVTXml;

		var $firstLaneXmlDoc = $(xmlDoc).find('HvtLane').eq(laneIndex);
		$.each(['relatedDriveWay', 'laneUsage', 'carDriveDirect', 'signSpeed', 'highSpeedLimit',
				 'lowSpeedLimit', 'bigCarSignSpeed', 'bigCarHighSpeedLimit', 'bigCarLowSpeedLimit',
				 'radarType', 'radarRS485', 'radarSensitivity', 'radarAngle', 'validRadarSpeedTime', 
				 'radarLinearCorrection', 'radarConstantCorrection',
				 'flashMode' ], function  (i, n) {
			var sel = '#dvTriggerParam *[x-model='+n+']';
    		var v = $firstLaneXmlDoc.find(n).eq(0).text();
    		if (v != '') {
    			$.g.setField2(sel, v, true);	
    		}
    		if (n == 'laneUsage') {
	    		if(v == "banTrucks"){
		            $('#postHVTTriggerPanesDiv #dvbanTrucksTimeSwitch').css("display","block");
		        }else{
		            $('#postHVTTriggerPanesDiv #dvbanTrucksTimeSwitch').css("display","none");
		        }	
    		};
		});

		function _tm2(v) {
			v = parseInt(v, 10);
			if (v < 10) {
				return "0"+v;
			}
			return v;
		}

		//大车禁行时间段
		$bTTList = $firstLaneXmlDoc.find('banTrucksTimeSwitch');
		var $bttdom = $('#dvTriggerParam #dvbanTrucksTimeSwitch');
		var arr = [];
		for (var i = 0; i < 4; i++) {
			var $n = $bTTList.eq(i);
			
			var startTime = _tm2($n.find('startHour').text())+":"+_tm2($n.find("startMinute").text());
			var endTime = _tm2($n.find('endHour').text())+":"+_tm2($n.find("endMinute").text());
			
			$bttdom.find('*[x-model=time'+(i+1)+'Start]').val(startTime);
			$bttdom.find('*[x-model=time'+(i+1)+'End]').val(endTime);
		};

		$firstLaneXmlDoc.find('IOOut').each(function (i, n) {
			var id = $(n).find('id').text();
			var enabled = $(n).find('enabled').text().toLowerCase() == 'true';
			$.g.setField2('#dvTriggerParam #AlarmOutputCheckboxChanO-'+id, enabled);
		});	
	}

	TriggerMode.prototype.DisplayHVTLaneParam = function (laneIndex) {
		$('#dvTriggerParam #tabpostHVT li').find('a').removeClass('current');
		$('#dvTriggerParam #tabpostHVT li#liHVT'+(laneIndex+1)).find('a').addClass('current');

		this.DisplayHVTLaneParamInner(laneIndex);

		getTriggerIOCopyRadarForHVT();
        getTriggerIOCopyInfoForHVT();	
	}


	TriggerMode.prototype.SetLineEffect = function(){
		var v = $(ia(TriggerMode).m_postHVTXml).find('trigLineEffect').eq(0).text();
		v = parseInt(v, 10);

		$.g.setField2('#leftTriggerLine_HVT', (v & 1) ? true : false);
		$.g.setField2('#rightTriggerLine_HVT', (v & (1 << 1)) ? true : false);
		$.g.setField2('#objectDetectAera_HVT', (v & (1 << 2)) ? true : false);
	}
	/*************************************************
	Function:		GetPostHVTParam
	Description:	获取虚拟线圈参数
	Input:			iValueType: 0 实际值 1 推荐值				
	Output:			无
	return:			无				
	*************************************************/
    TriggerMode.prototype.GetPostHVTParam = function (iValueType) {
		var that=this;
		var szUrl = "/PSIA/Custom/SelfExt/ITC/PostHVT";
		if(iValueType == 1) {
			szUrl += "/recommendation";
		}
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + szUrl,
			timeout: 15000,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				ia(TriggerMode).m_postHVTXml = parseXmlFromStr(xmlToStr(xmlDoc));
				// var min = 1;
				// var max = $(xmlDoc).find('HvtLane').length;
				// fillLaneCountOptions(min, max, null);
				
				g_transStack.translate();		

                $.ajax(
                    {
                        type: "GET",
                        async: false,
                        url:  m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/deviceInfo",
                        beforeSend: function(xhr) {
                            xhr.setRequestHeader("If-Modified-Since", "0");
                            
                        },
                        success: function(xmlDoc, textStatus, xhr) {
                            that.radarRS485Num = $(xmlDoc).find('maxRS485Num').eq(0).text();
                        }
                });

                var $sel = $('#dvTriggerParam #radarEnableDiv_HVT').find('#radarRS485_HVT');
            	$sel.find('option').each(function(i, n){
            		var v = $(this).attr('value');
            		if (parseInt(v) > that.radarRS485Num) {
            			$(this).remove();
            		}
            	});

                if(that.radarRS485Num == 1){
                    $('#dvTriggerParam #radarEnableDiv_HVT').css('display','none');
                    $sel.find('#RadarEnabledOpt0_HVT').remove();
                }else{                	
                    $('#dvTriggerParam #radarEnableDiv_HVT').css('display','block');
                }

                ia(TriggerMode).PostHVTAdvanceParam();
                $.each(['sceneMode', 'capMode', 'speedDetector', 'snapType', 
                		'eCarHighSpeed','eCarLowSpeed','eBigCarHighSpeed','eBigCarLowSpeed'], function(i,n){
                		var sel = '#taTriggerMode *[x-model='+n+'] ';
                		var v = $(xmlDoc).find(n).eq(0).text();
                		$.g.setField2(sel, v);

                		if (n == 'speedDetector') {
                			changeSpeedDetectorHVT(v);
                		};
                });

                var totalLaneCount = parseInt($(xmlDoc).find("RelatedLaneCount").eq(0).text());
				for(var i = 1; i <= 5; i++) {
					if(i > totalLaneCount) {
					    $("#dvTriggerParam #liHVT" + i).hide();
					} else {
						$("#dvTriggerParam #liHVT" + i).show();
					}
				}

				changeSpeedParam();
				
				$.g.setField2('#RelatedLaneCount_videoEp', $(xmlDoc).find("RelatedLaneCount").eq(0).text());
				ia(TriggerMode).SetLineEffect();

				ia(TriggerMode).DisplayHVTLaneParam(0);


				m_iCurSelIONum = 1;
				m_iLastSelIONum = 1;

				PostHVTReDisplay();
			}
		});		
	}
	
	//虚拟线圈相关
	/*************************************************
	Function:		GetVTCoilParamCap
	Description:	获取虚拟线圈参数能力
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.GetVTCoilParamCap = function () {
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/PostVTCoil/capabilities",
			timeout: 15000,
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				fillLaneCountOptions(1, $(xmlDoc).find("vtCoilNum").eq(0).attr("max"), null);
				g_transStack.translate();
			}
		});		
	}
	/*************************************************
	Function:		GetVTCoilParam
	Description:	获取虚拟线圈参数
	Input:			iValueType: 0 实际值 1 推荐值				
	Output:			无
	return:			无				
	*************************************************/
    TriggerMode.prototype.GetVTCoilParam = function (iValueType) {
    	var that=this;
		var szUrl = "/PSIA/Custom/SelfExt/ITC/PostVTCoil";
		if(iValueType == 1) {
			szUrl += "/recommendation";
		}
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + szUrl,
			timeout: 15000,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				ia(TriggerMode).m_PostVTCoilXml = parseXmlFromStr(xmlToStr(xmlDoc));
                $.ajax(
                    {
                        type: "GET",
                        async: false,
                        url:  m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/deviceInfo",
                        beforeSend: function(xhr) {
                            xhr.setRequestHeader("If-Modified-Since", "0");
                            
                        },
                        success: function(xmlDoc, textStatus, xhr) {
                            that.radarRS485Num = $(xmlDoc).find('maxRS485Num').eq(0).text();
                        }
                });

                var $sel = $('#radarEnableDiv').find('#radarRS485_VTCoil');
            	$sel.find('option').each(function(i, n){
            		var v = $(this).attr('value');
            		if (parseInt(v) > that.radarRS485Num) {
            			$(this).remove();
            		}
            	});

                if(that.radarRS485Num == 1){
                    $('#radarEnableDiv').css('display','none');
                    $sel.find('#RadarEnabledOpt0_vtCoil').remove();
                }else{                	
                    $('#radarEnableDiv').css('display','block');
                }

                var rsidx = $(xmlDoc).find("radarRS485").eq(0).text();
                $.g.setField2('#radarRS485_VTCoil', rsidx);

                $.each(['displayEnabled', 'recordEnabled', 'sceneMode',
                	'debugMode', 'capMode', 'speedDetector', 'carHighSpeed_VTCoil','carLowSpeed_VTCoil','bigCarHighSpeed_VTCoil','bigCarLowSpeed_VTCoil'], function(i,n){
                		var sel = '#drawRightRegionContent #'+n;
                        if(n.split('_VTCoil').length>0){
                            n = n.split('_VTCoil')[0];
                        }
                		var v = $(xmlDoc).find(n).eq(0).text();
                		$.g.setField2(sel, v);
                });
				
				for(var i = 1; i <= 5; i++) {
					if(i > parseInt($(xmlDoc).find("RelatedLaneCount").eq(0).text())) {
					    $("#liVT" + i).css("display", "none");
					} else {
						$("#liVT" + i).css("display", "block");
					}
				}
				ia(TriggerMode).changeUseageType($(xmlDoc).find("laneUsage").eq(0).text());
				$("#RelatedLaneCount_videoEp").val($(xmlDoc).find("RelatedLaneCount").eq(0).text());
				$("#RelatedDriveWay_VTCoil").val($(xmlDoc).find("relatedDriveWay").eq(0).text());
				$("#laneDirectionType_postVTCoil").val($(xmlDoc).find("laneDirectionType").eq(0).text());
				
				$("#useageType").val($(xmlDoc).find("laneUsage").eq(0).text());
				$("#carDriveDirect").val($(xmlDoc).find("carDriveDirect").eq(0).text());
				$("#carsignSpeed").val($(xmlDoc).find("signSpeed").eq(0).text());
				$("#lowSpeedLimit").val($(xmlDoc).find("lowSpeedLimit").eq(0).text());
				$("#highSpeedLimit").val($(xmlDoc).find("highSpeedLimit").eq(0).text());
				
				$("#bigCarHighSpeedLimit").val($(xmlDoc).find("bigCarHighSpeedLimit").eq(0).text());
				$("#bigCarLowSpeedLimit").val($(xmlDoc).find("bigCarLowSpeedLimit").eq(0).text());
				$("#bigCarSignSpeed").val($(xmlDoc).find("bigCarSignSpeed").eq(0).text());

				for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
					$("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked",$(xmlDoc).find("IOOutList").eq(0).find("enabled").eq(i).text() === "true" ? true : false);
				}
				
				$.g.setField2('#FlashMode', $(xmlDoc).find("flashMode").eq(0).text());
				
				$("#RadarType").val($(xmlDoc).find("radarType").eq(0).text());
               	var rs = parseInt($(xmlDoc).find('radarSensitivity').eq(0).text(), 10);
               	setTimeout(function () {
               		$.g.setField2('#RadarSensitivity_VTCoil', rs);	
               	}, 200);

                $("#radarAngle").val($(xmlDoc).find("radarAngle").eq(0).text());
                $("#validRadarSpeedTime").val($(xmlDoc).find("validRadarSpeedTime").eq(0).text());
                $("#radarLinearCorrection").val($(xmlDoc).find("radarLinearCorrection").eq(0).text());
                $("#radarConstantCorrection").val($(xmlDoc).find("radarConstantCorrection").eq(0).text());
				ia(TriggerMode).changeSpeedDetector($(xmlDoc).find("speedDetector").eq(0).text());

                //四个时间段赋值
				for(var i = 1; i < 5; i++) {
				    $("#banTrucksStartTime" + i).val($(xmlDoc).find("banTrucksTimeSwitchList").eq(0).find("startHour").eq(i-1).text() + ":" + $(xmlDoc).find("banTrucksTimeSwitchList").eq(0).find("startMinute").eq(i-1).text());
				    $("#banTrucksStopTime" + i).val($(xmlDoc).find("banTrucksTimeSwitchList").eq(0).find("endHour").eq(i-1).text() + ":" + $(xmlDoc).find("banTrucksTimeSwitchList").eq(0).find("endMinute").eq(i-1).text());
				}	

				var $busWay = $(xmlDoc).find("busWayTimeSwitchList").eq(0);
				for(var j = 1; j < 5; j++) {
				    $("#busWayStartTime" + j).val($busWay.find("startHour").eq(j-1).text() + ":" + $busWay.find("startMinute").eq(j-1).text());
				    $("#busWayStopTime" + j).val($busWay.find("endHour").eq(j-1).text() + ":" + $busWay.find("endMinute").eq(j-1).text());
				}

				
				
				getTriggerIOCopyRadarForVTCoil();
                getTriggerIOCopyInfoForVTCoil();

				m_iCurSelIONum = 1;
				m_iLastSelIONum = 1;

				PostVTCoilReDisplay();
			}
		});		
	}



	 //出入口视频
	TriggerMode.prototype.changeMprTrigType = function () {
		var v = $('#taTriggerMode #triggerType').val();
		if (v == '2') {  // IO
			$('#taTriggerMode #485Wrapper').hide();
			$('#taTriggerMode #IOWrapper').show();
		}else if(v == '3'){  // 485
			$('#taTriggerMode #IOWrapper').hide();
			$('#taTriggerMode #485Wrapper').show();
		}else{
			$('#taTriggerMode #IOWrapper').hide();
			$('#taTriggerMode #485Wrapper').hide();
		}
	}

	/*************************************************
	Function:		GetPostMprParam
	Description:	获取出入口视频参数
	Input:			strTriggerMode:触发模式		
	                iTypeValue: 0 实际值 1 推荐值
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.GetPostMprParam = function (strTriggerMode, iValueType) {
		var szUrl = "/PSIA/Custom/SelfExt/ITC/PostMpr";
		if(iValueType == 1) {
			szUrl += "/recommendation";
		}
		var PostMprCount =0;

		var $trigDiv = $('#taTriggerMode');
		var $sel = $trigDiv.find('#IOWrapper #relateIO');
		$sel.find('option').remove();

		for (var i = 1; i <= parseInt(ia(TriggerMode).m_iTriggerIONum); i++) {
			$sel.append("<option value="+i+">IO "+i+"</option>");
		};

		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + szUrl,
			timeout: 15000,
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				ia(TriggerMode).m_PostMprXml = xmlDoc;

				$xmlDoc = $(xmlDoc);

				var lanecount = parseInt($(xmlDoc).find("laneCount").eq(0).text());
				$.g.setField('RelatedLaneCount_videoEp', 'lanecount');

				var $trigDiv = $('#taTriggerMode');
				
				for(var i = lanecount + 1; i <= 6; i++) {
					$trigDiv.find("#lilaneCount" + i).css("display", "none");
				}
				$trigDiv.find("#triggerType").val($xmlDoc.find("triggerType").eq(0).text());

				$trigDiv.find("#RelatedDriveWay").val($(xmlDoc).find("relatedDriveWay").eq(0).text());
				//$trigDiv.find("#OSDDriveWay").val($xmlDoc.find("OSDDriveWay").eq(0).text());
								
				$.g.setField2('#taTriggerMode #relate485Chan', $(xmlDoc).find("relate485Chan").eq(0).text());
				$.g.setField2('#taTriggerMode #relateIO', $(xmlDoc).find("relateIO").eq(0).text());
				$.g.setField2('#taTriggerMode #IODefaultStatus', $(xmlDoc).find("IODefaultStatus").eq(0).text());


				ia(TriggerMode).changeMprTrigType();

				if(PostMprCount == 0&&$trigDiv.find("#RelatedLaneCount_videoEp option").length < 2){
					for(var i = 1;i <= lanecount;i++){
						$("<option value='"+ i +"'>"+ i +"</option>").appendTo("#RelatedLaneCount_videoEp");	
					}
					PostMprCount = i;
				}
				$trigDiv.find("#RelatedLaneCount_videoEp").val($(xmlDoc).find("laneCount").eq(0).text());


				ia(TriggerMode).changeVideoEpLancCount($('#RelatedLaneCount_videoEp').val());
				PostMprReDisplay();
			}
		})
	}

	TriggerMode.prototype.GetVideoMonitorParam = function(strTriggerMode, iValueType) {
		var szUrl = "/PSIA/Custom/SelfExt/ITC/VideoMonitor";
		if(iValueType == 1) {
			szUrl += "/recommendation";
		}

		var self = this;
		
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + szUrl,
			//url:"/doc/test/laneNo.xml",
			timeout: 15000,
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				ia(TriggerMode).m_videoMonitorXml = xmlDoc;

				var lanecount = parseInt($(xmlDoc).find("laneCount").eq(0).text());
				var laneCountRes = self.GetVideoMonitorLaneCount();

				fillVideoMonitorLaneCountOptions(laneCountRes.min, laneCountRes.max, lanecount);
				
				var $xmlDoc = $(ia(TriggerMode).m_videoMonitorXml);
				var $trigDiv = $('#taTriggerMode');
				$trigDiv.find("#divCapMode_VideoMonitor #snapType").val($xmlDoc.find("snapType").eq(0).text());
				ia(TriggerMode).capModeChange();
				if(iValueType==1){
					var current = $('#tabVideoMonitor a.current').not(":hidden");
        	        var idx = current.eq(0).parent().attr('id').replace("lilaneCount", "");
			        idx = parseInt(idx, 10) - 1;
			        $trigDiv.find("#laneDirectionType_videoMonitor").val($xmlDoc.find("laneDirectionType").eq(idx).text());
			        $trigDiv.find("#RelatedDriveWay").val($xmlDoc.find("relatedDriveWay").eq(idx).text());
					$trigDiv.find("#carDriveDirect").val($xmlDoc.find("carDriveDirect").eq(idx).text());
				}else{
					$trigDiv.find("#laneDirectionType_videoMonitor").val($xmlDoc.find("laneDirectionType").eq(0).text());
                    $trigDiv.find("#RelatedDriveWay").val($xmlDoc.find("relatedDriveWay").eq(0).text());
                    $trigDiv.find("#carDriveDirect").val($xmlDoc.find("carDriveDirect").eq(0).text());
				}
				
				ia(TriggerMode).changeVideoMonitorLaneCount(lanecount);

				VideoMonitorReDisplay();
			}
		})
	}

	TriggerMode.prototype.capModeChange=function(){
		if($("#divCapMode_VideoMonitor #snapType").val()=="vehWithHum"){
			$("#carDriveDirect_VideoMonitor").show();
		}else{
			$("#carDriveDirect_VideoMonitor").hide();
		}
	}

	TriggerMode.prototype.GetVideoMonitorLaneCount = function () {
		var url = m_lHttp + m_szHostName + ":"+m_lHttpPort 
					+ '/PSIA/Custom/SelfExt/ITC/VideoMonitor/capabilities';
		var res = {
			min: 1, 
			max: 3
		};
		$.ajax({
			type: "GET",
			url: url,
			timeout: 15000,
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				var $nd = $(xmlDoc).find('laneCount').eq(0);
				if ($nd.length) {
					min = parseInt($nd.attr('min'));
					max = parseInt($nd.attr('max'));
					if (min >=0 && max > 1) {
						res.min = min;
						res.max = max;
					};
				};
			}
		});

		return res;
	}


	 function getTriggerIOCopyRadarForHVT(){
        $('#TriggerIOCopyRadarDiv_HVT').find('div.singleIo_checkbox_copy_div').remove();
        var len = $('#RelatedLaneCount_videoEp').val();

        for(var i=0; i < len; i++){

            var disStr = '';
            if($('#tabpostHVT #liHVT' + (i+1)).find('a').first().is('.current')){
                disStr = 'disabled="disabled" checked="checked" ';
            }
            var arr = ['<div class="singleIo_checkbox_copy_div">',
                '<input id="HVT_copyRadar_checkbox_'+(i+1)+'" ioIdx="'+(i+1)+'" type="checkbox" ',
                disStr,
                'class="singleIo_checkbox"><label for="HVT_copyRadar_checkbox_'+(i+1)+'" ',
                ' class="singleIo_checkbox">'+getNodeValue('aRelatedLane'+(i+1))+'</label></div>'];

            $('#TriggerIOCopyRadarDiv_HVT').append(arr.join(' '));
        }
    }

    function getTriggerIOCopyInfoForHVT(){

        $('#TriggerIOCopyDiv_HVT').find('div.singleIo_checkbox_copy_div').remove();
        var len = $('#RelatedLaneCount_videoEp').val();

        for(var i=0; i < len; i++){

            var disStr = '';
            if($('#tabpostHVT #liHVT' + (i+1)).find('a').first().is('.current')){
                disStr = 'disabled="disabled" checked="checked" ';
            }
            var arr = ['<div class="singleIo_checkbox_copy_div">',
                '<input id="HVT_copy_checkbox_'+(i+1)+'" ioIdx="'+(i+1)+'" type="checkbox" ',
                disStr,
                'class="singleIo_checkbox"><label for="HVT_copy_checkbox_'+(i+1)+'" ',
                ' class="singleIo_checkbox">'+getNodeValue('aRelatedLane'+(i+1))+'</label></div>'];

            $('#TriggerIOCopyDiv_HVT').append(arr.join(' '));
        }
    }


    function getTriggerIOCopyRadarForVTCoil(){
        $('#TriggerIOCopyRadarDiv_VTCoil').find('div.singleIo_checkbox_copy_div').remove();
        var len = $('#RelatedLaneCount_videoEp').val();

        for(var i=0; i < len; i++){

            var disStr = '';
            if($('#tabpostVTCoil #liVT' + (i+1)).find('a').first().is('.current')){
                disStr = 'disabled="disabled" checked="checked" ';
            }
            var arr = ['<div class="singleIo_checkbox_copy_div">',
                '<input id="vtCoil_copyRadar_checkbox_'+(i+1)+'" ioIdx="'+(i+1)+'" type="checkbox" ',
                disStr,
                'class="singleIo_checkbox"><label for="vtCoil_copyRadar_checkbox_'+(i+1)+'" ',
                ' class="singleIo_checkbox">'+getNodeValue('aRelatedLane'+(i+1))+'</label></div>'];

            $('#TriggerIOCopyRadarDiv_VTCoil').append(arr.join(' '));
        }
    }

    function getTriggerIOCopyInfoForVTCoil(){

        $('#TriggerIOCopyDiv_VTCoil').find('div.singleIo_checkbox_copy_div').remove();
        var len = $('#RelatedLaneCount_videoEp').val();

        for(var i=0; i < len; i++){

            var disStr = '';
            if($('#tabpostVTCoil #liVT' + (i+1)).find('a').first().is('.current')){
                disStr = 'disabled="disabled" checked="checked" ';
            }
            var arr = ['<div class="singleIo_checkbox_copy_div">',
                '<input id="vtCoil_copy_checkbox_'+(i+1)+'" ioIdx="'+(i+1)+'" type="checkbox" ',
                disStr,
                'class="singleIo_checkbox"><label for="vtCoil_copy_checkbox_'+(i+1)+'" ',
                ' class="singleIo_checkbox">'+getNodeValue('aRelatedLane'+(i+1))+'</label></div>'];

            $('#TriggerIOCopyDiv_VTCoil').append(arr.join(' '));
        }
    }
	/*************************************************
	Function:		SetVTCoilParam
	Description:	设置虚拟线圈参数
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
    TriggerMode.prototype.SetVTCoilParam = function () {
		ia(TriggerMode).m_bSetTriggerMode = false;
		//保存当前虚拟线圈坐标
		var iIndex = parseInt(m_iCurSelIONum) - 1;
		var iVtXmlIndex = 0;

		$(ia(TriggerMode).m_PostVTCoilXml).find("RelatedLaneCount").eq(0).text($("#RelatedLaneCount_videoEp").val());

		$(ia(TriggerMode).m_PostVTCoilXml).find("displayEnabled").eq(0).text($("#drawRightRegionContent #displayEnabled").prop("checked") ? "true" : "false");
        $(ia(TriggerMode).m_PostVTCoilXml).find("sceneMode").eq(0).text($("#drawRightRegionContent #sceneMode").val());
       
        $(ia(TriggerMode).m_PostVTCoilXml).find("recordEnabled").eq(0).text($("#drawRightRegionContent #recordEnabled").prop("checked") ? "true" : "false");
      	$(ia(TriggerMode).m_PostVTCoilXml).find("capMode").eq(0).text($("#drawRightRegionContent #capMode").val());
		$(ia(TriggerMode).m_PostVTCoilXml).find("debugMode").eq(0).text($("#drawRightRegionContent #debugMode").prop("checked") ? "true" : "false");
		$(ia(TriggerMode).m_PostVTCoilXml).find("speedDetector").eq(0).text($("#drawRightRegionContent #speedDetector").val());
        
        $(ia(TriggerMode).m_PostVTCoilXml).find("carHighSpeed").eq(0).text($("#drawRightRegionContent #carHighSpeed_VTCoil").val());
        $(ia(TriggerMode).m_PostVTCoilXml).find("carLowSpeed").eq(0).text($("#drawRightRegionContent #carLowSpeed_VTCoil").val());
        $(ia(TriggerMode).m_PostVTCoilXml).find("bigCarHighSpeed").eq(0).text($("#drawRightRegionContent #bigCarHighSpeed_VTCoil").val());
        $(ia(TriggerMode).m_PostVTCoilXml).find("bigCarLowSpeed").eq(0).text($("#drawRightRegionContent #bigCarLowSpeed_VTCoil").val());

		//保存当前线圈的值			
		$(ia(TriggerMode).m_PostVTCoilXml).find("relatedDriveWay").eq(iIndex).text($("#RelatedDriveWay_VTCoil").val());
		$(ia(TriggerMode).m_PostVTCoilXml).find("laneDirectionType").eq(iIndex).text($("#laneDirectionType_postVTCoil").val());
		
		$(ia(TriggerMode).m_PostVTCoilXml).find("laneUsage").eq(iIndex).text($("#useageType").val());
		$(ia(TriggerMode).m_PostVTCoilXml).find("carDriveDirect").eq(iIndex).text($("#carDriveDirect").val());
		
		$(ia(TriggerMode).m_PostVTCoilXml).find("signSpeed").eq(iIndex).text($("#carsignSpeed").val());
		$(ia(TriggerMode).m_PostVTCoilXml).find("lowSpeedLimit").eq(iIndex).text($("#lowSpeedLimit").val());
		$(ia(TriggerMode).m_PostVTCoilXml).find("highSpeedLimit").eq(iIndex).text($("#highSpeedLimit").val());
		
        $(ia(TriggerMode).m_PostVTCoilXml).find("bigCarSignSpeed").eq(iIndex).text($("#bigCarSignSpeed").val());
        $(ia(TriggerMode).m_PostVTCoilXml).find("bigCarHighSpeedLimit").eq(iIndex).text($("#bigCarHighSpeedLimit").val());
		$(ia(TriggerMode).m_PostVTCoilXml).find("bigCarLowSpeedLimit").eq(iIndex).text($("#bigCarLowSpeedLimit").val());
		
		//黄车禁行时间段
		for(var i = 1; i < 5; i++) {
			$(ia(TriggerMode).m_PostVTCoilXml).find("banTrucksTimeSwitchList").eq(iIndex).find("startHour").eq(i-1).text($("#banTrucksStartTime" + i).val().split(":")[0]);
			$(ia(TriggerMode).m_PostVTCoilXml).find("banTrucksTimeSwitchList").eq(iIndex).find("startMinute").eq(i-1).text($("#banTrucksStartTime" + i).val().split(":")[1]);
			$(ia(TriggerMode).m_PostVTCoilXml).find("banTrucksTimeSwitchList").eq(iIndex).find("endHour").eq(i-1).text($("#banTrucksStopTime" + i).val().split(":")[0]);
			$(ia(TriggerMode).m_PostVTCoilXml).find("banTrucksTimeSwitchList").eq(iIndex).find("endMinute").eq(i-1).text($("#banTrucksStopTime" + i).val().split(":")[1]);
		}

		//公交车专用车道
		for(var i = 1; i < 5; i++) {
			$(ia(TriggerMode).m_PostVTCoilXml).find("busWayTimeSwitchList").eq(iIndex).find("startHour").eq(i-1).text($("#dvbusTimeSwitch #busWayStartTime" + i).val().split(":")[0]);
			$(ia(TriggerMode).m_PostVTCoilXml).find("busWayTimeSwitchList").eq(iIndex).find("startMinute").eq(i-1).text($("#dvbusTimeSwitch #busWayStartTime" + i).val().split(":")[1]);
			$(ia(TriggerMode).m_PostVTCoilXml).find("busWayTimeSwitchList").eq(iIndex).find("endHour").eq(i-1).text($("#dvbusTimeSwitch #busWayStopTime" + i).val().split(":")[0]);
			$(ia(TriggerMode).m_PostVTCoilXml).find("busWayTimeSwitchList").eq(iIndex).find("endMinute").eq(i-1).text($("#dvbusTimeSwitch #busWayStopTime" + i).val().split(":")[1]);
		}


       /* if (radarRS485Num == 1) {
        	$(ia(TriggerMode).m_PostVTCoilXml).find("radarType").eq(0).text($("#RadarType").val());
			$(ia(TriggerMode).m_PostVTCoilXml).find("radarSensitivity").eq(0).text($('#RadarSensitivity_VTCoil').val());
	        $(ia(TriggerMode).m_PostVTCoilXml).find("radarAngle").eq(0).text($("#radarAngle").val());
	        $(ia(TriggerMode).m_PostVTCoilXml).find("validRadarSpeedTime").eq(0).text($("#validRadarSpeedTime").val());
	        $(ia(TriggerMode).m_PostVTCoilXml).find("radarLinearCorrection").eq(0).text($("#radarLinearCorrection").val());
	        $(ia(TriggerMode).m_PostVTCoilXml).find("radarConstantCorrection").eq(0).text($("#radarConstantCorrection").val());
       	} else {*/
       		$(ia(TriggerMode).m_PostVTCoilXml).find("radarType").eq(iIndex).text($("#RadarType").val());
       		$.each(['radarAngle', 'validRadarSpeedTime',
	       		 'radarLinearCorrection', 'radarConstantCorrection'], function (i,n) {
	       		 	$(ia(TriggerMode).m_PostVTCoilXml).find(n).eq(iIndex).text($("#"+n).val());
	       	});
	       	$(ia(TriggerMode).m_PostVTCoilXml).find("radarRS485").eq(iIndex).text($("#radarRS485_VTCoil").val());
       		$(ia(TriggerMode).m_PostVTCoilXml).find("radarSensitivity").eq(iIndex).text($("#RadarSensitivity_VTCoil").val());
       	//}
		
		for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
			$(ia(TriggerMode).m_PostVTCoilXml).find("IOOutList").eq(iIndex).find("enabled").eq(i).text($("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked").toString());
		}
		$(ia(TriggerMode).m_PostVTCoilXml).find("flashMode").eq(iIndex).text($("#FlashMode").val());

        var idxs = [];
        var idxRadar = [];
        var curIoInfo;

        $('#TriggerIOCopyRadarDiv_VTCoil input[ioIdx]').each(function(i, n){//雷达参数复制到
            if($(n).prop('checked') && !$(n).prop('disabled')){
                idxRadar.push($(n).attr('ioIdx'));
            }
        });

        $('#TriggerIOCopyDiv_VTCoil input[ioIdx]').each(function(i, n){  //参数复制到
            if($(n).prop('checked') && !$(n).prop('disabled')){
                idxs.push($(n).attr('ioIdx'));
            }
        });

        $(ia(TriggerMode).m_PostVTCoilXml).find('VtCoil').each(function(i, n){
            var id = $(n).find('vtCoilNum').eq(0).text();
            if(id == m_iCurSelIONum){
                curIoInfo = $(n);
            }
        });

        if(curIoInfo && idxs.length > 0 || (curIoInfo && idxRadar.length)){

            $(ia(TriggerMode).m_PostVTCoilXml).find('VtCoil').each(function(i, n){
				$p = $(n);
                var idx = $(n).find('vtCoilNum').eq(0).text();

                if(idxRadar.length > 0 &&_.contains(idxRadar, idx)){ //复制雷达参数信息
                    SimpleCopyXmlNode(curIoInfo[0],$(n),['laneDirectionType','laneUsage','lowSpeedCapEnable','radarType','radarRS485','radarSensitivity','radarAngle',
                        'validRadarSpeedTime','radarLinearCorrection','radarConstantCorrection']);
                }

                if (idxs.length > 0 &&_.contains(idxs, idx)){ //复制其他参数信息
                    SimpleCopyXmlNode(curIoInfo[0],$p[0],['laneDirectionType','laneUsage','lowSpeedCapEnable','carDriveDirect','signSpeed','lowSpeedLimit','highSpeedLimit','bigCarSignSpeed',
                        'bigCarHighSpeedLimit','bigCarLowSpeedLimit','flashMode',
						{propName: 'banTrucksTimeSwitchList', type: 'subNode'},
						{propName: 'busWayTimeSwitchList', type: 'subNode'},
                        {propName: 'IOOutList', type: 'subNode'}]);
                }
            });
        }
		
		$.ajax({
			type: "put",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/PostVTCoil",
			timeout: 15000,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			data: ia(TriggerMode).m_PostVTCoilXml,
			processData: false,
			complete:function(xhr, textStatus) {
				if(xhr.status != 200) {
					if(xhr.status == 403) {
						var szErrorInfo = m_szError8;
						szRetInfo = m_szErrorState + szErrorInfo;
					} else {
						var xmlDoc =xhr.responseXML;
						if($(xmlDoc).find("detailedStatusCode").eq(0).text() != "") {
							var szErrorInfo = getNodeValue("Error" + $(xmlDoc).find("detailedStatusCode").eq(0).text());
						} else {
							var szErrorInfo = m_szError13;
						}
						szRetInfo = m_szErrorState + szErrorInfo;
					}
		            $("#SetResultTips").html(szRetInfo); 
			        setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			        return;	
				} else {
					if($(xhr.responseXML).find("statusCode").eq(0).text() == "7") {
						ia(TriggerMode).m_bRebootRequired = true;
					}
					ia(TriggerMode).m_bSetTriggerMode = true;
				    pr(TriggerMode).SetPlateRecognition("postVTCoil");
				}
			}
		});
	}

	TriggerMode.prototype.SetVideoMonitorParam = function () {
		ia(TriggerMode).m_bSetTriggerMode = false;
		var laneCount = $('#RelatedLaneCount_VideoMonitor').val();

		var $xmlDoc = $(ia(TriggerMode).m_videoMonitorXml);
		$xmlDoc.find('laneCount').eq(0).text(laneCount);

		var $trigDiv = $('#taTriggerMode');
		$xmlDoc.find("snapType").text($trigDiv.find("#snapType").val());
		var iIndex = parseInt(m_iCurSelIONum) - 1;
		
		$xmlDoc.find("relatedDriveWay").eq(iIndex).text($trigDiv.find("#RelatedDriveWay").val());
		$xmlDoc.find("laneDirectionType").eq(iIndex).text($trigDiv.find("#laneDirectionType_videoMonitor").val());
		$xmlDoc.find("carDriveDirect").eq(iIndex).text($trigDiv.find("#carDriveDirect").val());
		$.ajax({
			type: "put",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/VideoMonitor",
			timeout: 15000,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			data: xmlToStr(ia(TriggerMode).m_videoMonitorXml),
			processData: false,
			complete:function(xhr, textStatus) {
				if(xhr.status != 200) {
					if(xhr.status == 403) {
						var szErrorInfo = m_szError8;
						szRetInfo = m_szErrorState + szErrorInfo;
					} else {
						var xmlDoc =xhr.responseXML;
						if($(xmlDoc).find("detailedStatusCode").eq(0).text() != "") {
							var szErrorInfo = getNodeValue("Error" + $(xmlDoc).find("detailedStatusCode").eq(0).text());
						} else {
							var szErrorInfo = m_szError13;
						}
						szRetInfo = m_szErrorState + szErrorInfo;
					}
		            $("#SetResultTips").html(szRetInfo); 
			        setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			        return;	
				} else {
					if($(xhr.responseXML).find("statusCode").eq(0).text() == "7") {
						ia(TriggerMode).m_bRebootRequired = true;
					}
					ia(TriggerMode).m_bSetTriggerMode = true;

					// $("#CurTriggerMode").html(getNodeValue("a" + $("#selTriggerMode").val()));

					if(ia(TriggerMode).m_bRebootRequired) {
						szRetInfo = m_szSuccessState + m_szSuccess5;
					} else {
						szRetInfo = m_szSuccessState + m_szSuccess1;
					}

					$("#SetResultTips").html(szRetInfo); 
				    setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
				}
			}
		});

	}

	TriggerMode.prototype.CopyPostHVTParam = function (srcIndex) {
		var $xmlDoc = $(ia(TriggerMode).m_postHVTXml);
		var copySrc = $xmlDoc.find('HvtLane').eq(srcIndex);

		if (!copySrc.length) {
			return;
		};

		$('#dvTriggerParam #TriggerIOCopyDiv_HVT').find('input[ioidx]:enabled:checked').not(":hidden").each(function  (i, n) {
			var idx = parseInt($(this).attr('ioidx'), 10) - 1;
			var $dst = $xmlDoc.find("HvtLane").eq(idx);

			SimpleCopyXmlNode(copySrc[0],$dst[0],
						['laneDirectionType','laneUsage','carDriveDirect','signSpeed','highSpeedLimit', 'lowSpeedLimit',
							'bigCarSignSpeed', 'bigCarHighSpeedLimit', 'bigCarLowSpeedLimit', 'flashMode',
							{propName: 'banTrucksTimeSwitchList', type: 'subNode'},
                            {propName: 'IOOutList', type: 'subNode'}]
                        );
		});
	}

	TriggerMode.prototype.CopyPostHVTRadarParam = function (srcIndex) {
        var sel = '#taTriggerMode *[x-model=speedDetector] ';
        if ($(sel).val() != 'radarSpeed') {
        	return;
        };

		var $xmlDoc = $(ia(TriggerMode).m_postHVTXml);
		var copySrc = $xmlDoc.find('HvtLane').eq(srcIndex).find('Radar');

		if (!copySrc.length) {
			return;
		};

		$('#dvTriggerParam #TriggerIOCopyRadarDiv_HVT').find('input[ioidx]:enabled:checked').not(":hidden").each(function  (i, n) {
			var idx = parseInt($(this).attr('ioidx'), 10) - 1;
			var $dst = $xmlDoc.find("HvtLane").eq(idx).find('Radar');

			SimpleCopyXmlNode(copySrc[0],$dst[0], ['laneDirectionType','radarType', 'radarSensitivity', 
							'radarAngle',  'radarRS485',
							'validRadarSpeedTime', 'radarLinearCorrection', 
							'radarLinearCorrection']);
		});
	}



	TriggerMode.prototype.SetPostHVTParam = function () {
		this.setHVTAdvanceParam();
		this.StoreHVTGParam();

		var iLastIndex = parseInt(m_iCurSelIONum) - 1;  
		this.StoreHVTLaneParam(iLastIndex);

		ia(TriggerMode).m_bSetTriggerMode = false;
		var laneCount = $('#RelatedLaneCount_videoEp').val();
		$(ia(TriggerMode).m_postHVTXml).find('RelatedLaneCount').eq(0).text(laneCount);

		var eff = 0;
		if ($('#leftTriggerLine_HVT').prop('checked')) {
			eff |= 1;
		}

		if ($('#rightTriggerLine_HVT').prop('checked')) {
			eff |= (1 << 1);
		}

		if ($('#objectDetectAera_HVT').prop('checked')) {
			eff |= (1 << 2);
		}

		$(ia(TriggerMode).m_postHVTXml).find('trigLineEffect').eq(0).text(eff);

		this.CopyPostHVTParam(iLastIndex);	
		this.CopyPostHVTRadarParam(iLastIndex);

		$.ajax({
			type: "put",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/PostHVT",
			timeout: 15000,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			data: xmlToStr(ia(TriggerMode).m_postHVTXml),
			processData: false,

			complete:function(xhr, textStatus) {
				if(xhr.status != 200) {
					if(xhr.status == 403) {
						var szErrorInfo = m_szError8;
						szRetInfo = m_szErrorState + szErrorInfo;
					} else {
						var xmlDoc =xhr.responseXML;
						if($(xmlDoc).find("detailedStatusCode").eq(0).text() != "") {
							var szErrorInfo = getNodeValue("Error" + $(xmlDoc).find("detailedStatusCode").eq(0).text());
						} else {
							var szErrorInfo = m_szError13;
						}
						szRetInfo = m_szErrorState + szErrorInfo;
					}
		            $("#SetResultTips").html(szRetInfo); 
			        setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			        return;	
				} else {
					if($(xhr.responseXML).find("statusCode").eq(0).text() == "7") {
						ia(TriggerMode).m_bRebootRequired = true;
					}
					ia(TriggerMode).m_bSetTriggerMode = true;
				    pr(TriggerMode).SetPlateRecognition("postHVT");
				}
			}
		});
	}
	/*************************************************
	Function:		SetPostMprParam
	Description:	设置出入口视频参数
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	 TriggerMode.prototype.SetPostMprParam = function () {
		 
		ia(TriggerMode).m_bSetTriggerMode = false;
		//保存当前出入口视频坐标
		var iIndex = parseInt(m_iCurSelIONum) - 1;
		var iVtXmlIndex = 0;


		var $trigDiv = $('#taTriggerMode');

		$(ia(TriggerMode).m_PostMprXml).find("RelatedLaneCount").eq(0).text($trigDiv.find("#RelatedLaneCount_videoEp").val());
		
		$xmlDoc = $(ia(TriggerMode).m_PostMprXml);

		$xmlDoc.find("relatedDriveWay").eq(iIndex).text($trigDiv.find("#RelatedDriveWay").val()); 	
		//$xmlDoc.find("OSDDriveWay").eq(iIndex).text($trigDiv.find("#OSDDriveWay").val()); 	
		
		var trigType = $trigDiv.find("#triggerType").val();
		$xmlDoc.find("triggerType").eq(0).text(trigType); 	

		if (trigType == '2' || trigType == '3') {  // IO or 485
			var tmpObj = x2js.xml_str2json(xmlToStr(ia(TriggerMode).m_PostMprXml));
			if (tmpObj) {
				var laneArr = tmpObj['PostMpr']['LaneParamList'].LaneParam_asArray;
				if (laneArr && laneArr.length) {
					var laneParam = laneArr[iIndex];

					if (trigType == '2') {
						laneParam.relateIO = $trigDiv.find("#relateIO").val();
						laneParam.IODefaultStatus = $trigDiv.find("#IODefaultStatus").val();
					}else{
						laneParam.relate485Chan = $trigDiv.find("#relate485Chan").val();
					}
				};

				ia(TriggerMode).m_PostMprXml = x2js.json2xml(tmpObj);
			};
		};
		

		$xmlDoc = $(ia(TriggerMode).m_PostMprXml);

		// $xmlDoc.find("relateIO").eq(iIndex).text(); 
		// $xmlDoc.find("IODefaultStatus").eq(iIndex).text(); 
		

		

		$.ajax({
			type: "PUT",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/PostMpr",
			timeout: 15000,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			data: xmlToStr(ia(TriggerMode).m_PostMprXml),
			processData: false,
			complete:function(xhr, textStatus) {
				if(xhr.status != 200) {
					if(xhr.status == 403) {
						var szErrorInfo = m_szError8;
						szRetInfo = m_szErrorState + szErrorInfo;
					} else {
						var xmlDoc =xhr.responseXML;
						if($(xmlDoc).find("detailedStatusCode").eq(0).text() != "") {
							var szErrorInfo = getNodeValue("Error" + $(xmlDoc).find("detailedStatusCode").eq(0).text());
						} else {
							var szErrorInfo = m_szError13;
						}
						szRetInfo = m_szErrorState + szErrorInfo;
					}
		            $trigDiv.find("#SetResultTips").html(szRetInfo); 
			        setTimeout(function(){$trigDiv.find("#SetResultTips").html("");},5000);  //5秒后自动清除
			        return;	
				} else {
					if($(xhr.responseXML).find("statusCode").eq(0).text() == "7") {
						ia(TriggerMode).m_bRebootRequired = true;
					}
					ia(TriggerMode).m_bSetTriggerMode = true;
				    pr(TriggerMode).SetPlateRecognition("PostMpr");
				}
			}
		});
	 }

	 

	 TriggerMode.prototype.selectHVT = function(laneIndex){
	 	var iLastIndex = parseInt(m_iCurSelIONum) - 1;  
		if(laneIndex == iLastIndex) {
			return;
		}
		$("#dvTriggerParam #tabpostHVT").find("li a").removeClass('current');
		$("#dvTriggerParam #tabpostHVT").find("#liHVT"+(laneIndex+1)).find("a").eq(0).addClass("current");
		
		ia(TriggerMode).StoreHVTLaneParam(iLastIndex);
		ia(TriggerMode).DisplayHVTLaneParam(laneIndex);

		m_iCurSelIONum = laneIndex + 1;

		PostHVTReDisplay();
		m_iLastSelIONum = m_iCurSelIONum;
	 }
	/*************************************************
	Function:		selectVTCoilIO
	Description:	选择不同的虚拟线圈
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.selectVTCoilIO = function (iVTCoilIO) {
		var iLastIndex = parseInt(m_iCurSelIONum) - 1;
		if(iVTCoilIO == iLastIndex) {
			return;
		}

		$("#tabpostVTCoil").find("li").each(function() {
			 if($(this).children().hasClass("current")) {
				 $(this).children().removeClass();
			 }
		});
		$("#tabpostVTCoil").find("li").eq(iVTCoilIO).find("a").eq(0).addClass("current");
		//保存之前Tab值
		$(ia(TriggerMode).m_PostVTCoilXml).find("laneDirectionType").eq(iLastIndex).text($("#laneDirectionType_postVTCoil").val());
		$(ia(TriggerMode).m_PostVTCoilXml).find("relatedDriveWay").eq(iLastIndex).text($("#RelatedDriveWay_VTCoil").val());
		$(ia(TriggerMode).m_PostVTCoilXml).find("laneUsage").eq(iLastIndex).text($("#useageType").val());
		$(ia(TriggerMode).m_PostVTCoilXml).find("carDriveDirect").eq(iLastIndex).text($("#carDriveDirect").val());
		
		$(ia(TriggerMode).m_PostVTCoilXml).find("signSpeed").eq(iLastIndex).text($("#carsignSpeed").val());
		$(ia(TriggerMode).m_PostVTCoilXml).find("lowSpeedLimit").eq(iLastIndex).text($("#lowSpeedLimit").val());
		$(ia(TriggerMode).m_PostVTCoilXml).find("highSpeedLimit").eq(iLastIndex).text($("#highSpeedLimit").val());
		
        $(ia(TriggerMode).m_PostVTCoilXml).find("bigCarSignSpeed").eq(iLastIndex).text($("#bigCarSignSpeed").val());
        $(ia(TriggerMode).m_PostVTCoilXml).find("bigCarHighSpeedLimit").eq(iLastIndex).text($("#bigCarHighSpeedLimit").val());
		$(ia(TriggerMode).m_PostVTCoilXml).find("bigCarLowSpeedLimit").eq(iLastIndex).text($("#bigCarLowSpeedLimit").val());
		
		//黄车禁行时间段
		for(var i = 1; i < 5; i++) {
			var startTime1=$("#banTrucksStartTime" + i).val().split(":")[0];
			var startTime2=$("#banTrucksStartTime" + i).val().split(":")[1]
			var stopTime1=$("#banTrucksStopTime" + i).val().split(":")[0];
			var stopTime2=$("#banTrucksStopTime" + i).val().split(":")[1];
			$(ia(TriggerMode).m_PostVTCoilXml).find("banTrucksTimeSwitchList").eq(iLastIndex).find("startHour").eq(i-1).text(startTime1);
			$(ia(TriggerMode).m_PostVTCoilXml).find("banTrucksTimeSwitchList").eq(iLastIndex).find("startMinute").eq(i-1).text(startTime2);
			$(ia(TriggerMode).m_PostVTCoilXml).find("banTrucksTimeSwitchList").eq(iLastIndex).find("endHour").eq(i-1).text(stopTime1);
			$(ia(TriggerMode).m_PostVTCoilXml).find("banTrucksTimeSwitchList").eq(iLastIndex).find("endMinute").eq(i-1).text(stopTime2);
		}

		//公交车专用车道
		if($("#dvpostVTCoilParam #useageType").val()=="bus"){
			for(var i = 1; i < 5; i++) {
				var startTime1=$("#busWayStartTime" + i).val().split(":")[0];
				var startTime2=$("#busWayStartTime" + i).val().split(":")[1]
				var stopTime1=$("#busWayStopTime" + i).val().split(":")[0];
				var stopTime2=$("#busWayStopTime" + i).val().split(":")[1];
				$(ia(TriggerMode).m_PostVTCoilXml).find("busWayTimeSwitchList").eq(iLastIndex).find("startHour").eq(i-1).text(startTime1);
				
				$(ia(TriggerMode).m_PostVTCoilXml).find("busWayTimeSwitchList").eq(iLastIndex).find("startMinute").eq(i-1).text(startTime2);
				
				$(ia(TriggerMode).m_PostVTCoilXml).find("busWayTimeSwitchList").eq(iLastIndex).find("endHour").eq(i-1).text(stopTime1);
				
				$(ia(TriggerMode).m_PostVTCoilXml).find("busWayTimeSwitchList").eq(iLastIndex).find("endMinute").eq(i-1).text(stopTime2);
				
			}
		}
        
		/*if (radarRS485Num == 1 && iLastIndex > 0) {
			
       	}else{*/
       		$(ia(TriggerMode).m_PostVTCoilXml).find("radarType").eq(iLastIndex).text($("#RadarType").val());
       		$.each(['radarAngle', 'validRadarSpeedTime',
	       		 'radarLinearCorrection', 'radarConstantCorrection'], function (i,n) {
	       		 	$(ia(TriggerMode).m_PostVTCoilXml).find(n).eq(iLastIndex).text($("#"+n).val());
	       	});

       		$(ia(TriggerMode).m_PostVTCoilXml).find("radarRS485").eq(iLastIndex).text($("#radarRS485_VTCoil").val());
       		$(ia(TriggerMode).m_PostVTCoilXml).find("radarSensitivity").eq(iLastIndex).text($("#RadarSensitivity_VTCoil").val());
       	//}
		
		for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
			$(ia(TriggerMode).m_PostVTCoilXml).find("IOOutList").eq(iLastIndex).find("enabled").eq(i).text($("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked").toString());
		}
		$(ia(TriggerMode).m_PostVTCoilXml).find("flashMode").eq(iLastIndex).text($("#FlashMode").val());
		
		//获取当前Tab值
		m_iCurSelIONum = iVTCoilIO + 1;
		ia(TriggerMode).changeUseageType($(ia(TriggerMode).m_PostVTCoilXml).find("laneUsage").eq(iVTCoilIO).text());
		$("#RelatedDriveWay_VTCoil").val($(ia(TriggerMode).m_PostVTCoilXml).find("relatedDriveWay").eq(iVTCoilIO).text());	
		$("#laneDirectionType_postVTCoil").val($(ia(TriggerMode).m_PostVTCoilXml).find("laneDirectionType").eq(iVTCoilIO).text());

		var lt = $(ia(TriggerMode).m_PostVTCoilXml).find("laneUsage").eq(iVTCoilIO).text();
		$.g.setField2('#useageType', lt);
		$("#carDriveDirect").val($(ia(TriggerMode).m_PostVTCoilXml).find("carDriveDirect").eq(iVTCoilIO).text());
		
		$("#carsignSpeed").val($(ia(TriggerMode).m_PostVTCoilXml).find("signSpeed").eq(iVTCoilIO).text());
		$("#lowSpeedLimit").val($(ia(TriggerMode).m_PostVTCoilXml).find("lowSpeedLimit").eq(iVTCoilIO).text());	
		$("#highSpeedLimit").val($(ia(TriggerMode).m_PostVTCoilXml).find("highSpeedLimit").eq(iVTCoilIO).text());	
        $("#bigCarSignSpeed").val($(ia(TriggerMode).m_PostVTCoilXml).find("bigCarSignSpeed").eq(iVTCoilIO).text());
        $("#bigCarHighSpeedLimit").val($(ia(TriggerMode).m_PostVTCoilXml).find("bigCarHighSpeedLimit").eq(iVTCoilIO).text());
		$("#bigCarLowSpeedLimit").val($(ia(TriggerMode).m_PostVTCoilXml).find("bigCarLowSpeedLimit").eq(iVTCoilIO).text());		
		
		//黄车禁行时间段
		for(var i = 1; i < 5; i++) {
			$("#dvpostVTCoilParam #banTrucksStartTime" + i).val($(ia(TriggerMode).m_PostVTCoilXml).find("banTrucksTimeSwitchList").eq(iVTCoilIO).find("startHour").eq(i-1).text() + ":" + $(ia(TriggerMode).m_PostVTCoilXml).find("banTrucksTimeSwitchList").eq(iVTCoilIO).find("startMinute").eq(i-1).text());
			$("#dvpostVTCoilParam #banTrucksStopTime" + i).val($(ia(TriggerMode).m_PostVTCoilXml).find("banTrucksTimeSwitchList").eq(iVTCoilIO).find("endHour").eq(i-1).text() + ":" + $(ia(TriggerMode).m_PostVTCoilXml).find("banTrucksTimeSwitchList").eq(iVTCoilIO).find("endMinute").eq(i-1).text());
		}

		var $busWay = $(ia(TriggerMode).m_PostVTCoilXml).find('busWayTimeSwitchList').eq(iVTCoilIO);
		for(var j = 1; j < 5; j++) {
			var startTime=$busWay.find("startHour").eq(j-1).text() + ":" + $busWay.find("startMinute").eq(j-1).text();
			var stopTime=$busWay.find("endHour").eq(j-1).text() + ":" + $busWay.find("endMinute").eq(j-1).text();
		    $("#dvpostVTCoilParam #busWayStartTime" + j).val(startTime);
		    $("#dvpostVTCoilParam #busWayStopTime" + j).val(stopTime);
		   
		}

				
		
       	/*if (radarRS485Num == 1 && iVTCoilIO > 0) {
       	}else{*/
       		$.g.setField2('#RadarType',  $(ia(TriggerMode).m_PostVTCoilXml).find("radarType").eq(iVTCoilIO).text());	
       		$.each([ 'radarAngle', 'validRadarSpeedTime',
	       		 'radarLinearCorrection', 'radarConstantCorrection'], function (i,n) {
	       		$.g.setField2('#'+n,  $(ia(TriggerMode).m_PostVTCoilXml).find(n).eq(iVTCoilIO).text());	
	       	});

       		$.g.setField2('#radarRS485_VTCoil',  $(ia(TriggerMode).m_PostVTCoilXml).find("radarRS485").eq(iVTCoilIO).text());	
       		$.g.setField2('#RadarSensitivity_VTCoil',  $(ia(TriggerMode).m_PostVTCoilXml).find("radarSensitivity").eq(iVTCoilIO).text());	
       	//}
       	
		for(var i = 0; i < ia(TriggerMode).m_iSyncOutNum; i++) {
			$("#AlarmOutputCheckboxChanO-" + (i + 1)).prop("checked",$(ia(TriggerMode).m_PostVTCoilXml).find("IOOutList").eq(iVTCoilIO).find("enabled").eq(i).text() === "true" ? true : false);
		}

		$.g.setField2('#FlashMode', $(ia(TriggerMode).m_PostVTCoilXml).find("flashMode").eq(iVTCoilIO).text());
		
		PostVTCoilReDisplay();
        getTriggerIOCopyInfoForVTCoil();
        getTriggerIOCopyRadarForVTCoil();

		m_iLastSelIONum = m_iCurSelIONum;
	}


	TriggerMode.prototype.selectVideoMonitorLane = function (iLaneNum) {
		var iLastIndex = parseInt(m_iCurSelIONum) - 1;
		if(iLaneNum == iLastIndex) {
			return;
		}

		var $a = $('#tabVideoMonitor a').eq(iLaneNum);
		if (!$a.length) {
			return;
		};

		var $xmlDoc = $(ia(TriggerMode).m_videoMonitorXml);
		var $trigDiv = $('#taTriggerMode');

		$trigDiv.find("#tabVideoMonitor").find("li").each(function() {
			 if($(this).children().hasClass("current")) {
				 $(this).children().removeClass();
			 }
		});

		$trigDiv.find("#tabVideoMonitor").find("li").eq(iLaneNum).find("a").eq(0).addClass("current");
		//保存之前Tab值
		$xmlDoc.find("laneDirectionType").eq(iLastIndex).text($trigDiv.find('#laneDirectionType_videoMonitor').val());
		$xmlDoc.find("relatedDriveWay").eq(iLastIndex).text($trigDiv.find('#RelatedDriveWay').val());
        $xmlDoc.find("carDriveDirect").eq(iLastIndex).text($trigDiv.find('#carDriveDirect').val());
        //获取当前tab值
        $trigDiv.find("#laneDirectionType_videoMonitor").val($xmlDoc.find("laneDirectionType").eq(iLaneNum).text());
		$trigDiv.find("#RelatedDriveWay").val($xmlDoc.find("relatedDriveWay").eq(iLaneNum).text());
		$trigDiv.find("#carDriveDirect").val($xmlDoc.find("carDriveDirect").eq(iLaneNum).text());

		m_iCurSelIONum = iLaneNum + 1;

		m_iLastSelIONum = m_iCurSelIONum;
	}

	 /*************************************************
	Function:		selectLaneCount
	Description:	切换车道
	Input:			iLaneNum: 车道号			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.selectLaneCount = function (iLaneNum) {
		var iLastIndex = parseInt(m_iCurSelIONum) - 1;
		if(iLaneNum == iLastIndex) {
			return;
		}

		var $xmlDoc = $(ia(TriggerMode).m_PostMprXml);
		var $trigDiv = $('#taTriggerMode');

		$trigDiv.find("#tabPostMpr").find("li").each(function() {
			 if($(this).children().hasClass("current")) {
				 $(this).children().removeClass();
			 }
		});
		$trigDiv.find("#tabPostMpr").find("li").eq(iLaneNum).find("a").eq(0).addClass("current");
		//保存之前Tab值
		$xmlDoc.find("relatedDriveWay").eq(iLastIndex).text($trigDiv.find("#RelatedDriveWay").val());
		// $xmlDoc.find("OSDDriveWay").eq(iLastIndex).text($trigDiv.find("#OSDDriveWay").val());
		
		var trigType = $trigDiv.find("#triggerType").val();
		if (trigType == '2' || trigType == '3') {  // IO or 485
			var tmpObj = x2js.xml_str2json(xmlToStr(ia(TriggerMode).m_PostMprXml));
			if (tmpObj) {
				var laneArr = tmpObj['PostMpr']['LaneParamList'].LaneParam_asArray;
				if (laneArr && laneArr.length) {
					var laneParam = laneArr[iIndex];

					if (trigType == '2') {
						laneParam.relateIO = $trigDiv.find("#relateIO").val();
						laneParam.IODefaultStatus = $trigDiv.find("#IODefaultStatus").val();
					}else{
						laneParam.relate485Chan = $trigDiv.find("#relate485Chan").val();
					}
				};

				ia(TriggerMode).m_PostMprXml = x2js.json2xml(tmpObj);
			};
		};

		$xmlDoc = $(ia(TriggerMode).m_PostMprXml);
		
		//获取当前Tab值
		m_iCurSelIONum = iLaneNum + 1;
		$trigDiv.find("#RelatedDriveWay").val($xmlDoc.find("relatedDriveWay").eq(iLaneNum).text());
		// $trigDiv.find("#OSDDriveWay").val($xmlDoc.find("OSDDriveWay").eq(iLaneNum).text());
		
		$.g.setField2('#taTriggerMode #relate485Chan', $xmlDoc.find("relate485Chan").eq(iLaneNum).text());
		$.g.setField2('#taTriggerMode #relateIO', $xmlDoc.find("relateIO").eq(iLaneNum).text());
		$.g.setField2('#taTriggerMode #IODefaultStatus', $xmlDoc.find("IODefaultStatus").eq(iLaneNum).text());

		PostMprReDisplay();
		m_iLastSelIONum = m_iCurSelIONum;
	}

	TriggerMode.prototype.PostHVTAdvanceParam = function () {
		if(ia(TriggerMode).m_postHVTXml == null) {
			return;
		}
		var intType = $(ia(TriggerMode).m_postHVTXml).find("intervalType").eq(0).text();
		$.g.setField2("#postHVT_g_params_div #IntervalType", intType);
		
		var $doc = $(ia(TriggerMode).m_postHVTXml);

		changeHVTIntervalType($(ia(TriggerMode).m_postHVTXml).find("intervalType").eq(0).text(), true);
		
		var $intvs = $doc.find('intervalValue');
		for (var i = 0; i < $intvs.length; i++) {
			if (i < 2) {
				var v = $intvs.eq(i).text();
				$('#postHVT_g_params_div #HVT_Interval'+(i+1)).val(v);
			}
		};

		$.each(['post', 'reverse', 'overSpeed','lowSpeed', 'banSign', 'driveLine'], function(i,n){
			var $capNo = $('#postHVT_g_params_div #HVT_vt'+n+'CapNo');
			//$capNo.find('option').remove();

			$.g.setField2('#postHVT_g_params_div #HVT_vt'+n, $doc.find(n).text());

            $.g.setField2('#postHVT_g_params_div #HVT_vtdriveLineSensitivity', $doc.find('driveLineSensitivity').text());

			//if($("#taTriggerMode #capMode_HVT").val() == "capFrame") { // 爆闪 1-3
				// for (var i = 1; i <= 3; i++) {
				// 	$capNo.append("<option value='"+i+"'>"+i+"</option>");
				// };
				var v = $doc.find(n+"CapNo").text();
				$.g.setField2('#postHVT_g_params_div #HVT_vt'+n+"CapNo", v);
				$capNo.prop('disabled', false).attr('disabled', false);
			// } else {
			// 	if(n != "post") {
			// 		$capNo.append("<option value='"+2+"'>"+2+"</option>");
			// 		$.g.setField2('#vt'+n+"CapNo", 2);
			// 		$("#vt" + n + "CapNo").prop("disabled", true).attr('disabled', true);
			// 	}else{  // post  1-2
			// 		for (var i = 1; i < 3; i++) {
			// 			$capNo.append("<option value='"+i+"'>"+i+"</option>");
			// 		};
			// 		var v = $doc.find(n+"CapNo").text();
			// 		$.g.setField2('#postHVT_g_params_div #vt'+n+"CapNo", v);
			// 		$capNo.prop('disabled', false).attr('disabled', false);
			// 	}
			// }


			
		});
	    //$("#postHVT_g_params_div").modal();
	}

	TriggerMode.prototype.setHVTAdvanceParam = function () {
		var intType = $("#postHVT_g_params_div #IntervalType").val();
		var res = true;

		var $xml = $(ia(TriggerMode).m_postHVTXml);
		$.each(['post', 'reverse', 'overSpeed','lowSpeed', 'banSign', 'driveLine'], function(i,n){
			var sel = '#postHVT_g_params_div #HVT_vt'+n;
			$xml.find(n).eq(0).text($(sel).prop("checked")? "true": "false");
			$xml.find(n+'CapNo').eq(0).text($('#postHVT_g_params_div #HVT_vt' + n +'CapNo').val());

			if (n == 'driveLine') {
				$xml.find('driveLineSensitivity').eq(0).text($('#postHVT_g_params_div #HVT_vtdriveLineSensitivity').val());				
			};
	    });
		$xml.find("intervalType").eq(0).text($("#postHVT_g_params_div #IntervalType").val());
		$xml.find('intervalValue').eq(0).text($('#postHVT_g_params_div #HVT_Interval').val());
		$xml.find('intervalValue').eq(1).text($('#postHVT_g_params_div #HVT_Interva2').val());

		//$.modal.impl.close();
	}

	
	/*************************************************
	Function:		VTCoilAdvanceParam
	Description:	获取虚拟线圈高级参数
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
    TriggerMode.prototype.VTCoilAdvanceParam = function () {
		if(ia(TriggerMode).m_PostVTCoilXml != null) {
			$("#VTCoilAdvancedParam #IntervalType").val($(ia(TriggerMode).m_PostVTCoilXml).find("intervalType").eq(0).text());
			changeIntervalType($(ia(TriggerMode).m_PostVTCoilXml).find("intervalType").eq(0).text(), true);
			
			$.each(['post', 'reverse', 'overSpeed','lowSpeed', 'banSign', 'driveLine'], function(i,n){
				if($("#drawRightRegionContent #capMode").val() == "0") {
					if(n != "post") {
						$("#vt" + n + "CapNo").prop("disabled", true);
						for(var i = 1; i < 3; i++){
							$("#" + n + "Interval" + i).prop("disabled", true);
						}
					}
				} else {
					$("#vt" + n + "CapNo").prop("disabled", false);
					for(var i = 1; i < 3; i++){
						$("#" + n + "Interval" + i).prop("disabled", false);
					}
				}
				var sel = '#vt'+n;
				var v = $(ia(TriggerMode).m_PostVTCoilXml).find(n).eq(0).text() == "true"?true:false;
				$.g.setField2(sel, v);
				
				var sel = '#vt'+(n+'CapNo');
				var v = $(ia(TriggerMode).m_PostVTCoilXml).find(n+'CapNo').eq(0).text();
				$.g.setField2(sel, v);
				
				for(var i = 1; i < 3; i++){
					$("#" + n + "Interval" + i).val("0");
				}
				for(var i = 1; i < v; i++) {
					$("#" + n + "Interval" + i).val(parseInt($(ia(TriggerMode).m_PostVTCoilXml).find(n+"Interval").eq(i-1).text(),10));
				}
				
			});
		}
		if($("#drawRightRegionContent #capMode").val()=="0"){
			$("#VTCoilAdvancedParam #dvvtpostCapNo").hide();
		}else if($("#drawRightRegionContent #capMode").val()=="1"){
			$("#VTCoilAdvancedParam #dvvtpostCapNo").show();
		}
	    $("#VTCoilAdvancedParam").modal();
	}
	/*************************************************
	Function:		setVTCoilAdvanceParam
	Description:	设置虚拟线圈高级参数
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.setVTCoilAdvanceParam = function () {
		var intType = $("#VTCoilAdvancedParam #IntervalType").val();
		var res = true;

		$.each(['post', 'reverse', 'overSpeed','lowSpeed', 'banSign', 'driveLine'], function(i,n){
			var sel = '#vt'+n;
			var chked = $(sel).prop("checked");
			var capNo = parseInt($('#vt' + n +'CapNo').val(),10);
			if (chked) {
				for(var i = 1; i < 3; i++) {
					if (i < capNo) {
						var interval = $("#" + n + "Interval" + i).val();
						if (intType == 'distance') {
							if (parseInt(interval, 10) > 50) {
								res = false;
								return;
							}
						}else{
							if (parseInt(interval, 10) > 10000) {
								res = false;
								return;
							}
						}
					}else{
						$("#" + n + "Interval" + i).val(0);
					}					
				}
			}else{
				for(var i = 1; i < 3; i++) {
					var intvDom = $("#" + n + "Interval" + i);
					if (i < capNo) {
						var interval = intvDom.val();
						if (intType == 'distance') {
							if (parseInt(interval, 10) > 50) {
								intvDom.val(50);
							}
						}else{
							if (parseInt(interval, 10) > 10000) {
								intvDom.val(10000);
							}
						}
					}else{
						intvDom.val(0);
					}					
				}
			}
	    });

		if (!res) {
			var errInfo = '';
			if (intType == 'distance') {
				errInfo = m_szErrorState + getNodeValue("IntervalShouldBeLessThan50");	
			}else{
				errInfo = m_szErrorState + getNodeValue("IntervalTimeShouldBeLessThan60000");
			}
			
			$('#VTCoilAdvancedParam #CheckResultTips').html(errInfo);
			setTimeout(function() {
				$('#VTCoilAdvancedParam #CheckResultTips').html('');	
			}, 5000);
			return;
		}
		


		//数据校验		
		$(ia(TriggerMode).m_PostVTCoilXml).find("post").eq(0).text($("#post").prop("checked").toString());
		
		
		// $.each(['post', 'reverse', 'overSpeed','lowSpeed', 'banSign', 'driveLine'], function(i,n){
		// 	$(ia(TriggerMode).m_PostVTCoilXml).find(n + "IntervalList").remove();
		// });

		var jsonobj=x2js.xml_str2json(xmlToStr(ia(TriggerMode).m_PostVTCoilXml));
		var detectSnapTypeArr=jsonobj['PostVTCoil']['detectSnapType'];

		$.each(['post', 'reverse', 'overSpeed','lowSpeed', 'banSign', 'driveLine'], function(i,n){
			var sel = '#vt'+n;
			// $(ia(TriggerMode).m_PostVTCoilXml).find(n).eq(0).text($(sel).prop("checked").toString());
			// $(ia(TriggerMode).m_PostVTCoilXml).find(n+'CapNo').eq(0).text($('#vt' + n +'CapNo').val());
			
			// $(ia(TriggerMode).m_PostVTCoilXml).find(n + "IntervalList").remove();
			detectSnapTypeArr[n]=$(sel).prop("checked").toString();
			detectSnapTypeArr[n+'CapNo']=$('#vt' + n +'CapNo').val();
			detectSnapTypeArr[n + "IntervalList"]=[];
			
			if(jsonobj){
				var obj0=[];
				obj0[n + "IntervalList"]=[];
				for(var i = 1; i < $('#vt' + n +'CapNo').val(); i++) {
					var obj1=[];
					var obj2=[];
					obj1[n + "IntervalValue"]=$("#" + n + "Interval" + i).val();
					obj2[n + "Interval"]=[];
					obj2[n + "Interval"].push(obj1);
					obj0[n + "IntervalList"].push(obj2);
				}
				detectSnapTypeArr[n + "IntervalList"].push(obj0);
			}
			
			// var szInfo = "<?xml version='1.0' encoding='UTF-8'?><IntervalList><" + n + "IntervalList>";
			// for(var i = 1; i < $('#vt' + n +'CapNo').val(); i++) {
			// 	szInfo += "<" + n + "Interval><" + n + "IntervalValue>" + $("#" + n + "Interval" + i).val() + "</" + n + "IntervalValue></" + n + "Interval>";
			// }
			// szInfo += "</" + n + "IntervalList></IntervalList>";
			// $(ia(TriggerMode).m_PostVTCoilXml).find("detectSnapType").eq(0).append($(parseXmlFromStr(szInfo)).find("IntervalList").eq(0).clone().children());
			
	    });
		ia(TriggerMode).m_PostVTCoilXml=x2js.json2xml(jsonobj);
		$(ia(TriggerMode).m_PostVTCoilXml).find("intervalType").eq(0).text($("#VTCoilAdvancedParam #IntervalType").val());
		
		$.modal.impl.close();
	}

    /*************************************************
     Function:		changeSpeedDetector
     Description:	切换测速模式
	 Input:			    无
     Output:			无
     return:			无
     *************************************************/
    TriggerMode.prototype.changeSpeedDetector = function(iType, parentDivSel){
    	if (!parentDivSel) {
    		parentDivSel = '';
    	};
        if(iType == "1"){
            $(parentDivSel+' #radarEnabledContent').css("display","block");
        }else{
            $(parentDivSel+' #radarEnabledContent').css("display","none");
        }
        autoResizeIframe();
    }
	
	TriggerMode.prototype.changeUseageType = function(strType, parentDivSel) {
		if (!parentDivSel) {
    		parentDivSel = '';
    	};

    	$('#dvbusTimeSwitch').hide();
		if (strType == 'bus') {
			$('#dvbusTimeSwitch').show();
		};

		if(strType == "banTrucks"){
            $(parentDivSel+" #dvbanTrucksTimeSwitch").css("display","block");
        }else{
            $(parentDivSel+" #dvbanTrucksTimeSwitch").css("display","none");
        }
        var directionType=$("#videoEpLaneParam #directionType").val();
        
        var html="";
        $("#videoEpLaneParam #directionType").html("");
        if("banLeft"==strType){
			html="<option value='straight' name='directionTypeOpt2'>"+getNodeValue("directionTypeOpt2")+"</option>"+
                 "<option value='right' name='directionTypeOpt4'>"+getNodeValue("directionTypeOpt4")+"</option>"+
        		 "<option value='rightStraight' name='directionTypeOpt6'>"+getNodeValue("directionTypeOpt6")+"</option>"+
                 "<option value='straightWait' name='directionTypeOpt9'>"+getNodeValue("directionTypeOpt9")+"</option>"+
                 "<option value='strightWaitRight' name='directionTypeOpt10'>"+getNodeValue("directionTypeOpt10")+"</option>";
            
        }else if("banRight"==strType){
			html="<option value='left' name='directionTypeOpt1'>"+getNodeValue("directionTypeOpt1")+"</option>"+
                 "<option value='straight' name='directionTypeOpt2'>"+getNodeValue("directionTypeOpt2")+"</option>"+
        		 "<option value='leftStraight' name='directionTypeOpt3'>"+getNodeValue("directionTypeOpt3")+"</option>"+
                 "<option value='leftWait' name='directionTypeOpt8'>"+getNodeValue("directionTypeOpt8")+"</option>"+
                 "<option value='straightWait' name='directionTypeOpt9'>"+getNodeValue("directionTypeOpt9")+"</option>";
           
        }else{
			html="<option value='left' name='directionTypeOpt1'>"+getNodeValue("directionTypeOpt1")+"</option>"+
        		"<option value='straight' name='directionTypeOpt2'>"+getNodeValue("directionTypeOpt2")+"</option>"+
        		"<option value='leftStraight' name='directionTypeOpt3'>"+getNodeValue("directionTypeOpt3")+"</option>"+
        		"<option value='right' name='directionTypeOpt4'>"+getNodeValue("directionTypeOpt4")+"</option>"+
        		"<option value='leftRight' name='directionTypeOpt5'>"+getNodeValue("directionTypeOpt5")+"</option>"+
        		"<option value='rightStraight' name='directionTypeOpt6'>"+getNodeValue("directionTypeOpt6")+"</option>"+
        		"<option value='leftRightStraight' name='directionTypeOpt7'>"+getNodeValue("directionTypeOpt7")+"</option>"+
        		"<option value='leftWait' name='directionTypeOpt8'>"+getNodeValue("directionTypeOpt8")+"</option>"+
        		"<option value='straightWait' name='directionTypeOpt9'>"+getNodeValue("directionTypeOpt9")+"</option>"+
        		"<option value='strightWaitRight' name='directionTypeOpt10'>"+getNodeValue("directionTypeOpt10")+"</option>";
        }
        $("#videoEpLaneParam #directionType").html(html);
        $("#videoEpLaneParam #directionType").val(directionType);
        autoResizeIframe();
	}

    TriggerMode.prototype.enabledRadarVideoEp = function(){
        if($('#radarEnabled_videoEp').prop("checked")){
            $('#radarEnabledContent_videoEp').css("display","block");
        }else{
            $('#radarEnabledContent_videoEp').css("display","none");
        }
        autoResizeIframe();
    }
    TriggerMode.prototype.videoEpAdvCfg = function(){
    	if ($('#videoEpContentDiv').is(':hidden')) {
    		$('#videoEpContentDiv').show();
    	}else{
    		$('#videoEpContentDiv').hide();
    	}
        autoResizeIframe();
    }

    TriggerMode.prototype.enableNonDriveWay = function(){
    	if($('#nonDriveWay').prop("checked")){
            $('#nonDriveWayTime').noUiSlider('disabled', false);
            $('#nonDriveWayCapNo').removeAttr('disabled');
        }else{
        	$('#nonDriveWayTime').noUiSlider('disabled', true);
            $('#nonDriveWayCapNo').attr('disabled', true);
        }
        autoResizeIframe();
    }

    TriggerMode.prototype.enableParkingTime = function(){
    	if(!$("#intersectionStop").prop("checked") && !$("#greenLightStop").prop("checked")){
    		$("#parkingTime").noUiSlider('disabled', true);
    	}else{
    		$("#parkingTime").noUiSlider('disabled', false);
    	}
    	autoResizeIframe();
    }

    TriggerMode.prototype.enableEhangeLane=function(){
    	if($('#changeLane').prop("checked")){
            $('#changeLaneSensitive').noUiSlider('disabled', false);
            
        }else{
            $('#changeLaneSensitive').noUiSlider('disabled', true);
        }
        autoResizeIframe();
    }

     TriggerMode.prototype.enableDriveLine = function(){
    	if($('#driveLine').prop("checked")){
            $('#driveLineCapNo').removeAttr('disabled');
            $('#driveLineSensitivity').noUiSlider('disabled', false);
            
        }else{
            $('#driveLineCapNo').attr('disabled', true);
            $('#driveLineSensitivity').noUiSlider('disabled', true);
        }
        autoResizeIframe();
    }

    TriggerMode.prototype.enableRedLight = function(){
    	if($('#redLight').prop("checked")){
           // $('#redLight_detail').css("display","block");
           $('#stopLineDistance, #capPositionOffset').each(function(){
           		$(this).noUiSlider('disabled', false);
           });
           $('#redLightMode, #illegalPriority').removeAttr('disabled');
        }else{
           $('#stopLineDistance, #capPositionOffset').each(function(){
           		$(this).noUiSlider('disabled', true);
           });
           $('#redLightMode, #illegalPriority').attr('disabled', true);
           // $('#redLight_detail').css("display","none");
        }
        autoResizeIframe();
    }

    TriggerMode.prototype.enableRedLightRecord = function(){
    	if($('#recordEnable').prop("checked")){
            $('#redLightRecord_detail').css("display","block");
        }else{
            $('#redLightRecord_detail').css("display","none");
        }
        autoResizeIframe();
    }

	TriggerMode.prototype.enableCaps = function(obj){
    	var id = $(obj).attr('id');
    	var selId = id+"CapNo";
    	$('#'+selId).prop('disabled', !$(obj).prop('checked'));
    }
    
    

    /*************************************************
     Function:		selectVTCoilModal
     Description:	虚拟线圈 却换弹出层Tab触发事件
     Input:			    无
     Output:			无
     return:			无
     *************************************************/
    TriggerMode.prototype.selectVTCoilModal = function(tabId){
    	var oldIdx = -1;

    	var idxArr = [];
        $("#tabpostVTCoilModal").find("li").not(":hidden").each(function() {
            var idx = $(this).attr('id').replace("liVTCoil", "");
            idxArr.push(parseInt(idx));
            if($(this).children().hasClass("current")) {
            	oldIdx = parseInt(idx)-1;
                $(this).children().removeClass();
            }
        });

        if (oldIdx >= 0) {
        	RestorePlateRegion('#VTCoilDrawActiveX', true);
        	RestoreVTCoilRegion();
        }

        $("#tabpostVTCoilModal").find("li").eq(tabId).find("a").eq(0).addClass("current");

        var opt = {
        	laneLine: $('#laneLine_vtCoil').prop('checked'),
        	laneRightBoundaryLine: $('#laneRightLine_vtCoil').prop('checked')
        }

        var ocx = $('#VTCoilDrawActiveX')[0];
    	DisplayPlateRegionEx(idxArr, '#VTCoilDrawActiveX', null,  true);
    	DisplayVTCoilRegion(idxArr, '#VTCoilDrawActiveX', {r:255,g:0,b:0}, true, opt);
		ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
    }
	
	/*************************************************
     Function:		selectPostMprModal
     Description:	虚拟线圈 却换弹出层Tab触发事件
     Input:			    无
     Output:			无
     return:			无
     *************************************************/
    TriggerMode.prototype.selectPostMprModal = function(tabId){
    	var oldIdx = -1;

    	var idxArr = [];
        $("#tabPostMprModal").find("li").not(":hidden").each(function() {
            var idx = $(this).attr('id').replace("liPostMpr", "");
            idxArr.push(parseInt(idx));
            if($(this).children().hasClass("current")) {
            	oldIdx = parseInt(idx)-1;
                $(this).children().removeClass();
            }
        });

        if (oldIdx >= 0) {
        	RestorePlateRegion('#PostMprDrawPlugin', true);
        	RestorePostMprRegion();
        }

        $("#tabPostMprModal").find("li").eq(tabId).find("a").eq(0).addClass("current");

        var opt = {
        	laneLine: $('#laneLine_PostMpr').prop('checked'),
        	laneRightBoundaryLine: $('#laneRightLine_PostMpr').prop('checked')
        }

        var ocx = $('#PostMprDrawPlugin')[0];
    	DisplayPlateRegionEx(idxArr, '#PostMprDrawPlugin', null,  true);
    	DisplayPostMprRegion(idxArr, '#PostMprDrawPlugin', {r:255,g:0,b:0}, true, opt);
		ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
    }

    TriggerMode.prototype.changeVideoMonitorLaneCount = function (v) {
    	var $t = $('#tabVideoMonitor');
		var iLength = $t.find('li').length;
        for (var i = 0; i < iLength; i++) {
            if (i < v ) {
                $t.find('li#lilaneCount'+(i+1)).show();
            }else{
                $t.find('li#lilaneCount'+(i+1)).hide();
            }
        }

        var l = $t.find('li').not(':hidden').find('a.current').length;
        if (l == 0) {
            ia(TriggerMode).selectVideoMonitorLane(0);
        }else{
        	var current = $('#tabVideoMonitor a.current').not(":hidden");
        	var idx = current.eq(0).parent().attr('id').replace("lilaneCount", "");
			idx = parseInt(idx, 10) - 1;
			ia(TriggerMode).selectVideoMonitorLane(idx);
        }
    	VideoMonitorReDisplay();
    }
    
	TriggerMode.prototype.changeVideoEpLancCount = function (v) {
        var triggerModeType = ia(TriggerMode).m_CurTriggerMode;

        switch(triggerModeType){
//            case "postSingleIO":
//                break;
//            case "postIOSpeed":
//                break;
            case "postRS485"://卡式车检器

                if($('#tabBackUpModel .current').attr("name") == "aBackUpModel2"){ //虚拟线圈
                    var $t = $('#tabpostVTCoil');
					var iLength = $t.find('li').length;
                    for (var i = 0; i < iLength; i++) {
                        if (i < v ) {
                            $t.find('li#liVT'+(i+1)).show();
                        }else{
                            $t.find('li#liVT'+(i+1)).hide();
                        }
                    }

                    var l = $t.find('li').not(':hidden').find('a.current').length;
                    if (l == 0) {
                        ia(TriggerMode).selectVTCoilIO(0);
                    }
                }else{
                    var $t = $('#tabRelatedLane_post485');
                    for (var i = 0; i < $t.find('li').length; i++) {
                        if (i < v ) {
                            $t.find('li#liRelatedLane'+(i+1)).show();
                        }else{
                            $t.find('li#liRelatedLane'+(i+1)).hide();
                        }
                    }

                    var l = $t.find('li').not(':hidden').find('a.current').length;
                    if (l == 0) {
                        ia(TriggerMode).selectRelatedLane(0);
                    }
                    PostRS485ReDisplay();
                }
                getTriggerIOCopyInfoForPost485();
                break;
            case "postRadar":
                var $t = $('#tabRelatedLane_post485');
                for (var i = 0; i < $t.find('li').length; i++) {
                    if (i < v ) {
                        $t.find('li#liRelatedLane'+(i+1)).show();
                    }else{
                        $t.find('li#liRelatedLane'+(i+1)).hide();
                    }
                }

                var l = $t.find('li').not(':hidden').find('a.current').length;
                if (l == 0) {
                    ia(TriggerMode).selectRelatedLane(0);
                }
                getTriggerIOCopyInfoForPost485();
                PostRadarReDisplay();
				autoResizeIframe();
                break;
            case "epoliceRS485":    //电警车检器

                var $t = $('#tabRelatedLane');
                for (var i = 0; i < $t.find('li').length; i++) {
                    if (i < v ) {
                        $t.find('li#liRelatedLane'+(i+1)).show();
                    }else{
                        $t.find('li#liRelatedLane'+(i+1)).hide();
                    }
                }

                var l = $t.find('li').not(':hidden').find('a.current').length;
                if (l == 0) {
                    ia(TriggerMode).selectEpoliceLane(0);
                }
                EpoliceRS485ReDisplay();
                getTriggerIOCopyInfoForEpolice485();
                break;
            case "postEpoliceRS485":
                var $t = $('#tabRelatedLane');
                for (var i = 0; i < $t.find('li').length; i++) {
                    if (i < v ) {
                        $t.find('li#liRelatedLane'+(i+1)).show();
                    }else{
                        $t.find('li#liRelatedLane'+(i+1)).hide();
                    }
                }

                var l = $t.find('li').not(':hidden').find('a.current').length;
                if (l == 0) {
                    ia(TriggerMode).selectEpoliceLane(0);
                }
                PostEpoliceRS485ReDisplay();
                getTriggerIOCopyInfoForEpolice485();
                break;
            case "postVTCoil":  //虚拟线圈触发
                var $t = $('#tabpostVTCoil');
                for (var i = 0; i < $t.find('li').length; i++) {
                    if (i < v ) {
                        $t.find('li#liVT'+(i+1)).show();
                    }else{
                        $t.find('li#liVT'+(i+1)).hide();
                    }
                }

                var l = $t.find('li').not(':hidden').find('a.current').length;
                if (l == 0) {
                    ia(TriggerMode).selectVTCoilIO(0);
                }
                PostVTCoilReDisplay();
                getTriggerIOCopyInfoForVTCoil();
                getTriggerIOCopyRadarForVTCoil();
                break;
            case "videoEpolice":
                var $t = $('#tabvideoEpolice');
                for (var i = 0; i < $t.find('li').length; i++) {
                    if (i < v ) {
                        $t.find('li#liRelatedLane'+(i+1)).show();
                    }else{
                        $t.find('li#liRelatedLane'+(i+1)).hide();
                    }
                }
                var l = $t.find('li').not(':hidden').find('a.current').length;
                if (l == 0) {
                    this.selectvideoEpolice(0);
                }
                VideoEpRedispay();
                break;
			case "PostMpr":
			    var $t = $('#tabPostMpr');
                for (var i = 0; i < $t.find('li').length; i++) {
                    if (i < v ) {
                        $t.find('li#lilaneCount'+(i+1)).show();
                    }else{
                        $t.find('li#lilaneCount'+(i+1)).hide();
                    }
                }

                var l = $t.find('li').not(':hidden').find('a.current').length;
                if (l == 0) {
                    ia(TriggerMode).selectLaneCount(0);
                }
				PostMprReDisplay();
                break;
	    case "postHVT":
				var $t = $("#dvTriggerParam #tabpostHVT");
				for (var i = 0; i < $t.find('li').length; i++) {
					if (i < v ) {
                        $t.find('li#liHVT'+(i+1)).show();
                    }else{
                        $t.find('li#liHVT'+(i+1)).hide();
                    }
				};
				var l = $t.find('li').not(':hidden').find('a.current').length;
                if (l == 0) {
                    this.selectHVT(0);
                }
				PostHVTReDisplay();
            default:
                break;

        }

        setTimeout(function(){
        	autoResizeIframe();
        }, 300);
	}
	
	function ResetVideoEpCopy () {
        $('#videoEpCopyDiv').find('div.singleIo_checkbox_copy_div').remove();
        $('#tabvideoEpolice li').not(":hidden").each(function () {
            if ($(this).find('a').first().is('.current')) {

            }else{
                var idx = $(this).attr('id').replace(/\D/g, "");
                var arr =  [
                '<div class="singleIo_checkbox_copy_div">',
                    '<input id="videoEp_copy_checkbox_'+idx+'" vepLaneIdx="'+idx+'" type="checkbox" ',
                    'class="singleIo_checkbox"><label for="videoEp_copy_checkbox_'+idx+'" ',
                    ' class="singleIo_checkbox">'+(getNodeValue("laVideoLane")+idx)+'</label></div>'];
                
                $('#videoEpCopyDiv').append(arr.join('')); 
            }
        });
    }
	
	
	TriggerMode.prototype.GetVideoEpoliceLaneCount = function () {
		var szUrl  = '/PSIA/Custom/SelfExt/ITC/VideoEpolice/capabilities';
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + szUrl,
			timeout: 15000,
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				var $d = $(xmlDoc).find('LaneCount').eq(0);
				var min = 0, max = 3, curVal = 3;
				if ($d.length) {
					min = parseInt($d.attr('min'));
					max = parseInt($d.attr('max'));
					curVal = parseInt($d.text());		
				}
				fillLaneCountOptions(min, max);
			},
			error: function() {
				fillLaneCountOptions(0, 3);
				_log("read cap failed use 0 3 3")  
			}
		});
	}
	
	function fillLaneCountOptions(min, max, curVal){
		if (min <= 0) {
			min = 1;
		}
        var $s = $('#RelatedLaneCount_videoEp');
        $s.find('option').remove();
        for (var i=min; i <= max; i++) {
            var opt = "<option value='"+i+"' ";
            if (curVal != null && i == curVal) {
                opt += " selected='selected' ";
            }
            opt += ">"+i+"</option>";
            
            $s.append(opt);
        }
    }

    function fillVideoMonitorLaneCountOptions(min, max, curVal){
		if (min <= 0) {
			min = 1;
		}
        var $s = $('#RelatedLaneCount_VideoMonitor');
        $s.find('option').remove();
        for (var i=min; i <= max; i++) {
            var opt = "<option value='"+i+"' ";
            if (curVal != null && i == curVal) {
                opt += " selected='selected' ";
            }
            opt += ">"+i+"</option>";
            
            $s.append(opt);
        }
    }


	//视频电警相关
	/*************************************************
	Function:		GetvideoEpoliceParam
	Description:	获取视频电警参数
	Input:			iValueType: 0 实际值 1 推荐值			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.GetvideoEpoliceParam = function (iValueType) {
		var that=this;
		var szUrl = "/PSIA/Custom/SelfExt/ITC/VideoEpolice";
		if(iValueType == 1) {
			szUrl += "/recommendation";
		}
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + szUrl,
			timeout: 15000,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				ia(TriggerMode).m_VideoEpoliceXml = xmlDoc;
				
				dontSave = true;

				var $xml = $(xmlDoc);
				//var laneMaxCount = $xml.find('#Lane').length;
				var laneCount = parseInt($xml.find('LaneCount').text());
				//fillLaneCountOptions(1, laneMaxCount, laneCount);

				m_iCurSelIONum = -1;
				m_iLastSelIONum = -1;

				if (laneCount == 0) {
					$('#tabvideoEpolice li').hide();
					$('#dvTriggerParam div.triggerpanes').hide();
					return;
				}

				$.g.setField('RelatedLaneCount_videoEp', laneCount);

				$('#tabvideoEpolice li').hide();
				$('#dvTriggerParam div.triggerpanes').show();

				for (var i = 1; i <= laneCount; i++) {
					$('#tabvideoEpolice li#liRelatedLane'+i).show();
				}

				$.ajax({
                    type: "GET",
                    async: false,
                    dataType: 'xml',
                    url:  m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/deviceInfo",
                    beforeSend: function(xhr) {
                        xhr.setRequestHeader("If-Modified-Since", "0");
                        
                    },
                    success: function(xmlDoc, textStatus, xhr) {
                    	that.radarRS485Num = $(xmlDoc).find('maxRS485Num').eq(0).text();

                    	var vrs = $(xmlDoc).find('VEPRadarSupport').eq(0).text();
                    	if (vrs.toLowerCase() == "true") {
                    		VEPRadarSupport = true;
                    	}
                    	
                    }
                });
                var $sel = $('#radarEnabledContent_videoEp').find('#radarRS485_videoEp');
            	$sel.find('option').each(function(i, n){
            		var v = $(this).attr('value');
            		if (parseInt(v) > that.radarRS485Num) {
            			$(this).remove();
            		}
            	});

                if(that.radarRS485Num == 1){
                    $('#radarEnableDiv_videoEp').css('display','none');
                    $('#radarRS485_videoEp').hide();
                    $sel.find('#RadarEnabledOpt0_videoEp').remove();
                }else{                	
                	$('#radarRS485_videoEp').show();
                    $('#radarEnableDiv_videoEp').css('display','block');
                }

				ia(TriggerMode).selectvideoEpolice(0);
				//ia(TriggerMode).showRadarVep(1);
				if (!VEPRadarSupport) {
					$('#radarEnabled_videoEp').prop('checked', false);
                	$('#divRadar_VideoEp, #radarEnabledContent_videoEp').hide();	
				};

				dontSave = false;
				
				//抓拍类型
				var $firstLane = $(xmlDoc).find('Lane').eq(0);
				_.each(['post', 'intersectionStop', 'direction', 'greenLightStop',
					'changeLane', 'banSign', 'reverse', 'driveLine', 'driveLineSensitivity',
					'overSpeed','parkingTime','changeLaneSensitive',
					'nonDriveWayTime', 
					'redLightMode', 'stopLineDistance', 'capPositionOffset',
					'nonDriveWay', 'redLight', 'illegalPriority',
					'illegalUTurn'/*,'driveYellowLine','banLeft','banRight'*/
					], function (v) {
					var val = $firstLane.find(v).eq(0).text();

					var cap = $firstLane.find(v+'CapNo').eq(0);
					if (cap.length) {
						$.g.setField(v+'CapNo', cap.text());
					}
					$.g.setField(v, val, true);
				});

				VideoEpRedispay();

				//信号灯
				var source = $xml.find('source').text();
				$.g.setField('source', source);
				ia(TriggerMode).changeSource($('#source').val());

				var $xmlDoc = $(xmlDoc);
			}
		});		
	}

	TriggerMode.prototype.ValidateLight = function () {
		var res = {result: true, msg: ''};
		var source = $('#source').val();
		if(source == "IO") {

		}else if(source == "RS485"){
			var redArr = [];
			var yelArr = [];
			for (var i = 1; i <= 3; i++) {
				redArr.push($('#relatedLightChan_'+i).val());
				yelArr.push($('#yellowLightChan_'+i).val());
			}

			var arr = _.intersection(redArr, yelArr);
			if (arr.length && !_.every(arr, function(ele){
				return ele == '0';
			})) {
				res.result = false;
				res.msg = '红、黄灯不能关联同一个通道！';
			}
		}

		return res;
	}
	/*************************************************
	Function:		SetvideoEpoliceParam
	Description:	设置视频电警参数
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.SetvideoEpoliceParam = function () {
		var res = this.ValidateLight();
		if (!res.result) {
			szRetInfo = m_szErrorState + res.msg;
            $("#SetResultTips").html(szRetInfo); 
	        setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			return;
		};
		ia(TriggerMode).m_bSetTriggerMode = false;
		
		this.storeVideoPoliceCurTab();
		//this.restoreRadarVep();

		var xmlDoc = ia(TriggerMode).m_VideoEpoliceXml;
		$(xmlDoc).find("changeLaneSensitive").eq(0).text($("#changeLaneSensitive").val());
		$(xmlDoc).find("parkingTime").eq(0).text($("#parkingTime").val());
		$(xmlDoc).find("driveLineSensitivity").eq(0).text($("#driveLineSensitivity").val());
		var $xml = $(xmlDoc);
		var laneCount = $('#RelatedLaneCount_videoEp').val();
		$xml.find('LaneCount').text(laneCount);

		var $firstLane = $xml.find('Lane').eq(0);
		_.each(['post', 'intersectionStop', 'direction', 'greenLightStop',
			'changeLane', 'banSign', 'reverse', 'driveLine',
			'nonDriveWayTime', 'overSpeed', 
			'redLightMode', 'stopLineDistance', 'capPositionOffset',
			'nonDriveWay', 'redLight', 'illegalPriority',
			'illegalUTurn'/*,'driveYellowLine','banLeft','banRight'*/
			], function (v) {
			var nd = $firstLane.find(v).eq(0);
			var capNd = $firstLane.find(v+'CapNo').eq(0);
			if (capNd.length) {
				capNd.text($('#'+v+'CapNo').val());
			}
			var val;
			if ($('#'+v).is(':checkbox')) {
				val = $('#'+v).prop('checked') ? "true" : "false";
			}else{
				val = $('#'+v).val();
			}
			nd.text(val);
		});

		
		//信号灯
		var source = $('#source').val();
		$xml.find('source').text(source);

		var lightTypeIdMap = {
			'left': 1,
			'straight': 2,
			'right': 3
		};

		if(source == "IO") {
			$xml.find('IOLight').each(function (i, n) {
				var $io = $(n);
				var lightId = parseInt($io.find('lightId').text());
				if (lightId <= 3) {
					$io.find('relatedIO').text($('#relatedIO_'+lightId).val());
					$io.find('redLightStatus').text($('#redLightStatus_'+lightId).val());
				}
			});
		} else if(source == "RS485"){
			$xml.find('RS485Light').each(function (i, n) {
				var $io = $(n);
				var lightId = parseInt($io.find('lightId').text());
				if (lightId <= 3) {
					$io.find('relatedLightChan').text($('#relatedLightChan_'+lightId).val());
					$io.find('yellowLightChan').text($('#yellowLightChan_'+lightId).val());
				}
			});
		}
		var copySrc;
		var copyDstArr = [];

		$('#videoEpCopyDiv input[vepLaneIdx]').each(function (i, n) {
			if ($(n).prop('checked')) {
				copyDstArr.push($(n).attr('vepLaneIdx'));
			}
		});

		$(ia(TriggerMode).m_VideoEpoliceXml).find('Lane').each(function (i,n) {
			var $p = $(n);
			var idx = $p.find('laneId').text();
			if (idx == m_iCurSelIONum) {
				copySrc = $p;
			}
		});

		//处理复制操作
		if (copySrc && copyDstArr.length) {
			$(ia(TriggerMode).m_VideoEpoliceXml).find('Lane').each(function (i,n) {
				var $p = $(n);
				var idx = $p.find('laneId').text();
				
				if (_.contains(copyDstArr, idx)) {
					SimpleCopyXmlNode(copySrc[0], $p[0], 
						['laneDirectionType','laneUsage','recordEnable', 'recordType', 'preRecordTime', 'signSpeed', 'highSpeedLimit',
							'recordDelayTime', 'recordTimeOut', 'useageType',
							'directionType', 'stopLineDistance', 'loopSensitivity',
							'capPositionOffset',
						{propName: 'busWayTimeSwitchList', type: 'subNode'},
						{propName: 'banTrucksTimeSwitchList', type: 'subNode'}]);  // 
				}
			});
		}
		
		$.ajax({
			type: "put",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/VideoEpolice",
			timeout: 15000,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			data: xmlToStr(ia(TriggerMode).m_VideoEpoliceXml),
			processData: false,
			complete: function(xhr, textStatus) {
				var xmlDoc =xhr.responseXML;
				if(xhr.status != 200) {
					if(xhr.status == 403) {
						var szErrorInfo = m_szError8;
						szRetInfo = m_szErrorState + szErrorInfo;
					} else {
						if($(xmlDoc).find("detailedStatusCode").eq(0).text() != "") {
							var szErrorInfo = getNodeValue("Error" + $(xmlDoc).find("detailedStatusCode").eq(0).text());
						} else {
							var szErrorInfo = m_szError13;
						}
						szRetInfo = m_szErrorState + szErrorInfo;
					}
		            $("#SetResultTips").html(szRetInfo); 
			        setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			        return;	
				} else {
					if($(xmlDoc).find("statusCode").eq(0).text() == "7") {
						ia(TriggerMode).m_bRebootRequired = true;
					}
					ia(TriggerMode).m_bSetTriggerMode = true;
				    pr(TriggerMode).SetPlateRecognition("videoEpolice");
				}
			}
		});		
	}

	//定位框
	TriggerMode.prototype.posting_videoEpoliceModal=function(){
		$("#dvposting_videoEpolice #postingEnable").prop("checked","true");
		var xmlDoc = ia(TriggerMode).m_VideoEpoliceXml;
		//showArtDialog($("#dvposting_videoEpolice")[0]);
		$.dialog({
			content: $("#dvposting_videoEpolice")[0],
			lock: true,
			ok: function(){
				var xmlDoc = ia(TriggerMode).m_VideoEpoliceXml;
				$(xmlDoc).find('Posting').eq(0).find('postingSize').eq(0).text($("#dvposting_videoEpolice #postingSize").val());
				$(xmlDoc).find('Posting').eq(0).find('postingEnable').eq(0).text($("#dvposting_videoEpolice #postingEnable").prop("checked")?"true":"false");
			},
			okVal:getNodeValue("laOK"),
			cancel:function(){return true;},
			cancelVal:getNodeValue("laCancel")
		});
		$("#dvposting_videoEpolice #postingEnable").prop("checked",$(xmlDoc).find('Posting').eq(0).find('postingEnable').eq(0).text()=="true"?true:false);
		$("#dvposting_videoEpolice #postingSize").val($(xmlDoc).find('Posting').eq(0).find('postingSize').eq(0).text());
		
	}

	//定位框确定按钮
    function posting_videoEpoliceOk(){
		var xmlDoc = ia(TriggerMode).m_VideoEpoliceXml;
		$.each(['postingEnable','postingSize'],function(i,n){
			$(xmlDoc).find('Posting').eq(0).find(n).eq(0).text($("#dvposting_videoEpolice #"+n).val());
		});
	}

	//定位框取消按钮
	TriggerMode.prototype.posting_videoEpoliceCancel=function(){
		this.close();
	}

	TriggerMode.prototype.storeVideoPoliceCurTab = function () {
		$(ia(TriggerMode).m_VideoEpoliceXml).find('Lane').each(function (i,n) {
			var $lane = $(n);

			var $trigDiv = $('#taTriggerMode #videoEpLaneParam');

			if ($lane.find('laneId').text() == m_iCurSelIONum) {
				//$lane.find("yellowLightTime").eq(0).text($("#yellowLightTime").val());
				$lane.find("laneDirectionType").eq(0).text($trigDiv.find("#laneDirectionType_videoEpolice").val());
				$lane.find("relatedDriveWay").eq(0).text($trigDiv.find("#RelatedDriveWay").val());
				$lane.find("useageType").eq(0).text($trigDiv.find("#useageType").val());
				$lane.find('directionType').eq(0).text($trigDiv.find("#directionType").val());
				$lane.find('loopSensitivity').eq(0).text($trigDiv.find("#loopSensitivity").val());	
				
				$lane.find("recordEnable").eq(0).text($trigDiv.find("#recordEnable").prop("checked")?"true":"false");
				$lane.find("recordType").eq(0).text($trigDiv.find("#recordType").val());
				$lane.find("preRecordTime").eq(0).text($trigDiv.find("#preRecordTime").val());
//					$lane.find("recordDelayTime").eq(0).text($trigDiv.find("#recordDelayTime").val());
				$lane.find("recordTimeOut").eq(0).text($trigDiv.find("#recordTimeOut").val());	

				$lane.find("signSpeed").eq(0).text($trigDiv.find("#signSpeed").val());
				$lane.find("highSpeedLimit").eq(0).text($trigDiv.find("#highSpeedLimit").val());

				$lane.find("radarEnabled").eq(0).text($trigDiv.find('#radarEnabled_videoEp').prop('checked')?"true":"false");
				// $.each(['radarType', 'radarSensitivity',
				// 		'radarAngle', 'validRadarSpeedTime', 'radarLinearCorrection',
				// 		'radarConstantCorrection'], function (i, s) {
				// 	$lane.find(s).eq(0).text($('#'+s+'_videoEp').val());
				// });
				//黄车禁行时间段
				$banTrucks = $lane.find('banTrucksTimeSwitchList').eq(0);
				for(var i = 1; i < 5; i++) {
					$banTrucks.find("startHour").eq(i-1).text($trigDiv.find("#banTrucksStartTime" + i).val().split(":")[0]);
					$banTrucks.find("startMinute").eq(i-1).text($trigDiv.find("#banTrucksStartTime" + i).val().split(":")[1]);
					$banTrucks.find("endHour").eq(i-1).text($trigDiv.find("#banTrucksStopTime" + i).val().split(":")[0]);
					$banTrucks.find("endMinute").eq(i-1).text($trigDiv.find("#banTrucksStopTime" + i).val().split(":")[1]);
				}

				if ($trigDiv.find("#useageType").val() == 'bus') {
					$busWay = $lane.find('busWayTimeSwitchList').eq(0);
					for(var i = 1; i < 5; i++) {
						$busWay.find("startHour").eq(i-1).text($trigDiv.find("#busWayStartTime" + i).val().split(":")[0]);
						$busWay.find("startMinute").eq(i-1).text($trigDiv.find("#busWayStartTime" + i).val().split(":")[1]);
						$busWay.find("endHour").eq(i-1).text($trigDiv.find("#busWayStopTime" + i).val().split(":")[0]);
						$busWay.find("endMinute").eq(i-1).text($trigDiv.find("#busWayStopTime" + i).val().split(":")[1]);
					}	
				};
			}
		});

		ia(TriggerMode).restoreRadarVep(m_iCurSelIONum);
	}

	TriggerMode.prototype.showRadarVep = function(laneId){
		var self = this;
		if (self.radarRS485Num == 1) {
			laneId = '1';
		}
		$(ia(TriggerMode).m_VideoEpoliceXml).find('Lane').each(function(i,n) {
			var $lane = $(n);
			if ($lane.find('laneId').text() == laneId) {
				// $.g.setField('radarEnabled_videoEp', $lane.find('radarEnabled').text());
				// self.enabledRadarVideoEp();

				$.each(['radarType', 'radarSensitivity',
						'radarAngle', 'validRadarSpeedTime', 'radarLinearCorrection',
						'radarConstantCorrection', 'radarRS485'], function (i, s) {
					var vlu = $lane.find(s).eq(0).text();
					$.g.setField(s+'_videoEp', vlu);
				});
			};
		});
	}

	TriggerMode.prototype.restoreRadarVep = function(laneId){
		var that=this;
		if (that.radarRS485Num == 1) {
			laneId = '1';
		}
		$(ia(TriggerMode).m_VideoEpoliceXml).find('Lane').each(function (i,n) {
			var $lane = $(n);
			if ($lane.find('laneId').text() == laneId) {
				//$lane.find("radarEnabled").eq(0).text($('#radarEnabled_videoEp').prop('checked')?"true":"false");
				$.each(['radarType', 'radarSensitivity',
						'radarAngle', 'validRadarSpeedTime', 'radarLinearCorrection',
						'radarConstantCorrection', 'radarRS485'], function (i, s) {
					$lane.find(s).eq(0).text($('#'+s+'_videoEp').val());
				});
			}
		});
	}
	/*************************************************
	Function:		selectvideoEpolice
	Description:	选择视频电警车道号
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.selectvideoEpolice = function (iLaneNum) {
		var iLastIndex = parseInt(m_iCurSelIONum) - 1;
		if(iLaneNum == iLastIndex) {
			return;
		}

		var self = this;
		_log("selectvideoEpolice -> "+iLaneNum);

		$("#tabvideoEpolice").find("li").each(function() {
			 if($(this).children().hasClass("current")) {
				 $(this).children().removeClass();
			 }
		});
		$("#tabvideoEpolice").find("li").eq(iLaneNum).find("a").eq(0).addClass("current");

		if (!dontSave) {
			this.storeVideoPoliceCurTab();
		}

		//获取当前Tab值
		m_iCurSelIONum = iLaneNum + 1;
		
		//DisplayRegion();
		m_iLastSelIONum = m_iCurSelIONum;

		var $trigDiv = $('#taTriggerMode #videoEpLaneParam');
		
		$(ia(TriggerMode).m_VideoEpoliceXml).find('Lane').each(function(i,n) {
			var $lane = $(n);
			if ($lane.find('laneId').text() == (iLaneNum+1)) {
				ia(TriggerMode).changeUseageType($lane.find("useageType").eq(0).text(),'#videoEpLaneParam');
				$.g.setField('RelatedDriveWay', $lane.find("relatedDriveWay").text());
				$.g.setField2('#laneDirectionType_videoEpolice', $lane.find("laneDirectionType").text());
				$.each(['useageType', 'directionType', 'loopSensitivity', 
						'signSpeed', 'highSpeedLimit',
						'recordType', 'preRecordTime', 'recordTimeOut'], function (i, s) {
					$.g.setField2('#videoEpLaneParam #'+s, $lane.find(s).eq(0).text());
				});

				$.g.setField2('#videoEpLaneParam #recordEnable', $lane.find("recordEnable").text());
				self.enableRedLightRecord();

				$.g.setField2('#videoEpLaneParam #radarEnabled_videoEp', $lane.find('radarEnabled').text());
				self.enabledRadarVideoEp();
				
				//四个时间段赋值
				var $banTrucks = $lane.find('banTrucksTimeSwitchList');
				for(var j = 1; j < 5; j++) {
				    $("#videoEpLaneParam #banTrucksStartTime" + j).val($banTrucks.find("startHour").eq(j-1).text() + ":" + $banTrucks.find("startMinute").eq(j-1).text());
				    $("#videoEpLaneParam #banTrucksStopTime" + j).val($banTrucks.find("endHour").eq(j-1).text() + ":" + $banTrucks.find("endMinute").eq(j-1).text());
				}

				var $busWay = $lane.find('busWayTimeSwitchList');
				for(var j = 1; j < 5; j++) {
				    $("#videoEpLaneParam #busWayStartTime" + j).val($busWay.find("startHour").eq(j-1).text() + ":" + $busWay.find("startMinute").eq(j-1).text());
				    $("#videoEpLaneParam #busWayStopTime" + j).val($busWay.find("endHour").eq(j-1).text() + ":" + $busWay.find("endMinute").eq(j-1).text());
				}
				
			}
		});

		ia(TriggerMode).showRadarVep(iLaneNum+1);
		
		// if (radarRS485Num == 1 && iLaneNum > 0) {
		// 	//$('#radarEnabledContent_videoEp').hide();
		// }

		VideoEpRedispay();		
		ResetVideoEpCopy();
	}
	/*************************************************
	Function:		changeSource
	Description:	改变信号源接入类型
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.changeSource = function (strSourceType) {
		$('#source_IO_div, #source_RS485_div, #source_videoDetect_div').hide();
		var id = 'source_'+strSourceType+'_div';
		$('#'+id).show();

		if (strSourceType == 'IO') {
			var $xml = $(ia(TriggerMode).m_VideoEpoliceXml);
			$xml.find('IOLight').each(function (i,n) {
				var $io = $(n);	
				var lightId = parseInt($io.find('lightId').text());
				if (lightId <= 3) {
					$.g.setField('relatedIO_'+lightId, $io.find('relatedIO').text());
					$.g.setField('redLightStatus_'+lightId, $io.find('redLightStatus').text());
				}
			});
		}else if (strSourceType == 'RS485') {
			var $xml = $(ia(TriggerMode).m_VideoEpoliceXml);
			$xml.find('RS485Light').each(function (i,n) {
				var $io = $(n);	
				var lightId = parseInt($io.find('lightId').text());
				if (lightId <= 3) {
					$.g.setField('relatedLightChan_'+lightId, $io.find('relatedLightChan').text());
					$.g.setField('yellowLightChan_'+lightId, $io.find('yellowLightChan').text());
				}
			})
		}
		autoResizeIframe();
	}
	/*************************************************
	Function:		setVideoDetect
	Description:	设置视频检测参数
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.setVideoDetect = function () {
		$("#VideoDetectDiv").modal();

		VD.init();

		HWP.Stop();
		$("#main_plugin").hide();
	}
	TriggerMode.prototype.setVideoDetect1 = function () {
		var PlateXmlDoc = null;   //点击进入视频检测区域之前需要保存当前车道的牌识区域
	
		$("#btnSetVideoDetect").show();
	 //    var xmlMainDoc = $.ajax({
		// 				 url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Streaming/channels/101",
		// 				 type: "GET",
		// 				 async: false,
		// 				 beforeSend: function(xhr) {
		// 					 xhr.setRequestHeader("If-Modified-Since", "0");
		// 					 
		// 				 }
		// 			 }).responseXML;
	 //    var xmlFlipDoc = $.ajax({
		// 				 url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "PSIA/Custom/SelfExt/ITCImage/channels/1/Flip",
		// 				 type: "GET",
		// 				 async: false,
		// 				 beforeSend: function(xhr) {
		// 					 xhr.setRequestHeader("If-Modified-Since", "0");
		// 					 
		// 				 }
		// 			 }).responseXML;
		// if($(xmlFlipDoc).find("enabled").eq(0).text() == "true") {
		//     m_iMainWndWidth = parseInt($(xmlMainDoc).find("videoResolutionWidth").eq(0).text(), 10);
		//     m_iMainWndHeight = parseInt($(xmlMainDoc).find("videoResolutionHeight").eq(0).text(), 10);
		// } else {
		// 	m_iMainWndWidth = parseInt($(xmlMainDoc).find("videoResolutionHeight").eq(0).text(), 10);
		//     m_iMainWndHeight = parseInt($(xmlMainDoc).find("videoResolutionWidth").eq(0).text(), 10);
		// }
		
		// $("#videodetectplugin").width(m_iMainWndWidth).height(m_iMainWndHeight);
		$("#VideoDetectDiv").modal();
		HWP.Stop();
		$("#main_plugin").hide();

		var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
		var iRet = $("#VideoDetectActiveX")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
		if (iRet !== 0) {
			alert(getNodeValue("previewfailed"));
		}
		m_szVideoEpoliceXmlDoc = ia(TriggerMode).m_VideoEpoliceXml;
									 
		$("#lightNum").val($(ia(TriggerMode).m_VideoEpoliceXml).find("lightNum").eq(0).text());
		$("#straightLight").prop("checked", $(ia(TriggerMode).m_VideoEpoliceXml).find("straightLight").eq(0).text() == "true"? true:false);
		$("#leftLight").prop("checked", $(ia(TriggerMode).m_VideoEpoliceXml).find("leftLight").eq(0).text() == "true"? true:false);
		$("#rightLight").prop("checked", $(ia(TriggerMode).m_VideoEpoliceXml).find("rightLight").eq(0).text() == "true"? true:false);
		$("#detectredLight").prop("checked", $(ia(TriggerMode).m_VideoEpoliceXml).find("videoDetectLight").eq(0).find("redLight").eq(0).text() == "true"? true:false);
		$("#greenLight").prop("checked", $(ia(TriggerMode).m_VideoEpoliceXml).find("greenLight").eq(0).text() == "true"? true:false);
		$("#yellowLight").prop("checked", $(ia(TriggerMode).m_VideoEpoliceXml).find("yellowLight").eq(0).text() == "true"? true:false);
		//$("#yellowLightTime").val($(ia(TriggerMode).m_VideoEpoliceXml).find("yellowLightTime").eq(0).text());
		
		 
		//显示区域
		var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>1</id><polygonType>0</polygonType><tips>";
		szInfo3 += getNodeValue("laDetectArea") + "1</tips><isClosed>true</isClosed><color><r>255</r><g>0</g><b>0</b></color><pointList>";
		if($(ia(TriggerMode).m_VideoEpoliceXml).find("positionLeft").eq(0).text() != 0 && $(ia(TriggerMode).m_VideoEpoliceXml).find("positionRight").eq(0).text() != 0) {
			var positionLeft = $(ia(TriggerMode).m_VideoEpoliceXml).find("positionLeft").eq(0).text()/m_iMainWndWidth;
			var positionTop = $(ia(TriggerMode).m_VideoEpoliceXml).find("positionTop").eq(0).text()/m_iMainWndHeight;
			var positionRight = $(ia(TriggerMode).m_VideoEpoliceXml).find("positionRight").eq(0).text()/m_iMainWndWidth;
			var positionBottom = $(ia(TriggerMode).m_VideoEpoliceXml).find("positionBottom").eq(0).text()/m_iMainWndHeight;
			szInfo3 += "<point><x>" + positionLeft + "</x><y>" +  positionTop + "</y></point><point><x>" + positionRight + "</x><y>" + positionTop + "</y></point><point><x>" + positionRight + "</x><y>" + positionBottom + "</y></point><point><x>" + positionLeft + "</x><y>" + positionBottom + "</y></point>";
		}
		szInfo3 += "</pointList></SnapPolygon></SnapPolygonList>";
		try {
			$("#VideoDetectActiveX")[0].HWP_ClearSnapInfo(4);
			$("#VideoDetectActiveX")[0].HWP_SetSnapPolygonInfo(szInfo3);
		} catch(e) {
			
		}
	}
	/*************************************************
	Function:		changeSignalIO
	Description:	改变信号灯号
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.changeSignalIO = function (iIONum) {
		//保存当前信号灯号值
		var iIndex = parseInt(ia(TriggerMode).m_iLastSignalNum) - 1;
		if($("#source").val() == "IO") {
			$(ia(TriggerMode).m_VideoEpoliceXml).find('source').eq(0).text("IO");
			$(ia(TriggerMode).m_VideoEpoliceXml).find("IOLightList").eq(0).find('lightType').eq(iIndex).text($("#lightType").val());
			$(ia(TriggerMode).m_VideoEpoliceXml).find("IOLightList").eq(0).find('relatedIO').eq(iIndex).text($("#relatedIO").val());
			$(ia(TriggerMode).m_VideoEpoliceXml).find("IOLightList").eq(0).find('redLightStatus').eq(iIndex).text($("#redLightStatus").val());
		} else if($("#source").val() == "RS485") {
			$(ia(TriggerMode).m_VideoEpoliceXml).find('source').eq(0).text("RS485");
			$(ia(TriggerMode).m_VideoEpoliceXml).find("RS485LightList").eq(0).find('lightType').eq(iIndex).text($("#lightType").val());
			$(ia(TriggerMode).m_VideoEpoliceXml).find("RS485LightList").eq(0).find('relatedLightChan').eq(iIndex).text($("#relatedLightChan").val());
		}
		//获取当前的值
	    ia(TriggerMode).m_iLastSignalNum = iIONum;
		var iCurIndex = parseInt(iIONum) - 1;
		if($("#source").val() == "IO") {
			$("#lightType").val($(ia(TriggerMode).m_VideoEpoliceXml).find("IOLightList").eq(0).find('lightType').eq(iCurIndex).text());
			$("#relatedIO").val($(ia(TriggerMode).m_VideoEpoliceXml).find("IOLightList").eq(0).find('relatedIO').eq(iCurIndex).text());
			$("#redLightStatus").val($(ia(TriggerMode).m_VideoEpoliceXml).find("IOLightList").eq(0).find('redLightStatus').eq(iCurIndex).text());
		} else {
			$("#lightType").val($(ia(TriggerMode).m_VideoEpoliceXml).find("RS485LightList").eq(0).find('lightType').eq(iCurIndex).text());
		    $("#relatedLightChan").val($(ia(TriggerMode).m_VideoEpoliceXml).find("RS485LightList").eq(0).find('relatedLightChan').eq(iCurIndex).text());
		}
	}
	/*************************************************
	Function:		TransLineType
	Description:	转换线类型
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.TransLineType = function (strType) {
		var iType = 0;
		switch(strType){
			case "laneLine":
				iType = 0;
				break;
			case "stopLine":
				iType = 1;
				break;
			case "waitLine":
				iType = 2;
				break;
			case "cancelLine":
				iType = 3;
				break;
			case "laneRightBoundaryLine":
				iType = 4;
				break;
			case "turnLeftLine":
				iType = 5;
				break;
			case "turnRightLine":
				iType = 6;
				break;
			case "redlightLine":
				iType = 7;
				break;

			case "triggerLine":
				iType = 21;
				break;

			case "leftTriggerLine":
				iType = 102;
				break;

			case "rightTriggerLine":
				iType = 102;
				break;			

			default:
			    iType = 8;
			    break;
		}
		return iType;
	}
	/*************************************************
	Function:		changelineType
	Description:	设置线属性
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.changelineType = function (strType) {
		if(ia(TriggerMode).m_strSelLineNum != ""){
			var szSelLineNum = ia(TriggerMode).m_strSelLineNum.split(":");
			if(szSelLineNum[0] == 0) {
				ia(TriggerMode).m_strCommonLineType[szSelLineNum[1]-4] = strType;
			} else {
				ia(TriggerMode).m_strLineType[szSelLineNum[0]-1][szSelLineNum[1]] = strType;
			}
		}
	}
	//获取信号灯状态
	TriggerMode.prototype.getLightStatus = function() {
		$.ajax({
			type:"GET",
			url:m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/LightStatus",
			beforeSend:function (xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			async:false,
			success:function (xmlDoc, textStatus, xhr) {
				$("#laLightStatus").html(getNodeValue($(xmlDoc).find("lightStatus").eq(0).text()));
			}
		});
    }
	/*************************************************
	Function:		GetCommendParam
	Description:	获取推荐值
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.GetCommendParam = function () {
		var strTriggerMode = $("#selTriggerMode").val();
		var realTriggerMode = strTriggerMode;

		switch(strTriggerMode) {
			case "postSingleIO":
			    pr(TriggerMode).selectPostSingleIO(0);
				pr(TriggerMode).GetPostSingleIOParam(1);
			    break;
			case "postIOSpeed":
			    pr(TriggerMode).selectPostIOSpeed(0);
			    pr(TriggerMode).GetpostIOSpeedParam(1);
			    break;
			case "postRS485":
			case "postRadar":
				var bakMode = ia(TriggerMode).m_CurBackUpMode;

                if($('#backupModeOpts').val() == 1 && bakMode == 1){ //虚拟线圈
                    pr(TriggerMode).selectVTCoilIO(0);
                    pr(TriggerMode).GetVTCoilParam(1);

                    realTriggerMode = "postVTCoil";
                }else if($('#backupModeOpts').val() == 2 && bakMode==2){ //混合车道

                	//realTriggerMode = "postVTCoil";
                }else{
                    pr(TriggerMode).selectRelatedLane(0);
                    pr(TriggerMode).Getpost485Param(strTriggerMode, 1);
                }
				break;
			case "epoliceIOTL":
				pr(TriggerMode).selectepoliceIOTL(0);
			    pr(TriggerMode).GetepoliceIOTLParam(1);
				break;
			case "epoliceRS485":
			case "postEpoliceRS485":
				pr(TriggerMode).selectEpoliceLane(0);
			    pr(TriggerMode).GetepoliceRS485Param(strTriggerMode, 1);
				break;
			case "postVTCoil":
				pr(TriggerMode).selectVTCoilIO(0);
			    pr(TriggerMode).GetVTCoilParam(1);
				break;
			case "PostMpr":
			    pr(TriggerMode).selectLaneCount(0);
				pr(TriggerMode).GetPostMprParam(strTriggerMode, 1);
				break;

			case "videoMonitor":
				pr(TriggerMode).GetVideoMonitorParam(strTriggerMode, 1);
				break;
			case "postHVT":
				pr(TriggerMode).GetPostHVTParam(1);
				break;
			default:
			    break;
		}
		pr(TriggerMode).GetPlateRecognition(realTriggerMode, 1);
		//DisplayRegion();//勾选显示区域时需显示其他车道区域

	}
	/*************************************************
	Function:		changeDetectNum
	Description:	切换视频检测区域
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TriggerMode.prototype.changeDetectNum = function () {
		//保存之前的检测区域值
		$(ia(TriggerMode).m_VideoEpoliceXml).find("lightNum").eq(m_iLastSelDetectIONum-1).text($("#lightNum").val());
		$(ia(TriggerMode).m_VideoEpoliceXml).find("straightLight").eq(m_iLastSelDetectIONum-1).text($("#straightLight").prop("checked").toString());
		$(ia(TriggerMode).m_VideoEpoliceXml).find("leftLight").eq(m_iLastSelDetectIONum-1).text($("#leftLight").prop("checked").toString());
		$(ia(TriggerMode).m_VideoEpoliceXml).find("rightLight").eq(m_iLastSelDetectIONum-1).text($("#rightLight").prop("checked").toString());
		$(ia(TriggerMode).m_VideoEpoliceXml).find("videoDetectLight").eq(m_iLastSelDetectIONum-1).find("redLight").eq(0).text($("#detectredLight").prop("checked").toString());
		$(ia(TriggerMode).m_VideoEpoliceXml).find("greenLight").eq(m_iLastSelDetectIONum-1).text($("#greenLight").prop("checked").toString());
		$(ia(TriggerMode).m_VideoEpoliceXml).find("yellowLight").eq(m_iLastSelDetectIONum-1).text($("#yellowLight").prop("checked").toString());
		$(ia(TriggerMode).m_VideoEpoliceXml).find("yellowLightTime").eq(m_iLastSelDetectIONum-1).text($("#yellowLightTime").val());
		
		var szInfo = $("#VideoDetectActiveX")[0].HWP_GetSnapPolygonInfo();
		var szTempXmlDoc = $(parseXmlFromStr(szInfo));
		var positionLeft = parseInt(szTempXmlDoc.find("x").eq(0).text()*m_iMainWndWidth);
	    var positionTop = parseInt(szTempXmlDoc.find("y").eq(0).text()*m_iMainWndHeight);
	    var positionRight = parseInt(szTempXmlDoc.find("x").eq(2).text()*m_iMainWndWidth);
	    var positionBottom = parseInt(szTempXmlDoc.find("y").eq(2).text()*m_iMainWndHeight);
		
		$(ia(TriggerMode).m_VideoEpoliceXml).find("positionLeft").eq(m_iLastSelDetectIONum-1).text(positionLeft);
		$(ia(TriggerMode).m_VideoEpoliceXml).find("positionTop").eq(m_iLastSelDetectIONum-1).text(positionTop);
		$(ia(TriggerMode).m_VideoEpoliceXml).find("positionRight").eq(m_iLastSelDetectIONum-1).text(positionRight);
		$(ia(TriggerMode).m_VideoEpoliceXml).find("positionBottom").eq(m_iLastSelDetectIONum-1).text(positionBottom);
		
		//获取当前检测区域值
		m_iCurSelDetectIONum = $("#DetectAreaNum").val();
		m_iLastSelDetectIONum = m_iCurSelDetectIONum;
		$("#lightNum").val($(ia(TriggerMode).m_VideoEpoliceXml).find("lightNum").eq(m_iCurSelDetectIONum-1).text());
		$("#straightLight").prop("checked", $(ia(TriggerMode).m_VideoEpoliceXml).find("straightLight").eq(m_iCurSelDetectIONum-1).text() == "true"? true:false);
		$("#leftLight").prop("checked", $(ia(TriggerMode).m_VideoEpoliceXml).find("leftLight").eq(m_iCurSelDetectIONum-1).text() == "true"? true:false);
		$("#rightLight").prop("checked", $(ia(TriggerMode).m_VideoEpoliceXml).find("rightLight").eq(m_iCurSelDetectIONum-1).text() == "true"? true:false);
		$("#detectredLight").prop("checked", $(ia(TriggerMode).m_VideoEpoliceXml).find("videoDetectLight").eq(m_iCurSelDetectIONum-1).find("redLight").eq(0).text() == "true"? true:false);
		$("#greenLight").prop("checked", $(ia(TriggerMode).m_VideoEpoliceXml).find("greenLight").eq(m_iCurSelDetectIONum-1).text() == "true"? true:false);
		$("#yellowLight").prop("checked", $(ia(TriggerMode).m_VideoEpoliceXml).find("yellowLight").eq(m_iCurSelDetectIONum-1).text() == "true"? true:false);
		$("#yellowLightTime").val($(ia(TriggerMode).m_VideoEpoliceXml).find("yellowLightTime").eq(m_iCurSelDetectIONum-1).text());
	    //显示区域
		var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>" + m_iCurSelDetectIONum + "</id><polygonType>0</polygonType><tips>";
		szInfo3 += getNodeValue("laDetectArea") + m_iCurSelDetectIONum + "</tips><isClosed>true</isClosed><color><r>255</r><g>0</g><b>0</b></color><pointList>";
		if($(ia(TriggerMode).m_VideoEpoliceXml).find("positionLeft").eq(m_iCurSelDetectIONum-1).text() != 0 && $(ia(TriggerMode).m_VideoEpoliceXml).find("positionRight").eq(m_iCurSelDetectIONum-1).text() != 0) {
			var positionLeft = $(ia(TriggerMode).m_VideoEpoliceXml).find("positionLeft").eq(m_iCurSelDetectIONum-1).text()/m_iMainWndWidth;
			var positionTop = $(ia(TriggerMode).m_VideoEpoliceXml).find("positionTop").eq(m_iCurSelDetectIONum-1).text()/m_iMainWndHeight;
			var positionRight = $(ia(TriggerMode).m_VideoEpoliceXml).find("positionRight").eq(m_iCurSelDetectIONum-1).text()/m_iMainWndWidth;
			var positionBottom = $(ia(TriggerMode).m_VideoEpoliceXml).find("positionBottom").eq(m_iCurSelDetectIONum-1).text()/m_iMainWndHeight;
			szInfo3 += "<point><x>" + positionLeft + "</x><y>" +  positionTop + "</y></point><point><x>" + positionRight + "</x><y>" + positionTop + "</y></point><point><x>" + positionRight + "</x><y>" + positionBottom + "</y></point><point><x>" + positionLeft + "</x><y>" + positionBottom + "</y></point>";
		}
		szInfo3 += "</pointList></SnapPolygon></SnapPolygonList>";
		try {
		    $("#VideoDetectActiveX")[0].HWP_ClearSnapInfo(4);
		    $("#VideoDetectActiveX")[0].HWP_SetSnapPolygonInfo(szInfo3);
		} catch(e) {
			
		}
	}
})();

function changeHVTIntervalType (strType, isVtcoil) {
	if(strType == "time") {
		$("#postHVT_g_params_div #IntervalUnit").html("ms");
		$("#postHVT_g_params_div .IntervalUnit").html("ms");
		$("#postHVT_g_params_div #IntervalUnit1").html("ms");
		$("#postHVT_g_params_div #DelayIntervalUnit").html("ms");
		$(".width34").unbind("blur").blur(function () {
			if(this.value != "" && !isVtcoil) {
			    CheackTriggerIntNum(this, this.value,'laInterval',0,10000,'ms');
			}
		});
		$(".width75").unbind("blur").blur(function () {
			if(this.value != "" && !isVtcoil) {
			    CheackTriggerIntNum(this, this.value,'laInterval',0,10000,'ms');
			}
		});
	} else {
		$("#postHVT_g_params_div #IntervalUnit").html("dm");
		$("#postHVT_g_params_div .IntervalUnit").html("dm");
		$("#postHVT_g_params_div #IntervalUnit1").html("dm");
		$("#postHVT_g_params_div .width34").unbind("blur").blur(function () {
			if(this.value != "" && !isVtcoil) {
			    CheackTriggerIntNum(this, this.value,'laInterval',0,50,'dm');
			}
		});
		$("#postHVT_g_params_div .width75").unbind("blur").blur(function () {
			if(this.value != "" && !isVtcoil) {
			    CheackTriggerIntNum(this, this.value,'laInterval',0,50,'dm');
			}
		});
		$("#postHVT_g_params_div #DelayIntervalUnit").html("dm");
	}
}	
/*************************************************
Function:		changeIntervalType
Description:	改变连拍间隔类型
Input:			无			
Output:			无
return:			无				
*************************************************/
function changeIntervalType(strType, isVtcoil) {
	if(strType == "time") {
		$("#IntervalUnit").html("ms");
		$(".IntervalUnit").html("ms");
		$("#IntervalUnit1").html("ms");
		$("#DelayIntervalUnit").html("ms");
		$(".width34").unbind("blur").blur(function () {
			if(this.value != "" && !isVtcoil) {
			    CheackTriggerIntNum(this, this.value,'laInterval',0,10000,'ms');
			}
		});
		$(".width75").unbind("blur").blur(function () {
			if(this.value != "" && !isVtcoil) {
			    CheackTriggerIntNum(this, this.value,'laInterval',0,10000,'ms');
			}
		});
	} else {
		$("#IntervalUnit").html("dm");
		$(".IntervalUnit").html("dm");
		$("#IntervalUnit1").html("dm");
		$(".width34").unbind("blur").blur(function () {
			if(this.value != "" && !isVtcoil) {
			    CheackTriggerIntNum(this, this.value,'laInterval',0,50,'dm');
			}
		});
		$(".width75").unbind("blur").blur(function () {
			if(this.value != "" && !isVtcoil) {
			    CheackTriggerIntNum(this, this.value,'laInterval',0,50,'dm');
			}
		});
		$("#DelayIntervalUnit").html("dm");
	}
}
/*************************************************
Function:		StartDrawPolygon
Description:	绘制区域
Input:			无			
Output:			无
return:			无				
*************************************************/
function StartDrawPolygon() {
	$("#IsDispalyRegion").prop("checked", false);
	DisplayRegion();
	var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>" + m_iCurSelIONum + "</id><polygonType>1</polygonType><tips>" + getNodeValue("PlateRegion") + m_iCurSelIONum + "</tips><isClosed>false</isClosed><color><r>255</r><g>255</g><b>0</b></color><pointList></pointList></SnapPolygon></SnapPolygonList>";
	try{
		var iRet = HWP.SetSnapPolygonInfo(szInfo3);
	}
	catch(e){
	}
	try{
		//HWP.ClearSnapInfo();
		var iRet = HWP.SetSnapDrawMode(2);
		if(iRet != 0) {
			alert(iRet);
		}
	}
	catch(e)
	{}
}

/**
 * 打开单IO卡口弹出层
 */
function ShowDrawSingleIoPolygonModal() {
	if (!g_bIsIE) {
        $("#postSingleIo_Draw_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='SingleIoDrawPlugin' width='100%' height='100%' name='SingleIoDrawPlugin' align='center' wndtype='1' playmode='snapdraw'>");
    } else {
        $("#postSingleIo_Draw_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='SingleIoDrawPlugin' width='100%' height='100%' name='SingleIoDrawPlugin' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
    }

        //根据启用的IO生成对应的按钮
        var rpr = getNodeValue('aRedrawPlateRegion');
        var tarr = [];
        tarr.push('<br/><br/>');
        var idxArr = [];
        $('#singleIoCheckBoxesDiv').find('input.singleIo_checkbox').filter(':checked').each(function () {
        	var ioIdx_t = $(this).attr('ioIdx');
        	idxArr.push(parseInt(ioIdx_t));
        	var arr = [
        		'<input type="button" class="showCountDetailBtn" ',
        		' id="singleIoDraw'+ioIdx_t+'" onclick="reDrawSingleIORegion('+ioIdx_t+')" value="'+rpr+'(IO'+ioIdx_t+')"/><br/><br/>'
        	];
        	tarr.push(arr.join(''));        	
        });
        $('#singleIOControlModal div.showmodalcontent').html(tarr.join(''));

        $('#postSingleIOModalDiv').modal();

        setTimeout(function () {
        	DisplayPlateRegionEx(idxArr, '#SingleIoDrawPlugin');
	        var ocx = $('#SingleIoDrawPlugin')[0];		
			try{
				ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
			}catch(e){}
        }, 500);

        HWP.Stop();
        $("#main_plugin").hide();

        var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
        var iRet = $("#SingleIoDrawPlugin")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
        if (iRet !== 0) {
            alert(getNodeValue("previewfailed"));
        }
}
function ShowDrawVideoEpModal () {
	ia(TriggerMode).storeVideoPoliceCurTab();

	if (!g_bIsIE) {
        $("#videoEp_Draw_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='VideoEpDrawPlugin' width='100%' height='100%' name='VideoEpDrawPlugin' align='center' wndtype='1' playmode='snapdraw'>");
    } else {
        $("#videoEp_Draw_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='VideoEpDrawPlugin' width='100%' height='100%' name='VideoEpDrawPlugin' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
    }
    //根据启用的车道数控制界面显示
    
    var laneCount = parseInt($('#RelatedLaneCount_videoEp').val());
    for (var i = 1; i <= 6; i++) {
    	if (i <= laneCount) {
    		$('#videoEpLaneDraw'+i).show();
    		$('#videoEp_laneLine_wrapper_'+i).show();
    	}else{
    		$('#videoEpLaneDraw'+i).hide();
    		$('#videoEp_laneLine_wrapper_'+i).hide();
    	}
    }

    var waitLineWrapper = $('#videoEp_waitLine_wrapper');
    waitLineWrapper.find(':checkbox').prop('checked', false);
    waitLineWrapper.find('span[id^=DrawWaitLaneBtnWrapper]').addClass('displaynone');

    var isWaitLane = false;
    $(ia(TriggerMode).m_VideoEpoliceXml).find("Lane").each(function (i,n) {
    	var lineT = $(n).find('directionType').text();
    	var id = $(n).find('laneId').text();

		if (lineT == 'straightWait' || lineT == 'leftWait') {
			isWaitLane = true;
			waitLineWrapper.find('#DrawWaitLaneBtnWrapper'+id).removeClass('displaynone');
			
			var $n = $(n);
			$n.find('ViolationDetectLine').each(function (i, line) {
				var $line = $(line);
				var lineName = $line.find('lineName').eq(0).text();
				if (lineName == 'waitLine') {
					var startX = parseFloat($line.find('positionX').eq(0).text(), 10);
					var startY = parseFloat($line.find('positionY').eq(0).text(), 10);
					var endX = parseFloat($line.find('positionX').eq(1).text(), 10);
					var endY = parseFloat($line.find('positionY').eq(1).text(), 10);
					
					if (_.every([startX, startY, endX, endY], function (ele) {
							return ele == 0;
						})) {   // 全为0，这里不勾选
						waitLineWrapper.find('#videoEp_waitLine'+id).prop('checked', false);
					}else{ // 勾选
						waitLineWrapper.find('#videoEp_waitLine'+id).prop('checked', true);
					}
				};
			});
		}
    });

    if (!isWaitLane) {
    	$('#videoEp_waitLine_wrapper').hide();
    }else{
    	$('#videoEp_waitLine_wrapper').show();
    }

    $('#videoEpModalDiv').modal();

    var isByLane = $('#redLightMode').val() == '1';
    if (isByLane) {
    	$('#videoEp_redLightLine_wrapper').show();
    }else{
    	$('#videoEp_redLightLine_wrapper').hide();
    }

    $('#videoEpModalWrapper input[type=checkbox]').not(":hidden").not("*[id^=videoEp_waitLine]").prop('checked', true);
    $('#videoEpModalWrapper input[type=checkbox]').filter(":hidden").prop('checked', false);

    $('#videoEpModalWrapper input[type=checkbox]').unbind().click(function () {
    	RestoreVideoEpLinesToTmpObj();
    	DrawVideoEpLinesInModal();
    });

    InitVideoEpTmpSnapLines();
    InitPlateRegionTempEle();

    var $tmpObj = $(videoEpTmpObj);
    $tmpObj.find('Lane').each(function (i, n) {
    	var $lane = $(n);
    	var laneId = parseInt($lane.find('laneId').text());
    	if (laneId <= laneCount) {
    		$lane.find('ViolationDetectLine').each(function (idx, vline) {
    			if($(vline).find('lineName').text() == 'laneLine'){
    				$.g.setField('laneLineType'+laneId, $(vline).find('lineType').text());
    				return;
    			}
    		});
    	}
    });
    $tmpObj.find('VirtualLane').each(function (i, vline) {
    	if($(vline).find('lineName').text() == 'laneRightBoundaryLine'){
			$.g.setField('laneRightBoundaryLineType', $(vline).find('lineType').text());
			return;
		}
    });

    for (var i = 1; i <= laneCount; i++) {
    	
    };
    
    DisplayVideoEpRegion({}, '#VideoEpDrawPlugin', true, true);
    
    HWP.Stop();
    $("#main_plugin").hide();

    var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
    var iRet = $("#VideoEpDrawPlugin")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
    if (iRet !== 0) {
        alert(getNodeValue("previewfailed"));
    }
}

function RestoreVideoEpLinesToTmpObj () {
	var ocx = $('#VideoEpDrawPlugin')[0];
	var lineObj = x2js.xml_str2json(ocx.HWP_GetSnapLineInfo());

	function getLineById (lineId) {
		if (!lineObj 
				|| !lineObj.SnapLineList 
				|| !lineObj.SnapLineList.SnapLine) {
			return false;
		}
		var obj = false;

		$.each(lineObj.SnapLineList.SnapLine, function (i, n) {
			if (n.id == lineId) {
				obj = n;
				return;
			}
		});

		return obj;
	}
	
	var xmlEle = videoEpTmpObj;

	$(xmlEle).find("Lane").each(function (i, lane) {
		var $lane = $(lane);
		var laneId = parseInt($lane.find('laneId').eq(0).text());

		var waitLineChecked = false;
		var chkEle = $('#videoEp_waitLine_wrapper #videoEp_waitLine'+laneId);
		if (chkEle.is(":visible") && chkEle.prop('checked')) {
			waitLineChecked = true;
		};

		$lane.find('ViolationDetectLine').each(function (idx, line) {
			var $line = $(line);

			var lineName = $line.find("lineName").eq(0).text();

			if (lineName == 'waitLine' && !waitLineChecked) {
				$line.find('positionX').eq(0).text(0);
				$line.find('positionY').eq(0).text(0);
				$line.find('positionX').eq(1).text(0);
				$line.find('positionY').eq(1).text(0);
				return true;
			}

			var LineType = ia(TriggerMode).TransLineType(lineName);
			var id = laneId*100+LineType;
			var realLine = getLineById(id);

			if (realLine) {		
				var sx = Math.round(realLine.StartPos.x*1000);
				var sy = Math.round(realLine.StartPos.y*1000);
				var ex = Math.round(realLine.EndPos.x*1000);
				var ey = Math.round(realLine.EndPos.y*1000);

				$line.find('positionX').eq(0).text(sx);
				$line.find('positionY').eq(0).text(sy);
				$line.find('positionX').eq(1).text(ex);
				$line.find('positionY').eq(1).text(ey);
			}

			if (lineName == 'laneLine') {
				$line.find('lineType').text($('#laneLineType'+laneId).val());
			};
		})
	});
	
	//不是按车道显示的线
	$(xmlEle).find("VirtualLane").each(function(i, vl){
		var $vl = $(vl);
		var lineName = $vl.find("lineName").eq(0).text();
		var LineType = ia(TriggerMode).TransLineType(lineName);
		var id = 10*100+LineType;
		var realLine = getLineById(id);

		if (realLine) {
			var sx = Math.round(realLine.StartPos.x*1000);
			var sy = Math.round(realLine.StartPos.y*1000);
			var ex = Math.round(realLine.EndPos.x*1000);
			var ey = Math.round(realLine.EndPos.y*1000);

			$vl.find('positionX').eq(0).text(sx);
			$vl.find('positionY').eq(0).text(sy);
			$vl.find('positionX').eq(1).text(ex);
			$vl.find('positionY').eq(1).text(ey);
		}

		if (lineName == 'laneRightBoundaryLine') {
			$vl.find('lineType').text($('#laneRightBoundaryLineType').val());
		};
	});

}


function DrawVideoEpLinesInModal () {
	var laneLineArray = [];

	$('input[id^=videoEp_laneLine]').not(":hidden").each(function (i, n) {
		if ($(this).prop('checked')) {
			var id = $(this).attr('id').replace('videoEp_laneLine', '');
			id = parseInt(id);
			laneLineArray.push(id);
		}
	});

	var waitLineMap = {};
	for (var i = 1; i <= 6; i++) {
		var chk = $('#videoEp_waitLine_wrapper #videoEp_waitLine'+i);
		if (!chk.is(":hidden")) {
			waitLineMap[i] = chk.prop('checked');
		};
	};

	var opt = {
		laneLine: laneLineArray, 
		laneRightBoundaryLine: $('#videoEp_laneRightBoundaryLine').prop('checked'), 

		stopLine: $('#videoEp_stopLine').prop('checked'), 
		redlightLine: $('#videoEp_redlightLine').prop('checked'),
		cancelLine: $('#videoEp_cancelLine').prop('checked'), 
		waitLine: waitLineMap,
 		
 		turnLeftLine: $('#videoEp_turnLeftLine').prop('checked'), 
 		turnRightLine: $('#videoEp_turnRightLine').prop('checked'),

 		plateRegion: false
 	};

	DisplayVideoEpRegion(opt, '#VideoEpDrawPlugin', true, true);
}

function cancelVideoEpModel () {
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }
    $.modal.impl.close();

    VideoEpRedispay();
}

function okVideoEpModel () {
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    RestoreVideoEpLinesToTmpObj();
    ia(TriggerMode).m_VideoEpoliceXml = x2js.parseXmlString(xmlToStr(videoEpTmpObj));
    RestorePlateRegion('#VideoEpDrawPlugin');
    
    $.modal.impl.close();
    VideoEpRedispay()
}

function SingleIoReDisplay() {
	if ($('#drawPicCheck').prop('checked')) {
		var idxArr = [];
		$('#singleIoCheckBoxesDiv input.singleIo_checkbox').each(function () {
			if ($(this).is(":checked")) {
				var ioIdx_t = $(this).attr('ioIdx');
				idxArr.push(parseInt(ioIdx_t));
			}
		});
		if (idxArr.length) {
			DisplayPlateRegionEx(idxArr);	
		}else{
			HWP.ClearSnapInfo(4);
		}
	}else{
		var idx = -1;
		if ($('#tabTriggerIO li').find('a:not(:hidden)').filter('.current').length == 0) {
			idx = $('#tabTriggerIO li').first().attr('ioIdx');
		}else{
			idx = $('#tabTriggerIO li').find('a:not(:hidden)').filter('.current').first().parent().attr('ioIdx');
		}
		idx = parseInt(idx);
		if (idx >= 0) {
			DisplayPlateRegionEx([idx]);	
		}
	}
}

function PostSpeedReDisplay () {
	if ($('#drawPicCheck').prop('checked')) {
		DisplayPlateRegionEx([1,2]);
	}else{
		DisplayPlateRegionEx([m_iCurSelIONum]);	
	}
}

function PostRadarReDisplay () {
	if ($('#drawPicCheck').prop('checked')) {
		var laneCount = $('#RelatedLaneCount_videoEp').val();
		laneCount = parseInt(laneCount);

		var arr = [];
		for (var i = 1; i <= laneCount; i++) {
			arr.push(i);
		};
	
		DisplayPlateRegionEx(arr);
	}else{
		DisplayPlateRegionEx([m_iCurSelIONum]);	
	}

}

function PostVTCoilReDisplay () {
	if ($('#drawPicCheck').prop('checked')) {
		var laneCount = $('#RelatedLaneCount_videoEp').val();
		var arr = [];
		for (var i = 1; i <= laneCount; i++) {
			arr.push(i);
		}
		DisplayPlateRegionEx(arr, null, null);
    	DisplayVTCoilRegion(arr, null, {r:255,g:0,b:0});
	}else{
		DisplayPlateRegionEx([m_iCurSelIONum], null, null);
    	DisplayVTCoilRegion([m_iCurSelIONum], null, {r:255,g:0,b:0});
	}
	HWP.SetSnapDrawMode(-1);
}


function PostHVTReDisplay () {
	HWP.ClearSnapInfo(4);
	if ($('#drawPicCheck').prop('checked')) {
		var laneCount = $('#RelatedLaneCount_videoEp').val();
		var arr = [];
		for (var i = 1; i <= laneCount; i++) {
			arr.push(i);
		}
		DisplayPlateRegionEx(arr, null, null);
    	DisplayPostHVTRegion(arr, null, {r:255,g:0,b:0});
	}else{
		DisplayPlateRegionEx([m_iCurSelIONum], null, null);
    	DisplayPostHVTRegion([m_iCurSelIONum], null, {r:255,g:0,b:0});
	}
	HWP.SetSnapDrawMode(-1);
}

function PostMprReDisplay () {
	if ($('#drawPicCheck').prop('checked')) {
		var laneCount = $('#RelatedLaneCount_videoEp').val();
		var arr = [];
		for (var i = 1; i <= laneCount; i++) {
			arr.push(i);
		}
		DisplayPlateRegionEx(arr, null, null);
		DisplayPostMprRegion(arr, null, {r:255,g:0,b:0});
	}else{
		DisplayPlateRegionEx([m_iCurSelIONum], null, null);
		DisplayPostMprRegion([m_iCurSelIONum], null, {r:255,g:0,b:0});
	}
	HWP.SetSnapDrawMode(-1);
}

function VideoMonitorReDisplay () {
	var laneCount = $('#RelatedLaneCount_VideoMonitor').val();
	DisplayVideoMonitorRegion(laneCount, null, {r:255,g:0,b:0});
	HWP.SetSnapDrawMode(-1);
}

function EpoliceRS485ReDisplay () {
	if ($('#drawPicCheck').prop('checked')) {
		var laneCount = $('#RelatedLaneCount_videoEp').val();
		laneCount = parseInt(laneCount);

		var arr = [];
		for (var i = 1; i <= laneCount; i++) {
			arr.push(i);
		};
	
		DisplayPlateRegionEx(arr);
	}else{
		DisplayPlateRegionEx([m_iCurSelIONum]);	
	}
}

function PostEpoliceRS485ReDisplay () {
	if ($('#drawPicCheck').prop('checked')) {
		var laneCount = $('#RelatedLaneCount_videoEp').val();
		laneCount = parseInt(laneCount);

		var arr = [];
		for (var i = 1; i <= laneCount; i++) {
			arr.push(i);
		};
	
		DisplayPlateRegionEx(arr);
	}else{
		DisplayPlateRegionEx([m_iCurSelIONum]);	
	}
}

function genDefautRedLightLineForBase() {
	var xmlEle = ia(TriggerMode).m_VideoEpoliceXml;

	var laneCount = $('#RelatedLaneCount_videoEp').val();
	laneCount = parseInt(laneCount, 10);

	$(xmlEle).find("Lane").each(function (i, lane) {
		var $lane = $(lane);
		var laneId = parseInt($lane.find('laneId').eq(0).text());

		$lane.find('ViolationDetectLine').each(function (idx, line) {
			var $line = $(line);
			var lineName = $line.find("lineName").eq(0).text();

			if (lineName == 'redlightLine') {
				var oriStartX = parseFloat($line.find('positionX').eq(0).text(), 10)
				var oriStartY = parseFloat($line.find('positionY').eq(0).text(), 10)
				var oriEndX = parseFloat($line.find('positionX').eq(1).text(), 10)
				var oriEndY = parseFloat($line.find('positionY').eq(1).text(), 10)

				if (_.every([oriStartX, oriStartY, oriEndX, oriEndY], function (ele) {
							return ele == 0;
						})) {

					var def = genDefautRedLightLine(laneCount, parseInt(laneId,10));

					var startX = Math.round(def.startX * 1000);
					var startY = Math.round(def.startY * 1000);
					var endX = Math.round(def.endX * 1000);
					var endY = Math.round(def.endY * 1000);

					$line.find('positionX').eq(0).text(startX);
					$line.find('positionY').eq(0).text(startY);
					$line.find('positionX').eq(1).text(endX);
					$line.find('positionY').eq(1).text(endY);
				}
			};
		});
	});
}

function changeRedLightMode () {
	var v = $('#redLightMode').val();
	if (v == '1') {  // 这里检查闯红灯触发线是否存在，不存在则创建
		genDefautRedLightLineForBase();
	};
	VideoEpRedispay();
}

function VideoEpRedispay () {
	if ($('#drawPicCheck').prop('checked')) {
		DisplayVideoEpRegion();
	}else{
		DisplayVideoEpRegion({
			laneArray: [m_iCurSelIONum]
		});
	}
}

function PostRS485ReDisplay () {
	if ($('#drawPicCheck').prop('checked')) {
		var laneCount = $('#RelatedLaneCount_videoEp').val();
		laneCount = parseInt(laneCount);

		var arr = [];
		for (var i = 1; i <= laneCount; i++) {
			arr.push(i);
		};
	
		DisplayPlateRegionEx(arr);
	}else{
		DisplayPlateRegionEx([m_iCurSelIONum]);	
	}
}

function RestoreVideoMonitor (ocxSel) {
	var ocx = $(ocxSel)[0];
	if (!ocx) {
		return;
	};

	var vmJson = x2js.xml_str2json(xmlToStr(ia(TriggerMode).m_videoMonitorXml));

	var lines = [];
	var rightLines = [];

	var $xmlDoc = $(ia(TriggerMode).m_videoMonitorXml);

	var lineXml = ocx.HWP_GetSnapLineInfo();
	$(parseXmlFromStr(lineXml)).find('SnapLine').each(function () {
		var lineId = $(this).find('id').eq(0).text();

		var $st = $(this).find("StartPos");
		var $et = $(this).find("EndPos");

		var sx = parseFloat($st.find('x').text());
		var sy = parseFloat($st.find('y').text());
		var ex = parseFloat($et.find('x').text());
		var ey = parseFloat($et.find('y').text());

		lineId = parseInt(lineId,10);

		sx = Math.floor(sx*1000);
		sy = Math.floor(sy*1000);
		ex = Math.floor(ex*1000);
		ey = Math.floor(ey*1000);

		var $line;
		if (lineId > 400) {
			$line = $xmlDoc.find('VirtualLane').eq(0);
		}else{
			var lineNum = lineId % 100 -1;
			$line = $xmlDoc.find('ViolationDetectLine').eq(lineNum);
		}

		$line.find('positionX').eq(0).text(sx);
		$line.find('positionX').eq(1).text(ex);
		$line.find('positionY').eq(0).text(sy);
		$line.find('positionY').eq(1).text(ey);
	});

	// vmJson.VideoMonitor.VirtualLaneList = {
	// 	ViolationDetectLine: lines,
	// 	VirtualLane: rightLines
	// };

	// ia(TriggerMode).m_videoMonitorXml = x2js.json2xml(vmJson);
}

function RestorePlateRegion(ocxSel, useTmpXmlEle) {
	var domEle;
	var useTmp = false;
	if (useTmpXmlEle && plateRegionEleTemp) {
		domEle = plateRegionEleTemp;
		useTmp = true;
	}else{
		domEle = ia(TriggerMode).m_PlateRecognitionXml;	
	}

	var ocx = $(ocxSel)[0];
	try{
    	var xml = ocx.HWP_GetSnapPolygonInfo();

    	var regionJson = x2js.xml_str2json(xmlToStr(domEle));

    	var pregions = regionJson.PlateRecognition.PlateRegionList.PlateRegion_asArray;
    	$(parseXmlFromStr(xml)).find('SnapPolygon').each(function (i, p) {
    		var regionId = $(p).find('id').text();
    		for (var i = 0; i < pregions.length; i++) {
    			var r = pregions[i];
    			if (r.regionId == regionId) {
    				var sarr = [];
    				$(p).find('point').each(function (i,n) {
    					var x = Math.floor(parseFloat($(n).find('x').text())*1000);
    					var y = Math.floor(parseFloat($(n).find('y').text())*1000);
    					sarr.push({
    						positionX: x,
    						positionY: y
    					});
    				});

    				r.RegionCoordinatesList = {
    					RegionCoordinates: sarr
    				};
    				break;
    			}
    		};
    	});

    	if (useTmp) {
    		plateRegionEleTemp = x2js.json2xml(regionJson);
    	}else{
    		ia(TriggerMode).m_PlateRecognitionXml = x2js.json2xml(regionJson);	
    	}
    }catch(e){
    	log("error:"+e.message);
    }
}

function reGenVideoMonitorLaneLine () {
	var laneCount = parseInt($('#RelatedLaneCount_VideoMonitor').val());

	if (!laneCount) {
		laneCount = 1;
	};

	var snapLines = {
		SnapLineList: {
			SnapLine:[]
		}
	};

	for (var i = 0; i < laneCount+1; i++) {
		var k = laneCount+2;
		var startX = ((1+i)/k).toFixed(4);
		var startY = (0.25).toFixed(4);
		var endX = startX;
		var endY = (0.75).toFixed(4);

		var LineType = 0;

		//var color = colorMap[LineType];
		//if (!color) {
		var	color = {r: 255, g: 0, b: 0};
		//}

		var id = 200 + (i+1);
		var Tips = getNodeValue(szTips[LineType])+(i+1);
		if (i == laneCount) {
			id = 401;
			LineType = ia(TriggerMode).TransLineType('laneRightBoundaryLine');
			Tips = getNodeValue(szTips[LineType]);
		};

		var _line = {
			id: id,
			LineType: LineType,
			Tips:  Tips,
			StartPos: {
				x: startX,
				y: startY
			},
			EndPos: {
				x: endX,
				y: endY
			},
			color: color
		};

		snapLines.SnapLineList.SnapLine.push(_line);
	};

	var ocx = $('#VideoMonitorDrawPlugin')[0];
	if (!ocx) {
		return;
	};

	ocx.HWP_ClearSnapInfo(4);
	if (snapLines.SnapLineList.SnapLine.length) {
		var szLineInfo = x2js.json2xml_str(snapLines);
		ocx.HWP_SetSnapLineInfo(szLineInfo);
	}
}

function cancelVideoMonitorModel(){
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }
    $('#VideoMonitor_Draw_plugin').html('');
    $.modal.impl.close();

    VideoMonitorReDisplay();
}

function okVideoMonitorModel () {
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }
    
   	RestoreVideoMonitor('#VideoMonitorDrawPlugin');

   	$('#VideoMonitor_Draw_plugin').html('');
    $.modal.impl.close();

    VideoMonitorReDisplay();
}

/**
 * 关闭单IO卡口弹出层
 * @return {[type]} [description]
 */
function cancelPostSingleIoModel () {
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }
    $.modal.impl.close();

    SingleIoReDisplay();
}

function okPostSingleIoModel () {
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }
    
   	RestorePlateRegion('#SingleIoDrawPlugin');

    $.modal.impl.close();

    SingleIoReDisplay();
}


function reDrawSingleIORegion (ioIdx) {
	reDrawPlateRegion(ioIdx, '#SingleIoDrawPlugin');
}

function reDrawVideoEpRegion (regionId) {
	reDrawPlateRegion(regionId, '#VideoEpDrawPlugin');
}

var ResW;
function getResW (argument) {
	if (ResW) {
		return ResW;
	}

	$.ajax({
		type: "GET",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + '/PSIA/Custom/SelfExt/ITC/ITCStatus',
		timeout: 15000,
		async: false,
		dataType:'text',
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) {
			var $xml = $(parseXmlFromStr(xmlDoc));
			ResW = $xml.find('resolutionWidth').eq(0).text();
		}
	});

	return ResW;
}

function buildTmpLinesForGenRegion (laneCount) {
	var resW = getResW();
	var laneCount = parseInt($('#RelatedLaneCount_videoEp').val());

	var szLineInfo ="<?xml version='1.0' encoding='utf-8'?><SnapLineList>";	
	szLineInfo += "<ImgWidth>"+resW+"</ImgWidth>";  //这里需要获取设备当前图像宽度 1280*720p
	szLineInfo += "<RoadNum>"+laneCount+"</RoadNum>";  //车道总数	
	szLineInfo += "<ReCogMode>0</ReCogMode>";  //识别模式

	var stopLineType = ia(TriggerMode).TransLineType('stopLine');
	var laneLineType = ia(TriggerMode).TransLineType('laneLine');
	var rightLaneLineType = ia(TriggerMode).TransLineType('laneRightBoundaryLine');

	var ocx = $('#VideoEpDrawPlugin')[0];

	var lineXml = ocx.HWP_GetSnapLineInfo();
	$(parseXmlFromStr(lineXml)).find('SnapLine').each(function () {
		var lineId = $(this).find('id').eq(0).text();

		var $st = $(this).find("StartPos");
		var $et = $(this).find("EndPos");

		var sx = $st.find('x').text();
		var sy = $st.find('y').text();
		var ex = $et.find('x').text();
		var ey = $et.find('y').text();

		lineId = parseInt(lineId,10);

		var lineType = lineId%100;
		if (_.contains([stopLineType, laneLineType, rightLaneLineType], lineType)) {
			szLineInfo += "<SnapLine><id>" + lineId + "</id><LineType>"+lineType+"</LineType>";
			szLineInfo += "<StartPos><x>"+sx+"</x><y>"+sy+"</y></StartPos><EndPos><x>"+ex+"</x><y>"+ey+"</y></EndPos></SnapLine>";
		}
	});
	szLineInfo += "</SnapLineList>";

	return szLineInfo;
}

function reGenVideoEpRegion () {
	var lineXml = buildTmpLinesForGenRegion();

	var szXMLInof = "";
	var ocx;
	try{
		ocx = $('#VideoEpDrawPlugin')[0];
		szXMLInof = ocx.HWP_GetSnapPolygonByRoadLine(0, lineXml);
	}catch(e){
		alert(getNodeValue("someErrorOccured"));
		return;
	}

	window.console && console.log(lineXml);

	if (!ocx) {
		return;
	};

	if (szXMLInof != null && szXMLInof != ""){  
		var regionJson = x2js.xml_str2json(xmlToStr(plateRegionEleTemp));

        var pregions = regionJson.PlateRecognition.PlateRegionList.PlateRegion_asArray;

        $(parseXmlFromStr(szXMLInof)).find('SnapPolygon').each(function (i, p) {
            var regionId = $(p).find('id').text();
            for (var i = 0; i < pregions.length; i++) {
                var r = pregions[i];
                if (r.regionId == regionId) {
                    var sarr = [];
                    $(p).find('point').each(function (i,n) {
                        var x = Math.floor(parseFloat($(n).find('x').text())*1000);
                        var y = Math.floor(parseFloat($(n).find('y').text())*1000);
                        sarr.push({
                            positionX: x,
                            positionY: y
                        });
                    });

                    r.RegionCoordinatesList = {
                        RegionCoordinates: sarr
                    };
                    break;
                }
            };
        });

		plateRegionEleTemp = x2js.json2xml(regionJson);

		var laneCount = parseInt($('#RelatedLaneCount_videoEp').val());
		var dispLaneArr = [];
		for (var i = 0; i < laneCount; i++) {
			dispLaneArr.push(i+1);
		};

		DisplayPlateRegionEx(dispLaneArr, '#VideoEpDrawPlugin', null, true);
		ocx.HWP_SetSnapDrawMode(0, 3)
	}else{
		var errorCode = ocx.HWP_GetLastError();
		if (errorCode == '9'
			|| errorCode == '10'
			|| errorCode == '11'
			|| errorCode == '12'
			|| errorCode == '13') {
			alert(getNodeValue("ocxError"+errorCode)+"!");	
		}else{
			alert(getNodeValue("ocxError")+"!");
		}
	}

}


function reDrawPlateRegion (regionId, ocxSel) {
	var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>"
				+ regionId
				+ "</id><polygonType>1</polygonType><tips>" + getNodeValue('PlateRegion') + regionId
				+ "</tips><isClosed>false</isClosed><color><r>255</r><g>255</g><b>0</b></color><pointList/></SnapPolygon></SnapPolygonList>";
	var ocx = $(ocxSel)[0];
	try{
		var iRet = ocx.HWP_SetSnapPolygonInfo(szInfo3);
	}catch(e){}
	try{
		ocx.HWP_SetSnapDrawMode(0, 2);  //设置为选择模式
	}catch(e){}
}

function reDrawPolygon (regionId, ocxSel, color, polygonName) {
	if (!color) {
		color = {r: 255, g: 255, b: 0};
	};
	var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>"
				+ regionId
				+ "</id><polygonType>1</polygonType><tips>" + polygonName
				+ "</tips><isClosed>false</isClosed>"
				+ "<color><r>"+color.r+"</r><g>"+color.g+"</g><b>"+color.b+"</b></color><pointList/></SnapPolygon></SnapPolygonList>";
	var ocx = $(ocxSel)[0];
	try{
		var iRet = ocx.HWP_SetSnapPolygonInfo(szInfo3);
	}catch(e){}
	try{
		ocx.HWP_SetSnapDrawMode(0, 2);  //设置为选择模式
	}catch(e){}
}

function reDrawPostSpeedRegion (regionId) {
	reDrawPlateRegion(regionId, '#IOSpeedDrawActiveX');
}

function reDrawPostRadarRegion(regionId) {
	reDrawPlateRegion(regionId, '#postRadarDrawActiveX');
}

function reDrawVtCoilRegion () {
	var selIdx = -1;
	 $("#tabpostVTCoilModal").find("li").each(function() {
        if($(this).children().hasClass("current")) {
        	var idx = $(this).attr('id').replace("liVTCoil", "");
        	selIdx = parseInt(idx);
        }
    });
	if (selIdx < 0) {
		return;
	}

	var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>"
				+ (selIdx+100)
				+ "</id><polygonType>0</polygonType><tips>" + getNodeValue('VTCoil') + selIdx
				+ "</tips><isClosed>false</isClosed><color><r>255</r><g>0</g><b>0</b></color><pointList/></SnapPolygon></SnapPolygonList>";
	var ocx = $('#VTCoilDrawActiveX')[0];
	try{
		var iRet = ocx.HWP_SetSnapPolygonInfo(szInfo3);
	}catch(e){}
	try{
		ocx.HWP_SetSnapDrawMode(0, 1);  //设置为选择模式
	}catch(e){}
}

function reDrawVtCoilPlateRegion () {
	var selIdx = -1;
	 $("#tabpostVTCoilModal").find("li").each(function() {
        if($(this).children().hasClass("current")) {
        	var idx = $(this).attr('id').replace("liVTCoil", "");
        	selIdx = parseInt(idx);
        }
    });
	if (selIdx >= 0) {
		reDrawPlateRegion(selIdx, '#VTCoilDrawActiveX');
	}
}

function reDrawHVTPlateRegion (laneNum) {
	reDrawPlateRegion(laneNum, '#HVTDrawActiveX');
}

function reDrawHVTObjectDetectArea () {
	if($('#objectDetectAera_HVT').prop('checked')){
		reDrawPolygon(100, '#HVTDrawActiveX', {r: 255, g:0, b:255}, getNodeValue("ObjectDetectAera"));	
	}
	
}

function reDrawPostMprPlateRegion() {
	var selIdx = -1;
	 $("#tabPostMprModal").find("li").each(function() {
        if($(this).children().hasClass("current")) {
        	var idx = $(this).attr('id').replace("liPostMpr", "");
        	selIdx = parseInt(idx);
        }
    });
	if (selIdx >= 0) {
		reDrawPlateRegion(selIdx, '#PostMprDrawPlugin');
	}
}

function reDrawEpoliceRS485Region (regionId) {
	reDrawPlateRegion(regionId, '#Epolice485DrawActiveX');
}

function reDrawPostEpoliceRS485Region  (regionId) {
	reDrawPlateRegion(regionId, '#PostEpolice485DrawActiveX');	
}

function reDrawPostRS485Region (regionId) {
	reDrawPlateRegion(regionId, '#postRS485DrawActiveX');
}

function ShowDrawPostSpeedPolygonModal () {
	if (!g_bIsIE) {
        $("#ioSpeedDraw_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='IOSpeedDrawActiveX' width='100%' height='100%' name='IOSpeedDrawActiveX' align='center' wndtype='1' playmode='snapdraw'>");
    } else {
        $("#ioSpeedDraw_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='IOSpeedDrawActiveX' width='100%' height='100%' name='IOSpeedDrawActiveX' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");

    }

    // test
    //var laneCount = $('#RelatedLaneCount_videoEp').val();
    laneCount = 2;
    var idxArr = [];
    for (var i = 1; i <= $('#postRadarControlModal input.showCountDetailBtn120').length; i++) {
    	if (i <= laneCount) {
    		idxArr.push(i);
    		$('#postRadarGroupOpt'+i).show();

    	}else{
    		$('#postRadarGroupOpt'+i).hide();
    	}
    }

    $('#postIOSpeedModalDiv').modal();

    HWP.Stop();
    $("#main_plugin").hide();

    var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
    var iRet = $("#IOSpeedDrawActiveX")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
    if (iRet !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    var ocx = $('#IOSpeedDrawActiveX')[0];	

    try {
        ocx.HWP_ClearSnapInfo(4);
        setTimeout(function () {
        	DisplayPlateRegionEx(idxArr, '#IOSpeedDrawActiveX');
			ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
        }, 500);
    } catch(e) {
    } 	   
}

function ShowVideoMonitorModal () {
	if (!g_bIsIE) {
        $("#VideoMonitor_Draw_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='VideoMonitorDrawPlugin' width='100%' height='100%' name='VideoMonitorDrawPlugin' align='center' wndtype='1' playmode='snapdraw'>");
    } else {
        $("#VideoMonitor_Draw_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='VideoMonitorDrawPlugin' width='100%' height='100%' name='VideoMonitorDrawPlugin' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
    }

    $('#videoMonitorModalDiv').modal();

    VideoMonitorTemp = x2js.parseXmlString(xmlToStr(ia(TriggerMode).m_videoMonitorXml));

    var laneCount = $('#RelatedLaneCount_VideoMonitor').val();
    setTimeout(function () {
    	DisplayVideoMonitorRegion(laneCount, '#VideoMonitorDrawPlugin');
        var ocx = $('#VideoMonitorDrawPlugin')[0];		
		try{
			ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
		}catch(e){}
    }, 500);

    HWP.Stop();
    $("#main_plugin").hide();

    var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
    var iRet = $("#VideoMonitorDrawPlugin")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
    if (iRet !== 0) {
        alert(getNodeValue("previewfailed"));
    }
}

function ShowPostMprModal () {
	var count = 0;
    $('#tabPostMpr').find("li").each(function(){
        if($(this).css('display') != 'none'){
            count++;
        }
    });
   if (!g_bIsIE) {
        $("#PostMpr_Draw_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='PostMprDrawPlugin' width='100%' height='100%' name='PostMprDrawPlugin' align='center' wndtype='1' playmode='snapdraw'>");
    } else {
        $("#PostMpr_Draw_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='PostMprDrawPlugin' width='100%' height='100%' name='PostMprDrawPlugin' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
    }

    InitPostMprTempEle();
    InitPlateRegionTempEle();

    $('#laneLine_PostMpr, #laneRightLine_PostMpr').prop('checked', true).unbind().click(function () {
    	var selIdx = -1;
    	var idxArr = [];
		 $("#tabPostMpr").find("li").not(":hidden").each(function() {
	        var idx = $(this).attr('id').replace("lilaneCount", "");
	        idx = parseInt(idx);
	        idxArr.push(idx);

	        if($(this).children().hasClass("current")) {
	        	selIdx = idx;
	        }
	    });
         /*var idxArr = [];
	        for (var i = 1; i <= count; i++) {
	        	idxArr.push(i);
	        };*/
    	var opt = {
        	laneLine: $('#laneLine_PostMpr').prop('checked'),
        	laneRightBoundaryLine: $('#laneRightLine_PostMpr').prop('checked')
        };

    	DisplayPostMprRegion(idxArr, '#PostMprDrawPlugin', {r:255,g:0,b:0}, true, opt);
        //DisplayPostMprRegion([selIdx], '#PostMprDrawPlugin', {r:255,g:0,b:0}, true, opt);
    });

    $('#PostMprDiv').modal();

    for(var i = count+1; i <= 5; i++){
        $('#liPostMpr' + i).css('display','none');
    }

    HWP.Stop();
    $("#main_plugin").hide();

    var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
    var iRet = $("#PostMprDrawPlugin")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
    if (iRet !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    var ocx = $('#PostMprDrawPlugin')[0];	

    try {
        ocx.HWP_ClearSnapInfo(4);
        setTimeout(function () {
        	var opt = {
	        	laneLine: $('#laneLine_PostMpr').prop('checked'),
	        	laneRightBoundaryLine: $('#laneRightLine_PostMpr').prop('checked')
	        };

	        var idxArr = [];
	        for (var i = 1; i <= count; i++) {
	        	idxArr.push(i);
	        };


        	DisplayPlateRegionEx(idxArr, '#PostMprDrawPlugin', null,  true);
        	DisplayPostMprRegion(idxArr, '#PostMprDrawPlugin', {r:255,g:0,b:0}, true, opt);
			ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
        }, 500);
    } catch(e) {
    } 	  
}

function InitHVTTempEle () {
	var x = xmlToStr(ia(TriggerMode).m_postHVTXml);
	postHVTTemp = x2js.parseXmlString(x);
}
function ShowPostHVTModel () {
	var count = $('#RelatedLaneCount_videoEp').val();
	count = parseInt(count);

    if (!g_bIsIE) {
        $("#HVTDraw_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='HVTDrawActiveX' width='100%' height='100%' name='HVTDrawActiveX' align='center' wndtype='1' playmode='snapdraw'>");
    } else {
        $("#HVTDraw_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='HVTDrawActiveX' width='100%' height='100%' name='HVTDrawActiveX' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
    }

    InitHVTTempEle();
    InitPlateRegionTempEle();

    $('#leftTriggerLine_HVT, #rightTriggerLine_HVT, #objectDetectAera_HVT').unbind().click(function () {
    	RestorePlateRegion('#HVTDrawActiveX', true);
    	RestoreHVTRegion(true);


    	var ocx = $("#HVTDrawActiveX")[0];
    	ocx.HWP_ClearSnapInfo(4);

    	var selIdx = -1;
    	var idxArr = [];

    	for (var i = 0; i < count; i++) {
    		idxArr.push(i+1);
    	};

    	DisplayPlateRegionEx(idxArr, '#HVTDrawActiveX', null,  true);
    	DisplayPostHVTRegion(idxArr, '#HVTDrawActiveX', {r:255,g:0,b:0}, true);
    	

    	if ($(this).attr('id') == 'objectDetectAera_HVT') {
    		if ($(this).prop('checked')) {
    			$('#HVTDrawObjectDetectArea_wrapper').show();
    		}else{
    			$('#HVTDrawObjectDetectArea_wrapper').hide();
    		}
    	};
    });

    if ($('#objectDetectAera_HVT').prop('checked')) {
		$('#HVTDrawObjectDetectArea_wrapper').show();
	}else{
		$('#HVTDrawObjectDetectArea_wrapper').hide();
	}

    $('#postHVTModalDiv').modal();

    for(var i = 1; i <= 5; i++){
    	if (i > count) {
    		$('#HVTDrawSignArea'+i+ ", #HVTDrawSignArea"+i+"_wrapper").hide();
    	}else{
    		$('#HVTDrawSignArea'+i+ ", #HVTDrawSignArea"+i+"_wrapper").show();
    	}
    }

    HWP.Stop();
    $("#main_plugin").hide();

    var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
    var iRet = $("#HVTDrawActiveX")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
    if (iRet !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    var ocx = $('#HVTDrawActiveX')[0];	

    try {
        ocx.HWP_ClearSnapInfo(4);
        setTimeout(function () {
        	var opt = {
	        	laneLine: true,
	        	laneRightBoundaryLine: true,
	        	leftTriggerLine: $('#leftTriggerLine_HVT').prop('checked'),
	    		rightTriggerLine: $('#rightTriggerLine_HVT').prop('checked'),
	    		objectDetectAera: $('#objectDetectAera_HVT').prop('checked')
	        };

	        var idxArr = [];
	        for (var i = 1; i <= count; i++) {
	        	idxArr.push(i);
	        };

        	DisplayPlateRegionEx(idxArr, '#HVTDrawActiveX', null,  true);
        	DisplayPostHVTRegion(idxArr, '#HVTDrawActiveX', {r:255,g:0,b:0}, true, opt);
			ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
        }, 500);
    } catch(e) {
    } 	  
}

function ShowDrawPostVTCoilPolygonModal () {
	var count = 0;
    $('#tabpostVTCoil').find("li").each(function(){
        if($(this).css('display') != 'none'){
            count++;
        }
    });
    if (!g_bIsIE) {
        $("#vtCoilDraw_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='VTCoilDrawActiveX' width='100%' height='100%' name='VTCoilDrawActiveX' align='center' wndtype='1' playmode='snapdraw'>");
    } else {
        $("#vtCoilDraw_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='VTCoilDrawActiveX' width='100%' height='100%' name='VTCoilDrawActiveX' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
    }

    InitVTCoilTempEle();
    InitPlateRegionTempEle();

    $('#laneLine_vtCoil, #laneRightLine_vtCoil').prop('checked', true).unbind().click(function () {
    	var selIdx = -1;
    	var idxArr = [];
		 $("#tabpostVTCoilModal").find("li").not(":hidden").each(function() {
	        var idx = $(this).attr('id').replace("liVTCoil", "");
	        idx = parseInt(idx);
	        idxArr.push(idx);

	        if($(this).children().hasClass("current")) {
	        	selIdx = idx;
	        }
	    });

    	var opt = {
        	laneLine: $('#laneLine_vtCoil').prop('checked'),
        	laneRightBoundaryLine: $('#laneRightLine_vtCoil').prop('checked')
        };

    	DisplayVTCoilRegion(idxArr, '#VTCoilDrawActiveX', {r:255,g:0,b:0}, true, opt);
       // DisplayVTCoilRegion([selIdx], '#VTCoilDrawActiveX', {r:255,g:0,b:0}, true, opt);
    });

    $('#postVTCoilModalDiv').modal();

    for(var i = count+1; i <= 5; i++){
        $('#liVTCoil' + i).css('display','none');
    }

    HWP.Stop();
    $("#main_plugin").hide();

    var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
    var iRet = $("#VTCoilDrawActiveX")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
    if (iRet !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    var ocx = $('#VTCoilDrawActiveX')[0];	

    try {
        ocx.HWP_ClearSnapInfo(4);
        setTimeout(function () {
        	var opt = {
	        	laneLine: $('#laneLine_vtCoil').prop('checked'),
	        	laneRightBoundaryLine: $('#laneRightLine_vtCoil').prop('checked')
	        };

	        var idxArr = [];
	        for (var i = 1; i <= count; i++) {
	        	idxArr.push(i);
	        };


        	DisplayPlateRegionEx(idxArr, '#VTCoilDrawActiveX', null,  true);
        	DisplayVTCoilRegion(idxArr, '#VTCoilDrawActiveX', {r:255,g:0,b:0}, true, opt);
			ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
        }, 500);
    } catch(e) {
    } 	  
}

function ShowPostRadarModal () {
	if (!g_bIsIE) {
        $("#postRadarDraw_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='postRadarDrawActiveX' width='100%' height='100%' name='postRadarDrawActiveX' align='center' wndtype='1' playmode='snapdraw'>");
    } else {
        $("#postRadarDraw_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='postRadarDrawActiveX' width='100%' height='100%' name='postRadarDrawActiveX' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
    }

    var laneCount = $('#RelatedLaneCount_videoEp').val();
	var idxArr = [];
    for (var i = 1; i <= 6; i++) {
    	if (i <= laneCount) {
			idxArr.push(i);
    		$('#postRadarGroupOpt'+i).show();
            $('#postRadarGroupOpt'+i).val(getNodeValue('aRedrawPlateRegion') + "(" + getNodeValue('laVideoLane')+i+")");
    	}else{
    		$('#postRadarGroupOpt'+i).hide();
    	}
    };

    $('#postRadarModalDiv').modal();

    HWP.Stop();
    $("#main_plugin").hide();

    var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
    var iRet = $("#postRadarDrawActiveX")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
    if (iRet !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    var ocx = $('#postRadarDrawActiveX')[0];	

    try {
        ocx.HWP_ClearSnapInfo(4);
        setTimeout(function () {
        	DisplayPlateRegionEx(idxArr, '#postRadarDrawActiveX');
			ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
        }, 500);
    } catch(e) {
    } 	   
}

function ShowEpliceRS485PolygonModal () {
	if (!g_bIsIE) {
        $("#epolice485_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='Epolice485DrawActiveX' width='100%' height='100%' name='Epolice485DrawActiveX' align='center' wndtype='1' playmode='snapdraw'>");
    } else {
        $("#epolice485_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='Epolice485DrawActiveX' width='100%' height='100%' name='Epolice485DrawActiveX' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
    }

    var laneCount = $('#RelatedLaneCount_videoEp').val();
    var idxArr = [];
    for (var i = 1; i <= $('#epolice485ControlModal input.showCountDetailBtn').length; i++) {
    	if (i <= laneCount) {
    		idxArr.push(i);
    		$('#epolice485GroupOpt'+i).show();
    	}else{
    		$('#epolice485GroupOpt'+i).hide();
    	}
    }

    $('#epoliceRS485ModalDiv').modal();

    HWP.Stop();
    $("#main_plugin").hide();

    var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
    var iRet = $("#Epolice485DrawActiveX")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
    if (iRet !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    var ocx = $('#Epolice485DrawActiveX')[0];	

    try {
        ocx.HWP_ClearSnapInfo(4);
        setTimeout(function () {
        	DisplayPlateRegionEx(idxArr, '#Epolice485DrawActiveX');
			ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
        }, 500);
    } catch(e) {
    } 	   
}

function ShowPostRS485Modal () {
	if (!g_bIsIE) {
        $("#postRS485Draw_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='postRS485DrawActiveX' width='100%' height='100%' name='postRS485DrawActiveX' align='center' wndtype='1' playmode='snapdraw'>");
    } else {
        $("#postRS485Draw_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='postRS485DrawActiveX' width='100%' height='100%' name='postRS485DrawActiveX' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
    }

    var laneCount = $('#RelatedLaneCount_videoEp').val();
    var idxArr = [];
    for (var i = 1; i <= $('#postRS485ControlModal input.showCountDetailBtn120').length; i++) {
    	if (i <= laneCount) {
    		idxArr.push(i);
    		$('#postRS485GroupOpt'+i).show();
            $('#postRS485GroupOpt'+i).val(getNodeValue('DrawPlateRegionbtn') + "(" + getNodeValue('laVideoLane')+i+")");
    	}else{
    		$('#postRS485GroupOpt'+i).hide();
    	}
    }

    $('#postRS485ModalDiv').modal();

    HWP.Stop();
    $("#main_plugin").hide();

    var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
    var iRet = $("#postRS485DrawActiveX")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
    if (iRet !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    var ocx = $('#postRS485DrawActiveX')[0];
    //生成牌识区域
    try {
        ocx.HWP_ClearSnapInfo(4);
        setTimeout(function () {
        	DisplayPlateRegionEx(idxArr, '#postRS485DrawActiveX');
			ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
        }, 500);
    } catch(e) {

    }
}

function ShowPostEpolicePolygonModal () {
	if (!g_bIsIE) {
        $("#postEpolice485_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='PostEpolice485DrawActiveX' width='100%' height='100%' name='PostEpolice485DrawActiveX' align='center' wndtype='1' playmode='snapdraw'>");
    } else {
        $("#postEpolice485_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='PostEpolice485DrawActiveX' width='100%' height='100%' name='PostEpolice485DrawActiveX' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
    }

    var laneCount = $('#RelatedLaneCount_videoEp').val();
    var idxArr = [];
    for (var i = 1; i <= $('#postEpolice485ControlModal input.showCountDetailBtn').length; i++) {
    	if (i <= laneCount) {
    		idxArr.push(i);
    		$('#postEpolice485GroupOpt'+i).show();
    	}else{
    		$('#postEpolice485GroupOpt'+i).hide();
    	}
    }

    $('#postEpoliceRS485ModalDiv').modal();

    HWP.Stop();
    $("#main_plugin").hide();

    var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
    var iRet = $("#PostEpolice485DrawActiveX")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
    if (iRet !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    var ocx = $('#PostEpolice485DrawActiveX')[0];	

    try {
        ocx.HWP_ClearSnapInfo(4);
        setTimeout(function () {
        	DisplayPlateRegionEx(idxArr, '#PostEpolice485DrawActiveX');
			ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
        }, 500);
    } catch(e) {
    } 	   
}

/*************************************************
 Function:		ShowDrawPolygonModal
 Description:	打开绘制牌示区域弹出层
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function ShowDrawPolygonModal(){

    var triggerMode = $('#selTriggerMode').val();
	switch(triggerMode) {
		case "postSingleIO":
		  ShowDrawSingleIoPolygonModal();
	      break;
		case "videoEpolice":
		  ShowDrawVideoEpModal();
		  break;
		case "postIOSpeed":
		  ShowDrawPostSpeedPolygonModal();
		  break;
		case "postVTCoil":
		  ShowDrawPostVTCoilPolygonModal();
		  break;
		case "epoliceRS485":
		  ShowEpliceRS485PolygonModal();
		  break;
		case "postRadar":
		  ShowPostRadarModal();
		  break;
		case "postRS485":
		  var curMode = ia(TriggerMode).m_CurBackUpMode;
		  if (curMode == 0) {
			  return ShowPostRS485Modal();
		  }else if(curMode == 1){
			  return ShowDrawPostVTCoilPolygonModal();
		  }
		  break;
		case "postEpoliceRS485":
		  ShowPostEpolicePolygonModal();
		  break;
		case "PostMpr":
		  ShowPostMprModal();
		  break;
		case 'videoMonitor':
		  ShowVideoMonitorModal();
		  break;
		case 'postHVT':
		  ShowPostHVTModel();
		  break;
	    default:
		  break;
	}
}

/*************************************************
Function:		StartDrawLine
Description:	绘制直线
Input:			iType:类型			
Output:			无
return:			无				
*************************************************/
function StartDrawLine(iType) {
	$("#IsDispalyRegion").prop("checked", false);
	//DisplayRegion();
	var szLineInfo = "";
	var iLaneNum =  $("#RelatedLaneCount").val();
	var step = parseFloat(1)/iLaneNum;
	var stepPlane = parseFloat(1)/(parseInt(iLaneNum) + 1);
	switch(iType) {
		case 0: //车道线
		    szLineInfo = "<?xml version='1.0' encoding='utf-8'?><SnapLineList>";
			for(var i = 1; i <= iLaneNum; i++){
				szLineInfo += "<SnapLine><id>" + i + "</id><LineType>0</LineType><color><r>146</r><g>208</g><b>80</b></color><Tips>" + getNodeValue("DrawLinebtn") + i + "</Tips><StartPos><x>" + (0.025 + (i-1)*step) + "</x><y>0.664</y></StartPos><EndPos><x>" + (0.025 + (i-1)*step) + "</x><y>0.967</y></EndPos></SnapLine>";
			}
			szLineInfo += "</SnapLineList>";
	        break;
		case 1: //停止线
		    szLineInfo = "<?xml version='1.0' encoding='utf-8'?><SnapLineList>";
			for(var i = 1; i <= iLaneNum; i++){
				szLineInfo += "<SnapLine><id>" + i + "</id><LineType>1</LineType><color><r>255</r><g>0</g><b>0</b></color><Tips>" + getNodeValue("DrawStopLinebtn") + i + "</Tips><StartPos><x>" + (0.025 + (i-1)*stepPlane + 0.1) + "</x><y>0.664</y></StartPos><EndPos><x>" + (0.025 + (i)*stepPlane) + "</x><y>0.664</y></EndPos></SnapLine>";
			}
			szLineInfo += "</SnapLineList>";
		    break;
		case 2: //待行区停止线
		   szLineInfo = "<?xml version='1.0' encoding='utf-8'?><SnapLineList>";
			for(var i = 1; i <= iLaneNum; i++){
				szLineInfo += "<SnapLine><id>" + i + "</id><LineType>2</LineType><color><r>255</r><g>255</g><b>0</b></color><Tips>" + getNodeValue("DrawWaitLinebtn") + i + "</Tips><StartPos><x>" + (0.025 + (i-1)*stepPlane + 0.1) + "</x><y>0.5</y></StartPos><EndPos><x>" + (0.025 + (i)*stepPlane) + "</x><y>0.5</y></EndPos></SnapLine>";
			}
			szLineInfo += "</SnapLineList>";
		    break;
		case 3: //直行触发边界线
		    szLineInfo = "<?xml version='1.0' encoding='utf-8'?><SnapLineList>";
			for(var i = 1; i <= iLaneNum; i++){
				szLineInfo += "<SnapLine><id>" + i + "</id><LineType>3</LineType><color><r>247</r><g>150</g><b>70</b></color><Tips>" + getNodeValue("DrawCancelLinebtn") + i + "</Tips><StartPos><x>" + (0.025 + (i-1)*stepPlane + 0.1) + "</x><y>0.3</y></StartPos><EndPos><x>" + (0.025 + (i)*stepPlane) + "</x><y>0.3</y></EndPos></SnapLine>";
			}
			szLineInfo += "</SnapLineList>";
		    break;
		case 4: //车道右边界线
		    szLineInfo = "<?xml version='1.0' encoding='utf-8'?><SnapLineList><SnapLine><id>1</id><LineType>4</LineType><color><r>146</r><g>208</g><b>80</b></color><Tips>" + getNodeValue("Drawlanerightline") + "</Tips><StartPos><x>0.989</x><y>0.664</y></StartPos><EndPos><x>0.989</x><y>0.967</y></EndPos></SnapLine></SnapLineList>";
		    break;
		case 5: //左转分界线
		    szLineInfo = "<?xml version='1.0' encoding='utf-8'?><SnapLineList><SnapLine><id>1</id><LineType>5</LineType><color><r>255</r><g>255</g><b>0</b></color><Tips>" + getNodeValue("DrawTurnleftLinebtn") + "</Tips><StartPos><x>0.3</x><y>0.171</y></StartPos><EndPos><x>0.009</x><y>0.667</y></EndPos></SnapLine></SnapLineList>";
		    break;
		case 6: //右转分界线
		    szLineInfo = "<?xml version='1.0' encoding='utf-8'?><SnapLineList><SnapLine><id>1</id><LineType>6</LineType><color><r>255</r><g>255</g><b>0</b></color><Tips>" + getNodeValue("DrawTurnRightLinebtn") + "</Tips><StartPos><x>0.57</x><y>0.185</y></StartPos><EndPos><x>0.948</x><y>0.763</y></EndPos></SnapLine></SnapLineList>";
		    break;
		default:
		    break;
	}
	
	try{
		var iRet = HWP.SetSnapLineInfo(szLineInfo);
	}
	catch(e){
	}
	try{
		//HWP.ClearSnapInfo();
		var iRet = HWP.SetSnapDrawMode(0);
		if(iRet != 0) {
			alert(iRet);
		}
	}
	catch(e)
	{}
}
/*************************************************
Function:		StartDrawVTCoil
Description:	绘制矩形框
Input:			无			
Output:			无
return:			无				
*************************************************/
function StartDrawVTCoil() {
	$("#IsDispalyRegion").prop("checked", false);
	DisplayRegion();
	var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>" + m_iCurSelIONum + "</id><polygonType>0</polygonType><tips>" + getNodeValue("VTCoil") + m_iCurSelIONum + "</tips><isClosed>false</isClosed><color><r>255</r><g>0</g><b>0</b></color><pointList></pointList></SnapPolygon></SnapPolygonList>";
	try{
		var iRet = HWP.SetSnapPolygonInfo(szInfo3);
	}
	catch(e){
	}
	
	try{
		var iRet = HWP.SetSnapDrawMode(1);
		if(iRet != 0) {
			alert(iRet);
		}
	}
	catch(e)
	{}
}
/*************************************************
Function:		StartDrawEntraVideo
Description:	绘制矩形框
Input:			无			
Output:			无
return:			无				
*************************************************/
function StartDrawEntraVideo() {
	$("#IsDispalyRegion").prop("checked", false);
	DisplayRegion();
	var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>" + m_iCurSelIONum + "</id><polygonType>0</polygonType><tips>" + getNodeValue("VTCoil") + m_iCurSelIONum + "</tips><isClosed>false</isClosed><color><r>255</r><g>0</g><b>0</b></color><pointList></pointList></SnapPolygon></SnapPolygonList>";
	try{
		var iRet = HWP.SetSnapPolygonInfo(szInfo3);
	}
	catch(e){
	}
	
	try{
		var iRet = HWP.SetSnapDrawMode(1);
		if(iRet != 0) {
			alert(iRet);
		}
	}
	catch(e)
	{}
}
/*************************************************
Function:		FullScreen
Description:	全屏
Input:			无			
Output:			无
return:			无				
*************************************************/
function FullScreen() {
	try{
		var iRet = HWP.FullScreenDisplay();
	}
	catch(e)
	{}
}
/*************************************************
Function:		ClearPolygon
Description:	清除区域
Input:			无			
Output:			无
return:			无				
*************************************************/
function ClearPolygon(iType) {
	if(arguments.length > 0)
	{
		iClearType = iType;
	} else {
		iClearType = 4;
	}
	try{
		var iRet = HWP.ClearSnapInfo(iClearType);
		if(iRet != 0) {
			//alert(getNodeValue("ClearFailed"));
		}
	}
	catch(e)
	{}
}



var plateRegionEleTemp;

function InitPlateRegionTempEle () {
	var x = xmlToStr(ia(TriggerMode).m_PlateRecognitionXml);
	plateRegionEleTemp = x2js.parseXmlString(x);
}

function DisplayPlateRegionEx (regionIdArray, ocxSel, color, useTmpXmlEle) {
	var domEle;
	if (useTmpXmlEle && plateRegionEleTemp) {
		domEle = plateRegionEleTemp;
	}else{
		domEle = ia(TriggerMode).m_PlateRecognitionXml;	
	}
	 
	var $regionList = $(domEle).find('PlateRegion');

	var polygonArray = [];
	var obj = {
		SnapPolygonList:{
			SnapPolygon: []
		}
	};

	if (!color) {
		color = {r: 255, g:255, b:0};
	}

	$regionList.each(function (i, r) {
		var $r = $(r);
		var rid = parseInt($r.find('regionId').text());
		if (_.contains(regionIdArray, rid)) {
			var pts = [];
			var $_pts = $r.find('RegionCoordinates');
			$_pts.each(function (i, n) {
				var tx = parseInt($(n).find('positionX').text());
				var ty = parseInt($(n).find('positionY').text());
				pts.push({
					x:(tx/1000).toFixed(3),
					y:(ty/1000).toFixed(3)
				});
			});
			obj['SnapPolygonList']['SnapPolygon'].push({
				id: rid,
				polygonType: 1,
				color: color,
				tips: getNodeValue("PlateRegion")+rid,
				isClosed: "true",
				pointList: {
					point:pts
				}
			});
				
		};
	});
	var xml = x2js.json2xml_str(obj, true);
	//_log("RegionXml="+xml);
	try{
		if (!ocxSel) {
			ocxSel = '#PreviewActiveX';
		}
		var ocx = $(ocxSel)[0];
		ocx.HWP_ClearSnapInfo(1);
		ocx.HWP_SetSnapPolygonInfo(xml);
	}catch(e){}
}

var vtCoilTemp;
function DisplayVTCoilRegion (regionIdArray, ocxSel, color, useTmpXmlEle, dispOpt) {
	var domEle;
	if (useTmpXmlEle && vtCoilTemp) {
		domEle = vtCoilTemp;
	}else{
		domEle = ia(TriggerMode).m_PostVTCoilXml;	
	}

	var $regionList = $(domEle).find('VtCoil');

	var polygonArray = [];
	var obj = {
		SnapPolygonList:{
			SnapPolygon: []
		}
	};

	if (!color) {
		color = {r: 255, g:255, b:0};
	}

	$regionList.each(function (i, r) {
		var $r = $(r);
		var rid = parseInt($r.find('vtCoilNum').text());
		if (_.contains(regionIdArray, rid)) {
			var pts = [];
			var $_pts = $r.find('RegionCoordinatesList').eq(0).find('RegionCoordinates');
			$_pts.each(function (i, n) {
				var tx = parseInt($(n).find('positionX').text());
				var ty = parseInt($(n).find('positionY').text());
				pts.push({
					x:(tx/1000).toFixed(3),
					y:(ty/1000).toFixed(3)
				});
			});
			obj['SnapPolygonList']['SnapPolygon'].push({
				id: 100+rid,
				polygonType: 0,
				color: color,
				tips: getNodeValue("VTCoil")+rid,
				isClosed: "true",
				pointList: {
					point:pts
				}
			});
				
		};
	});
	var xml = x2js.json2xml_str(obj, true);

	if (!ocxSel) {
		ocxSel = '#PreviewActiveX';
	}
	var ocx = $(ocxSel)[0];

	try{	
		ocx.HWP_ClearSnapInfo(0);
		ocx.HWP_SetSnapPolygonInfo(xml);
	}catch(e){}

	var opts = {
		laneLine: true,
		laneRightBoundaryLine: true
	};

	opts = $.extend({}, opts, dispOpt);

	if (!opts.laneLine && !opts.laneRightBoundaryLine) {
		//return;
	}

	var snapLines = {
		SnapLineList: {
			SnapLine:[]
		}
	};
	if (opts.laneLine) {
		$(domEle).find('VtCoil').each(function () {
			var $line = $(this).find('ViolationDetectLine').eq(0);
			var coilId = parseInt($(this).find('vtCoilNum').text());

			if (_.contains(regionIdArray, coilId)) {
				var lineName = $line.find('lineName').eq(0).text();

				if (lineName == 'laneLine') {
					var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
					var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
					var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
					var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

					var LineType = ia(TriggerMode).TransLineType(lineName);

					var color = colorMap[LineType];
					if (!color) {
						color = {r: 255, g: 255, b: 0};
					}

					var _line = {
						id: 200+coilId,
						LineType: LineType,
						Tips:  getNodeValue(szTips[LineType])+coilId,
						StartPos: {
							x: startX,
							y: startY
						},
						EndPos: {
							x: endX,
							y: endY
						},
						color: color
					};

					snapLines.SnapLineList.SnapLine.push(_line);
				}
			}
		});
	}

	if (opts.laneRightBoundaryLine) {
		var $line = $(domEle).find('VirtualLane').eq(0);
		var lineName = $line.find('lineName').eq(0).text();

		if (lineName == 'laneRightBoundaryLine') {
			var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
			var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
			var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
			var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

			var LineType = ia(TriggerMode).TransLineType(lineName);

			var color = colorMap[LineType];
			if (!color) {
				color = {r: 255, g: 255, b: 0};
			}

			var _line = {
				id: 300,
				LineType: LineType,
				Tips:  getNodeValue(szTips[LineType]),
				StartPos: {
					x: startX,
					y: startY
				},
				EndPos: {
					x: endX,
					y: endY
				},
				color: color
			};

			snapLines.SnapLineList.SnapLine.push(_line);
		}
	}
	
	if (snapLines.SnapLineList.SnapLine.length) {
		var szLineInfo = x2js.json2xml_str(snapLines);

		ocx.HWP_ClearSnapInfo(2);
		ocx.HWP_SetSnapLineInfo(szLineInfo);
	}
}

var postHVTTemp;
function DisplayPostHVTRegion (regionIdArray, ocxSel, color, useTmpXmlEle, dispOpt) {

	var domEle;
	if (useTmpXmlEle && postHVTTemp) {
		domEle = postHVTTemp;
	}else{
		domEle = ia(TriggerMode).m_postHVTXml;	
	}

	if (!ocxSel) {
		ocxSel = '#PreviewActiveX';
	}
	
	var ocx = $(ocxSel)[0];

	try{	
		//ocx.HWP_ClearSnapInfo(4);
	}catch(e){}

	var opts = {
		laneLine: true,
		laneRightBoundaryLine: true,
		triggerLine: true,
		leftTriggerLine: $('#leftTriggerLine_HVT').prop('checked'),
		rightTriggerLine: $('#rightTriggerLine_HVT').prop('checked'),
		objectDetectAera: $('#objectDetectAera_HVT').prop('checked')
	};

	opts = $.extend({}, opts, dispOpt);

	var $regionList = $(domEle).find('HvtLane');

	var polygonArray = [];
	var obj = {
		SnapPolygonList:{
			SnapPolygon: []
		}
	};

	if (!color) {
		color = {r: 255, g:255, b:0};
	}

	if(opts.objectDetectAera){
		var pts = [];
		var $r = $(domEle).find('ObjectDetectAera');

		var $_pts = $r.find('AeraCoordinates');
		$_pts.each(function (i, n) {
			var tx = parseInt($(n).find('positionX').text());
			var ty = parseInt($(n).find('positionY').text());
			pts.push({
				x:(tx/1000).toFixed(3),
				y:(ty/1000).toFixed(3)
			});
		});

        var objDetColor = {r: 255, g:0, b:255};

		obj['SnapPolygonList']['SnapPolygon'].push({
			id: 100,
			polygonType: 1,
			color: objDetColor,
			tips: getNodeValue("ObjectDetectAera"),
			isClosed: "true",
			pointList: {
				point:pts
			}
		});
	}

	var xml = x2js.json2xml_str(obj, true);

	try{	
		ocx.HWP_SetSnapPolygonInfo(xml);
	}catch(e){}

	

	var snapLines = {
		SnapLineList: {
			SnapLine:[]
		}
	};
	if (opts.laneLine) {
		$(domEle).find('HvtLane').each(function () {
			var $line = $(this).find('LaneLine').eq(0);
			var coilId = parseInt($(this).find('HvtLaneNum').text());

			if (_.contains(regionIdArray, coilId)) {
				var lineName = $line.find('lineName').eq(0).text();

				if (lineName == 'laneLine') {
					var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
					var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
					var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
					var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

					var LineType = ia(TriggerMode).TransLineType(lineName);

					var color = {r: 0, g: 0, b: 255};

					var _line = {
						id: 200+coilId,
						LineType: LineType,
						Tips:  getNodeValue(szTips[LineType])+coilId,
						StartPos: {
							x: startX,
							y: startY
						},
						EndPos: {
							x: endX,
							y: endY
						},
						color: color
					};

					snapLines.SnapLineList.SnapLine.push(_line);
				}
			}
		});
	}

	if (opts.laneRightBoundaryLine) {
		var $line = $(domEle).find('LaneRightBoundaryLine').eq(0);
		var lineName = $line.find('lineName').eq(0).text();

		if (lineName == 'laneRightBoundaryLine') {
			var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
			var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
			var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
			var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

			var LineType = ia(TriggerMode).TransLineType(lineName);

			var color = {r: 0, g: 0, b: 255};

			var _line = {
				id: LineType*100,
				LineType: LineType,
				Tips:  getNodeValue(szTips[LineType]),
				StartPos: {
					x: startX,
					y: startY
				},
				EndPos: {
					x: endX,
					y: endY
				},
				color: color
			};

			snapLines.SnapLineList.SnapLine.push(_line);
		}
	}

	if (opts.triggerLine) {
		var $line = $(domEle).find('TriggerLine').eq(0);
		var lineName = $line.find('lineName').eq(0).text();

		if (lineName == 'triggerLine') {
			var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
			var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
			var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
			var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

			var LineType = ia(TriggerMode).TransLineType(lineName);

			var color = {r: 255, g: 0, b: 0};

			var _line = {
				id: LineType*100,
				LineType: LineType,
				Tips:  getNodeValue("HVTtriggerLine"),
				StartPos: {
					x: startX,
					y: startY
				},
				EndPos: {
					x: endX,
					y: endY
				},
				color: color
			};

			snapLines.SnapLineList.SnapLine.push(_line);
		}
	}	

	if (opts.leftTriggerLine) {
		var $line = $(domEle).find('LeftTriggerLine').eq(0);
		var lineName = $line.find('lineName').eq(0).text();

		if (lineName == 'leftTriggerLine') {
			var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
			var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
			var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
			var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

			var LineType = ia(TriggerMode).TransLineType(lineName);

			var color = {r: 0, g: 255, b: 0};

			var _line = {
				id: LineType*100+1,
				LineType: LineType,
				Tips:  getNodeValue("HVTleftTriggerLine"),
				StartPos: {
					x: startX,
					y: startY
				},
				EndPos: {
					x: endX,
					y: endY
				},
				color: color
			};

			snapLines.SnapLineList.SnapLine.push(_line);
		}
	}	

	if (opts.rightTriggerLine) {
		var $line = $(domEle).find('RightTriggerLine').eq(0);
		var lineName = $line.find('lineName').eq(0).text();

		if (lineName == 'rightTriggerLine') {
			var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
			var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
			var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
			var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

			var LineType = ia(TriggerMode).TransLineType(lineName);
			
			var color = {r: 0, g: 255, b: 0};
			

			var _line = {
				id: LineType*100+2,
				LineType: LineType,
				Tips:  getNodeValue('HVTrightTriggerLine'),
				StartPos: {
					x: startX,
					y: startY
				},
				EndPos: {
					x: endX,
					y: endY
				},
				color: color
			};

			snapLines.SnapLineList.SnapLine.push(_line);
		}
	}	

	if (snapLines.SnapLineList.SnapLine.length) {
		var szLineInfo = x2js.json2xml_str(snapLines);
		ocx.HWP_SetSnapLineInfo(szLineInfo);

		ocx.HWP_SetSnapDrawMode(0, 3);
	}
}

var PostMprTemp;
function DisplayPostMprRegion (regionIdArray, ocxSel, color, useTmpXmlEle, dispOpt) {
	var domEle;
	if (useTmpXmlEle && PostMprTemp) {
		domEle = PostMprTemp;
	}else{
		domEle = ia(TriggerMode).m_PostMprXml;	
	}

	if (!color) {
		color = {r: 255, g:255, b:0};
	}

	if (!ocxSel) {
		ocxSel = '#PreviewActiveX';
	}
	var ocx = $(ocxSel)[0];

	var opts = {
		laneLine: true,
		laneRightBoundaryLine: true
	};

	opts = $.extend({}, opts, dispOpt);

	if (!opts.laneLine && !opts.laneRightBoundaryLine) {
		//return;
	}

	var snapLines = {
		SnapLineList: {
			SnapLine:[]
		}
	};

	if (opts.laneLine) {
		$(domEle).find('LaneParam').each(function () {
			var $line = $(this).find('ViolationDetectLine').eq(0);
			var coilId = parseInt($(this).find('laneNum').text());

			if (_.contains(regionIdArray, coilId)) {
				var lineName = $line.find('lineName').eq(0).text();

				if (lineName == 'laneLine') {
					var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
					var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
					var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
					var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

					var LineType = ia(TriggerMode).TransLineType(lineName);

					var color = colorMap[LineType];
					if (!color) {
						color = {r: 255, g: 255, b: 0};
					}

					var _line = {
						id: 200+coilId,
						LineType: LineType,
						Tips:  getNodeValue(szTips[LineType])+coilId,
						StartPos: {
							x: startX,
							y: startY
						},
						EndPos: {
							x: endX,
							y: endY
						},
						color: color
					};

					snapLines.SnapLineList.SnapLine.push(_line);
				}
			}
		});
	}

	if (opts.laneRightBoundaryLine) {
		var $line = $(domEle).find('VirtualLane').eq(0);
		var lineName = $line.find('lineName').eq(0).text();

		if (lineName == 'laneRightBoundaryLine') {
			var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
			var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
			var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
			var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

			var LineType = ia(TriggerMode).TransLineType(lineName);

			var color = colorMap[LineType];
			if (!color) {
				color = {r: 255, g: 255, b: 0};
			}

			var _line = {
				id: 300,
				LineType: LineType,
				Tips:  getNodeValue(szTips[LineType]),
				StartPos: {
					x: startX,
					y: startY
				},
				EndPos: {
					x: endX,
					y: endY
				},
				color: color
			};

			snapLines.SnapLineList.SnapLine.push(_line);
		}
	}
	ocx.HWP_ClearSnapInfo(2);
	if (snapLines.SnapLineList.SnapLine.length) {
		var szLineInfo = x2js.json2xml_str(snapLines);
		ocx.HWP_SetSnapLineInfo(szLineInfo);
	}
}

var VideoMonitorTemp;
function DisplayVideoMonitorRegion (laneCount, ocxSel, color, useTmpXmlEle) {
	var domEle;
	if (useTmpXmlEle && VideoMonitorTemp) {
		domEle = VideoMonitorTemp;
	}else{
		domEle = ia(TriggerMode).m_videoMonitorXml;	
	}

	if (!color) {
		color = {r: 255, g:0, b:0};
	}

	if (!ocxSel) {
		ocxSel = '#PreviewActiveX';
	}
	var ocx = $(ocxSel)[0];

	var opts = {
		laneLine: true,
		laneRightBoundaryLine: true
	};

	var virtualLaneArray = $(domEle).find('ViolationDetectLine');    // 车道

	var rightLine = $(domEle).find('VirtualLane');

	var lineNum = laneCount;
	if (lineNum > virtualLaneArray.length) {
		lineNum = virtualLaneArray.length;
	}

	var snapLines = {
		SnapLineList: {
			SnapLine:[]
		}
	};

	for (var i = 0; i < lineNum; i++) {
		var $line = virtualLaneArray.eq(i);

		var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
		var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
		var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
		var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

		var LineType = 0;
		var color = {r: 255, g: 0, b: 0};

		var _line = {
			id: 200+(i+1),
			LineType: LineType,
			Tips:  getNodeValue(szTips[LineType])+(i+1),
			StartPos: {
				x: startX,
				y: startY
			},
			EndPos: {
				x: endX,
				y: endY
			},
			color: color
		};

		snapLines.SnapLineList.SnapLine.push(_line);
	};


	var $rightLine = rightLine.eq(0);

	var startX = (parseFloat($rightLine.find('positionX').eq(0).text())/1000).toFixed(4);
	var startY = (parseFloat($rightLine.find('positionY').eq(0).text())/1000).toFixed(4);
	var endX = (parseFloat($rightLine.find('positionX').eq(1).text())/1000).toFixed(4);
	var endY = (parseFloat($rightLine.find('positionY').eq(1).text())/1000).toFixed(4);

	var LineType = ia(TriggerMode).TransLineType('laneRightBoundaryLine');
	var color = {r: 255, g: 0, b: 0};

	var _line = {
		id: 401,
		LineType: LineType,
		Tips:  getNodeValue(szTips[LineType]),
		StartPos: {
			x: startX,
			y: startY
		},
		EndPos: {
			x: endX,
			y: endY
		},
		color: color
	};
	snapLines.SnapLineList.SnapLine.push(_line);


	ocx.HWP_ClearSnapInfo(4);
	if (snapLines.SnapLineList.SnapLine.length) {
		var szLineInfo = x2js.json2xml_str(snapLines);
		ocx.HWP_SetSnapLineInfo(szLineInfo);
	}
}

function RestoreHVTRegion(restoreAll) {
	var ocx = $('#HVTDrawActiveX')[0];
	try{
    	var xml = ocx.HWP_GetSnapPolygonInfo();
    	var lineXml = ocx.HWP_GetSnapLineInfo();

    	var regionJson = x2js.xml_str2json(xmlToStr(postHVTTemp));

    	// 目标检测区域
    	if($('#objectDetectAera_HVT').prop('checked') || restoreAll){
    		var objArea = regionJson.PostHVT.ObjectDetectAera;
	    	$(parseXmlFromStr(xml)).find('SnapPolygon').each(function (i, p) {
	    		var regionId = $(p).find('id').text();
	    		regionId = parseInt(regionId);

	    		if (regionId == '100') {
	    			var sarr = [];
					$(p).find('point').each(function (i,n) {
						var x = Math.floor(parseFloat($(n).find('x').text())*1000);
						var y = Math.floor(parseFloat($(n).find('y').text())*1000);
						sarr.push({
							positionX: x,
							positionY: y
						});
					});

					objArea.AeraCoordinatesList = {
						AeraCoordinates: sarr
					};
	    		};
	    	});
    	}
    	

    	$(parseXmlFromStr(lineXml)).find('SnapLine').each(function () {
    		var lineId = $(this).find('id').eq(0).text();

    		var $st = $(this).find("StartPos");
    		var $et = $(this).find("EndPos");

    		var sx = Math.round(parseFloat($st.find('x').text())*1000);
			var sy = Math.round(parseFloat($st.find('y').text())*1000);
			var ex = Math.round(parseFloat($et.find('x').text())*1000);
			var ey = Math.round(parseFloat($et.find('y').text())*1000);

			var laneRightBoundaryLineType = ia(TriggerMode).TransLineType('laneRightBoundaryLine');
			var triggerLineType = ia(TriggerMode).TransLineType('triggerLine');
			var leftTriggerLineType = ia(TriggerMode).TransLineType('leftTriggerLine');
			var rightTriggerLineType = ia(TriggerMode).TransLineType('rightTriggerLine');

			if (($('#rightTriggerLine_HVT').prop('checked') || restoreAll)
					 && lineId == (rightTriggerLineType*100+2)) {
				var rts = regionJson.PostHVT.RightTriggerLineList.RightTriggerLine.RegionCoordinatesList;
    			delete rts.RegionCoordinates_asArray;
    			rts.RegionCoordinates = [{
    				positionX: sx,
    				positionY: sy
    			},{
    				positionX: ex,
    				positionY: ey
    			}];
			}else if (($('#leftTriggerLine_HVT').prop('checked') || restoreAll)
						 && lineId == (leftTriggerLineType*100+1)) {
				var rts = regionJson.PostHVT.LeftTriggerLineList.LeftTriggerLine.RegionCoordinatesList;
    			delete rts.RegionCoordinates_asArray;
    			rts.RegionCoordinates = [{
    				positionX: sx,
    				positionY: sy
    			},{
    				positionX: ex,
    				positionY: ey
    			}];
			}else if (lineId == triggerLineType*100) {  // 正背向触发线
				var rts = regionJson.PostHVT.TriggerLineList.TriggerLine.RegionCoordinatesList;
    			delete rts.RegionCoordinates_asArray;
    			rts.RegionCoordinates = [{
    				positionX: sx,
    				positionY: sy
    			},{
    				positionX: ex,
    				positionY: ey
    			}];
			}else if (lineId == laneRightBoundaryLineType*100) {  // 右车道线
    			var rts = regionJson.PostHVT.LaneRightBoundaryLineList.LaneRightBoundaryLine.RegionCoordinatesList;
    			delete rts.RegionCoordinates_asArray;
    			rts.RegionCoordinates = [{
    				positionX: sx,
    				positionY: sy
    			},{
    				positionX: ex,
    				positionY: ey
    			}];
    		}else if (lineId > 200 && lineId < 300) {  // 车道线
    			var cid = lineId%200;
    			var lrts = regionJson.PostHVT.HvtLaneList.HvtLane_asArray;
    			var vtc = null;
    			for (var i = 0; i < lrts.length; i++) {
    				var r = lrts[i];
    				if (r.HvtLaneNum == cid) {
    					var rl = r.LaneLineList.LaneLine.RegionCoordinatesList;
    					delete rl.RegionCoordinates_asArray;
    					rl.RegionCoordinates = [{
		    				positionX: sx,
		    				positionY: sy
		    			},{
		    				positionX: ex,
		    				positionY: ey
		    			}];
    					break;
    				}
    			};
    		};
    	});
   
    	postHVTTemp = x2js.json2xml(regionJson);
    }catch(e){
    	_log(e.message);
    }
}

function RestoreVTCoilRegion() {
	var ocx = $('#VTCoilDrawActiveX')[0];
	try{
    	var xml = ocx.HWP_GetSnapPolygonInfo();
    	var lineXml = ocx.HWP_GetSnapLineInfo();

    	var regionJson = x2js.xml_str2json(xmlToStr(vtCoilTemp));

    	var pregions = regionJson.PostVTCoil.VtCoilList.VtCoil_asArray;

    	$(parseXmlFromStr(xml)).find('SnapPolygon').each(function (i, p) {
    		var regionId = $(p).find('id').text();
    		regionId = parseInt(regionId);
    		for (var i = 0; i < pregions.length; i++) {
    			var r = pregions[i];
    			if (!r.vtCoilNum) {
    				continue;
    			}
    			var rrid = parseInt(r.vtCoilNum)+100;
    			if (rrid == regionId) {
    				var sarr = [];
    				$(p).find('point').each(function (i,n) {
    					var x = Math.floor(parseFloat($(n).find('x').text())*1000);
    					var y = Math.floor(parseFloat($(n).find('y').text())*1000);
    					sarr.push({
    						positionX: x,
    						positionY: y
    					});
    				});

    				r.RegionCoordinatesList = {
    					RegionCoordinates: sarr
    				};
    				break;
    			}
    		};
    	});

    	$(parseXmlFromStr(lineXml)).find('SnapLine').each(function () {
    		var lineId = $(this).find('id').eq(0).text();

    		var $st = $(this).find("StartPos");
    		var $et = $(this).find("EndPos");

    		var sx = Math.round(parseFloat($st.find('x').text())*1000);
			var sy = Math.round(parseFloat($st.find('y').text())*1000);
			var ex = Math.round(parseFloat($et.find('x').text())*1000);
			var ey = Math.round(parseFloat($et.find('y').text())*1000);

    		if (lineId == 300) {
    			var rts = regionJson.PostVTCoil.VirtualLaneList.VirtualLane.RegionCoordinatesList;
    			delete rts.RegionCoordinates_asArray;
    			rts.RegionCoordinates = [{
    				positionX: sx,
    				positionY: sy
    			},{
    				positionX: ex,
    				positionY: ey
    			}];
    		}else if (lineId > 200 && lineId < 300) {
    			var cid = lineId%200;
    			var lrts = regionJson.PostVTCoil.VtCoilList.VtCoil_asArray;
    			var vtc = null;
    			for (var i = 0; i < lrts.length; i++) {
    				var r = lrts[i];
    				if (r.vtCoilNum == cid) {
    					var rl = r.ViolationDetectLineList.ViolationDetectLine.RegionCoordinatesList;
    					delete rl.RegionCoordinates_asArray;
    					rl.RegionCoordinates = [{
		    				positionX: sx,
		    				positionY: sy
		    			},{
		    				positionX: ex,
		    				positionY: ey
		    			}];
    					break;
    				}
    			};
    		};
    	});
   
    	vtCoilTemp = x2js.json2xml(regionJson);
    }catch(e){
    	_log(e.message);
    }
}

function RestorePostMprRegion() {
	var ocx = $('#PostMprDrawPlugin')[0];
	try{
    	var xml = ocx.HWP_GetSnapPolygonInfo();
    	var lineXml = ocx.HWP_GetSnapLineInfo();

    	var regionJson = x2js.xml_str2json(xmlToStr(PostMprTemp));

    	//var pregions = regionJson.PostMpr.LaneParamList.LaneParam_asArray;
		

    	/*$(parseXmlFromStr(xml)).find('SnapPolygon').each(function (i, p) {
    		var regionId = $(p).find('id').text();
    		regionId = parseInt(regionId);
    		for (var i = 0; i < pregions.length; i++) {
    			var r = pregions[i];
    			if (!r.vtCoilNum) {
    				continue;
    			}
    			var rrid = parseInt(r.vtCoilNum)+100;
    			if (rrid == regionId) {
    				var sarr = [];
    				$(p).find('point').each(function (i,n) {
    					var x = Math.floor(parseFloat($(n).find('x').text())*1000);
    					var y = Math.floor(parseFloat($(n).find('y').text())*1000);
    					sarr.push({
    						positionX: x,
    						positionY: y
    					});
    				});

    				r.RegionCoordinatesList = {
    					RegionCoordinates: sarr
    				};
    				break;
    			}
    		};
    	});*/

    	$(parseXmlFromStr(lineXml)).find('SnapLine').each(function () {
    		var lineId = $(this).find('id').eq(0).text();

    		var $st = $(this).find("StartPos");
    		var $et = $(this).find("EndPos");

    		var sx = Math.round(parseFloat($st.find('x').text())*1000);
			var sy = Math.round(parseFloat($st.find('y').text())*1000);
			var ex = Math.round(parseFloat($et.find('x').text())*1000);
			var ey = Math.round(parseFloat($et.find('y').text())*1000);

    		if (lineId == 300) {
    			var rts = regionJson.PostMpr.VirtualLane.RegionCoordinatesList;
    			delete rts.RegionCoordinates_asArray;
    			rts.RegionCoordinates = [{
    				positionX: sx,
    				positionY: sy
    			},{
    				positionX: ex,
    				positionY: ey
    			}];
    		}else if (lineId > 200 && lineId < 300) {
    			var cid = lineId%200;
    			var lrts = regionJson.PostMpr.LaneParamList.LaneParam_asArray;
    			var vtc = null;
    			for (var i = 0; i < lrts.length; i++) {
    				var r = lrts[i];
    				if (r.laneNum == cid) {
    					var rl = r.ViolationDetectLine.RegionCoordinatesList;
    					delete rl.RegionCoordinates_asArray;
    					rl.RegionCoordinates = [{
		    				positionX: sx,
		    				positionY: sy
		    			},{
		    				positionX: ex,
		    				positionY: ey
		    			}];
    					break;
    				}
    			};
    		};
    	});
   
    	PostMprTemp = x2js.json2xml(regionJson);
    }catch(e){
    	_log(e.message);
    }
}

function InitVTCoilTempEle () {
	var x = xmlToStr(ia(TriggerMode).m_PostVTCoilXml);
	vtCoilTemp = x2js.parseXmlString(x);
}

function InitPostMprTempEle () {
	var x = xmlToStr(ia(TriggerMode).m_PostMprXml);
	PostMprTemp = x2js.parseXmlString(x);
}

var snapLinesTmpJson = [];

var colorMap = {
	'0': {r: 146, g:208, b:80},
	'1': {r: 255, g: 0, b:0},
	'2': {r: 255, g: 255, b: 0},
	'3': {r: 247, g: 150, b: 70}
};

var szTips = ["DrawLinebtn", "DrawStopLinebtn", "DrawWaitLinebtn", 
					"DrawCancelLinebtn", "Drawlanerightline", 
					"DrawTurnleftLinebtn", "DrawTurnRightLinebtn", "DrawRedLightLinebtn"];

var videoEpTmpObj = null;
function InitVideoEpTmpSnapLines () {
	// var o = $(ia(TriggerMode).m_VideoEpoliceXml).find('VideoEpolice').clone()
	// videoEpTmpObj = o[0];

	var x = xmlToStr(ia(TriggerMode).m_VideoEpoliceXml);
	videoEpTmpObj = x2js.parseXmlString(x);
}

var lineDis = 0.003;
var lineHeight = 0.06;
function genDefautWaitLine (totalLaneNum, curLaneNum, waitType) {
	var totalW = 0.8 - (totalLaneNum-1)*lineDis;
	var oneW = totalW/totalLaneNum;

	var startX, stopX;

	startX = 0.1+(curLaneNum-1)*(oneW+lineDis);
	stopX = startX + oneW;

	var startY, stopY;
	if (waitType == 'leftWait') {
		startY = 0.333;
		stopY = 0.333 - lineHeight;
	}else if (waitType == 'straightWait') {
		startY = 0.333;
		stopY = 0.333;
	}

	return {
		startX: startX,
		startY: startY,
		endX: stopX,
		endY: stopY
	};
}

function genDefautRedLightLine (totalLaneNum, curLaneNum) {
	var totalW = 0.8 - (totalLaneNum-1)*lineDis;
	var oneW = totalW/totalLaneNum;

	var startX, stopX;

	startX = 0.1+(curLaneNum-1)*(oneW+lineDis);
	stopX = startX + oneW;
	
	var startY = 0.5;
	var stopY = 0.5;

	return {
		startX: startX,
		startY: startY,
		endX: stopX,
		endY: stopY
	};
}



function DisplayVideoEpRegion (dispOpt, ocxSel, selMode, useTmpXmlEle) {
	if (!ocxSel) {
		ocxSel = '#PreviewActiveX';
	}

	var isByLane = $('#redLightMode').val() == '1';

	var opt = {
		laneLine: true, 
		laneRightBoundaryLine: true, 

		stopLine: true, 
		redlightLine: isByLane,
		cancelLine: true, 
		waitLine: {},
 		
 		turnLeftLine: true, 
 		turnRightLine: true,
 		//topZebraLine: true, 
 		//bottomZebraLine: true, 
 		plateRegion: true,
 		laneArray: true
 	};

 	opt = $.extend({}, opt, dispOpt);

 	var laneCount = parseInt($('#RelatedLaneCount_videoEp').val());

 	var dispLaneArr = [];
 	if (opt.laneArray === true) {
 		for (var i = 1; i <= laneCount; i++) {
			dispLaneArr.push(i);
		};
 	}else if ($.isArray(opt.laneArray)) {
 		dispLaneArr = opt.laneArray;
 	}
		
	var snapLines = {
		SnapLineList: {
			SnapLine:[]
		}
	};

	var xmlEle;
	if (!useTmpXmlEle) {
		xmlEle = ia(TriggerMode).m_VideoEpoliceXml;
	}else{
		xmlEle = videoEpTmpObj;
	}

	$(xmlEle).find("Lane").each(function (i, lane) {
		var $lane = $(lane);
		var laneId = parseInt($lane.find('laneId').eq(0).text());

		if (_.contains(dispLaneArr, laneId)) {
			$lane.find('ViolationDetectLine').each(function (idx, line) {
				var $line = $(line);
				var lineName = $line.find("lineName").eq(0).text();

				var oriStartX = parseFloat($line.find('positionX').eq(0).text(), 10)
				var oriStartY = parseFloat($line.find('positionY').eq(0).text(), 10)
				var oriEndX = parseFloat($line.find('positionX').eq(1).text(), 10)
				var oriEndY = parseFloat($line.find('positionY').eq(1).text(), 10)

				var draw = true;
				var waitType = false;

				if (lineName == 'waitLine') {
					var lineT = $lane.find('directionType').eq(0).text();
					waitType = lineT;

					if (opt.waitLine[laneId] === false) {  // 强制不绘
						draw = false;
					}else if (opt.waitLine[laneId]) {  // 强制绘
						draw = true;
					}else{  // 没有指定，按照坐标情况
						if (lineT != 'straightWait' && lineT != 'leftWait') {
							draw = false;
						}else if (_.every([oriStartX, oriStartY, oriEndX, oriEndY], function (ele) {
								return ele == 0;
							})) {
							draw = false;
						}
					}
				}else if (lineName == 'laneLine' && !_.isBoolean(opt[lineName])) {
					if (!$.isArray(opt[lineName])) {
						draw = false;
					}else if(!_.contains(opt[lineName], laneId)){
						draw = false; 
					}
				}

				if (opt[lineName] && draw) {
					var LineType = ia(TriggerMode).TransLineType(lineName);
					if (LineType < 8) {
						var startX = (oriStartX/1000).toFixed(4);
						var startY = (oriStartY/1000).toFixed(4);
						var endX = (oriEndX/1000).toFixed(4);
						var endY = (oriEndY/1000).toFixed(4);

						if (_.every([oriStartX, oriStartY, oriEndX, oriEndY], function (ele) {
								return ele == 0;
							})) {
							if (lineName == 'waitLine') {
								var def = genDefautWaitLine(laneCount, parseInt(laneId,10), waitType);
								startX = def.startX;
								startY = def.startY;
								endX = def.endX;
								endY = def.endY;
							}else if (lineName == 'redlightLine') {
								var def = genDefautRedLightLine(laneCount, parseInt(laneId,10), waitType);
								startX = def.startX;
								startY = def.startY;
								endX = def.endX;
								endY = def.endY;
							};
						};

						if (_.every([startX, startY, endX, endY], function (ele) {
								return ele == 0;
							})) {

						}

						var color = colorMap[LineType];
						if (!color) {
							color = {r: 255, g: 255, b: 0};
						}

						var _line = {
							id: laneId*100+LineType,
							LineType: LineType,
							Tips:  getNodeValue(szTips[LineType])+laneId,
							StartPos: {
								x: startX,
								y: startY
							},
							EndPos: {
								x: endX,
								y: endY
							},
							color: color
						};

						snapLines.SnapLineList.SnapLine.push(_line);
					}
				}
			});
		}		
	});
	
	//不是按车道显示的线
	$(xmlEle).find("VirtualLane").each(function(i, vl){
		var $vl = $(vl);
		var lineName = $vl.find("lineName").eq(0).text();

		if (opt[lineName]) {
			var LineType = ia(TriggerMode).TransLineType(lineName);
			if (LineType < 8) {
				var startX = (parseFloat($vl.find('positionX').eq(0).text())/1000).toFixed(4);
				var startY = (parseFloat($vl.find('positionY').eq(0).text())/1000).toFixed(4);
				var endX = (parseFloat($vl.find('positionX').eq(1).text())/1000).toFixed(4);
				var endY = (parseFloat($vl.find('positionY').eq(1).text())/1000).toFixed(4);

				var color = colorMap[LineType];
				if (!color) {
					color = {r: 255, g: 255, b: 0};
				}

				var _line = {
					id: 10*100+LineType,
					LineType: LineType,
					Tips:  getNodeValue(szTips[LineType]),
					StartPos: {
						x: startX,
						y: startY
					},
					EndPos: {
						x: endX,
						y: endY
					},
					color: color
				};
				snapLines.SnapLineList.SnapLine.push(_line);
			}
		}
	});

	var szLineInfo = x2js.json2xml_str(snapLines);

	var ocx = $(ocxSel)[0];

	//_log("szLineInfo="+szLineInfo);

	ocx.HWP_ClearSnapInfo(2);
	ocx.HWP_SetSnapLineInfo(szLineInfo);
	

	if (opt.plateRegion) {
		DisplayPlateRegionEx(dispLaneArr, ocxSel, null, useTmpXmlEle);
	}

	if (selMode) {
		try{
    		ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
    	}catch(e){}
	}
}

/*************************************************
Function:		DisplayRegion
Description:	显示区域
Input:			无			
Output:			无
return:			无	
*************************************************/
function DisplayRegion() {
	if($("#IsDispalyRegion").prop("checked")) {
		//需要保存当前tab的牌识区域
		try{
			var szInfo = HWP.GetSnapPolygonInfo();
			var szTempXmlDoc = $(parseXmlFromStr(szInfo));
			$(ia(TriggerMode).m_PlateRecognitionXml).find("regionId").each( function() {
				if($(this).text() == m_iLastSelIONum) {
					$(this).parent().remove();
				}
			});
			var szInfo1 = "<?xml version='1.0' encoding='UTF-8'?><PlateRegion><regionId>" + m_iLastSelIONum + "</regionId><RegionCoordinatesList>";
			var iIndex = 0;
			$(szTempXmlDoc).find("id").each( function(i) {
				if($(this).text() == m_iLastSelIONum && $(szTempXmlDoc).find("polygonType").eq(i).text() == 1) {
					iIndex = i;
				}
			});
			for(var i = 0; i < szTempXmlDoc.find("SnapPolygon").eq(iIndex).find("point").length; i++) {
				szInfo1 += "<RegionCoordinates><positionX>" + parseInt(szTempXmlDoc.find("SnapPolygon").eq(iIndex).find("x").eq(i).text()*1000) + "</positionX><positionY>" + parseInt(szTempXmlDoc.find("SnapPolygon").eq(iIndex).find("y").eq(i).text()*1000) + "</positionY></RegionCoordinates>";
			}
			szInfo1 += "</RegionCoordinatesList></PlateRegion>";
			$(ia(TriggerMode).m_PlateRecognitionXml).find("PlateRegionList").eq(0).append($(parseXmlFromStr(szInfo1)).find("PlateRegion").eq(0).clone().children());
			
			if($("#selTriggerMode").val() == "postVTCoil") { //需要保存当前Tab的虚拟线圈
				var iVtXmlIndex = 0;
				var szInfo1 = "<?xml version='1.0' encoding='UTF-8'?><RegionCoordinatesList>";
				$(ia(TriggerMode).m_PostVTCoilXml).find("vtCoilNum").each( function(i) {
					if($(this).text() == m_iLastSelIONum) {
						$(this).parent().find("RegionCoordinatesList").eq(0).remove();
						iVtXmlIndex = i;
					}
				});
				$(szTempXmlDoc).find("id").each( function(i) {
					if($(this).text() == m_iLastSelIONum && $(szTempXmlDoc).find("polygonType").eq(i).text() == 0) {
						iIndex = i;
					}
				});
				for(var i = 0; i < szTempXmlDoc.find("SnapPolygon").eq(iIndex).find("point").length; i++) {
					szInfo1 += "<RegionCoordinates><positionX>" + parseInt(szTempXmlDoc.find("SnapPolygon").eq(iIndex).find("x").eq(i).text()*1000) + "</positionX><positionY>" + parseInt(szTempXmlDoc.find("SnapPolygon").eq(iIndex).find("y").eq(i).text()*1000) + "</positionY></RegionCoordinates>";
				}
				szInfo1 += "</RegionCoordinatesList>";
				$(ia(TriggerMode).m_PostVTCoilXml).find("VtCoil").eq(iVtXmlIndex).append($(parseXmlFromStr(szInfo1)).find("RegionCoordinatesList").eq(0).clone().children());
			}
		}
		catch(e){
		}
		if(ia(TriggerMode).m_PlateRecognitionXml !== null) {
			var PlateNum = $(ia(TriggerMode).m_PlateRecognitionXml).find("PlateRegion").length;
			var strType = $("#selTriggerMode").val();
			if(strType == "postRS485" || strType == "postRadar" || strType == "epoliceRS485" || strType == "postEpoliceRS485") {
			    PlateNum = $(ia(TriggerMode).m_PlateRecognitionXml).find("PlateRegionCount").eq(0).text();
			}
			var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList>";
			for(var i = 0; i < $(ia(TriggerMode).m_PlateRecognitionXml).find("PlateRegion").length; i++) {
				if($(ia(TriggerMode).m_PlateRecognitionXml).find("regionId").eq(i).text() <= PlateNum) {
					szInfo3 += "<SnapPolygon><id>" + $(ia(TriggerMode).m_PlateRecognitionXml).find("regionId").eq(i).text() + "</id><polygonType>1</polygonType><tips>" + getNodeValue("PlateRegion") + $(ia(TriggerMode).m_PlateRecognitionXml).find("regionId").eq(i).text() + "</tips><isClosed>true</isClosed><color><r>255</r><g>255</g><b>0</b></color><pointList>";
					for(var j = 0; j < $(ia(TriggerMode).m_PlateRecognitionXml).find("PlateRegion").eq(i).find("RegionCoordinates").length; j++) {
						var positionX = parseFloat($(ia(TriggerMode).m_PlateRecognitionXml).find("PlateRegion").eq(i).find("positionX").eq(j).text())/1000;
						var positionY = parseFloat($(ia(TriggerMode).m_PlateRecognitionXml).find("PlateRegion").eq(i).find("positionY").eq(j).text())/1000;
						szInfo3 += "<point><x>" + positionX + "</x><y>" +  positionY + "</y></point>";
					}
					szInfo3 += "</pointList></SnapPolygon>";
				}
			}
			szInfo3 += "</SnapPolygonList>";
			try{
				ClearPolygon(3);
				var iRet = HWP.SetSnapPolygonInfo(szInfo3);
			}
			catch(e){
			}
		}
		//显示虚拟线圈
		if($("#selTriggerMode").val() == "postVTCoil") {
			var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList>";
			for(var i = 0; i < $(ia(TriggerMode).m_PostVTCoilXml).find("VtCoil").length; i++) {
				szInfo3 += "<SnapPolygon><id>" + $(ia(TriggerMode).m_PostVTCoilXml).find("vtCoilNum").eq(i).text() + "</id><polygonType>0</polygonType><tips>" + getNodeValue("VTCoil") + $(ia(TriggerMode).m_PostVTCoilXml).find("vtCoilNum").eq(i).text() + "</tips><isClosed>true</isClosed><color><r>255</r><g>0</g><b>0</b></color><pointList>";
				for(var j = 0; j < $(ia(TriggerMode).m_PostVTCoilXml).find("RegionCoordinatesList").eq(i).find("RegionCoordinates").length; j++) {
					var positionX = parseFloat($(ia(TriggerMode).m_PostVTCoilXml).find("RegionCoordinatesList").eq(i).find("positionX").eq(j).text())/1000;
					var positionY = parseFloat($(ia(TriggerMode).m_PostVTCoilXml).find("RegionCoordinatesList").eq(i).find("positionY").eq(j).text())/1000;
					szInfo3 += "<point><x>" + positionX + "</x><y>" + positionY  + "</y></point>";
				}
				szInfo3 += "</pointList></SnapPolygon>";
			}
			szInfo3 += "</SnapPolygonList>";
			HWP.SetSnapPolygonInfo(szInfo3);
		}
		//显示线
		if($("#selTriggerMode").val() == "videoEpolice") {
			var szInfo = HWP.GetSnapLineInfo();
			var szSnapLineXml = $(parseXmlFromStr(szInfo));
			var szTips = new Array("DrawLinebtn", "DrawStopLinebtn", "DrawWaitLinebtn", "DrawCancelLinebtn", "Drawlanerightline", "DrawTurnleftLinebtn", "DrawTurnRightLinebtn");
			if($(szSnapLineXml).find("x").length == 0){ //未生成任何线时显示原有的从设备获取回来的线
			    var szLineInfo = "<?xml version='1.0' encoding='utf-8'?><SnapLineList>";
				$(ia(TriggerMode).m_VideoEpoliceXml).find("ViolationDetectLine").each(function(){
					var id = $(this).parent().parent().find("laneId").eq(0).text();																	   					
					var LineType = ia(TriggerMode).TransLineType($(this).find("lineName").eq(0).text());
					if(LineType < 8) { //屏蔽设备送回来的线中目前不需要配置的线
						szLineInfo += "<SnapLine><id>" + id + "</id><LineType>" + LineType + "</LineType><Tips>" + getNodeValue(szTips[LineType]) + id + "</Tips>";
						szLineInfo += "<StartPos><x>" + parseFloat($(this).find("positionX").eq(0).text())/1000 + "</x><y>";
						szLineInfo += parseFloat($(this).find("positionY").eq(0).text())/1000 + "</y></StartPos>";
						szLineInfo += "<EndPos><x>" + parseFloat($(this).find("positionX").eq(1).text())/1000 + "</x><y>";
						szLineInfo += parseFloat($(this).find("positionY").eq(1).text())/1000 + "</y></EndPos>";
						if(LineType == 0) {
							szLineInfo += "<color><r>146</r><g>208</g><b>80</b></color>";
						} else if(LineType == 1) {
							szLineInfo += "<color><r>255</r><g>0</g><b>0</b></color>";
						} else if(LineType == 2) {
							szLineInfo += "<color><r>255</r><g>255</g><b>0</b></color>";
						} else if(LineType == 3) {
							szLineInfo += "<color><r>247</r><g>150</g><b>70</b></color>";
						}
						szLineInfo += "</SnapLine>";
					}
			    });
				$(ia(TriggerMode).m_VideoEpoliceXml).find("VirtualLane").each(function(){
					var LineType = ia(TriggerMode).TransLineType($(this).find("lineName").eq(0).text());
					if(LineType < 8) {
						szLineInfo += "<SnapLine><id>1</id><LineType>" + LineType + "</LineType><Tips>" + getNodeValue(szTips[LineType]) + "</Tips>";
						szLineInfo += "<StartPos><x>" + parseFloat($(this).find("positionX").eq(0).text())/1000 + "</x><y>";
						szLineInfo += parseFloat($(this).find("positionY").eq(0).text())/1000 + "</y></StartPos>";
						szLineInfo += "<EndPos><x>" + parseFloat($(this).find("positionX").eq(1).text())/1000 + "</x><y>";
						szLineInfo += parseFloat($(this).find("positionY").eq(1).text())/1000 + "</y></EndPos>";
						if(LineType == 4) {
							szLineInfo += "<color><r>146</r><g>208</g><b>80</b></color>";
						} else if(LineType == 5 || LineType == 6) {
							szLineInfo += "<color><r>255</r><g>255</g><b>0</b></color>";
						}
						szLineInfo += "</SnapLine>";
					}
				});
				szLineInfo += "</SnapLineList>";
				HWP.SetSnapLineInfo(szLineInfo);
				HWP.SetSnapDrawMode(0);
			}
		}
	} else {
		//需要保存当前tab的牌识区域
		var PlateXmlDoc = null;
		try{
			var szInfo = HWP.GetSnapPolygonInfo();
			var szTempXmlDoc = $(parseXmlFromStr(szInfo));
			$(szTempXmlDoc).find("id").each( function(i) {
				if($(this).text() == m_iLastSelIONum && $(szTempXmlDoc).find("polygonType").eq(i).text() == 1) {
					PlateXmlDoc = $(this).parent();
				}
			});
			if(PlateXmlDoc == null) {
				PlateXmlDoc = $(szTempXmlDoc);
			}
			$(ia(TriggerMode).m_PlateRecognitionXml).find("regionId").each( function() {
				if($(this).text() == m_iLastSelIONum) {
					$(this).parent().remove();
				}
			});
			var szInfo1 = "<?xml version='1.0' encoding='UTF-8'?><PlateRegion><regionId>" + m_iLastSelIONum + "</regionId><RegionCoordinatesList>";
			for(var i = 0; i < PlateXmlDoc.find("point").length; i++) {
				szInfo1 += "<RegionCoordinates><positionX>" + parseInt(PlateXmlDoc.find("x").eq(i).text()*1000) + "</positionX><positionY>" + parseInt(PlateXmlDoc.find("y").eq(i).text()*1000) + "</positionY></RegionCoordinates>";
			}
			szInfo1 += "</RegionCoordinatesList></PlateRegion>";
			$(ia(TriggerMode).m_PlateRecognitionXml).find("PlateRegionList").eq(0).append($(parseXmlFromStr(szInfo1)).find("PlateRegion").eq(0).clone().children());
			
			if($("#selTriggerMode").val() == "postVTCoil") { //需要保存当前Tab的虚拟线圈
				var iVtXmlIndex = 0;
				var szInfo1 = "<?xml version='1.0' encoding='UTF-8'?><RegionCoordinatesList>";
				$(ia(TriggerMode).m_PostVTCoilXml).find("vtCoilNum").each( function(i) {
					if($(this).text() == m_iLastSelIONum) {
						$(this).parent().find("RegionCoordinatesList").eq(0).remove();
						iVtXmlIndex = i;
					}
				});
				$(szTempXmlDoc).find("id").each( function(i) {
					if($(this).text() == m_iLastSelIONum && $(szTempXmlDoc).find("polygonType").eq(i).text() == 0) {
						iIndex = i;
					}
				});
				for(var i = 0; i < szTempXmlDoc.find("SnapPolygon").eq(iIndex).find("point").length; i++) {
					szInfo1 += "<RegionCoordinates><positionX>" + parseInt(szTempXmlDoc.find("SnapPolygon").eq(iIndex).find("x").eq(i).text()*1000) + "</positionX><positionY>" + parseInt(szTempXmlDoc.find("SnapPolygon").eq(iIndex).find("y").eq(i).text()*1000) + "</positionY></RegionCoordinates>";
				}
				szInfo1 += "</RegionCoordinatesList>";
				$(ia(TriggerMode).m_PostVTCoilXml).find("VtCoil").eq(iVtXmlIndex).append($(parseXmlFromStr(szInfo1)).find("RegionCoordinatesList").eq(0).clone().children());
			}
		}
		catch(e){
		}
		//显示当前区域
		for(var i = 0; i < $(ia(TriggerMode).m_PlateRecognitionXml).find("regionId").length; i++) {
			if($(ia(TriggerMode).m_PlateRecognitionXml).find("regionId").eq(i).text() == m_iCurSelIONum) {
				var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>" + m_iCurSelIONum + "</id><polygonType>1</polygonType><tips>" + getNodeValue("PlateRegion") + m_iCurSelIONum + "</tips><isClosed>true</isClosed><color><r>255</r><g>255</g><b>0</b></color><pointList>";
				for(var j = 0; j < $(ia(TriggerMode).m_PlateRecognitionXml).find("PlateRegion").eq(i).find("RegionCoordinates").length; j++) {
					szInfo3 += "<point><x>" + parseFloat($(ia(TriggerMode).m_PlateRecognitionXml).find("PlateRegion").eq(i).find("positionX").eq(j).text())/1000 + "</x><y>" +  parseFloat($(ia(TriggerMode).m_PlateRecognitionXml).find("PlateRegion").eq(i).find("positionY").eq(j).text())/1000 + "</y></point>";
				}
				szInfo3 += "</pointList></SnapPolygon></SnapPolygonList>";
				try{
					ClearPolygon(3);
					var iRet = HWP.SetSnapPolygonInfo(szInfo3);
				}
				catch(e){
				}
				break;
			}
		}
	    if($("#selTriggerMode").val() == "postVTCoil") { //显示虚拟线圈
			var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>" + m_iCurSelIONum + "</id><polygonType>0</polygonType><tips>";
			szInfo3 += getNodeValue("VTCoil") + m_iCurSelIONum + "</tips><isClosed>true</isClosed><color><r>255</r><g>0</g><b>0</b></color><pointList>";
			$(ia(TriggerMode).m_PostVTCoilXml).find("vtCoilNum").each( function(i) {
				if($(this).text() == m_iCurSelIONum) {
					iIndex = i;
				}
			});
			for(var j = 0; j < $(ia(TriggerMode).m_PostVTCoilXml).find("VtCoil").eq(iIndex).find("RegionCoordinates").length; j++) {
				szInfo3 += "<point><x>" + parseFloat($(ia(TriggerMode).m_PostVTCoilXml).find("VtCoil").eq(iIndex).find("positionX").eq(j).text())/1000 + "</x><y>" +  parseFloat($(ia(TriggerMode).m_PostVTCoilXml).find("VtCoil").eq(iIndex).find("positionY").eq(j).text())/1000 + "</y></point>";
			}
			szInfo3 += "</pointList></SnapPolygon>";
			szInfo3 += "</SnapPolygonList>";
			try{
				var iRet = HWP.SetSnapPolygonInfo(szInfo3);
			}
			catch(e){
			}
		}
		if($("#selTriggerMode").val() == "videoEpolice") {
			HWP.SetSnapDrawMode(0);
		}
	}
}
/*************************************************
Function:		CancelVideoDetectDlg
Description:	关闭视频检测窗口
Input:			无			
Output:			无
return:			无				
*************************************************/
function CancelVideoDetectDlg() {
	$("#main_plugin").show();
	if (HWP.Play() !== 0) {
		alert(getNodeValue("previewfailed"));
	}
	ia(TriggerMode).m_VideoEpoliceXml = m_szVideoEpoliceXmlDoc;
	$.modal.impl.close();
	//显示当前区域
	for(var i = 0; i < $(ia(TriggerMode).m_PlateRecognitionXml).find("regionId").length; i++) {
		if($(ia(TriggerMode).m_PlateRecognitionXml).find("regionId").eq(i).text() == m_iCurSelIONum) {
			var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>" + m_iCurSelIONum + "</id><polygonType>1</polygonType><tips>" + getNodeValue("PlateRegion") + m_iCurSelIONum + "</tips><isClosed>true</isClosed><color><r>255</r><g>255</g><b>0</b></color><pointList>";
			for(var j = 0; j < $(ia(TriggerMode).m_PlateRecognitionXml).find("PlateRegion").eq(i).find("RegionCoordinates").length; j++) {
				szInfo3 += "<point><x>" + parseFloat($(ia(TriggerMode).m_PlateRecognitionXml).find("PlateRegion").eq(i).find("positionX").eq(j).text())/1000 + "</x><y>" +  parseFloat($(ia(TriggerMode).m_PlateRecognitionXml).find("PlateRegion").eq(i).find("positionY").eq(j).text())/1000 + "</y></point>";
			}
			szInfo3 += "</pointList></SnapPolygon></SnapPolygonList>";
			try{
				ClearPolygon(3);
				var iRet = HWP.SetSnapPolygonInfo(szInfo3);
			}
			catch(e){
			}
			break;
		}
	}
}
/*************************************************
Function:		StartDrawRect
Description:	画矩形
Input:			无			
Output:			无
return:			无				
*************************************************/
function StartDrawRect() {
	$("#IsDispalyRegion").prop("checked", false);
	var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>" + m_iCurSelDetectIONum + "</id><polygonType>0</polygonType><tips>" + getNodeValue("laDetectArea") + m_iCurSelDetectIONum + "</tips><isClosed>false</isClosed><color><r>255</r><g>0</g><b>0</b></color><pointList></pointList></SnapPolygon></SnapPolygonList>";
	try{
		var iRet = $("#VideoDetectActiveX")[0].HWP_SetSnapPolygonInfo(szInfo3);
	}
	catch(e){
	}
	
	try{
		var iRet = $("#VideoDetectActiveX")[0].HWP_SetSnapDrawMode(0,1);
		if(iRet != 0) {
			alert(iRet);
		}
	}
	catch(e)
	{}
}
/*************************************************
Function:		OKVideoDetectDlg
Description:	点击视频检测窗口确定按钮
Input:			无			
Output:			无
return:			无				
*************************************************/
function OKVideoDetectDlg() {
	//保存当前选中区域的内容
	$(ia(TriggerMode).m_VideoEpoliceXml).find("lightNum").eq(m_iLastSelDetectIONum-1).text($("#lightNum").val());
	$(ia(TriggerMode).m_VideoEpoliceXml).find("straightLight").eq(m_iLastSelDetectIONum-1).text($("#straightLight").prop("checked").toString());
	$(ia(TriggerMode).m_VideoEpoliceXml).find("leftLight").eq(m_iLastSelDetectIONum-1).text($("#leftLight").prop("checked").toString());
	$(ia(TriggerMode).m_VideoEpoliceXml).find("rightLight").eq(m_iLastSelDetectIONum-1).text($("#rightLight").prop("checked").toString());
	$(ia(TriggerMode).m_VideoEpoliceXml).find("videoDetectLight").eq(m_iLastSelDetectIONum-1).find("redLight").eq(0).text($("#detectredLight").prop("checked").toString());
	$(ia(TriggerMode).m_VideoEpoliceXml).find("greenLight").eq(m_iLastSelDetectIONum-1).text($("#greenLight").prop("checked").toString());
	$(ia(TriggerMode).m_VideoEpoliceXml).find("yellowLight").eq(m_iLastSelDetectIONum-1).text($("#yellowLight").prop("checked").toString());
	$(ia(TriggerMode).m_VideoEpoliceXml).find("yellowLightTime").eq(m_iLastSelDetectIONum-1).text($("#yellowLightTime").val());
	
	var szInfo = $("#VideoDetectActiveX")[0].HWP_GetSnapPolygonInfo();
	var szTempXmlDoc = $(parseXmlFromStr(szInfo));
	
	var positionLeft = parseInt(szTempXmlDoc.find("x").eq(0).text()*m_iMainWndWidth);
	var positionTop = parseInt(szTempXmlDoc.find("y").eq(0).text()*m_iMainWndHeight);
	var positionRight = parseInt(szTempXmlDoc.find("x").eq(2).text()*m_iMainWndWidth);
	var positionBottom = parseInt(szTempXmlDoc.find("y").eq(2).text()*m_iMainWndHeight);
		
	$(ia(TriggerMode).m_VideoEpoliceXml).find("positionLeft").eq(m_iLastSelDetectIONum-1).text(positionLeft);
	$(ia(TriggerMode).m_VideoEpoliceXml).find("positionTop").eq(m_iLastSelDetectIONum-1).text(positionTop);
	$(ia(TriggerMode).m_VideoEpoliceXml).find("positionRight").eq(m_iLastSelDetectIONum-1).text(positionRight);
	$(ia(TriggerMode).m_VideoEpoliceXml).find("positionBottom").eq(m_iLastSelDetectIONum-1).text(positionBottom);

	
	$("#main_plugin").show();
	if (HWP.Play() !== 0) {
		alert(getNodeValue("previewfailed"));
	}
	$.modal.impl.close();
	m_iLastSelDetectIONum = 1;
	
	//显示当前区域
	for(var i = 0; i < $(ia(TriggerMode).m_PlateRecognitionXml).find("regionId").length; i++) {
		if($(ia(TriggerMode).m_PlateRecognitionXml).find("regionId").eq(i).text() == m_iCurSelIONum) {
			var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>" + m_iCurSelIONum + "</id><polygonType>1</polygonType><tips>" + getNodeValue("PlateRegion") + m_iCurSelIONum + "</tips><isClosed>true</isClosed><color><r>255</r><g>255</g><b>0</b></color><pointList>";
			for(var j = 0; j < $(ia(TriggerMode).m_PlateRecognitionXml).find("PlateRegion").eq(i).find("RegionCoordinates").length; j++) {
				szInfo3 += "<point><x>" + parseFloat($(ia(TriggerMode).m_PlateRecognitionXml).find("PlateRegion").eq(i).find("positionX").eq(j).text())/1000 + "</x><y>" +  parseFloat($(ia(TriggerMode).m_PlateRecognitionXml).find("PlateRegion").eq(i).find("positionY").eq(j).text())/1000 + "</y></point>";
			}
			szInfo3 += "</pointList></SnapPolygon></SnapPolygonList>";
			try{
				ClearPolygon(3);
				var iRet = HWP.SetSnapPolygonInfo(szInfo3);
			}
			catch(e){
			}
			break;
		}
	}
}



/*************************************************
 Function:		cancelPostSpeedModel
 Description:	点击IO测速取消按钮
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function cancelPostSpeedModel(){
    $("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    $.modal.impl.close();
    PostSpeedReDisplay();
}

function okPostSpeedModel(){
    $("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    RestorePlateRegion('#IOSpeedDrawActiveX');

    $.modal.impl.close();
    PostSpeedReDisplay();
}

function okPostRadarModel () {
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    RestorePlateRegion('#postRadarDrawActiveX');

    $.modal.impl.close();
    PostRadarReDisplay();
}

function cancelPostRadarModel () {
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    $.modal.impl.close();
    PostRadarReDisplay();
}

function okPostHVTModal () {
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }

   	var tmpObj = {};
    $('#leftTriggerLine_HVT, #rightTriggerLine_HVT, #objectDetectAera_HVT').each(function (i, n) {
    	var v = $(this).prop('checked');
    	
    	tmpObj[$(this).attr('id')] = v;
    });

    RestorePlateRegion('#HVTDrawActiveX', true);
    RestoreHVTRegion();

	ia(TriggerMode).m_postHVTXml = x2js.parseXmlString(xmlToStr(postHVTTemp));
	ia(TriggerMode).m_PlateRecognitionXml = x2js.parseXmlString(xmlToStr(plateRegionEleTemp));
    $.modal.impl.close();

    $.each(['leftTriggerLine_HVT', 'rightTriggerLine_HVT', 'objectDetectAera_HVT'], function (i, n) {
    	$('#'+n).prop('checked', tmpObj[n]);
    });

   	PostHVTReDisplay();
}

function cancelPostHVTModal () {
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }
    $('#HVTDraw_plugin').html('');
    $.modal.impl.close();

    PostHVTReDisplay();
}

function okPostVTCoilModal () {
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    RestorePlateRegion('#VTCoilDrawActiveX', true);
    RestoreVTCoilRegion();

	ia(TriggerMode).m_PostVTCoilXml = x2js.parseXmlString(xmlToStr(vtCoilTemp));
	ia(TriggerMode).m_PlateRecognitionXml = x2js.parseXmlString(xmlToStr(plateRegionEleTemp));

    $.modal.impl.close();

   PostVTCoilReDisplay();
}

function cancelPostVTCoilModal () {
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    $.modal.impl.close();
    PostVTCoilReDisplay();
}

function okPostMprModel () {
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }
    
   	RestorePlateRegion('#PostMprDrawPlugin',true);
	RestorePostMprRegion();
	
	ia(TriggerMode).m_PostMprXml = x2js.parseXmlString(xmlToStr(PostMprTemp));
	ia(TriggerMode).m_PlateRecognitionXml = x2js.parseXmlString(xmlToStr(plateRegionEleTemp));

    $.modal.impl.close();
	
	//PostMprRedisplay();
	if ($('#drawPicCheck').prop('checked')) {
		var laneCount = $('#RelatedLaneCount_videoEp').val();
		var arr = [];
		for (var i = 1; i <= laneCount; i++) {
			arr.push(i);
		}
		DisplayPlateRegionEx(arr, null, null);
		DisplayPostMprRegion(arr, null, {r:255,g:0,b:0});
	}else{
		DisplayPlateRegionEx([m_iCurSelIONum], null, null);
		DisplayPostMprRegion([m_iCurSelIONum], null, {r:255,g:0,b:0});
	}
	HWP.SetSnapDrawMode(-1);
}

function cancelPostMprModel () {
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }
    $.modal.impl.close();

   //PostMprRedisplay();
   if ($('#drawPicCheck').prop('checked')) {
		var laneCount = $('#RelatedLaneCount_videoEp').val();
		var arr = [];
		for (var i = 1; i <= laneCount; i++) {
			arr.push(i);
		}
		DisplayPlateRegionEx(arr, null, null);
		DisplayPostMprRegion(arr, null, {r:255,g:0,b:0});
	}else{
		DisplayPlateRegionEx([m_iCurSelIONum], null, null);
		DisplayPostMprRegion([m_iCurSelIONum], null, {r:255,g:0,b:0});
	}
	HWP.SetSnapDrawMode(-1);
}

function okEpoliceRS485Model () {
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    RestorePlateRegion('#Epolice485DrawActiveX');

    $.modal.impl.close();
    EpoliceRS485ReDisplay();
}

function cancelEpoliceRS485Model () {
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    $.modal.impl.close();
    EpoliceRS485ReDisplay();
}

function okPostEpoliceRS485Model () {
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    RestorePlateRegion('#PostEpolice485DrawActiveX');

    $.modal.impl.close();
    PostEpoliceRS485ReDisplay();
}

function cancelPostEpoliceRS485Model () {
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    $.modal.impl.close();
    PostEpoliceRS485ReDisplay();
}

function okPostRS485Modal () {
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    RestorePlateRegion('#postRS485DrawActiveX');

    $.modal.impl.close();
    PostRS485ReDisplay();
}

function cancelPostRS485Modal () {
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }

    $.modal.impl.close();
    PostRS485ReDisplay();
}

ia(TriggerMode).changeSnapTime = function(){
    // if(!$('#speedCapEnable_ioSpeed').prop("checked")){
    //     $('#firstCoilInterval4').val('0');
    //     $('#firstCoilInterval4').hide();
    //     $('#secondCoilInterval4').val('0');
    //     $('#secondCoilInterval4').hide();
    // }else{
        $('#firstCoilInterval4').show();
        $('#secondCoilInterval4').show();
    // }
}


function showAllShapes () {
	
//    postSingleIO	//单IO触发
//    postIOSpeed	//卡口IO测速
//    postRS485	//卡口车检器
//    postRadar	//卡口RS485雷达
//    epoliceIOTL				//混合车道触发 -------
//    epoliceRS485	//电警车检器
//    postEpoliceRS485//卡式电警车检器
//    postVTCoil	//卡口虚拟线圈
//    videoEpolice    //视频电警
//    PostMpr    //出入口视频

    var triggerMode = ia(TriggerMode).m_CurTriggerMode;
	switch(triggerMode) {
		case "postSingleIO":
		  SingleIoReDisplay(); 
		  break;
		case "postIOSpeed":
		  PostSpeedReDisplay();
		  break;
		case "postRadar":
		  PostRadarReDisplay();
		  break;
		case "postVTCoil":
		  PostVTCoilReDisplay();
		  break;
		case "epoliceRS485":
		  EpoliceRS485ReDisplay();
		  break;
		case "postRS485":
		  PostRS485ReDisplay();
		  break;
		case "postEpoliceRS485":
		  PostEpoliceRS485ReDisplay();
		  break;
		case "videoEpolice":
		  VideoEpRedispay();
		  break;
		case "PostMpr":
		  if ($('#drawPicCheck').prop('checked')) {
		     var laneCount = $('#RelatedLaneCount_videoEp').val();
		    var arr = [];
			for (var i = 1; i <= laneCount; i++) {
				arr.push(i);
			}
			DisplayPlateRegionEx(arr, null, null);
			DisplayPostMprRegion(arr, null, {r:255,g:0,b:0});
		  }else{
			  DisplayPlateRegionEx([m_iCurSelIONum], null, null);
			  DisplayPostMprRegion([m_iCurSelIONum], null, {r:255,g:0,b:0});
		  }
		  HWP.SetSnapDrawMode(-1);
		  break;
		case "postHVT":
			PostHVTReDisplay();
			break;
	}
}

// 补光模式
function changeCapModeHVT(value) {
	
}

function changeSpeedDetectorHVT(value) {
	if (value == 'radarSpeed') {
		$('#dvTriggerParam #radarEnabledContent').show();
	}else{
		$('#dvTriggerParam #radarEnabledContent').hide();
	}

	changeSpeedParam();
}

function changeSpeedParam () {
	var value = $('*[x-model=speedDetector]').val();

	if ((value == 'radarSpeed' || value == 'videoSpeed')
			&& ($('#vtoverSpeed').prop('checked') || $('#vtlowSpeed').prop('checked'))) {
		$('#speedParamDiv, #taTriggerMode #drawRightRegionContent').show();
	}else{
		$('#speedParamDiv, #taTriggerMode #drawRightRegionContent').hide();
	}
	autoResizeIframe();
}



function validateSetupParamForOverspeed(){
	$.ajax({
		type: "GET",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/ITCSetUp",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) {
			var focalType = $(xmlDoc).find("focalType").eq(0).text();
			if (focalType == 'unknown') {
				alert(getNodeValue("SetupParamValidForOverspeed"));
			};
		}
	});
}

function vtoverSpeedClicked(ele){
	if ($(ele).prop('checked') && $('#drawRightRegionContent #speedDetector').val() == '2') {  // 视频测速
		validateSetupParamForOverspeed();
	};
}

function videoEpOverSpeedClicked(ele){
	if ($(ele).prop('checked')) {  // 视频测速
		validateSetupParamForOverspeed();
	};
}