(function(window){
	var PlateRegion = window.PlateRegion || {};

	var tmpXmlEle = null;

	var oriXmlEle = null;

	PlateRegion.SetXml = function(xml){
		if (typeof xml == 'string') {
			oriXmlEle = parseXmlFromStr(xml);
		};
		oriXmlEle = xml;
	}

	PlateRegion.GenTmpXmlEle = function () {
		tmpXmlEle = parseXmlFromStr(xmlToStr(oriXmlEle));
	}

	PlateRegion.ConvertTmpToOri=function(){
		oriXmlEle=parseXmlFromStr(xmlToStr(tmpXmlEle));
	}

	PlateRegion.DisplayPlateRegionEx = function(regionIdArray, 
		ocxSel, color, useTmpXmlEle) {
		var domEle;
		if (useTmpXmlEle && tmpXmlEle) {
			domEle = tmpXmlEle;
		}else{
			domEle = oriXmlEle;	
		}
		 
		var $regionList = $(domEle).find('PlateRegion');

		var polygonArray = [];
		var obj = {
			SnapPolygonList:{
				SnapPolygon: []
			}
		};

		if (!color) {
			color = {r: 255, g:255, b:0};
		}

		$regionList.each(function (i, r) {
			var $r = $(r);
			var rid = parseInt($r.find('regionId').text());
			if (_.contains(regionIdArray, rid)) {
				var pts = [];
				var $_pts = $r.find('RegionCoordinates');
				$_pts.each(function (i, n) {
					var tx = parseInt($(n).find('positionX').text());
					var ty = parseInt($(n).find('positionY').text());
					pts.push({
						x:(tx/1000).toFixed(3),
						y:(ty/1000).toFixed(3)
					});
				});
				obj['SnapPolygonList']['SnapPolygon'].push({
					id: rid,
					polygonType: 1,
					color: color,
					tips: getNodeValue("PlateRegion")+rid,
					isClosed: "true",
					pointList: {
						point:pts
					}
				});
					
			};
		});
		var xml = x2js.json2xml_str(obj, true);
		//_log("RegionXml="+xml);
		try{
			if (!ocxSel) {
				ocxSel = '#PreviewActiveX';
			}
			var ocx = $(ocxSel)[0];
			ocx.HWP_ClearSnapInfo(1);
			ocx.HWP_SetSnapPolygonInfo(xml);
		}catch(e){}
	}

	PlateRegion.RestorePlateRegion = function(ocxSel, useTmpXmlEle) {
		var domEle;
		var useTmp = false;
		if (useTmpXmlEle && tmpXmlEle) {
			domEle = tmpXmlEle;
			useTmp = true;
		}else{
			domEle = oriXmlEle;	
		}

		var ocx = $(ocxSel)[0];
		try{
			//控件传的xml字符串
	    	var xml = ocx.HWP_GetSnapPolygonInfo();
            //根据PSIA协议得到的xml对象
	    	var regionJson = x2js.xml_str2json(xmlToStr(domEle));
            
	    	var pregions = regionJson.PlateRecognition.PlateRegionList.PlateRegion_asArray;
	    	$(parseXmlFromStr(xml)).find('SnapPolygon').each(function (i, p) {
	    		var regionId = $(p).find('id').text();
	    		for (var i = 0; i < pregions.length; i++) {
	    			var r = pregions[i];
	    			if (r.regionId == regionId) {
	    				var sarr = [];
	    				$(p).find('point').each(function (i,n) {
	    					var x = Math.floor(parseFloat($(n).find('x').text())*1000);
	    					var y = Math.floor(parseFloat($(n).find('y').text())*1000);
	    					sarr.push({
	    						positionX: x,
	    						positionY: y
	    					});
	    				});

	    				r.RegionCoordinatesList = {
	    					RegionCoordinates: sarr
	    				};
	    				break;
	    			}
	    		};
	    	});

	    	if (useTmp) {
	    		tmpXmlEle = x2js.json2xml(regionJson);
	    	}else{
	    		oriXmlEle = x2js.json2xml(regionJson);	
	    	}
	    }catch(e){
	    	log("error:"+e.message);
	    }
	}

	PlateRegion.GetPlateRecognition =function(url, callback){
		var self = this;

		$.ajax({
			type: "GET",
			url: url,
			timeout: 15000,
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				self.SetXml(xmlDoc);

				if (callback) {
					callback();					
				};
			}
		});
	}

	PlateRegion.SetPlateRecognition = function(url){
		var xmlDoc = oriXmlEle;
		
		$.ajax({
			type: "put",
			url: url,
			timeout: 15000,
			async: false,
			data: xmlToStr(xmlDoc),
			processData: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				$("#CurTriggerMode").html(getNodeValue("a" + $("#selTriggerMode").val()));
				if(ia(TriggerMode).m_bRebootRequired) {
					szRetInfo = m_szSuccessState + m_szSuccess5;
				} else {
					szRetInfo = m_szSuccessState + m_szSuccess1;
				}
				$("#SetResultTips").html(szRetInfo); 
			    setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			},
			error:function(xmlDoc, textStatus, xhr){
				szRetInfo = m_szErrorState + m_szError1;
		        $("#SetResultTips").html(szRetInfo); 
			    setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			}
		});
	}

	PlateRegion.reDrawPlateRegion =function (regionId, ocxSel) {
		var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>"
					+ regionId
					+ "</id><polygonType>1</polygonType><tips>" + getNodeValue('PlateRegion') + regionId
					+ "</tips><isClosed>false</isClosed><color><r>255</r><g>255</g><b>0</b></color><pointList/></SnapPolygon></SnapPolygonList>";
		var ocx = $(ocxSel)[0];
		try{
			var iRet = ocx.HWP_SetSnapPolygonInfo(szInfo3);
		}catch(e){}
		try{
			ocx.HWP_SetSnapDrawMode(0, 2);  //设置为选择模式
		}catch(e){}
	}




	window.PlateRegion = PlateRegion;

})(window);
