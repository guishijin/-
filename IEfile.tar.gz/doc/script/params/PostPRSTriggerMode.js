function PostPRSTriggerModeS () {
	SingletonInheritor.implement(this);	
}

SingletonInheritor.declare(PostPRSTriggerModeS);

PostPRSTriggerModeS.prototype.updateLang = function () {
	$('#CommendParamBtn, #SaveConfigBtn').hide();

	g_transStack.clear();
	var that = ia(PostPRSTriggerModeS);
	g_transStack.push(function() {
		var prsDoc = parent.translator.getLanguageXmlDoc("PostPRSTriggerMode");
		that.setLxd(prsDoc);

		var tModeDoc = parent.translator.getLanguageXmlDoc("TriggerMode");
		parent.translator.appendLanguageXmlDoc(that.getLxd(), tModeDoc);

		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	}, true);
};

(function() {
	var PostPRSTriggerMode = window.PostPRSTriggerMode || {};

	var ParamLoaded = false;
	
	var originalXml = null;
	var $xml = null;
	var sTriggerTypeCurNum=null;
	var triggerIONum=0;

	//cmd代表是否获得推荐值
	function GetParam(cmd){
		ParamLoaded = false;

		var tail = '';
		if (cmd) {
			tail = '/recommendation'
		};
        
		var laneCountRes = GetLaneCount();
		
		$.ajax({
	        type: "GET",
	        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/PostPRS"+tail,
	        timeout: 15000,
	        dataType: 'text', 
	        beforeSend: function(xhr) {
	            xhr.setRequestHeader("If-Modified-Since", "0");
	            
	        },
	        success: function(xmlDoc, textStatus, xhr) {
	            originalXml = parseXmlFromStr(xmlDoc);
	            $xml = $(originalXml);
                sTriggerTypeCurNum=$xml.find("triggerType").eq(0).text();
                $.g.setField2('#dvPostPRS #sTriggerType',sTriggerTypeCurNum);
                $.g.setField2('#dvPostPRS #capPicMode',$xml.find("capPicMode").eq(0).text());
                $.g.setField2('#dvPostPRS #capMode',$xml.find("capMode").eq(0).text());

	            var laneCount = $xml.find('laneCount').eq(0).text();

	            ParamLoaded = true;

	            fillLaneCountOptions(laneCountRes.min, laneCountRes.max, laneCount);

	            PostPRSTriggerMode.lastLaneIndex = false;
	            PostPRSTriggerMode.changePostPRSCount(laneCount);

	            PostPRSTriggerMode.changeTriggerType(sTriggerTypeCurNum);

	            GetPlateRegionParam(cmd);
	        },
	        error: function(xhr, textStatus, errorThrown) {
	            alert("获取参数失败！");
	        }
	    });
	}

	function GetPlateRegionParam(cmd){
		var url = m_lHttp + m_szHostName + ":"+m_lHttpPort + 
				"/PSIA/Custom/SelfExt/ITC/PlateRecognition/PostPRS";//PostPRS
		if (cmd) {
			url += "/recommendation";
		}

		PlateRegion.GetPlateRecognition(url, function(){
			displayRegions();
		});
	}

	function GetLaneCount () {
		var url = m_lHttp + m_szHostName + ":"+m_lHttpPort 
					+ '/PSIA/Custom/SelfExt/ITC/PostPRS/capabilities';
		var res = {
			min: 1, 
			max: 1
		};
		$.ajax({
			type: "GET",
			url: url,
			timeout: 15000,
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				var $nd = $(xmlDoc).find('laneCount').eq(0);
				if ($nd.length) {
					min = parseInt($nd.attr('min'));
					max = parseInt($nd.attr('max'));

					if (min >=0 && max >= 1) {
						res.min = min;
						res.max = max;
					};
				};
			}
		});

		return res;
	}

	function fillLaneCountOptions(min, max, curVal){
		if (min <= 0) {
			min = 1;
		}
        var $s = $('#RelatedLaneCount_PostPRS');
        $s.find('option').remove();
        for (var i=min; i <= max; i++) {
            var opt = "<option value='"+i+"' ";
            if (curVal != null && i == curVal) {
                opt += " selected='selected' ";
            }
            opt += ">"+i+"</option>";
            
            $s.append(opt);
        }
    }

	function SetParam(callback){
		ia(TriggerMode).m_bRebootRequired = false;

		PostPRSTriggerMode.restoreLaneParam();

		$xml.find('triggerType').eq(0).text($('#sTriggerType').val());
        $xml.find('capPicMode').eq(0).text($('#capPicMode').val());
        $xml.find('capMode').eq(0).text($('#capMode').val());
        
		$.ajax({
	        type: "PUT",
	        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/PostPRS",
	        timeout: 15000,
	        dataType:"text",
	        data: xmlToStr(originalXml),
			//processData: false,
	        beforeSend: function(xhr) {
	            xhr.setRequestHeader("If-Modified-Since", "0");
	            
	        },
			complete:function(xhr, textStatus) {
				if(xhr.status != 200) {
					if(xhr.status == 403) {
						var szErrorInfo = m_szError8;
						szRetInfo = m_szErrorState + szErrorInfo;
					} else {
						var xmlDoc =xhr.responseXML;
						if($(xmlDoc).find("detailedStatusCode").eq(0).text() != "") {
							var szErrorInfo = getNodeValue("Error" + $(xmlDoc).find("detailedStatusCode").eq(0).text());
						} else {
							var szErrorInfo = m_szError13;
						}
						szRetInfo = m_szErrorState + szErrorInfo;
					}
		            $("#SetResultTips").html(szRetInfo); 
			        setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			        return;	
				} else {
					if($(xhr.responseXML).find("statusCode").eq(0).text() == "7") {
						ia(TriggerMode).m_bRebootRequired = true;
					}

					if (callback) {
						callback();
					}
				}
			}
	    });
	}
    
    PostPRSTriggerMode.changeTriggerType=function(sTriggerTypeNum){
    	sTriggerTypeCurNum=sTriggerTypeNum;
    	if(sTriggerTypeNum=='0'){//视频检测
    		$('#capModeParam, #capPicModeParam').show();
    		$('#ioDefaultStatusParam, #relate485ChanParam, #postPrsRelatedIOParam').hide();
    	}else if(sTriggerTypeNum=='1'){//IO线圈
    		$('#capPicModeParam,#ioDefaultStatusParam,#postPrsRelatedIOParam').show();
    		$('#capModeParam, #relate485ChanParam').hide();
    	}else if(sTriggerTypeNum=='2'){//RS485
    		$('#capPicModeParam,#relate485ChanParam').show();
            $('#capModeParam,#ioDefaultStatusParam,#postPrsRelatedIOParam').hide();
    	}
    }

	PostPRSTriggerMode.changePostPRSCount = function (laneCount) {
		if (!laneCount) {
			laneCount = 1;
		};

		$('#tabPostPRS li').each(function (i, n) {
			if (i < laneCount) {
				$(this).show();
			}else{
				$(this).hide();
			}
		});

		var current = $('#tabPostPRS a.current').not(":hidden");
		if (current.length == 0) {
			this.selectLane(0);
		} else {
			var idx = current.eq(0).parent().attr('id').replace("aPostPRSLane", "");
			idx = parseInt(idx, 10) - 1;
			this.selectLane(idx);
		}

		displayRegions();
	}

	PostPRSTriggerMode.updateLang = function () {
		ia(PostPRSTriggerModeS).updateLang();
	}

	PostPRSTriggerMode.update = function () {
		if ($("#main_plugin").html() == "") {
			if (checkPlugin('2', getNodeValue('laPlugin'), 1, 'snapdraw', 0)) {
				if (!CompareFileVersion()) {
					UpdateTips();
				}
			}
		}

		triggerIONum=parseInt(pr(DeviceInfo).queryAlarmInNum());
		var sel=$("#postPrsRelatedIOParam #relateIO");
		sel.find('option').remove();
		for(var i=1;i<=triggerIONum;i++){
			sel.append("<option value='IO"+i+"'>IO"+i+"</option>");
		}
		GetParam();
		
		setTimeout(function(){
			if (HWP.Play() !== 0) {
				alert(getNodeValue("previewfailed"));
			}
		}, 300);

		autoResizeIframe();
	}
    
    //存储每个车道下的数据，非识牌区
	PostPRSTriggerMode.restoreLaneParam = function (laneIndex) {
		if (typeof laneIndex == 'undefined') {
			laneIndex = this.lastLaneIndex;
		};
		if (this.lastLaneIndex === false) {
			return;
		};

		var $lane = $xml.find('LaneParam').eq(laneIndex);

		$.each(['relate485Chan', 'IODefaultStatus',
				/*'capMode',*/ 'relateIO', 
				'relatedDriveWay','laneDirectionType'], function (i, n) {
				var v = $.g.getEleVal('#dvPostPRS #'+n);
				if (v !== '') {
					$lane.find(n).eq(0).text(v);
				}
			});
	}
    
    //显示此车道之前存储的数据，非识牌区
	PostPRSTriggerMode.displayLaneParam = function (laneIndex) {
		if (typeof laneIndex == 'undefined') {
			return;
		};
       
        var $laneparam=$xml.find("LaneParam").eq(laneIndex)

        $.each(['relate485Chan', 'relateIO', 
        	'IODefaultStatus', /*'capMode', */
        	'relatedDriveWay','laneDirectionType'], function (i, n) {
        	$.g.setField2('#dvPostPRS #'+n, $laneparam.find(n).eq(0).text());		
        });
	}

	PostPRSTriggerMode.selectLane = function (laneIndex) {
		var $a = $('#tabPostPRS a').eq(laneIndex);
		if (!$a.length) {
			return;
		};

		$('#tabPostPRS a').removeClass('current');
		$a.addClass('current');

		this.restoreLaneParam();
		this.displayLaneParam(laneIndex);

		this.lastLaneIndex = laneIndex;

		this.showAllShapes();
	}

	PostPRSTriggerMode.GetCommendParam = function(){
		GetParam(true);
	}

	PostPRSTriggerMode.SetParam = function(){
		SetParam(function(){
			var url = m_lHttp + m_szHostName + ":"+m_lHttpPort + 
				"/PSIA/Custom/SelfExt/ITC/PlateRecognition/PostPRS";
			PlateRegion.SetPlateRecognition(url);
		});
	}

	PostPRSTriggerMode.showAllShapes = function(){
		var idxArr = [];

		var v = $('#drawPicCheck').prop('checked');
		if (v) {
			var laneCount = $('#RelatedLaneCount_PostPRS').val();
	    	laneCount = parseInt(laneCount, 10);

	    	idxArr = $.g.range(laneCount, 1);
		}else{
			if (this.lastLaneIndex === false) {
				idxArr = [1];
			}else{
				idxArr.push(this.lastLaneIndex+1);
			}
		}

		DisplayPostPRSShapes(idxArr);
	}

    //线数据存储临时变量
	var PostPRSTmp;

	function RestorePostPRSToTmpObj () {
		//将线数据存到临时变量中
		RestorePRSLines('#PostPRSDrawPlugin');
		//将区域数据存到临时变量中
		PlateRegion.RestorePlateRegion('#PostPRSDrawPlugin', true);
	}
    
	function RestorePRSLines (ocxSel) {
		var ocx = $(ocxSel)[0];
		if (!ocx) {
			return;
		};

		var $xmlDoc = $(PostPRSTmp);

		var lineXml = ocx.HWP_GetSnapLineInfo();
		$(parseXmlFromStr(lineXml)).find('SnapLine').each(function () {
			var lineId = $(this).find('id').eq(0).text();

			var $st = $(this).find("StartPos");
			var $et = $(this).find("EndPos");

			var sx = parseFloat($st.find('x').text());
			var sy = parseFloat($st.find('y').text());
			var ex = parseFloat($et.find('x').text());
			var ey = parseFloat($et.find('y').text());

			lineId = parseInt(lineId,10);

			sx = Math.floor(sx*1000);
			sy = Math.floor(sy*1000);
			ex = Math.floor(ex*1000);
			ey = Math.floor(ey*1000);

			var $line;

			if (lineId == 300) { //车道右边界线
				$line = $xmlDoc.find('VirtualLane').eq(0);
			}else if (lineId > 200 && lineId < 300){   // 车道线
				var lineNum = lineId % 100 - 1;
				$line = $xmlDoc.find('ViolationDetectLine').eq(lineNum);
			}

			$line.find('positionX').eq(0).text(sx);
			$line.find('positionX').eq(1).text(ex);
			$line.find('positionY').eq(0).text(sy);
			$line.find('positionY').eq(1).text(ey);
		});

	}

	function DisplayPostPRSShapes (regionIdArray, ocxSel, 
    				color, useTmpXmlEle, dispOpt) {
        //画线
		DisplayPostPRSLines(regionIdArray, ocxSel, 
    				color, useTmpXmlEle, dispOpt);
        //画区域
		PlateRegion.DisplayPlateRegionEx(regionIdArray, 
					ocxSel, color, useTmpXmlEle);
	}

    function DisplayPostPRSLines (regionIdArray, ocxSel, 
    				color, useTmpXmlEle, dispOpt) {
	    var domEle;
	    if (useTmpXmlEle && PostPRSTmp) {
	    	domEle = PostPRSTmp;
	    }else{
		    domEle = originalXml;	
	    }

	    if (!color) {
		    color = {r: 255, g:255, b:0};
	    }

	    if (!ocxSel) {
		    ocxSel = '#PreviewActiveX';
	    }
	    var ocx = $(ocxSel)[0];

	    var opts = {
		    laneLine: true,
		    laneRightBoundaryLine: true
	    };

	    try{
	    	ocx.HWP_ClearSnapInfo(2);
	    }catch(e){}

	    opts = $.extend({}, opts, dispOpt);

	    if (!opts.laneLine && !opts.laneRightBoundaryLine) {
			return;
	    }

	    var snapLines = {
		    SnapLineList: {
		    	SnapLine:[]
		    }
	    };

	    if (opts.laneLine) {
	    	$(domEle).find('LaneParam').each(function () {
	    		var $line = $(this).find('ViolationDetectLine').eq(0);
			    var laneId = parseInt($(this).find('laneNum').text());

			    if (_.contains(regionIdArray, laneId)) {
			    	var lineName = $line.find('lineName').eq(0).text();

				    if (lineName == 'laneLine') {
				    	var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
					    var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
					    var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
					    var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

					    var LineType = ia(TriggerMode).TransLineType(lineName);

					    var color = colorMap[LineType];
					    if (!color) {
					    	color = {r: 255, g: 255, b: 0};
					    }

					    var _line = {
					    	id: 200+laneId,
						    LineType: LineType,
						    Tips:  getNodeValue(szTips[LineType])+laneId,
						    StartPos: {
						    	x: startX,
							    y: startY
						    },
						    EndPos: {
							    x: endX,
							    y: endY
						    },
						    color: color
					    };

					    snapLines.SnapLineList.SnapLine.push(_line);
				    }
			    }
		    });
	    }

	    if (opts.laneRightBoundaryLine) {
	    	var $line = $(domEle).find('VirtualLane').eq(0);
		    var lineName = $line.find('lineName').eq(0).text();

		    if (lineName == 'laneRightBoundaryLine') {
		    	var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
			    var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
			    var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
			    var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

			    var LineType = ia(TriggerMode).TransLineType(lineName);

			    var color = colorMap[LineType];
			    if (!color) {
			    	color = {r: 255, g: 255, b: 0};
			    }

			    var _line = {
			    	id: 300,
				    LineType: LineType,
				    Tips:  getNodeValue(szTips[LineType]),
				    StartPos: {
				    	x: startX,
					    y: startY
				    },
				    EndPos: {
				    	x: endX,
					    y: endY
				    },
				    color: color
			    };

			    snapLines.SnapLineList.SnapLine.push(_line);
		    }
	    }
	    
	    if (snapLines.SnapLineList.SnapLine.length) {
		    var szLineInfo = x2js.json2xml_str(snapLines);
		    ocx.HWP_SetSnapLineInfo(szLineInfo);
	    }
    }

	PostPRSTriggerMode.SelectPostPRSModal = function(laneIndex){
		$("#tabPostPRSModal").find("li a").removeClass('current');
		$("#tabPostPRSModal li").eq(laneIndex).find("a").addClass("current");
	}

	function drawLines() {
		RestorePostPRSToTmpObj();

		var selIdx = -1;
	    var idxArr = [];
	    $("#tabPostPRS").find("li").not(":hidden").each(function() {
	    	var idx = $(this).attr('id').replace("aPostPRSLane", "");
            idx = parseInt(idx);
            idxArr.push(idx);

            if($(this).children().hasClass("current")) {
            	selIdx = idx;
            }
        });
    
	    var opt = {
	    	laneLine: $('#laneLine_PostPRS').prop('checked'),
    	    laneRightBoundaryLine: $('#laneRightLine_PostPRS').prop('checked')
        };

	    DisplayPostPRSShapes(idxArr, '#PostPRSDrawPlugin', null, true, opt);

	    var ocx = $('#PostPRSDrawPlugin')[0];		
		try{
			ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
		}catch(e){}
    }

	PostPRSTriggerMode.initEvt=function(){
		$('#laneLine_PostPRS, #laneRightLine_PostPRS').prop('checked', true).unbind().click(drawLines);
	}


	PostPRSTriggerMode.reDrawPostPRSPlateRegion=function() {
	    var selIdx = -1;
	    $("#tabPostPRSModal").find("li").each(function() {
	    	if($(this).children().hasClass("current")) {
	    		var idx = $(this).attr('id').replace("liPostPRS", "");
        	    selIdx = parseInt(idx);
            }
        });
	    if (selIdx >= 0) {
	    	PlateRegion.reDrawPlateRegion(selIdx, '#PostPRSDrawPlugin');
	    }
    }

    PostPRSTriggerMode.initPostPRSTemp = function () {
    	var x = xmlToStr(originalXml);
		PostPRSTmp = x2js.parseXmlString(x);
    }

	PostPRSTriggerMode.ShowDrawPolygonModal = function() {
		if (!g_bIsIE) {
	        $("#PostPRS_Draw_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='PostPRSDrawPlugin' width='100%' height='100%' name='PostPRSDrawPlugin' align='center' wndtype='1' playmode='snapdraw'>");
	    } else {
	        $("#PostPRS_Draw_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='PostPRSDrawPlugin' width='100%' height='100%' name='PostPRSDrawPlugin' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
	    }
        //初始化线的临时变量
		this.initPostPRSTemp();
		//初始化区域的临时变量
		PlateRegion.GenTmpXmlEle();

	    var idxArr = [];

	    var laneCount = $('#RelatedLaneCount_PostPRS').val();
	    laneCount = parseInt(laneCount, 10);
	    
	    for (var i = 0; i < 6; i++) {
	    	if (i < laneCount) {
	    		idxArr.push(i+1);
	    		var j = i+1;
	    		$('#liPostPRS'+(i+1)).show();
	    	}else{
	    		$('#liPostPRS'+(i+1)).hide();
	    	}
	    };
        
        $('#PostPRSModalDiv').modal();

        PostPRSTriggerMode.initEvt();

        setTimeout(function () {
        	DisplayPostPRSShapes(idxArr, '#PostPRSDrawPlugin', null, true);

	        var ocx = $('#PostPRSDrawPlugin')[0];		
			try{
				//设置为选择模式
				ocx.HWP_SetSnapDrawMode(0, 3);  
			}catch(e){}
        }, 500);

        HWP.Stop();
        $("#main_plugin").hide();

        var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
        var iRet = $("#PostPRSDrawPlugin")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
        if (iRet !== 0) {
            alert(getNodeValue("previewfailed"));
        }
	}


	function displayRegions(){
		PostPRSTriggerMode.showAllShapes();
	}


	PostPRSTriggerMode.OkModel = function(){
		$("#main_plugin").show();
	    if (HWP.Play() !== 0) {
	        alert(getNodeValue("previewfailed"));
	    }
	    
	   	RestorePostPRSToTmpObj();
        originalXml=parseXmlFromStr(xmlToStr(PostPRSTmp));
        PlateRegion.ConvertTmpToOri();

	    $.modal.impl.close();
	    displayRegions();
	}

	PostPRSTriggerMode.CancelModel = function () {
		$("#main_plugin").show();
	    if (HWP.Play() !== 0) {
	        alert(getNodeValue("previewfailed"));
	    }
	    $.modal.impl.close();

	    displayRegions();
	}

	window.PostPRSTriggerMode = PostPRSTriggerMode;
})();

