
$(function () {
	document.onkeydown = function(e){
		var ev = e || window.event;  
	    var obj = ev.target || ev.srcElement;
	    var t = obj.type || obj.getAttribute('type');  

	    var vReadOnly = obj.readOnly; 
	    var vDisabled = obj.disabled; 

	    vReadOnly = (vReadOnly == undefined) ? false : vReadOnly; 
	    vDisabled = (vDisabled == undefined) ? true : vDisabled; 

	    //并且readOnly属性为true或disabled属性为true的，则退格键失效 
	    var flag1= ev.keyCode == 8 && (t=="password" || t=="text" || t=="textarea")&& (vReadOnly==true || vDisabled==true); 
	    //当敲Backspace键时，事件源类型非密码或单行、多行文本的，则退格键失效 
	    var flag2= ev.keyCode == 8 && t != "password" && t != "text" && t != "textarea" ; 
	    //判断 
	    if(flag2 || flag1)return false; 
	}
})

var xmldocITCPicOSDType=null;
var PicOverlapItems=[];
var PicOverlap_SelectedItems = [];
var overlayTypeInfoNum=0;
//获取字符叠加能力数据，包含名称
function getITCPicOSDType(){
	PicOverlapItems=[];
	$.ajax({
		url:m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Snapshot/channels/1/ITCPicOSDType",
		async:false,
		type:"GET",
		dataType:"text",
		beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success:function(xmldoc,textstatus,xhr){
        	xmldocITCPicOSDType=parseXmlFromStr(xmldoc);
        	var $xml=$(xmldocITCPicOSDType);
        	try{
        		overlayTypeInfoNum=parseInt($xml.find("overlayTypeInfoNum").eq(0).text());
        		//overlayTypeInfoNum=$xml.find("overlayTypeInfo").length;
        	}
        	catch(e){
        		overlayTypeInfoNum=0;
        	}
        	for(var i=0;i<overlayTypeInfoNum;i++){
        		var overlayTypeInfo=$xml.find("overlayTypeInfo").eq(i);
        		var itemType=parseInt($(overlayTypeInfo).find("itemType").eq(0).text());
        		var overlayTypeText=$(overlayTypeInfo).find("overlayTypeText").eq(0).text();
        		initItems(itemType,overlayTypeText);
        	}
        	return true;
        },
        error:function(xhr){
        	return false;
        }
	});
}

//初始加载字符叠加项
function initItems(itemType,itemName){
	var item=null;

	switch(itemType){
		case 1:
			item={
			    itemType: 1,
			    itemName: itemName,
			    editable: true,
			    maxlength: 88
			};
			break;
		case 2:
			item={
			    itemType: 2,
			    itemName: itemName,
			    editable: true,
			    maxlength: 31
			};
			break;
		case 3:
			item={
			    itemType: 3,
			    itemName: itemName,
			    editable: true,
			    maxlength: 31
			};
			break;
		case 4:
			item={
			    itemType: 4,
			    itemName: itemName,
			    editable: true,
			    maxlength: 31
			};
			break;
		case 5:
			item={
			    itemType: 5,
			    itemName: itemName,
			    editable: true,
			    maxlength: 31
			};
			break;
		case 6:
			item={
			    itemType: 6,
			    itemName: itemName
			};
			break;
		case 7:
			item={
			    itemType: 7,
			    itemName: itemName,
			    editable: true,
			    maxlength: 31
			};
			break;
		case 8:
			item={
			    itemType: 8,
			    itemName: itemName,
			    useMs: false
			};
			break;
		case 9:
			item={
			    itemType: 9,
			    itemName: itemName
			};
			break;
		case 10:
			item={
			    itemType: 10,
			    itemName: itemName
			};
			break;
		case 11:
			item={
			    itemType: 11,
			    itemName: itemName
			};
			break;
		case 12:
			item={
			    itemType: 12,
			    itemName: itemName
			};
			break;
		case 13:
			item={
			    itemType: 13,
			    itemName: itemName
			};
			break;
		case 14:
			item={
			    itemType: 14,
			    itemName: itemName
			};
			break;
		case 15:	
			item={
			    itemType: 15,
			    itemName: itemName
			};
			break;
		case 16:
			item={
			    itemType: 16,
			    itemName: itemName
			};
			break;
		case 17:
			item={
			    itemType: 17,
			    itemName: itemName
			};
			break;
		case 18:
			item={
			    itemType: 18,
			    itemName: itemName,
			    maxlength1: 43,
			    maxlength2: 31
			};
			break;
		case 19:
			item={
			    itemType: 19,
			    itemName: itemName
			};
			break;
		case 20:
			item={
			    itemType: 20,
			    itemName: itemName
			};
			break;
		case 21:
			item={
			    itemType: 21,
			    itemName: itemName,
			    useMs: false
			};
			break;
		case 22:
			item={
			    itemType: 22,
			    itemName: itemName,
			    useMs: false
			};
			break;
		case 23:
			item={
			    itemType: 23,
			    itemName: itemName,
			    useMs: false
			};
			break;
		case 24:
			item={
			    itemType: 24,
			    itemName: itemName
			};
			break;
		case 25:
			item={
			    itemType: 25,
			    itemName: itemName
			};
			break;
		case 26:
			item={
			    itemType: 26,
			    itemName: itemName
			};
			break;
		case 27:
			item={
				itemType: 27,   // 监测点编号
				itemName: itemName,
				editable: true,
			    maxlength: 31
			};
			break;
		case 28:
			item={
				itemType: 28,   // 遮阳板
				itemName: itemName
			};
			break;
		case 29:
			item={
				itemType: 29,   // 车道行驶方向
				itemName: itemName
			};
			break;
		case 30:
			item={
				itemType: 30,   // 
				itemName: itemName
			};
			break;
		case 31:
			item={
				itemType: 31,   // 
				itemName: itemName
			};
			break;
		case 32:
			item={
				itemType: 32,   // 
				itemName: itemName
			};
			break;
		case 33:
			item={
				itemType: 33,   // 黄标车检测
				itemName: itemName
			};
			break;
		case 34:
			item={
				itemType: 34,   // 危险品车检测
				itemName: itemName
			};
			break;
		default:
			item={
				itemType: itemType, 
				itemName: itemName
			};
			break;
	}
	if(null!=item){
		PicOverlapItems.push(item);
	}
}

//table列表的字符叠加名称改变时触发的事件
function itemNameOnblur(itemType,itemName){
	
	$.each(PicOverlap_SelectedItems,function(i,selectedItem){
		if(itemType==selectedItem.itemType){
			selectedItem.itemName=itemName;
		}
	});
	
	if(itemType){
		try{
			for(var i=0;i<PicOverlapItems.length;i++){
				if(PicOverlapItems[i].itemType==itemType){
					PicOverlapItems[i].itemName=itemName;
					$("#lasingleIocheckbox_"+itemType).html(itemName);
				}
			}
		}
		catch(e){
			
		}		
	}
	autoResizeIframe();
}

//保存字符叠加能力数据，包含名称
function setITCPicOSDType(iType){
	var $xml=$(xmldocITCPicOSDType);
	var flag=false;
	$.each(PicOverlapItems,function(i,item){
		if(getStrLen(item.itemName)>31){
			$("#SetResultTips").html(m_szErrorState+item.itemName+":长度不能超过31字节!");
			var $table = $('#SingleOverlayInfoList');
			$tr = $table.find('tr[itemType='+item.itemType+']');
			$tr.find('td[field=itemName]').addClass('error');
			autoResizeIframe();
			flag=true;
			return false;
		}
		var itemName=$("#lasingleIocheckbox_"+item.itemType).html();
		$xml.find("overlayTypeInfo").eq(i).find("overlayTypeText").text(itemName);
	});
	setTimeout(function(){
		$("#SetResultTips").html("");
		$('#SingleOverlayInfoList').find('td').removeClass('error');
	},5000);
	if(flag){
		return flag;
	}else{
		$.ajax({
			type:"put",
			url:m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Snapshot/channels/1/ITCPicOSDType",
			timeout: 15000,
			data:xmlToStr(xmldocITCPicOSDType),
			beforeSend: function(xhr) {
	            xhr.setRequestHeader("If-Modified-Since", "0");
	            
	        },
	        complete:function(xhr,textstatus){
	        	if(xhr.status==200){
	        		submitPicOSD(iType);
	        	}else{
	        		SaveState(xhr);
	        	}
	        }
		});
	}
		
	
}

function InitItemTypes () {
	for (var i = 0; i < PicOverlapItems.length; i++) {
		var pt = PicOverlapItems[i];
		pt.itemName = getNodeValue("itemTypeOpt"+pt.itemType);
	};
}

function GetPicOverlapItem (itemType) {
	var item = _.find(PicOverlapItems, function (it) {
		return it.itemType == itemType;
	});
	return item;
}


function PicOverlap_InitItems (objContainer, objTable) {
	//yqw 新改初始化叠加项 begin
	//InitItemTypes();
	PicOverlapItems=[];
	getITCPicOSDType();
	//end

	PicOverlap_SelectedItems.length = 0;
	var $container = objContainer;
	var $table = objTable;
	$container.find('*').remove();
	$.each(PicOverlapItems, function (i, item) {
        if((item.itemType !=37) && (item.itemType !=38) && (item.itemType !=39)) {
            var arr = [
                '<div class="picOverlapItem">',
                    '<input id="picOverlapType_' + item.itemType + '" itemType="' + item.itemType + '" type="checkbox" ',
                ' class="picOverlapItemChkbox">&nbsp;',
                    '<label for="picOverlapType_' + item.itemType + '" id="lasingleIocheckbox_' + item.itemType,
                    '" class="picOverlapItemLabel">' + item.itemName + '</label> ',
                '</div>'
            ];
            $container.append(arr.join(''));
        }
	});
	if($container.is("#picOverlayItemsDiv")) {
		$('#selectAllPicItems').unbind().click(function () {
			var v = $(this).prop('checked');
			$("#picOverlayItemsDiv").find('input.picOverlapItemChkbox').each(function () {
				if ($(this).prop('checked') != v) {
					$(this).prop('checked', v).click().prop('checked', v);
				}
			});
		});
	} 
	$container.find('input.picOverlapItemChkbox').click(function () {
		var itemType = $(this).attr('itemType');
		var item = GetPicOverlapItem(itemType);
		if (!item) {
			return;
		};
		if ($(this).prop('checked')) {
			PicOverlap_SelectedItems.push({
				itemType: itemType,
				itemName: item.itemName,
				editable: item.editable,
				changeLineNum: 0,
				spaceNum: 0,
				overlayInfoText: item.overlayInfoText,
				overlayInfoText2: item.overlayInfoText2,
				maxlength: item.maxlength,
				maxlength1: item.maxlength1,
				maxlength2: item.maxlength2,
				startPosEnable: item.startPosEnable,
				startPosTop: 0,
				startPosLeft: 0
			});
		}else{
			var idx = -1;
			_.each(PicOverlap_SelectedItems, function (item, i) {
				if (item.itemType == itemType) {
					idx = i;
					return;
				}
			});
			if (idx >= 0) {
				PicOverlap_SelectedItems.splice(idx, 1);
			}
		}
		PicOverlap_RenderAll($table);
		
		PicOverlap_ResetPicPosition();

		var allChecked = true;
		$container.find('input.picOverlapItemChkbox').each(function () {
			if (!$(this).prop('checked')) {
				allChecked = false;
				return;
			}
		});
		if (allChecked) {
			$('#selectAllPicItems').prop('checked', true);
		}else{
			$('#selectAllPicItems').prop('checked', false);
		}		
	});

	$table.delegate('tr', 'click', function () {
		var itemType = $(this).attr('itemType');

		var $curSelTr = $table.find('tr.picOverlap_selected');
		if ($curSelTr.length) {
			$curSelTr.removeClass('error');
			$curSelTr.find('td').removeClass('error');

			var curItemType = $curSelTr.attr('itemType');
			if (curItemType == itemType) {
				return;
			}

			var $td = $curSelTr.find('td[field=spaceNum]');
			var spaceNum = $td.find('input[type="text"]').val();
			$td.text(spaceNum);

			$td = $curSelTr.find('td[field=changeLineNum]');
			var changeLineNum = $td.find('input[type="text"]').val();
			$td.text(changeLineNum);

			$td = null;

			$curSelTr.removeClass("picOverlap_selected");
			$curSelTr.find('td[field=upDown]').find('div').hide();
		}

        //onkeyup="this.value=this.value.replace(/\D/g,'')"  onafterpaste="this.value=this.value.replace(/\D/g,'')"
		var $td = $(this).find('td[field=spaceNum]');
		var spaceNum = $td.text();
        var strNull = '';
		$td.html("<input type='text' value='"+spaceNum+"' style='width:96%;'/>");

		$td = $(this).find('td[field=changeLineNum]');
		var changeLineNum = $td.text();
		$td.html("<input type='text' value='"+changeLineNum+"' style='width:96%;'/>");

		$(this).addClass("picOverlap_selected");
		$(this).find('td[field=upDown]').find('div').show();

		_.each(PicOverlap_SelectedItems, function (item) {
			if (item.itemType == itemType) {
				item.selected = true;
			}else{
				item.selected = false;	
			}
		});
	});
}
function PicOverlap_ResetPicPosition() {
	//先获取现有的叠加信息位置
	
}
function PicOverlap_Clear (objContainer, objTable) {
	var $container = objContainer;
	var $table = objTable;
	$container.find('input[type=checkbox]').prop('checked', false);
	$table.find('tr[itemType]').remove();
	PicOverlap_SelectedItems.length = 0;
}

function PicOverlap_RestoreItems (objTable) {
	var $table = objTable;
	var strOSDTextInfo = HWP.GetTextOverlay();
	var XmlTempDoc = parseXmlFromStr(strOSDTextInfo);
	var iLength = $(XmlTempDoc).find("TextOverlay").length;
	for(var i = 0; i < iLength; i++) {
		if($(XmlTempDoc).find("TextOverlay").eq(i).find("id").text() == "1000"){
			$(XmlTempDoc).find("TextOverlay").eq(i).remove();
			break;
		}
	}
	var j = 0;
	$.each(PicOverlap_SelectedItems, function (i, item) {
		$tr = $table.find('tr[itemType='+item.itemType+']').eq(0);
		if ($tr.length) {
			if (item.itemType == '8' || item.itemType == '21' || item.itemType == '22' || item.itemType == '23') {  // 时间的处理
				item.useMs = $('#containsMs').prop("checked");
			}else if (item.itemType == '21' || item.itemType == '22' || item.itemType == '23') {  // 时间的处理
				item.useMs = $('#containsMs'+item.itemType).prop("checked");
			}else if (item.itemType == '24') {  // 防伪码
				item.useMD5 = false;//$('#containsMD5').prop("checked"); 设备暂不支持
			}else if (item.itemType == '18') {
				if ($tr.find('input[info=1]').length) {
					item.overlayInfoText = $tr.find('input[info=1]').val();
				}
				if ($tr.find('input[info=2]').length) {
					item.overlayInfoText2 = $tr.find('input[info=2]').val();
				}	
			}else if (item.editable) {
				if ($tr.find('input[info=1]').length) {
					item.overlayInfoText = $tr.find('input[info=1]').val();
				}
			}

			var spaceNum = 0;
			var changeLineNum = 0;

			if ($tr.is('.picOverlap_selected')) {
				spaceNum = $tr.find('td[field=spaceNum]').find('input[type="text"]').val();
				changeLineNum = $tr.find('td[field=changeLineNum]').find('input[type="text"]').val();
			}else{
				spaceNum = $tr.find('td[field=spaceNum]').text();
				changeLineNum = $tr.find('td[field=changeLineNum]').text();
			}

			item.spaceNum = spaceNum;
			item.changeLineNum = changeLineNum;
			item.startPosEnable = $tr.find('td[field=overlayPosition]').find(":checkbox").prop("checked");
			if(item.startPosEnable == true) {
				item.startPosLeft = $(XmlTempDoc).find("positionX").eq(j).text();
				item.startPosTop = $(XmlTempDoc).find("positionY").eq(j).text();
				j++;
			} else {
				item.startPosLeft = 0;
				item.startPosTop = 0;
			}
			if(item.startPosLeft == "") {
				item.startPosLeft = 0;
			}
			if(item.startPosTop == "") {
				item.startPosTop = 0;
			}
		}
	});
}

function PicOverlap_RenderOne (idx, item, isComposite) {
	var retStr = "";

	if (!isComposite) {
		isComposite = false;
	};

	//yqw 字符叠加自定义名称 begin
	var head = [
		'<tr idx="'+idx+'" itemType="'+item.itemType+'">'+
			'<td field="itemName">'+'<input id="itemType'+idx+'" style="width:195px;" maxlength="32" onblur="itemNameOnblur('+item.itemType+',this.value)"'+' tpye="text" value="'+escapeXmlChars(item.itemName) +'"/></td>'
			];

	//end
	var detail = [];

	var upDownArror = ["<div style='display:none;'>",
		'<input type="button" value="↑" style="width:22px;" onclick="PicOverlap_Up(event, this);"/>',
		'<input type="button" value="↓" style="width:22px;" onclick="PicOverlap_Down(event, this);"/>',
		"</div>"
	].join('');
	
	var disStr = '';
	if (isComposite) {
		disStr = ' disabled="true" ';
	}

	var PositionChkArror = ["<div>",
		'<input type="checkbox" onclick="PicOverlap_RenderAll()" ' + disStr + '/>',
		"</div>"
	].join('');
	
	
	var tail =["<td align='center' field='overlayPosition'>", PositionChkArror, "</td>",
			"<td align='center' field='spaceNum'>", item.spaceNum, "</td>",
			"<td align='center' field='changeLineNum'>", item.changeLineNum, "</td>",
			"<td align='center' field='upDown'>",upDownArror, "</td>",
		"</tr>"];

	//监测点信息
	if (item.itemType == '18') {
		detail.push('<td field="detail">');

		if (!_.isString(item.overlayInfoText)) {
			item.overlayInfoText = "";
		};
		if (!_.isString(item.overlayInfoText2)) {
			item.overlayInfoText2 = "";
		};
		detail.push('<span>'+getNodeValue("itemType18_1")+':</span><input type="text" info="1" '
				+' value="'+escapeXmlChars(item.overlayInfoText)+'"/>');

		detail.push('<br/><span>'+getNodeValue("itemType18_2")+':</span><input type="text" info="2" '
				+' value="'+escapeXmlChars(item.overlayInfoText2)+'"/>');

		detail.push('</td>');
	}else if (item.itemType == '8') {  	//时间，处理带毫秒
		var chkStr = '';
		if (item.useMs) {
			chkStr = ' checked="checked" ';
		}
		detail.push('<td field="detail">');
		detail.push('<input type="checkbox" class="checkbox" id="containsMs" '+chkStr+'/>'+
				'&nbsp;<label for="containsMs" class="checkboxLabel">'+getNodeValue("itemType8_0")+'</label>');
		detail.push('</td>');
	/*}else if (item.itemType == '24') {  	//防伪码，处理MD5加密
		var chkStr = '';
		if (item.useMD5) {
			chkStr = ' checked="checked" ';
		}
		detail.push('<td field="detail">');
		detail.push('<input type="checkbox" class="checkbox" id="containsMD5" '+chkStr+'/>'+
				'&nbsp;<label for="containsMD5" class="checkboxLabel">'+getNodeValue("itemType24_0")+'</label>');
		detail.push('</td>');*/
	}else if (item.itemType == '21'||item.itemType == '22'||item.itemType == '23') {  	//时间，处理带毫秒
		var chkStr = '';
		if (item.useMs) {
			chkStr = ' checked="checked" ';
		}
		detail.push('<td field="detail">');
		detail.push('<input type="checkbox" class="checkbox" id="containsMs"'+item.itemType+' '+chkStr+'/>'+
				'&nbsp;<label for="containsMs"'+item.itemType+' class="checkboxLabel">'+getNodeValue("itemType8_0")+'</label>');
		detail.push('</td>');
	}else if (item.editable) { //处理有信息输入的
		if (!_.isString(item.overlayInfoText)) {
			item.overlayInfoText = "";
		};
		
		detail.push('<td field="detail">');
		detail.push('<input type="text" style="width:98%;" info="1" value="'+escapeXmlChars(item.overlayInfoText)+'"></input>');
		detail.push('</td>');
	}else {
		detail.push('<td>&nbsp;</td>');
	}

	retStr = [head.join(''), detail.join(''), tail.join('')].join('');
	
	return retStr;
}

function PicOverlap_RenderAll(objTable) {
	if (arguments.length === 0) {
		var $table = $("#SingleOverlayInfoList");
	} else {
	    var $table = objTable;
	}

	var isComposite = window._g_isComposite;
	if (!isComposite) {
		isComposite = false;
	};

	if(PicOverlap_SelectedItems.length > 0) {
	    PicOverlap_SelectedItems[0].startPosEnable = true;
	}
	PicOverlap_RestoreItems($table);

	$table.find('tr[itemType]').remove();

	var selIdx = -1;
	$.each(PicOverlap_SelectedItems, function (i, item) {
		var str = PicOverlap_RenderOne(i, item, isComposite);
		$table.append(str);
		
		if(item.startPosEnable == true && !isComposite) {
			$table.find('td[field=overlayPosition]').eq(i).find(":checkbox").prop("checked", true);
		}

		if (item.selected === true) {
			selIdx = i;
		}
	});
	if (selIdx >= 0) {
		var $sel = $table.find('tr[idx='+selIdx+']').click();	
	};
	//生成叠加位置xml并塞入插件
	ia(SnapOverlay).createSnapOSDTextInfo();
	autoResizeIframe();
}

function PicOverlap_Up (evt, obj) {
	var $table =  $(obj).parents('table').eq(0);
	var $tr = $(obj).parents('tr').eq(0);
	var $tr2 = $tr.prev('tr[itemType]');
	if ($tr2.length == 0) {
		return;
	};
	var idx = $tr.attr('idx');
	var idx2 = $tr2.attr('idx');

	var tmpObj = PicOverlap_SelectedItems[idx];
	PicOverlap_SelectedItems[idx] = PicOverlap_SelectedItems[idx2];
	PicOverlap_SelectedItems[idx2] = tmpObj;

	PicOverlap_RenderAll($table);
}

function PicOverlap_Down (evt, obj) {
	var $table =  $(obj).parents('table').eq(0);
	var $tr = $(obj).parents('tr').eq(0);
	var $tr2 = $tr.next('tr[itemType]');
	if ($tr2.length == 0) {
		return;
	};
	var idx = $tr.attr('idx');
	var idx2 = $tr2.attr('idx');

	var tmpObj = PicOverlap_SelectedItems[idx];
	PicOverlap_SelectedItems[idx] = PicOverlap_SelectedItems[idx2];
	PicOverlap_SelectedItems[idx2] = tmpObj;

	PicOverlap_RenderAll($table);
}

function GetOverlayInfos () {
	PicOverlap_RestoreItems($("#SingleOverlayInfoList"));

	var arr = [];

	_.each(PicOverlap_SelectedItems, function (item, i) {
		var obj = {
			Id: i+1,
			itemType: item.itemType,
			spaceNum: item.spaceNum,
			changeLineNum: item.changeLineNum,
			startPosEnable: item.startPosEnable,
			startPosTop: item.startPosTop,
			startPosLeft: item.startPosLeft
		};
		if (item.editable) {
			obj.overlayInfoText = item.overlayInfoText;
		}
		if (item.itemType == '8') {
			if (item.useMs) {
				obj.itemType = '9';
			}
		}else if (item.itemType == '21') {
			if (item.useMs) {
				obj.itemType = '37';
			}
		}else if (item.itemType == '22') {
			if (item.useMs) {
				obj.itemType = '38';
			}
		}else if (item.itemType == '23') {
			if (item.useMs) {
				obj.itemType = '39';
			}
		}else if(item.itemType == '18'){
			obj.overlayInfoText = item.overlayInfoText;
			obj.overlayInfoText2 = item.overlayInfoText2;
		}
		if (item.itemType == '24') {
		    obj.useMD5 = item.useMD5;
		}
		arr.push(obj);
	});
	return arr;
}

function ValidateInfos () {
	var msg = '';
	var infoTextErr = false;
	var spaceNumErr = false;
	var changeLineNumErr = false;
	
	var lengthInvalidMsg = getNodeValue("vs_tips_1");
	var spaceInvalidMsg = getNodeValue("vs_tips_2");
	var changeLineInvalidMsg = getNodeValue("vs_tips_3");

	var msg1 = getNodeValue('vs_tips_4');
	var notNullMsg=getNodeValue('vs_tips_5');

	var errItem;

	var $table = $('#SingleOverlayInfoList');

	$.each(PicOverlap_SelectedItems, function (i, item) {
		//_log(item.itemName);
		$tr = $table.find('tr[itemType='+item.itemType+']');

		if (item.itemType == '18') {  // 监测点
			if(item.overlayInfoText==null||item.overlayInfoText==""||
				item.overlayInfoText2==null||item.overlayInfoText2==""){
				infoTextErr=true;
				msg+=notNullMsg+';';
			}else if (getStrLen(item.overlayInfoText) > item.maxlength1) {
				infoTextErr = true;
				msg += item.itemName+"1"+msg1+item.maxlength1+';';
			}else if (getStrLen(item.overlayInfoText2) > item.maxlength2) {
				infoTextErr = true;
				msg += item.itemName+"2"+msg1+item.maxlength2+';';
			};
		}else if (item.editable) {
			if(item.overlayInfoText==null||item.overlayInfoText==""){
				infoTextErr=true;
				msg+=notNullMsg+';';
			}else{
				if (getStrLen(item.overlayInfoText) > item.maxlength) {
					infoTextErr = true;
					msg += lengthInvalidMsg+item.maxlength+getNodeValue("vs_tips_6")+';';
				}
			}

		}

		if (infoTextErr) {
			$tr.find('td[field=detail]').addClass('error');
		};

		var re = new RegExp('^\\d+$', "g");

		if (re.test(item.spaceNum+"")) {
			var spaceNum = parseInt(item.spaceNum,10);
			if (spaceNum > 255 || spaceNum < 0) {
				spaceNumErr = true;
				msg+=spaceInvalidMsg;
			}
		}else{
			spaceNumErr = true;
			msg+=spaceInvalidMsg;
		}

		re = new RegExp('^\\d+$', "g");
		if (re.test(item.changeLineNum+"")) {
			var changeLineNum = parseInt(item.changeLineNum,10);
			if (changeLineNum > 100 || changeLineNum < 0) {
				changeLineNumErr = true;
				msg+=changeLineInvalidMsg;
			};
		}else{
			changeLineNumErr = true;
			msg+=changeLineInvalidMsg;
		}
		
		if (spaceNumErr) {
			$tr.find('td[field=spaceNum]').addClass('error');
		};

		if (changeLineNumErr) {
			$tr.find('td[field=changeLineNum]').addClass('error');
		};

		if (msg != '') {			
			msg = item.itemName+':'+msg;
			errItem = item;
			return false;
		};
	});

	return {
		msg: msg,
		errItem: errItem
	};
}

function getStrLen (value) {
	var chc = value.replace(/[^\u4e00-\u9fa5]/gi, "").length;
	return value.length + chc;
}