
function personRunRedLightTriggerModeS () {
	SingletonInheritor.implement(this);	
}

SingletonInheritor.declare(personRunRedLightTriggerModeS);

personRunRedLightTriggerModeS.prototype.updateLang = function () {
	$('#CommendParamBtn').hide();

	g_transStack.clear();
	var that = ia(personRunRedLightTriggerModeS);
	g_transStack.push(function() {
		var itsModeDoc = parent.translator.getLanguageXmlDoc("personRunRedLightTriggerMode");
		that.setLxd(itsModeDoc);

		var tModeDoc = parent.translator.getLanguageXmlDoc("TriggerMode");
		parent.translator.appendLanguageXmlDoc(that.getLxd(), tModeDoc);

		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
		$("#FullScreenbutton").attr("title", getNodeValue("FullScreenExitTips"));
	}, true);
};


(function() {
	var personRunRedLightTriggerMode = window.personRunRedLightTriggerMode || {};

	var m_bPlay = false;

	function PlayView(ele){
		if (HWP.wnds[0].isPlaying) {
			StopPlay(ele);
			return;
		}
		setTimeout(function()
		{
			try {
				if(!ele) {
					ele = $(".ConfigBtn :button:visible")[0];
				}
				iRes = HWP.Play();
				if (iRes != 0) {
					m_bPlay = false;
					$(ele).attr("name", "btnPlay");
					$(ele).attr("title", getNodeValue("btnPlay"));
					$(ele).val(getNodeValue("btnPlay"));
					return;	
				} else {
					m_bPlay = true;
					$(ele).attr("name", "btnStop");
					$(ele).attr("title", getNodeValue("btnStop"));
					$(ele).val(getNodeValue("btnStop"));
				}
			} catch(e){
			}
		},10);	
	}

	personRunRedLightTriggerMode.PlayView = function(){
		HWP.ClearSnapInfo(4);
        // 入侵区域
        personRunRedLightTriggerMode._drawRuleRegion();
        // 停止线
        personRunRedLightTriggerMode._drawRuleDirection();
	};


	function StopPlay(ele) {
		if (!m_bPlay) {
			return;	
		} else {
			try {
				if (HWP.Stop(0) != 0) {
					return;	
				} else {
					m_bPlay = false;
					$(ele).attr("name", "btnPlay");
					$(ele).attr("title", getNodeValue("btnPlay"));
					$(ele).val(getNodeValue("btnPlay"));	
				}
			} catch(e){
				m_bPlay = false;
				$(ele).attr("name", "btnStop");
				$(ele).attr("title", getNodeValue("btnStop"));
				$(ele).val(getNodeValue("btnStop"));		
			}
		}
	}
    var originalXml = null;
	var $xml = null;
	personRunRedLightTriggerMode.update = function () {
		if ($("#main_plugin").html() == "") {
			if (checkPlugin('2', getNodeValue('laPlugin'), 1, 'snapdraw', 0)) {
				if (!CompareFileVersion()) {
					UpdateTips();
				}
			}
		}

		// if ($.browser.msie) {
		// 	var iIEVersion = parseInt($.browser.version, 10);
		// 	if (iIEVersion == 6) {
		// 		$("#ptzCfg").find("select").hide();
		// 		$("#homePos").find("select").show();
		// 	}
		// } else {
		// 	StopPlay();
		// }
		// PlayView();

		HWP.Stop();
		HWP.Play();

		$('#SetResultTips').html('');
		$("#SaveConfigBtn").hide();
		GetParam();
	}

	function GetParam(cmd){
		var tail = '';
		if (cmd) {
			tail = '/recommendation'
		};
		$.ajax({
	        type: "GET",
	        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/personrunredlight"+tail,
	        timeout: 15000,
	        dataType: 'text', 
	        beforeSend: function(xhr) {
	            xhr.setRequestHeader("If-Modified-Since", "0");
	            
	        },
	        success: function(xmlDoc, textStatus, xhr) {
	            originalXml = parseXmlFromStr(xmlDoc);
	            var $xml=$(originalXml);
	            $.each(['capNum','direction','delayFrm','eventContinueTime','source'],function(i,n){
	            	$("#"+n).val($xml.find(n).eq(0).text());
	            });

	            personRunRedLightTriggerMode.changeSource($("#source").val());
	            HWP.ClearSnapInfo(4);
	            // 入侵区域
	            personRunRedLightTriggerMode._drawRuleRegion();
	            // 停止线
	            personRunRedLightTriggerMode._drawRuleDirection();
	        },
	        error: function(xhr, textStatus, errorThrown) {
	        }
	    });
	}

	personRunRedLightTriggerMode.changeSource = function (strSourceType) {
		$('#source_IO_div, #source_RS485_div, #source_videoDetect_div').hide();
		var id = 'source_'+strSourceType+'_div';
		$('#'+id).show();

		if (strSourceType == 'IO') {
			var $xml = $(originalXml);
			$xml.find('IOLight').each(function (i,n) {
				var $io = $(n);	
				var lightId = parseInt($io.find('lightId').text());
				if (lightId <= 3) {
					$.g.setField('relatedIO_'+lightId, $io.find('relatedIO').text());
					$.g.setField('redLightStatus_'+lightId, $io.find('redLightStatus').text());
				}
			});
		}else if (strSourceType == 'RS485') {
			var $xml = $(originalXml);
			$xml.find('RS485Light').each(function (i,n) {
				var $io = $(n);	
				var lightId = parseInt($io.find('lightId').text());
				if (lightId <= 3) {
					$.g.setField('relatedLightChan_'+lightId, $io.find('relatedLightChan').text());
					$.g.setField('yellowLightChan_'+lightId, $io.find('yellowLightChan').text());
				}
			})
		}
		autoResizeIframe();
	}

	personRunRedLightTriggerMode.SetParam=function(){
		var $xml=$(originalXml);
        $.each(['capNum','direction','delayFrm','eventContinueTime','source'],function(i,n){
        	$xml.find(n).eq(0).text($("#"+n).val());
        });

        var regionXml=HWP.GetSnapPolygonInfo();
        $(parseXmlFromStr(regionXml)).find("SnapPolygon").each(function(){
			var $s=$(this);
			var id=$s.find("id").eq(0).text();
			if("200"==id){
				$s.find('point').each(function (i,n) {
					var x = Math.floor(parseFloat($(n).find('x').text())*1000);
					var y = Math.floor(parseFloat($(n).find('y').text())*1000);
					$xml.find("sidewalkArea").find("sidewalkAreaCoordinates").eq(i).find("positionX").text(x);
					$xml.find("sidewalkArea").find("sidewalkAreaCoordinates").eq(i).find("positionY").text(y);
				});
				var l=$s.find("point").length;
				for(var j=l;j<$xml.find("sidewalkArea").find("sidewalkAreaCoordinates").length;j++){
					$xml.find("sidewalkArea").find("sidewalkAreaCoordinates").eq(j).find("positionX").text(0);
					$xml.find("sidewalkArea").find("sidewalkAreaCoordinates").eq(j).find("positionY").text(0);
				}
			}
		});

        var directionXml=HWP.GetSnapLineInfo();
        $(parseXmlFromStr(directionXml)).find('SnapLine').each(function () {
			var lineId = $(this).find('id').eq(0).text();
			if("100"==lineId){
				var $st = $(this).find("StartPos");
				var $et = $(this).find("EndPos");
				var sx = parseFloat($st.find('x').text());
				var sy = parseFloat($st.find('y').text());
				var ex = parseFloat($et.find('x').text());
				var ey = parseFloat($et.find('y').text());
				sx = Math.floor(sx*1000);
				sy = Math.floor(sy*1000);
				ex = Math.floor(ex*1000);
				ey = Math.floor(ey*1000);

				var $line=$xml.find("stopLine").eq(0);
				$line.find('positionX').eq(0).text(sx);
				$line.find('positionX').eq(1).text(ex);
				$line.find('positionY').eq(0).text(sy);
				$line.find('positionY').eq(1).text(ey);
			}
		});

		if(source == "IO") {
			$xml.find('IOLight').each(function (i, n) {
				var $io = $(n);
				var lightId = parseInt($io.find('lightId').text());
				if (lightId <= 3) {
					$io.find('relatedIO').text($('#relatedIO_'+lightId).val());
					$io.find('redLightStatus').text($('#redLightStatus_'+lightId).val());
				}
			});
		} else if(source == "RS485"){
			$xml.find('RS485Light').each(function (i, n) {
				var $io = $(n);
				var lightId = parseInt($io.find('lightId').text());
				if (lightId <= 3) {
					$io.find('relatedLightChan').text($('#relatedLightChan_'+lightId).val());
					$io.find('yellowLightChan').text($('#yellowLightChan_'+lightId).val());
				}
			});
		}

		$.ajax({
	        type: "PUT",
	        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/personrunredlight",
	        timeout: 15000,
	        beforeSend: function(xhr) {
	            xhr.setRequestHeader("If-Modified-Since", "0");
	            
	        },
	        data: xmlToStr(originalXml),
			processData: false,
			complete:function(xhr, textStatus) {
				SaveState(xhr);
			}
	    });
	}

	personRunRedLightTriggerMode.updateLang = function () {
		ia(personRunRedLightTriggerModeS).updateLang();
	}

	personRunRedLightTriggerMode.drawRuleRegion=function(){
		try{
			var xml="<?xml version='1.0' encoding='utf-8'?>"+
			"<SnapPolygonList><SnapPolygon><id>200</id><polygonType>1</polygonType><color><r>0</r><g>255</g><b>0</b></color>"+
			"<tips>入侵区域</tips><isClosed>false</isClosed>"+
			"<PointNumMax>11</PointNumMax><MinClosed>5</MinClosed><pointList/>"+
			"</SnapPolygon></SnapPolygonList>";
			
			HWP.SetSnapPolygonInfo(xml);
			HWP.SetSnapDrawMode(2);
		}
		catch(e){};
	}

	personRunRedLightTriggerMode.drawRuleDirection=function(){
		HWP.ClearSnapInfo(2);
		var szLineInfo ="<?xml version='1.0' encoding='utf-8'?>";
		szLineInfo += "<SnapLineList><SnapLine><id>100</id><LineType>1</LineType>"+
		"<color><r>255</r><g>0</g><b>0</b></color><Tips>停止线</Tips><StartPos><x>0.2</x><y>0.2</y></StartPos>"+
		"<EndPos><x>0.2</x><y>0.5</y></EndPos><isClosed>false</isClosed></SnapLine></SnapLineList>";	
		try{
			HWP.SetSnapLineInfo(szLineInfo);
			HWP.SetSnapDrawMode(3);
		}
		catch(e){}
	}

	personRunRedLightTriggerMode._drawRuleDirection = function () {
		if(!originalXml){
			return;
		}

		var $d=$(originalXml).find("stopLine")
		startX = parseInt($d.find("stopLineCoordinates").eq(0).find("positionX").text(), 10);
		startY = parseInt($d.find("stopLineCoordinates").eq(0).find("positionY").text(), 10);
		endX = parseInt($d.find("stopLineCoordinates").eq(1).find("positionX").text(), 10);
		endY = parseInt($d.find("stopLineCoordinates").eq(1).find("positionY").text(), 10);

		if (startY == 0 && startX == 0 && endX == 0 && endY == 0) {
			return;
		}

		var snapLines = {
			SnapLineList: {
				SnapLine:[]
			}
		};

		startX = (startX/1000).toFixed(3);
		startY = (startY/1000).toFixed(3);
		endX = (endX/1000).toFixed(3);
		endY = (endY/1000).toFixed(3);
		
		snapLines.SnapLineList.SnapLine.push({
			id: 100,
			LineType: 1,
			Tips:  '停止线',
			StartPos: {
				x: startX,
				y: startY
			},
			EndPos: {
				x: endX,
				y: endY
			},
			color:  {r: 255, g: 0, b: 0}
		});

		if (snapLines.SnapLineList.SnapLine.length) {
			try{
				var szLineInfo = x2js.json2xml_str(snapLines);
				HWP.SetSnapLineInfo(szLineInfo);
				HWP.SetSnapDrawMode(0, 3);
			}catch(e){}
		}
	}

	personRunRedLightTriggerMode._drawRuleRegion = function(){

		if(!originalXml){
			return;
		}
		var ptArr=[];
		$(originalXml).find("sidewalkArea").eq(0).find("sidewalkAreaCoordinates").each(function(){
			var $s=$(this);
			var x=parseInt($s.find("positionX").text(),10);
			var y=parseInt($s.find("positionY").text(),10);
			if(x==0 && y==0 ){
				return true;
			}
			ptArr.push({
				x:(x/1000).toFixed(3),
				y:(y/1000).toFixed(3)
			})
		})

		var obj = {
			SnapPolygonList:{
				SnapPolygon: [{
					id: 200,
					polygonType: 1,
					color: {r: 0, g: 255, b: 0},
					tips: '入侵区域',
					isClosed: "true",
					PointNumMax:11,
					MinClosed:5,
					pointList: {
						point: ptArr
					}
				}]
			}
		};

		try{	
			var xml = x2js.json2xml_str(obj, true);
			HWP.SetSnapPolygonInfo(xml);

			HWP.SetSnapDrawMode(0, 2);
		}catch(e){}
	}

	window.personRunRedLightTriggerMode = personRunRedLightTriggerMode;
	window.PlayView = PlayView;


	personRunRedLightTriggerMode.PersonObj = null;
	personRunRedLightTriggerMode.InitPersonTmpSnapLines =function() {
		var x = xmlToStr(originalXml);
		personRunRedLightTriggerMode.PersonObj = x2js.parseXmlString(x);
	}
	
	personRunRedLightTriggerMode.setXml = function(xml){
		originalXml = xml;
	}

	personRunRedLightTriggerMode.setVideoDetect = function () {
		$("#VideoDetectDiv").modal();

		VD3.init();

		HWP.Stop();
		$("#main_plugin").hide();
	}
})();









