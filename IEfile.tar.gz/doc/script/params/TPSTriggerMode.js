function TPSTriggerModeS(){
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(TPSTriggerModeS);

TPSTriggerModeS.prototype.updateLang=function(){
	$('#CommendParamBtn,#SaveConfigBtn').hide();

	g_transStack.clear();
	var that=ia(TPSTriggerModeS);
	g_transStack.push(function(){
		var prsDoc=parent.translator.getLanguageXmlDoc("TPSTriggerMode");
		that.setLxd(prsDoc);

		var tModeDoc=parent.translator.getLanguageXmlDoc("TriggerMode");
		parent.translator.appendLanguageXmlDoc(that.getLxd(), tModeDoc);

		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	},true);
};

(function(){
	var TPSTriggerMode=window.TPSTriggerMode||{};
	var m_TPSXml=null;
	var originalXmlDoc=null;

	var m_iCurSelIONum = 1;
    var m_iLastSelIONum = 0;
    var m_bSetTriggerMode = false;
	var m_bRebootRequired = false;

	TPSTriggerMode.updateLang = function () {
		ia(TPSTriggerModeS).updateLang();
	}

	TPSTriggerMode.updateParam=function(iValueType){
        if ($("#main_plugin").html() == "") {
			if (checkPlugin('2', getNodeValue('laPlugin'), 1, 'snapdraw', 0)) {
				if (!CompareFileVersion()) {
					UpdateTips();
				}
			}
		}
		HWP.Stop(0);
		HWP.Play();

		var szUrl = "/PSIA/Custom/SelfExt/ITC/TPS";
		if(iValueType == 1) {
			szUrl += "/recommendation";
		}
        
		var self = this;
		
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + szUrl,
			timeout: 15000,
			async: false,
			dataType:"text",
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			}
		}).done(function (xmlDoc, textStatus, xhr) {
			m_TPSXml = parseXmlFromStr(xmlDoc);

			var lanecount = parseInt($(xmlDoc).find("laneCount").eq(0).text());
			var laneCountRes = self.GetTPSLaneCount();

			fillLaneCountOptions(laneCountRes.min, laneCountRes.max, lanecount);

			$.each(["enRealtimeDataUpload", "enStatisticalDataUpload", "statisticsTime",
				"isPosenable","pointX","pointY",
				"laneFlow","queueLength","laneNumber","timeHeadway","spaceHeadway","trafficState",
				"vehicleSpeed","timeOccupyRation","spaceOccupyRation"], function (i, n) {
				$.g.setField2('*[x-model='+n+']', $(xmlDoc).find(n).eq(0).text());
			});

			self.changeVideoEpLancCount(lanecount);
			self.DisplayTPSLaneParam(0);
			self.isPosenableClick();

			m_iCurSelIONum = 1;
			m_iLastSelIONum = 1;

			drawTPSShapes();
		});
	}

	TPSTriggerMode.GetTPSLaneCount=function(){
		var url = m_lHttp + m_szHostName + ":"+m_lHttpPort 
					+ '/PSIA/Custom/SelfExt/ITC/TPS/capabilities';
		var res = {
			min: 1, 
			max: 6
		};
		$.ajax({
			type: "GET",
			url: url,
			timeout: 15000,
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				var $nd = $(xmlDoc).find('laneCount').eq(0);
				if ($nd.length) {
					min = parseInt($nd.attr('min'));
					max = parseInt($nd.attr('max'));
					if (min >=0 && max > 1) {
						res.min = min;
						res.max = max;
					};
				};
			}
		});

		return res;
	}

	function fillLaneCountOptions(min, max, curVal){
		if (min <= 0) {
			min = 1;
		}
        var $s = $('#RelatedLaneCount_videoEp');
        $s.find('option').remove();
        for (var i=min; i <= max; i++) {
            var opt = "<option value='"+i+"' ";
            if (curVal != null && i == curVal) {
                opt += " selected='selected' ";
            }
            opt += ">"+i+"</option>";
            
            $s.append(opt);
        }
    }

    TPSTriggerMode.isPosenableClick=function(){
    	if($("#chkIsPosenable").prop("checked")){
    		$("#dvChklanePosEnable").show();
    		$("#dvPosInfoXY,#dvPosOverlayInfo").show();
    	}else{
    		$("#dvChklanePosEnable").hide();
    		$("#dvPosInfoXY,#dvPosOverlayInfo").hide();
    	}
    	autoResizeIframe();
    }

    TPSTriggerMode.changeVideoEpLancCount=function(v){
    	var $t = $('#tabsTPS');
		for (var i = 0; i < $t.find('li').length; i++) {
            if (i < v ) {
                $t.find('li#TPSLane_'+(i+1)).show();
            }else{
                $t.find('li#TPSLane_'+(i+1)).hide();
            }
        }

        var current = $t.find('li').not(':hidden').find('a.current');
        if (current.length == 0) {
            this.selectTPSLane(0);
        }else{
        	getTriggerIOCopyInfoForTPS();	
        }
        drawTPSShapes();
    }

    TPSTriggerMode.DisplayTPSLaneParamInner = function (laneIndex) {
		laneIndex = parseInt(laneIndex, 10);
		var xmlDoc = m_TPSXml;

		var $thisLaneXmlDoc = $(xmlDoc).find('LaneParam').eq(laneIndex);
		$.each(['relatedDriveWay','lanePosEnable',
			"laneVolumeEnable", "laneVelocityEnable", "timeHeadwayEnable",
			"spaceHeadwayEnable", "timeOccupyRationEnable", "spaceOccupyRationEnable",
			"queueLengthEnable", "vehicleTypeEnable", "trafficStateEnable"], function  (i, n) {
			var sel = '#dvTriggerParam *[x-model='+n+']';
    		var v = $thisLaneXmlDoc.find(n).eq(0).text();
    		if (v != '') {
    			$.g.setField2(sel, v, true);	
    		}
		});
	}

	TPSTriggerMode.DisplayTPSLaneParam = function (laneIndex) {
		$('#dvTriggerParam #tabsTPS li').find('a').removeClass('current');
		$('#dvTriggerParam #tabsTPS li#TPSLane_'+(laneIndex+1)).find('a').addClass('current');

		this.DisplayTPSLaneParamInner(laneIndex);

        getTriggerIOCopyInfoForTPS();	
	}
    
    // 画图,判别是否显示全部图
	function drawTPSShapes () {
		HWP.ClearSnapInfo(4);
		if ($('#drawAllPicCheck').prop('checked')) {
			var laneCount = $('#RelatedLaneCount_videoEp').val();
			var arr = [];
			for (var i = 1; i <= laneCount; i++) {
				arr.push(i);
			}
	    	DisplayTPSRegion(arr, null, {r:255,g:0,b:0});
		}else{
	    	DisplayTPSRegion([m_iCurSelIONum], null, {r:255,g:0,b:0});
		}
		HWP.SetSnapDrawMode(-1);
	}

	var TPSTemp;
	//useTmpXmlEle表示是否使用临时存储
	function DisplayTPSRegion (regionIdArray, ocxSel, color, useTmpXmlEle) {
		var domEle;
		if (useTmpXmlEle && TPSTemp) {
			domEle = TPSTemp;
		}else{
			domEle = m_TPSXml;	
		}

		if (!color) {
			color = {r: 255, g:0, b:0};
		}

		if (!ocxSel) {
			ocxSel = '#PreviewActiveX';
		}
		var ocx = $(ocxSel)[0];

		var obj = {
			SnapPolygonList:{
				SnapPolygon: []
			}
		};

		var snapLines = {
			SnapLineList: {
				SnapLine:[]
			}
		};

		$(domEle).find('LaneParam').each(function (i, n) {
			var $thisLane = $(n);
			var laneId = parseInt($thisLane.find('laneNum').text());
			if ($.g.contains(regionIdArray, laneId)) {
				var regionName = getNodeValue("TPSRegion")+laneId;
				var directionName = getNodeValue("TPSRegionDirection")+laneId;
				var virtualName = getNodeValue("TPSVirtualRegion")+laneId;

				var regionPts = getTPSRegionPts($thisLane.find("AreaRegion")[0]);
				var virtualPts = getTPSRegionPts($thisLane.find('VirtualRegion')[0]);

				// 虚拟线圈区域id： 200+车道号
				obj['SnapPolygonList']['SnapPolygon'].push({
					id: 200 + laneId,
					polygonType: 1,
					color: {r: 255, g: 0, b: 0},
					tips: virtualName,
					isClosed: "true",
					PointNumMax:11,
					MinClosed:5,
					pointList: {
						point:virtualPts
					}
				});

				// 车道区域id： 100+车道号
				obj['SnapPolygonList']['SnapPolygon'].push({
					id: 100 + laneId,
					polygonType: 1,
					color: {r: 0, g: 255, b: 0},
					tips: regionName,
					isClosed: "true",
					PointNumMax:11,
					MinClosed:5,
					pointList: {
						point:regionPts
					}
				});

				// 车道方向id： 300+车道号
				var arrowPts = getTPSArrowPos($thisLane.find('DirectionLine')[0]);

				var _line = {
					id: 300+laneId,
					LineType: 0,
					tips:  directionName,
					color: {r: 255, g: 0, b: 0},
					ArrowType: 1,
					StartPos: arrowPts.StartPos,
					EndPos: arrowPts.EndPos
				};

				snapLines.SnapLineList.SnapLine.push(_line);
			}
		});

		ocx.HWP_ClearSnapInfo(4);

		try{	
			var xml = x2js.json2xml_str(obj, true);
			ocx.HWP_SetSnapPolygonInfo(xml);
		}catch(e){}

		if (snapLines.SnapLineList.SnapLine.length) {
			var szLineInfo = x2js.json2xml_str(snapLines);
			ocx.HWP_SetSnapLineInfo(szLineInfo);
		}
		//设置选择模式
		ocx.HWP_SetSnapDrawMode(0, 3);
	}

	function getTPSRegionPts (ele) {
		if (!ele) {
			throw new Error("ele is empty!!");
		};

		var $r = $(ele);

		var pts = [];
		var $_pts = $r.find('RegionCoordinates');
		$_pts.each(function (i, n) {
			var tx = parseInt($(n).find('positionX').text());
			var ty = parseInt($(n).find('positionY').text());
			pts.push({
				x:(tx/1000).toFixed(3),
				y:(ty/1000).toFixed(3)
			});
		});

		return pts;
	}

	function getTPSArrowPos (ele) {
		var $line = $(ele);

		var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
		var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
		var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
		var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

		return {
			StartPos: {
				x: startX,
				y: startY
			},
			EndPos: {
				x: endX,
				y: endY
			}
		}
	}

	TPSTriggerMode.selectTPSLane = function(laneIndex){
	 	var iLastIndex = parseInt(m_iCurSelIONum) - 1;  
		if(laneIndex == iLastIndex) {
			return;
		}
		$("#dvTriggerParam #tabsTPS").find("li a").removeClass('current');
		$("#dvTriggerParam #tabsTPS").find("#TPSLane_"+(laneIndex+1)).find("a").eq(0).addClass("current");
		
		TPSTriggerMode.StoreTPSLaneParam(iLastIndex);
		TPSTriggerMode.DisplayTPSLaneParam(laneIndex);

		m_iCurSelIONum = laneIndex + 1;

		drawTPSShapes();
		m_iLastSelIONum = m_iCurSelIONum;
	}

	TPSTriggerMode.StoreTPSLaneParam = function (laneIndex) {
		laneIndex = parseInt(laneIndex, 10);
		var xmlDoc = m_TPSXml;

		var $thisLaneXmlDoc = $(xmlDoc).find('LaneParam').eq(laneIndex);
		$.each(['relatedDriveWay','lanePosEnable',
			"laneVolumeEnable", "laneVelocityEnable", "timeHeadwayEnable",
			"spaceHeadwayEnable", "timeOccupyRationEnable", "spaceOccupyRationEnable",
			"queueLengthEnable", "vehicleTypeEnable", "trafficStateEnable"], function  (i, n) {
			var sel = '#dvTriggerParam *[x-model='+n+']';
    		
    		var $d = $(sel);
    		if ($d.length) {
    			var v = $d.val();
	    		if ($d.is(":checkbox")) {
	    			v = $d.prop('checked') ? "true":"false";
	    		}
	    		$thisLaneXmlDoc.find(n).eq(0).text(v);
    		};
		});
	}

	function getTriggerIOCopyInfoForTPS(){

        $('#TriggerIOCopyDiv_TPS').find('div.singleIo_checkbox_copy_div').remove();
        var len = $('#RelatedLaneCount_videoEp').val();

        for(var i=0; i < len; i++){
            var disStr = '';
            if($('#tabsTPS #TPSLane_' + (i+1)).find('a').first().is('.current')){
                disStr = 'disabled="disabled" checked="checked" ';
            }
            var arr = ['<div class="singleIo_checkbox_copy_div">',
                '<input id="TPS_copy_checkbox_'+(i+1)+'" ioIdx="'+(i+1)+'" type="checkbox" ',
                disStr,
                'class="singleIo_checkbox"><label for="TPS_copy_checkbox_'+(i+1)+'" ',
                ' class="singleIo_checkbox">'+getNodeValue('aTPSLane'+(i+1))+'</label></div>'];

            $('#TriggerIOCopyDiv_TPS').append(arr.join(' '));
        }

        autoResizeIframe();
    }

    TPSTriggerMode.showAllShapes=function(){
    	drawTPSShapes();
    }

    TPSTriggerMode.ShowTPSModal=function() {
		if (!g_bIsIE) {
	        $("#TPS_Draw_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='TPSDrawPlugin' width='100%' height='100%' name='TPSDrawPlugin' align='center' wndtype='1' playmode='snapdraw'>");
	    } else {
	        $("#TPS_Draw_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='TPSDrawPlugin' width='100%' height='100%' name='TPSDrawPlugin' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
	    }

	    var laneCount= $('#RelatedLaneCount_videoEp').val();
	    var sel = $('#TPSModelLaneSelect');
	    sel.find('option').remove();
	    for (var i = 1; i <= parseInt(laneCount); i++) {
	    	sel.append("<option id='TPSLaneOption"+i+"' value='"+i+"'>"+getNodeValue("TPSLaneOption"+i)+"</option>");
	    };

	    $('#TPSModalDiv').modal();

	    TPSTemp = x2js.parseXmlString(xmlToStr(m_TPSXml));
	    setTimeout(function () {
	    	var ocx = $('#TPSDrawPlugin')[0];	
	    	ocx.HWP_ClearSnapInfo(4);

	    	var selIdx = -1;
	    	var idxArr = [];

	    	for (var i = 0; i < laneCount; i++) {
	    		idxArr.push(i+1);
	    	};

	    	DisplayTPSRegion(idxArr, '#TPSDrawPlugin', {r:255,g:0,b:0}, true);
	    		
			try{
				ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
			}catch(e){}
	    }, 500);

	    HWP.Stop();
	    $("#main_plugin").hide();

	    var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
	    var iRet = $("#TPSDrawPlugin")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
	    if (iRet !== 0) {
	        alert(getNodeValue("previewfailed"));
	    }
	}

	TPSTriggerMode.okTPSModal=function() {
		RestoreTPS();

		m_TPSXml = x2js.parseXmlString(xmlToStr(TPSTemp));
	    var ocx = $("#TPSDrawPlugin")[0];
		if(ocx){
			ocx.HWP_Stop(0);
		}

	    $('#TPS_Draw_plugin').html('');
	    $.modal.impl.close();

	    $("#main_plugin").show();
	    setTimeout(function(){
	    	if (HWP.Play() !== 0) {
		        alert(getNodeValue("previewfailed"));
		    }
	    },100);

	   	drawTPSShapes();
	}
    
    //存储绘制识牌区的数据
	function RestoreTPS (ocxSel) {
		var ocx = $('#TPSDrawPlugin')[0];
		try{
			//车道区域和虚拟线圈数据
	    	var xml = ocx.HWP_GetSnapPolygonInfo();
	    	//车道方向数据
	    	var lineXml = ocx.HWP_GetSnapLineInfo();

	    	var regionJson = x2js.xml_str2json(xmlToStr(TPSTemp));

	    	var laneParams = regionJson.TPS.LaneParamList.LaneParam;
	    	if (!$.isArray(laneParams)) {
	    		laneParams = [laneParams];
	    	};

	    	var $polygon = $(parseXmlFromStr(xml));

	    	$polygon.find('SnapPolygon').each(function () {
	    		var $p = $(this);
	    		var id = parseInt($p.find('id').text());
	    		var ptype = Math.floor(id/100);
	    		var laneId = id%100;

	    		var lp = _.find(laneParams, function (ele) {
	    			return ele.laneNum == laneId;
	    		});
	    		if (lp) {
	    			var sarr = [];
					$p.find('point').each(function (i,n) {
						var x = Math.floor(parseFloat($(n).find('x').text())*1000);
						var y = Math.floor(parseFloat($(n).find('y').text())*1000);
						sarr.push({
							positionX: x,
							positionY: y
						});
					});

	    			if (ptype == '1') {  // 车道区域
	    				lp.AreaRegion.RegionCoordinatesList = {
	    					'RegionCoordinates': sarr
	    				};
	    			}else if (ptype == '2') {  // 虚拟线圈
	    				lp.VirtualRegion.RegionCoordinatesList = {
	    					'RegionCoordinates': sarr
	    				};
	    			}
	    		};
	    	});

	    	var $lines = $(parseXmlFromStr(lineXml));
	    	$lines.find('SnapLine').each(function () {
	    		var $p = $(this);
	    		var id = parseInt($p.find('id').text());
	    		var ptype = Math.floor(id/100);
	    		var laneId = id%100;

	    		if (ptype == '3') {
	    			var $st = $p.find("StartPos");
		    		var $et = $p.find("EndPos");

		    		var sx = Math.round(parseFloat($st.find('x').text())*1000);
					var sy = Math.round(parseFloat($st.find('y').text())*1000);
					var ex = Math.round(parseFloat($et.find('x').text())*1000);
					var ey = Math.round(parseFloat($et.find('y').text())*1000);


					var lp = _.find(laneParams, function (ele) {
		    			return ele.laneNum == laneId;
		    		});
		    		if (lp) {
		    			var rts = lp.DirectionLine.RegionCoordinatesList;
	    				delete rts.RegionCoordinates_asArray;
	    				
	    				rts.RegionCoordinates = [{
		    				positionX: sx,
		    				positionY: sy
		    			},{
		    				positionX: ex,
		    				positionY: ey
		    			}];
		    		}
	    		};

	    	})
	    	TPSTemp = x2js.json2xml(regionJson);
	    }catch(e){
	    	_log(e.message);
	    }
	}

	TPSTriggerMode.cancelTPSModal=function() {
		var ocx = $("#TPSDrawPlugin")[0];
		if(ocx){
			ocx.HWP_Stop(0);
		}

	    $('#TPS_Draw_plugin').html('');
	    $.modal.impl.close();

	    $("#main_plugin").show();
	    setTimeout(function(){
	    	if (HWP.Play() !== 0) {
		        alert(getNodeValue("previewfailed"));
		    }
	    },500);

	    drawTPSShapes();
	}
    
    //相机标定
	TPSTriggerMode.ShowCalibrationModel=function() {
		if (!g_bIsIE) {
	        $("#TPSCalibration_Draw_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='TPSCalibrationDrawPlugin' width='100%' height='100%' name='TPSCalibrationDrawPlugin' align='center' wndtype='1' playmode='snapdraw'>");
	    } else {
	        $("#TPSCalibration_Draw_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='TPSCalibrationDrawPlugin' width='100%' height='100%' name='TPSCalibrationDrawPlugin' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
	    }

	    HWP.Stop();
		$('#TPSCalibrationModalDiv').modal();

		setTimeout(function () {
	    	var ocx = $('#TPSCalibrationDrawPlugin')[0];	
	    	ocx.HWP_ClearSnapInfo(4);

	    	DisplayCalibrationRegion();

			try{
				ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
			}catch(e){}
	    }, 200);

		
	    $("#main_plugin").hide();

	    var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
	    var iRet = $("#TPSCalibrationDrawPlugin")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
	    if (iRet !== 0) {
	        alert(getNodeValue("previewfailed"));
	    }
	}
    
    //画标定区域图
	function DisplayCalibrationRegion () {
		var $xml = $(m_TPSXml);
	    $('#CalibrationRegionWidth').val($xml.find('CalibrationRegion RegionWidth').text());
	    $('#CalibrationRegionHeight').val($xml.find('CalibrationRegion RegionLength').text());

		var ele = $xml.find('CalibrationRegion').find("RegionCoordinatesList");
		var pts = getTPSRegionPts(ele);
		
		var obj = {
			SnapPolygonList:{
				SnapPolygon: []
			}
		};

		// 虚拟线圈区域id：1
		obj['SnapPolygonList']['SnapPolygon'].push({
			id: 1,
			polygonType: 1,
			color: {r: 0, g: 255, b: 0},
			tips: '',
			showWH: "true",
			isClosed: "true",
			// <PointNumMax>5</PointNumMax><MinClosed>5</MinClosed>
			//PointNumMax:10,
			//MinClosed:10,
			pointList: {
				point:pts
			}
		});

		var ocx = $('#TPSCalibrationDrawPlugin')[0];

		try{	
			ocx.HWP_ClearSnapInfo(4);
			var xml = x2js.json2xml_str(obj, true);
			ocx.HWP_SetSnapPolygonInfo(xml);

			ocx.HWP_SetSnapDrawMode(0, 3);
		}catch(e){}
	}

	//标定区确定
	TPSTriggerMode.okTPSCalibrationModal=function() {
		var ret = RestoreTPSCalibration();
	    if (!ret) {
	    	$("#TPSCalibrationTips").html(getNodeValue("aTPSCalibrationTips"));
	    	setTimeout(function(){$("#TPSCalibrationTips").html("");},5000);
	    	return;
	    };

	    var ocx = $("#TPSCalibrationDrawPlugin")[0];
		if(ocx){
			ocx.HWP_Stop(0);
		}

	    $('#TPSCalibration_Draw_plugin').html('');
	    $.modal.impl.close();

	    $("#main_plugin").show();
	    setTimeout(function(){
	    	if (HWP.Play() !== 0) {
		        alert(getNodeValue("previewfailed"));
		    }
	    },100);

	   	drawTPSShapes();
	}
    
    //取消相机标定
	TPSTriggerMode.cancelTPSCalibrationModal=function() {
		var ocx = $("#TPSCalibrationDrawPlugin")[0];
		if(ocx){
			ocx.HWP_Stop(0);
		}
	    $('#TPSCalibration_Draw_plugin').html('');
	    $.modal.impl.close();

	    $("#main_plugin").show();
	    setTimeout(function(){
	    	if (HWP.Play() !== 0) {
		        alert(getNodeValue("previewfailed"));
		    }
	    },500);

	    drawTPSShapes();
	}
    
    //存储标定区数据
	function RestoreTPSCalibration() {
		var cw = $('#CalibrationRegionWidth').val();
		var ch = $('#CalibrationRegionHeight').val();
     	
		// if(!CheackTriggerIntNum($('#CalibrationRegionWidth')[0],
		// 	cw, getNodeValue("laCalibrationW"), 1, 99, '')
		// 	|| !CheackTriggerIntNum($('#CalibrationRegionHeight')[0],
		// 	ch, getNodeValue("laCalibrationH"), 1, 99, '')){

		// 	return false;
		// }

		if($("#CalibrationRegionWidth").val()==""
			||$("#CalibrationRegionHeight").val()==""){
			return false;
		}
		else{
			var width=parseInt($("#CalibrationRegionWidth").val());
			var height=parseInt($("#CalibrationRegionHeight").val());
			if(!(width<100&&width>0)||!(height<100&&height>0)){
				return false;
			}
		}


		var ocx = $('#TPSCalibrationDrawPlugin')[0];
		try{
	    	var xml = ocx.HWP_GetSnapPolygonInfo();
	    	var $tps = $(m_TPSXml);
	    	var $cali = $tps.find('CalibrationRegion');

	    	$cali.find("RegionWidth").eq(0).text(cw);
	    	$cali.find("RegionLength").eq(0).text(ch);

	    	var tmpPoints = [];

	    	var $polygon = $(parseXmlFromStr(xml));
	    	$polygon.find('SnapPolygon').each(function () {
	    		var $p = $(this);
	    		var id = parseInt($p.find('id').text());
	            
	    		if (id == '1') {
	    			$p.find('point').each(function (i,n) {
	    				if (i < 4) {
	    					var x = Math.floor(parseFloat($(n).find('x').text())*1000);
							var y = Math.floor(parseFloat($(n).find('y').text())*1000);

							tmpPoints.push({
								x: x,
								y: y
							});
	    				}
					});
	    		}
	    	});

	    	if (tmpPoints.length != 4) {
	    		alert(getNodeValue("jsAreaLineNum"));
	    		return false;
	    	};

	    	
	        if (!LineCheckPoint(tmpPoints)) {
	        	alert(getNodeValue("jsAreaInterSect"));
	        	return false;
	        };

	    	for (var i = 0; i < tmpPoints.length; i++) {
	    		var p = tmpPoints[i];
	    		var $r = $cali.find('RegionCoordinates').eq(i);
				$r.find('positionX').text(p.x);
				$r.find('positionY').text(p.y);	
	    	};

	    	return true;
	    	
	    }catch(e){
	    	_log(e.message);
	    }

	    return true;
	}
    
    //绘制区域
	TPSTriggerMode.reDrawTPSRegion=function() {
		var laneId = parseInt($('#TPSModelLaneSelect').val());
		reDrawPolygonRegion(100+laneId, 
			'#TPSDrawPlugin', 
			{r: 0, g:255, b:0}, 
			 getNodeValue("TPSRegion")+laneId);	
	}

	function reDrawPolygonRegion (regionId, ocxSel, color, polygonName) {
		if (!color) {
			color = {r: 255, g: 255, b: 0};
		};
		var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>"
					+ regionId
					+ "</id><polygonType>1</polygonType><tips>" + polygonName
					+ "</tips><isClosed>false</isClosed><PointNumMax>11</PointNumMax><MinClosed>5</MinClosed>"
					+ "<color><r>"+color.r+"</r><g>"+color.g+"</g><b>"+color.b+"</b></color><pointList/></SnapPolygon></SnapPolygonList>";
		var ocx = $(ocxSel)[0];
		try{
			var iRet = ocx.HWP_SetSnapPolygonInfo(szInfo3);
		}catch(e){}
		try{
			ocx.HWP_SetSnapDrawMode(0, 2);  //设置为选择模式
		}catch(e){}
	}
    
    //绘制方向
	TPSTriggerMode.reDrawTPSDirection=function() {
		var laneId = parseInt($('#TPSModelLaneSelect').val());
		var laneCount = parseInt($('#RelatedLaneCount_videoEp').val());
		var snapLines = {
			SnapLineList: {
				SnapLine:[]
			}
		};
		
		var X = laneId/(laneCount+1);
		var startY = 0.25;
		var endY = 0.75;

		// 车道方向id： 300+车道号
		
		var _line = {
			id: 300+laneId,
			LineType: 0,
			tips:  getNodeValue("TPSRegionDirection")+laneId,
			color: {r: 255, g: 0, b: 0},
			ArrowType: 1,
			StartPos: {
				x: X,
				y: startY
			},
			EndPos: {
				x: X,
				y: endY
			}
		};

		try{
			var ocx = $('#TPSDrawPlugin')[0];
			snapLines.SnapLineList.SnapLine.push(_line);
				
			var szLineInfo = x2js.json2xml_str(snapLines);
			ocx.HWP_SetSnapLineInfo(szLineInfo);
		}catch(e){

		}	
	}
    
    //绘制虚拟线圈
	TPSTriggerMode.reDrawTPSVirtualRegion=function() {	
		var laneId = parseInt($('#TPSModelLaneSelect').val());
		reDrawPolygonRegion(200+laneId, 
			'#TPSDrawPlugin', 
			{r: 255, g:0, b:0}, 
			 getNodeValue("TPSVirtualRegion")+laneId);	
	}
    
    //重绘标定区域
	TPSTriggerMode.reDrawTPSCalibrationRegion=function() {
		var obj = {
			SnapPolygonList:{
				SnapPolygon: [{
					id: 1,
					polygonType: 1,
					color: {r: 0, g: 255, b: 0},
					tips: '',
					showWH: "true",
					isClosed: "false",
					PointNumMax:5,
					MinClosed:5,
					pointList: {}
				}]
			}
		};

		var ocx = $('#TPSCalibrationDrawPlugin')[0];

		try{	
			ocx.HWP_ClearSnapInfo(4);
			var xml = x2js.json2xml_str(obj, true);
			ocx.HWP_SetSnapPolygonInfo(xml);

			ocx.HWP_SetSnapDrawMode(0, 2);
		}catch(e){}
	}
    
    //保存数据
	TPSTriggerMode.SetTPSParam = function () {
		
		var enRealtimeDataUpload = $('*[x-model=enRealtimeDataUpload]').prop('checked') ? "true" : "false";
		var enStatisticalDataUpload = $('*[x-model=enStatisticalDataUpload]').prop('checked') ? "true" : "false";
		var statisticsTime = $('*[x-model=statisticsTime]').val();

		var $xmlDoc = $(m_TPSXml);
		$xmlDoc.find('enRealtimeDataUpload').text(enRealtimeDataUpload);
		$xmlDoc.find('enStatisticalDataUpload').text(enStatisticalDataUpload);
		$xmlDoc.find('statisticsTime').text(statisticsTime);

		$.each(["isPosenable","pointX","pointY",
			"laneFlow","queueLength","laneNumber","timeHeadway","spaceHeadway","trafficState",
			"vehicleSpeed","timeOccupyRation","spaceOccupyRation"], function  (i, n) {
			var sel = '*[x-model='+n+']';
    		
    		var $d = $(sel);
    		if ($d.length) {
    			var v = $d.val();
	    		if ($d.is(":checkbox")) {
	    			v = $d.prop('checked') ? "true":"false";
	    		}
	    		$xmlDoc.find(n).eq(0).text(v);
    		};
		});

		var iLastIndex = parseInt(m_iCurSelIONum) - 1;  
		this.StoreTPSLaneParam(iLastIndex);

		m_bSetTriggerMode = false;
		var laneCount = $('#RelatedLaneCount_videoEp').val();
		$(m_TPSXml).find('laneCount').eq(0).text(laneCount);

		CopyPostTPSParam(iLastIndex);	

		$.ajax({
			type: "put",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/TPS",
			timeout: 15000,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			data: xmlToStr(m_TPSXml),
			processData: false,
			complete:function(xhr, textStatus) {
				if(xhr.status != 200) {
					if(xhr.status == 403) {
						var szErrorInfo = m_szError8;
						szRetInfo = m_szErrorState + szErrorInfo;
					} else {
						var xmlDoc =xhr.responseXML;
						if($(xmlDoc).find("detailedStatusCode").eq(0).text() != "") {
							var szErrorInfo = getNodeValue("Error" + $(xmlDoc).find("detailedStatusCode").eq(0).text());
						} else {
							var szErrorInfo = m_szError13;
						}
						szRetInfo = m_szErrorState + szErrorInfo;
					}
		            $("#SetResultTips").html(szRetInfo); 
			        setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			        return;	
				} else {
					if($(xhr.responseXML).find("statusCode").eq(0).text() == "7") {
						m_bRebootRequired = true;
					}
					m_bSetTriggerMode = true;

					$("#CurTriggerMode").html(getNodeValue("a" + $("#selTriggerMode").val()));

					if(m_bRebootRequired) {
						szRetInfo = m_szSuccessState + m_szSuccess5;
					} else {
						szRetInfo = m_szSuccessState + m_szSuccess1;
					}

					$("#SetResultTips").html(szRetInfo); 
				    setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
				}
			}
		});

	}

		/*
	Function:检测绘制区域是否有交叉线；
	points:  绘制区域的坐标点集；
	bOpened: 绘制区域是否闭合，false--闭合；true--开合；
	Return:  true - 无交叉； false - 有交叉；
	*/
	function LineCheckPoint(points){
		var bOpened = false;
	    var iLength = points.length;
		if(iLength <4) {
			return true;
		}
		for(var i = 2; i < iLength; i++) {
			for(var j=0; j <= i - 2; j++) {
				if(i == iLength -1 && j == 0) {
					continue;
				}
				if(bOpened && typeof points[i+1] != 'object') {
					continue;
				}
				if(intersectLineLine(points[i],typeof points[i+1] == 'object'?points[i+1]:points[0], points[j], points[j+1])) {
					return false;
				}
			}
		}
		return true;
	}

	/*
	Function:检测两条线是否有交叉;
	a1:      第一条线段的起点坐标；
	a2：     第一条线段的终点坐标；
	b1：     第二条线段的起点坐标；
	b2：     第二条线段的终点坐标；
	Return： true--有交叉；false--无交叉；
	*/
	function intersectLineLine(a1, a2, b1, b2) {
	    var ua_t = (b2.x - b1.x) * (a1.y - b1.y) - (b2.y - b1.y) * (a1.x - b1.x);
	    var ub_t = (a2.x - a1.x) * (a1.y - b1.y) - (a2.y - a1.y) * (a1.x - b1.x);
	    var u_b  = (b2.y - b1.y) * (a2.x - a1.x) - (b2.x - b1.x) * (a2.y - a1.y);

	    if ( u_b != 0 ) {
	        var ua = ua_t / u_b;
	        var ub = ub_t / u_b;

	        if ( 0 <= ua && ua <= 1 && 0 <= ub && ub <= 1 ) {
				return true;
	        } else {
				return false;
	        }
	    } else {
	        if ( ua_t == 0 || ub_t == 0 ) {
				return true;
	        } else {
				return false;
	        }
	    }
	}

	function CopyPostTPSParam(srcIndex) {
		var $xmlDoc = $(m_TPSXml);
		var copySrc = $xmlDoc.find('LaneParam').eq(srcIndex);

		if (!copySrc.length) {
			return;
		};

		$('#dvTriggerParam #TriggerIOCopyDiv_TPS').find('input[ioidx]:enabled:checked').not(":hidden").each(function  (i, n) {
			var idx = parseInt($(this).attr('ioidx'), 10) - 1;
			var $dst = $xmlDoc.find("LaneParam").eq(idx);

			SimpleCopyXmlNode(copySrc[0],$dst[0],
						[{propName: 'DataAcqType', type: 'subNode'}]
                        );
		});
	}



	window.TPSTriggerMode = TPSTriggerMode;
})()