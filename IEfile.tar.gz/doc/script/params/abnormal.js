var m_iExceptionID = new Array();//异常对应的event ID
var path = m_lHttp + m_szHostName + ":" + m_lHttpPort;
for(var i = 0; i < 8; i++)
{
	m_iExceptionID[i] = 0;
}
var iMethodNum = 0;

/*************************************************
 Function:		ExceptionListInfo
 Description:	获取硬盘录像机的异常参数信息
 Input:			    无
 Output:			无
 Return:
 *************************************************/
function ExceptionListInfo(){

    var len = 0;
    try{
        var len = document.getElementById("tableEventLinkage").rows.length;
    }catch(e){
        len = 0;
    }
    for(var i = 1; i < len; i++){
        document.getElementById("tableEventLinkage").deleteRow(1);
    }

    $.ajax({
        type: "GET",
        url: path + "/PSIA/Custom/SelfExt/Event/triggers",
        timeout: 15000,
        async: false,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {

            ia(Exception).sz_exceptionXML = xmlDoc;


            if($(xmlDoc).find("EventTrigger").length > 0){
                var len = $(xmlDoc).find("EventTrigger").length;

                var eId = "";
                var isUsedEnable =false;
                var eType = "";
                var uploadCenterEnable = false;
                var alarmEnable = false;
                var lastTime = "";

                for(var i=0; i< len; i++){
                    var eventType = $(xmlDoc).find("eventType").eq(i).text();
                    if(eventType == "IO") continue;
                    getSingleEventException(eventType);
                }
            }
        }
    });
}

/*************************************************
 Function:		getSingleEventException
 Description:	获取单个异常事件函数
 Input:		eventType  异常类型
 Output:			无
 Return:
 *************************************************/
function getSingleEventException(eventType){

    var szURL = path + "/PSIA/Custom/SelfExt/Event/triggers/";
    $.ajax({
        type: "GET",
        url: szURL + eventType,
        timeout: 15000,
        async: false,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {

            var eId = "";
            var eNum = -1;
            var isUsedEnable =false;
            var eType = "";
            var uploadCenterEnable = false;
            var alarmEnable = false;
            var lastTime = "";
            var notification = "";
            var centerShowEnable = false;

            if(eventType == "diskerror"){       //            硬盘错误

                eId = $(xmlDoc).find("id").eq(0).text();
                eNum = 1;
                isUsedEnable = $(xmlDoc).find("enable").eq(0).text() == "1" ? true: false;
                eType = getNodeValue('hdError');
                lastTime = $(xmlDoc).find("notificationInterval").eq(0).text();
                centerShowEnable = true;

                for(var a=0; a < $(xmlDoc).find("notificationMethod").length; a++){
                    notification = $(xmlDoc).find("notificationMethod").eq(a).text();
                    if(notification == "center"){
                        uploadCenterEnable = true;
                    }
                    if(notification == "IO"){
                        alarmEnable = true;
                    }
                }
            }
            if(eventType == "ipconflict"){      //            IP冲突

                eId = $(xmlDoc).find("id").eq(0).text();
                eNum = 3;
                isUsedEnable = $(xmlDoc).find("enable").eq(0).text() == "1" ? true: false;
                eType = getNodeValue('ExceptionTypeOpt4');
                lastTime = $(xmlDoc).find("notificationInterval").eq(0).text();
                centerShowEnable = false;

                for(var a=0; a < $(xmlDoc).find("notificationMethod").length; a++){

                    notification = $(xmlDoc).find("notificationMethod").eq(a).text();
                    if(notification == "center"){
                        uploadCenterEnable = true;
                    }
                    if(notification == "IO"){
                        alarmEnable = true;
                    }
                }
            }
            if(eventType == "nicbroken"){  // 网线断

                eId = $(xmlDoc).find("id").eq(0).text();
                eNum = 2;
                isUsedEnable = $(xmlDoc).find("enable").eq(0).text() == "1" ? true: false;
                eType = getNodeValue('ExceptionTypeOpt3');
                lastTime = $(xmlDoc).find("notificationInterval").eq(0).text();
                centerShowEnable = false;
                for(var a=0; a < $(xmlDoc).find("notificationMethod").length; a++){

                    notification = $(xmlDoc).find("notificationMethod").eq(a).text();
                    if(notification == "center"){
                        uploadCenterEnable = true;
                    }
                    if(notification == "IO"){
                        alarmEnable = true;
                    }
                }
            }
            if(eventType == "detectorerror"){ //  信号灯检测器异常

                eId = $(xmlDoc).find("id").eq(0).text();
                eNum = 5;
                isUsedEnable = $(xmlDoc).find("enable").eq(0).text() == "1" ? true: false;
                eType = getNodeValue('ExceptionTypeOpt2');
                lastTime = $(xmlDoc).find("notificationInterval").eq(0).text();
                centerShowEnable = true;
                for(var a=0; a < $(xmlDoc).find("notificationMethod").length; a++){

                    notification = $(xmlDoc).find("notificationMethod").eq(a).text();
                    if(notification == "center"){
                        uploadCenterEnable = true;
                    }
                    if(notification == "IO"){
                        alarmEnable = true;
                    }
                }
            }
            if(eventType == "sensorserror"){  //车检器异常

                eId = $(xmlDoc).find("id").eq(0).text();
                eNum = 4;
                isUsedEnable = $(xmlDoc).find("enable").eq(0).text() == "1" ? true: false;
                eType = getNodeValue('ExceptionTypeOpt1');
                lastTime = $(xmlDoc).find("notificationInterval").eq(0).text();
                centerShowEnable = true;
                for(var a=0; a < $(xmlDoc).find("notificationMethod").length; a++){

                    notification = $(xmlDoc).find("notificationMethod").eq(a).text();
                    if(notification == "center"){
                        uploadCenterEnable = true;
                    }
                    if(notification == "IO"){
                        alarmEnable = true;
                    }
                }
            }
            insertExceptionInfoList(eId,isUsedEnable,eType,uploadCenterEnable,alarmEnable,lastTime,centerShowEnable, eNum);
        }
    });
}

/*************************************************
 Function:		insertExceptionInfoList
 Description:	插入异常信息函数
 Input:		num               异常Id
			used			  是否可以使用
			exceptionType	  异常类别
			uploadCenter	  上传中心数据
			trggerAlarm		  IO报警是否启用
			lastTime		  持续时间
			centerShowEnable  上传中心是否启用
			eId				  当前Id(无实际用处)
 Output:			无
 Return:
 *************************************************/
function insertExceptionInfoList(num,used,exceptionType,uploadCenter,trggerAlarm,lastTime,centerShowEnable, eId){
    var ObjTr;
    var ObjTd;
    var tableInsert = document.getElementById("tableEventLinkage");
    ObjTr = tableInsert.insertRow(tableInsert.rows.length);
    ObjTr.style.height = 27 + 'px';
    ObjTr.style.cursor = "pointer";
    ObjTr.style.backgroundColor ="#ffffff";
    ObjTr.style.color ="#39414A";

    for(var j = 0; j < tableInsert.rows[0].cells.length; j++){
        ObjTd = ObjTr.insertCell(j);
        $(ObjTd).css({border:"1px solid #d7d7d7",padding:"0 0 0 5px"});
        switch(j)
        {
            case 0:
                var usedInfo = "";
                if(used){
                    usedInfo = "<input type='checkbox' id='exceptionOpt_"+ num +"' name='exceptionOpt_"+ num +"' onclick='useabledExceptionInfo(this.id);' checked='checked'>";
                }else{
                    usedInfo ="<input type='checkbox' id='exceptionOpt_"+ num +"' name='exceptionOpt_"+ num +"' onclick='useabledExceptionInfo(this.id);'>";
                }
                ObjTd.innerHTML = usedInfo;
                ObjTd.id = "isUsedException_"+ num;
                ObjTd.name = eId;
                break;
            case 1:
                ObjTd.innerHTML = exceptionType;
                ObjTd.id = "exceptionType_"+ num;
                ObjTd.name = eId;
                break;
            case 2:
                var usedInfo = "";
                if(centerShowEnable){


                    if(uploadCenter){
                        usedInfo = "<input type='checkbox' id='exceptionUploadOpt_" + num + "' name='exceptionUploadOpt_"+ num +"' checked='checked'>";
                    }else{
                        usedInfo ="<input type='checkbox' id='exceptionUploadOpt_" + num + "' name='exceptionUploadOpt_"+ num +"'>";
                    }
                }
                ObjTd.innerHTML = usedInfo;
                ObjTd.id = "uploadCenter_"+ num;
                ObjTd.name = eId;
                break;
            case 3:
                var usedInfo = "";
                if(trggerAlarm){
                    usedInfo = "<input type='checkbox' id='exceptionAlarmOpt_"+ num +"' name='exceptionAlarmOpt_"+ num +"' checked='checked'>";
                }else{
                    usedInfo ="<input type='checkbox' id='exceptionAlarmOpt_"+ num +"' name='exceptionAlarmOpt_"+ num +"'>";
                }
                ObjTd.innerHTML = usedInfo;
                ObjTd.id = "trggerAlarm_"+ num;
                ObjTd.name = eId;
                if(parent.g_alarmOutNum == 0){
                    $('#exceptionAlarmOpt_'+num).css('display','none');
                }
                if(!used){
                    $('#exceptionUploadOpt_' + num).css('display','none');
                    $('#exceptionAlarmOpt_'+num).css('display','none');
                }
                break;
            case 4:
                ObjTd.innerHTML = lastTime;
                ObjTd.id = "lastTime_"+ num;
                ObjTd.name = eId;
                break;
            default:
                break;
        }
    }

}

/*************************************************
 Function:		useabledExceptionInfo
 Description:       是否启用异常类型控制函数
 Input:			    excId 启用Id
 Output:			无
 Return:
 *************************************************/
function useabledExceptionInfo(excId){
    var num = excId.split('_')[1];
    if($('#' + excId).prop('checked')){
        $('#exceptionUploadOpt_'+num).css('display','block');
        if(parent.g_alarmOutNum > 0){
            $('#exceptionAlarmOpt_'+num).css('display','block');
        }
    }else{

        $('#exceptionUploadOpt_'+num).css('display','none');
        $('#exceptionAlarmOpt_'+num).css('display','none');
		$('#lastTime_'+num).html('');

        if($('#lastTimeOpt_'+num).length > 0){
            $('#lastTimeOpt_'+num).css('display','none');
            document.getElementById('lastTimeOpt_' + num).parentNode.parentNode.style.backgroundColor="#ffffff";
            document.getElementById('lastTimeOpt_' + num).parentNode.parentNode.style.color="#39414A";
        }
    }
}

// <!--设备异常参数信息(接口需要传入 异常类型)-->
/*************************************************
Function:		GetExceptionInfo	
Description:	获取硬盘录像机的异常参数信息   已作废!!!
Input:			无
Output:			无	
Return:			以XML形式记录硬盘录像机异常参数信息的一个字符串。
*************************************************/
function GetExceptionInfo()               
{
	iMethodNum = 0;
	$("input[type='checkbox']").prop("checked", false);
	GetAlarmOutNo();//获取报警输出数
	CreateAlarmOutputList(m_iAlarmOutputAnalogNum,m_iAlarmOutputTotalNum); //列出触发报警输出通道
	
	$("#ExEmail").prop("checked",false);
	$("#ExUpload").prop("checked",false);
	$("#ExSoundAlarm").prop("checked",false);
	$("#ExMonitorAlarm").prop("checked",false);
	
	if($("#ExceptionType").val() == "nicbroken" || $("#ExceptionType").val() == "ipconflict")
	{
		$("#ExUpload").prop("disabled",true);
		$("#ExEmail").prop("disabled",true);
	}
	else
	{
		$("#ExUpload").prop("disabled",false);
		$("#ExEmail").prop("disabled",false);
	}
	szXmlhttp = new getXMLHttpRequest();
	szXmlhttp.onreadystatechange = GetExceptionInfoCallback;
	var szURL = path + "/PSIA/Custom/SelfExt/Event/triggers";

    var userPwdValue = g_oWebSession.getItem("userInfo"+m_lHttpPort);
    var userName = Base64.decode(userPwdValue).split(":")[0];
    var password = Base64.decode(userPwdValue).split(":")[1];

	szXmlhttp.open("GET", szURL, true,userName,password);
	szXmlhttp.setRequestHeader("If-Modified-Since","0");

    szXmlhttp.send(null);
}

/*************************************************
Function:		GetExceptionInfoCallback	
Description:	获取硬盘录像机的异常参数信息的回调函数   已作废!!!
Input:			无
Output:			无	
Return:			
*************************************************/
function GetExceptionInfoCallback()
{
	if(szXmlhttp.readyState == 4)
	{   
		if(szXmlhttp.status == 200)
		{
			var xmlDoc = szXmlhttp.responseXML;
			var EventNum = xmlDoc.documentElement.getElementsByTagName('EventTrigger').length;
			for(var i = 0; i < EventNum; i++)
			{
				if(xmlDoc.documentElement.getElementsByTagName('eventType')[i].childNodes[0].nodeValue == $("#ExceptionType").val())
				{
					var index = document.getElementById("ExceptionType").selectedIndex;
					m_iExceptionID[index] = get_previoussibling(xmlDoc.documentElement.getElementsByTagName('eventType')[i]).childNodes[0].nodeValue;
					EventTriggerNotificationList = xmlDoc.documentElement.getElementsByTagName('EventTriggerNotificationList')[i];
					iMethodNum = EventTriggerNotificationList.getElementsByTagName("notificationMethod").length;

					var iOutPut = EventTriggerNotificationList.getElementsByTagName("outputIOPortID").length;					   
				   for(var j = 0;j < iOutPut; j++)
				   {
					   var iNo = EventTriggerNotificationList.getElementsByTagName("outputIOPortID")[j].childNodes[0].nodeValue;
					   for(var i = 0; i < m_iAlarmOutputTotalNum; i++)
					   {
						   if(m_szAlarmOutInfo[i] == iNo)
						   {
							   iNo = i;
							   break;
						   }
					   }
					   $("#AlarmOutputCheckboxChanO-" + (iNo + 1)).prop("checked",true);
				   }
				   for(i = 0;i < iMethodNum;i++)//报警输入联动信息
				   {
					   if("email" == EventTriggerNotificationList.getElementsByTagName('notificationMethod')[i].childNodes[0].nodeValue)
					   {
						   $("#ExEmail").prop("checked",true);
					   }
					   if("center" == EventTriggerNotificationList.getElementsByTagName('notificationMethod')[i].childNodes[0].nodeValue)
					   {
						   $("#ExUpload").prop("checked",true);
					   }
					   if("beep" == EventTriggerNotificationList.getElementsByTagName('notificationMethod')[i].childNodes[0].nodeValue)
					   {
						   $("#ExSoundAlarm").prop("checked",true);
					   }
						if("monitorAlarm" == EventTriggerNotificationList.getElementsByTagName('notificationMethod')[i].childNodes[0].nodeValue)
					   {
						   $("#ExMonitorAlarm").prop("checked",true);
					   }
				   }
				   CheackAlarmOutputAllSel();  //判断是否全选
				   break;
				}//if
			}//for
		}//status = 200
	}
}
/*************************************************
Function:		SaveSingleExceptionInfo	
Description:	保存单条异常信息
Input:			triggerId  当前异常事件ID
Output:			无	
Return:			
*************************************************/
function SaveSingleExceptionInfo(triggerId){
    var XmlTempDoc = ia(Exception).sz_exceptionXML;

    var XmlDoc = new createxmlDoc();
    var Instruction = XmlDoc.createProcessingInstruction("xml","version='1.0' encoding='utf-8'");
    XmlDoc.appendChild(Instruction);
    var Root = XmlDoc.createElement("EventTrigger");

    var triggerLength = $(XmlTempDoc).find('EventTrigger').length;
    for(var i = 0; i < triggerLength; i++){

        var eventId = $(XmlTempDoc).find('EventTrigger').eq(i).find('id').eq(0).text();

        if(eventId != triggerId) continue;

        var eventType =$(XmlTempDoc).find('EventTrigger').eq(i).find('eventType').eq(0).text();
        var eventDescription = $(XmlTempDoc).find('EventTrigger').eq(i).find('eventDescription').eq(0).text();

        Element = XmlDoc.createElement("enable");
        if(eventId == 'diskerror'){        //硬盘错误 
            text = XmlDoc.createTextNode($('#exceptionOpt_diskerror').prop('checked')?"1":"0");
        }else if(eventId == 'ipconflict'){ //IP冲突
            text = XmlDoc.createTextNode($('#exceptionOpt_ipconflict').prop('checked')?"1":"0");
        }else if(eventId == 'nicbroken'){  //网线断
            text = XmlDoc.createTextNode($('#exceptionOpt_nicbroken').prop('checked')?"1":"0");
        }else if(eventId == 'detectorerror'){//信号灯检测器异常
            text = XmlDoc.createTextNode($('#exceptionOpt_detectorerror').prop('checked')?"1":"0");
        }else if(eventId == 'sensorserror'){ //车检器异常
            text = XmlDoc.createTextNode($('#exceptionOpt_sensorserror').prop('checked')?"1":"0");
        }
        Element.appendChild(text);
        Root.appendChild(Element);

        Element = XmlDoc.createElement("id");
        text = XmlDoc.createTextNode(eventId);
        Element.appendChild(text);
        Root.appendChild(Element);

        Element = XmlDoc.createElement("eventType");
        text = XmlDoc.createTextNode(eventType);
        Element.appendChild(text);
        Root.appendChild(Element);

        Element = XmlDoc.createElement("eventDescription");
        text = XmlDoc.createTextNode(eventDescription);
        Element.appendChild(text);
        Root.appendChild(Element);

        notificationListObject = XmlDoc.createElement("EventTriggerNotificationList");

        if(eventId == 'diskerror'){    //硬盘错误

            if($('#exceptionAlarmOpt_diskerror').prop('checked')){

                EventTriggerNotification = XmlDoc.createElement("EventTriggerNotification");

                Element = XmlDoc.createElement("id");
                text = XmlDoc.createTextNode("IO-1");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationMethod");
                text = XmlDoc.createTextNode("IO");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationRecurrence");
                text = XmlDoc.createTextNode("beginning");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationInterval");
                text = XmlDoc.createTextNode($('#lastTimeOpt_diskerror').length>0?$('#lastTimeOpt_diskerror').val():$('#lastTime_diskerror').html());
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("outputIOPortID");
                text = XmlDoc.createTextNode("1");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);
                notificationListObject.appendChild(EventTriggerNotification);
            }

            if($('#exceptionUploadOpt_diskerror').prop('checked')){

                EventTriggerNotification = XmlDoc.createElement("EventTriggerNotification");

                Element = XmlDoc.createElement("id");
                text = XmlDoc.createTextNode("center");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationMethod");
                text = XmlDoc.createTextNode("center");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationRecurrence");
                text = XmlDoc.createTextNode("beginning");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);
                notificationListObject.appendChild(EventTriggerNotification);
            }

        }
        if(eventId == 'ipconflict'){    //IP冲突  无上传中心。

            if($('#exceptionAlarmOpt_ipconflict').prop('checked')){

                EventTriggerNotification = XmlDoc.createElement("EventTriggerNotification");
                Element = XmlDoc.createElement("id");
                text = XmlDoc.createTextNode("IO-1");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationMethod");
                text = XmlDoc.createTextNode("IO");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationRecurrence");
                text = XmlDoc.createTextNode("beginning");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationInterval");
                text = XmlDoc.createTextNode($('#lastTimeOpt_ipconflict').length>0?$('#lastTimeOpt_ipconflict').val():$('#lastTime_ipconflict').html());
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("outputIOPortID");
                text = XmlDoc.createTextNode("1");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);
                notificationListObject.appendChild(EventTriggerNotification);
            }
        }
        if(eventId == 'nicbroken'){     //网线断  无上传中心

            if($('#exceptionAlarmOpt_nicbroken').prop('checked')){

                EventTriggerNotification = XmlDoc.createElement("EventTriggerNotification");
                Element = XmlDoc.createElement("id");
                text = XmlDoc.createTextNode("IO-1");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationMethod");
                text = XmlDoc.createTextNode("IO");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationRecurrence");
                text = XmlDoc.createTextNode("beginning");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationInterval");
                text = XmlDoc.createTextNode($('#lastTimeOpt_nicbroken').length>0?$('#lastTimeOpt_nicbroken').val():$('#lastTime_nicbroken').html());
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("outputIOPortID");
                text = XmlDoc.createTextNode("1");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);
                notificationListObject.appendChild(EventTriggerNotification);
            }
        }
        if(eventId == 'detectorerror'){     //信号灯检测器异常

            if($('#exceptionAlarmOpt_detectorerror').prop('checked')){

                EventTriggerNotification = XmlDoc.createElement("EventTriggerNotification");

                Element = XmlDoc.createElement("id");
                text = XmlDoc.createTextNode("IO-1");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationMethod");
                text = XmlDoc.createTextNode("IO");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationRecurrence");
                text = XmlDoc.createTextNode("beginning");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationInterval");
                text = XmlDoc.createTextNode($('#lastTimeOpt_detectorerror').length>0?$('#lastTimeOpt_detectorerror').val():$('#lastTime_detectorerror').html());
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("outputIOPortID");
                text = XmlDoc.createTextNode("1");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);
                notificationListObject.appendChild(EventTriggerNotification);
            }

            if($('#exceptionUploadOpt_detectorerror').prop('checked')){

                EventTriggerNotification = XmlDoc.createElement("EventTriggerNotification");

                Element = XmlDoc.createElement("id");
                text = XmlDoc.createTextNode("center");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationMethod");
                text = XmlDoc.createTextNode("center");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationRecurrence");
                text = XmlDoc.createTextNode("beginning");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);
                notificationListObject.appendChild(EventTriggerNotification);
            }

        }
        if(eventId == 'sensorserror'){      //车检器异常

            if($('#exceptionAlarmOpt_sensorserror').prop('checked')){

                EventTriggerNotification = XmlDoc.createElement("EventTriggerNotification");

                Element = XmlDoc.createElement("id");
                text = XmlDoc.createTextNode("IO-1");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationMethod");
                text = XmlDoc.createTextNode("IO");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationRecurrence");
                text = XmlDoc.createTextNode("beginning");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationInterval");
                text = XmlDoc.createTextNode($('#lastTimeOpt_sensorserror').length > 0?$('#lastTimeOpt_sensorserror').val():$('#lastTime_sensorserror').html());
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("outputIOPortID");
                text = XmlDoc.createTextNode("1");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);
                notificationListObject.appendChild(EventTriggerNotification);
            }

            if($('#exceptionUploadOpt_sensorserror').prop('checked')){

                EventTriggerNotification = XmlDoc.createElement("EventTriggerNotification");

                Element = XmlDoc.createElement("id");
                text = XmlDoc.createTextNode("center");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationMethod");
                text = XmlDoc.createTextNode("center");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);

                Element = XmlDoc.createElement("notificationRecurrence");
                text = XmlDoc.createTextNode("beginning");
                Element.appendChild(text);
                EventTriggerNotification.appendChild(Element);
                notificationListObject.appendChild(EventTriggerNotification);
            }
        }

        Root.appendChild(notificationListObject);
    }

    XmlDoc.appendChild(Root);

    $.ajax({
        type: "put",
        url: path + "/PSIA/Custom/SelfExt/Event/triggers/" + triggerId,
        timeout: 15000,
        processData: false,
        async: false,
        data: XmlDoc,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        complete:function(xhr, textStatus) {
            SaveState(xhr);
        }
    });
}

/*************************************************
Function:		SaveExceptionInfo	
Description:	设置硬盘录像机的异常参数信息
Input:			lExceptionType	异常类型
				lpAlarmOutCfgXML 以XML形式记录硬盘录像机异常参数信息的一个字符串。
Output:			无	
Return:			-1 -- 失败，0 -- 成功， 1 -- 成功并需要重启设备。
*************************************************/
function SaveExceptionInfo()
{
    var XmlTempDoc = ia(Exception).sz_exceptionXML;
    var triggerLength = $(XmlTempDoc).find('EventTrigger').length;
    for(var i = 0; i < triggerLength; i++){

        var eventId = $(XmlTempDoc).find('EventTrigger').eq(i).find('id').eq(0).text();
        if(fetchEventExceptionByType(eventId)) continue;
        SaveSingleExceptionInfo(eventId);
    }
}
/*************************************************
Function:		fetchEventExceptionByType	
Description:	根据异常类型遍历事件的公共函数
Input:			eventType	异常类型
Output:			无
Return:			true: 正常判断 false: 错误判断
*************************************************/
function fetchEventExceptionByType(eventType){//&& $('#exceptionOpt_nicbroken').prop("checked")
    if(eventType == 'nicbroken'){
        return false;
    }else if(eventType == 'diskerror' ){//&& $('#exceptionOpt_diskerror').prop("checked")
        return false;
    }else if(eventType == 'ipconflict'){// && $('#exceptionOpt_ipconflict').prop("checked")
        return false;
    }else if(eventType == 'sensorserror'){//&& $('#exceptionOpt_sensorserror').prop("checked")
        return false;
    }else if(eventType == 'detectorerror'){// && $('#exceptionOpt_detectorerror').prop("checked")
        return false;
    }
    return true;
}


/*************************************************
Function:		SelectAlarmText	
Description:	选中异常信息事件
Input:			event	异常类型
Output:			无
Return:			无
*************************************************/
function SelectAlarmText(event){

    event = event?event:(window.event?window.event:null);
    var ObjTable = event.srcElement?event.srcElement:event.target;

    if(ObjTable.tagName == "TD")
    {
        while(ObjTable.tagName != "TR")
        {
            ObjTable = ObjTable.parentNode;
        }
        var curentOjbId = ObjTable.childNodes[0].id.split('_')[1];

        for(var i=1;i< ObjTable.parentNode.childNodes.length;i++ ){

            var trObj = ObjTable.parentNode.getElementsByTagName('tr')[i];
            var objId = trObj.getElementsByTagName('td')[0].id.split('_')[1];

            if(!$('#exceptionOpt_' + curentOjbId).prop('checked') || parent.g_alarmOutNum == 0){
                return;
            }

            trObj.style.backgroundColor="#ffffff";
            trObj.style.color="#39414A";

            if(curentOjbId != objId ){
                $('#lastTime_'+objId).html($('#lastTimeOpt_' + objId).val());
            }else{
                trObj.style.backgroundColor="#316ac5";
                trObj.style.color="#ffffff";
                var v = '';
                if($('#lastTimeOpt_'+objId).length > 0){
                    v = $('#lastTimeOpt_'+objId).val()||'';
                }else{
                    v = $('#lastTime_'+objId).html()||'';
                }

                var szInfo = "<input type='text' class='width130' maxlength='12' value='" + v + "' id='lastTimeOpt_"+ objId +"'/>";
                $('#lastTime_'+objId).html(szInfo);
                $('#lastTimeOpt_'+objId).focus();
            }
        }
    }
}