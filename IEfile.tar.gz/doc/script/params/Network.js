document.charset = "utf-8";
var g_oXmlRtspPort;
var g_oXmlHttpPort;
var g_bIsRestart = true;
var g_bIsErorr=false;
var g_bHttpXhr=null;
var g_oXhr = null;
var g_oSNMPXml = null;  //记录取得的snmp信息
var m_iSelectItem = -1;
var Network = {
	tabs: null	// 保存网络配置页面的tabs对象引用
};
var m_strItem = new Array();
for(var i = 0; i < 15; i++) {
	m_strItem[i] = "none";
}
var m_strCustomStr = new Array();
for(var i = 0; i < 15; i++) {
	m_strCustomStr[i] = "";
}

function DDNS() {
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(DDNS);
pr(DDNS).update = function() {
	$('#SetResultTips').html('');
	$("#SaveConfigBtn").show();
	g_transStack.clear();
	var that = this;
	g_transStack.push(function() {
		that.setLxd(parent.translator.getLanguageXmlDoc(["System", "DDNS"]));
		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	}, true);
	initDDNS();
}

function PPPoE() {
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(PPPoE);
pr(PPPoE).update = function() {
	$('#SetResultTips').html('');
	$("#SaveConfigBtn").show();
	g_transStack.clear();
	var that = this;
	g_transStack.push(function() {
		that.setLxd(parent.translator.getLanguageXmlDoc(["Network", "PPPoE"]));
		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	}, true);
	initPPPOE();
}

function SNMP() {
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(SNMP);
pr(SNMP).update = function() {
	$('#SetResultTips').html('');
	$("#SaveConfigBtn").show();
	g_transStack.clear();
	var that = this;
	g_transStack.push(function() {
		that.setLxd(parent.translator.getLanguageXmlDoc(["Network", "SNMP"]));
		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	}, true);
	initSNMP();
}

function P8021x() {
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(P8021x);
pr(P8021x).update = function() {
	$('#SetResultTips').html('');
	$("#SaveConfigBtn").show();
	g_transStack.clear();
	var that = this;
	g_transStack.push(function() {
		that.setLxd(parent.translator.getLanguageXmlDoc(["Network", "P8021x"]));
		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	}, true);
	init8021x();
}

function QoS() {
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(QoS);
pr(QoS).update = function() {
	$('#SetResultTips').html('');
	$("#SaveConfigBtn").show();
	g_transStack.clear();
	var that = this;
	g_transStack.push(function() {
		that.setLxd(parent.translator.getLanguageXmlDoc(["Network", "QoS"]));
		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	}, true);
	initQos();
}

/*******WIFI********/
function WIFI() {
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(WIFI);
pr(WIFI).update = function() {
	$('#SetResultTips').html('');
	$("#SaveConfigBtn").show();
	g_transStack.clear();
	var that = this;
	g_transStack.push(function() {
		that.setLxd(parent.translator.getLanguageXmlDoc(["Network", "WIFI"]));
		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	}, true);
	initWIFI();
}

//28181
function Cfg28181() {
    SingletonInheritor.implement(this);
    this.m_xmlCfg281281Capa = "";  //能力集
    this.m_xmlCfg281281 = "";   //28281参数
    this.m_xmlSIPInfo = "";   //报警ID
    this.m_bNeedReboot = false; //保存参数需要两条命令，所以需要一个参数来保存是否要重启
}
SingletonInheritor.declare(Cfg28181);
pr(Cfg28181).update = function () {
	window.parent.$("#dvErrorTips").hide().html("");
	$("#SetResultTips").html("");
    $("#SaveConfigBtn").show();
    g_transStack.clear();
    var that = this;
    g_transStack.push(function () {
        that.setLxd(parent.translator.getLanguageXmlDoc(["System", "Cfg28181"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);

    this.Init28181();
    autoResizeIframe();
}

/*************************************************
Function:		GetPPPOEInfo
Description:	获取PPPOE信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function GetPPPOEInfo()
{
	var szURL = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/PPPoE";
	$.ajax(
	{
		type: "GET",
		url: szURL,
		timeout: 15000,
		async: false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) 
		{
			if("true" == xmlDoc.documentElement.getElementsByTagName('enabled')[0].childNodes[0].nodeValue)
			{
				$("#PPPOEenabled").prop("checked",true);
				$("#PPPOEUserPsw").val(oCheckPassword.m_szDefaultPassword);
				$("#PswConfirm").val(oCheckPassword.m_szDefaultPassword);
			}
			else
			{
				$("#PPPOEenabled").prop("checked",'');
			}
			
			if(xmlDoc.documentElement.getElementsByTagName('userName')[0].hasChildNodes())
			{
			    $("#PPPOEUserName").val(xmlDoc.documentElement.getElementsByTagName('userName')[0].childNodes[0].nodeValue);
			}
			else
			{
			    $("#PPPOEUserName").val('');
			}
			oCheckPassword.checkUserName($(xmlDoc).find('userName').eq(0).text(), $('#PPPOEUserPsw'), $('#PswConfirm'));
			
			if(!$("#PPPOEenabled").prop("checked"))
			{
				$("#PPPOEUserName").prop("disabled",true);   
				$("#PPPOEUserPsw").prop("disabled",true); 
				$("#PswConfirm").prop("disabled",true); 
				$("#PPPoEIP").val('0.0.0.0');
			}
			else
			{
			    GetPPPOEAddress();
			}
		}
	});
}
/*************************************************
Function:		SetPPPOEInfo
Description:	设置PPPOE信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function SetPPPOEInfo()
{
	var szAreaNameInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
	$("#PswConfirmtips").html('');
	if($("#PPPOEenabled").prop("checked"))
	{
	    if(!CheackStringLenthNull($('#PPPOEUserName').val(),'PPPOEUserNametips','jsPPPOEName',32))
	    {
	  	    return;
	    }
	    if(!CheackStringLenth($('#PPPOEUserPsw').val(),'PPPOEUserPswtips','jsPPPOEPassword',16))
	    {
	  	    return;
	    }
		if($("#PPPOEUserPsw").val() != $("#PswConfirm").val() )
		{
			var szAreaNameInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
			szAreaNameInfo += getNodeValue('jsPwdCheckMismatch');
			$("#SetResultTips").html(szAreaNameInfo);
			return -1;
		}
		if($('#PPPOEUserPsw').val().length == 0)
		{
			var szPasswordInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
			szPasswordInfo += getNodeValue("gePassword") + getNodeValue("NullTips");
			$("#PPPOEUserPswtips").html(szPasswordInfo);
			return -1;
		}
	}
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><PPPoE><id>1</id>";
	
	szXml += "<enabled>"+$("#PPPOEenabled").prop("checked").toString()+"</enabled>";
	
	szXml += "<ethernetIfId>1</ethernetIfId>";
	
	szXml += "<userName>"+$('#PPPOEUserName').val().replace(/&/g, "&amp;").replace(/</g, "&lt;")+"</userName>";
	
    if($('#PPPOEUserPsw').val() != "" && $('#PPPOEUserPsw').val() != oCheckPassword.m_szDefaultPassword)
	{
		szXml += "<password>"+$('#PPPOEUserPsw').val().replace(/&/g, "&amp;").replace(/</g, "&lt;")+"</password>";
	}
	
	szXml += "</PPPoE>";
	
	var xmlDoc = parseXmlFromStr(szXml);

	var szURL = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/PPPoE/1";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		EnablePPPOE
Description:	设置PPPOE状态
Input:			无			
Output:			无
return:			无				
*************************************************/
function EnablePPPOE()
{
	if($("#PPPOEenabled").prop("checked"))
	{
		$("#PPPOEUserName").prop("disabled",false);   
		$("#PPPOEUserPsw").prop("disabled",false); 
		$("#PswConfirm").prop("disabled",false);
	}else
	{
		$("#PPPOEUserName").prop("disabled",true);   
		$("#PPPOEUserPsw").prop("disabled",true); 
		$("#PswConfirm").prop("disabled",true);
	}
}
/*************************************************
Function:		GetPPPOEAddress
Description:	获取PPPOE IP地址
Input:			无			
Output:			无
return:			无				
*************************************************/
function GetPPPOEAddress()
{
	var szURL = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/PPPoE/1/status";
	$.ajax(
	{
		type: "GET",
		url: szURL,
		timeout: 15000,
		async: false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) 
		{
			if(xmlDoc.documentElement.getElementsByTagName('ipAddress')[0].hasChildNodes())
			{
				$("#PPPoEIP").val($(xmlDoc).find('ipAddress').eq(0).text());
			}
			else
			{
				$("#PPPoEIP").val('0.0.0.0');
			}
		}
	});
}
/*************************************************
Function:		GetDDNSCapabilities
Description:	获取DDNS能力集
Input:			无			
Output:			无
return:			无				
*************************************************/
function GetDDNSCapability()
{
	var szURL = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/DDNS/capabilities";
	$.ajax(
	{
		type: "GET",
		url: szURL,
		timeout: 15000,
		async: false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) 
		{
			var DDNSType = [];
			if($(xmlDoc).find('provider').length > 0)
			{
				$("#provider").empty();
				DDNSType = $(xmlDoc).find('provider').eq(0).attr("opt").split(",");
			}
			for(i = 0;i < DDNSType.length; i++)
			{
				switch(DDNSType[i])
				{
					case 'DynDns':
						strTemp = 'DynDNS';
						break;
					case 'PeanutHall':
						strTemp = 'PeanutHull';
						break;
					case 'NoIpDns':
						strTemp = 'NO-IP';
						break;
					default:
						strTemp = DDNSType[i];
						break;
				}
				$("<option value ='"+DDNSType[i]+"'>"+strTemp+"</option>").appendTo("#provider");
			}
		}
	});
}
/*************************************************
Function:		GetDDNSInfo
Description:	获取网络基本信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function GetDDNSInfo()
{
	GetDDNSCapability();
	$.ajax(
	{
		type: "GET",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/DDNS/1",
		async: false,
		timeout: 15000,
		beforeSend: function(xhr) 
		{
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) 
		{
			if("true" == $(xmlDoc).find('enabled').eq(0).text())
			{
				$("#DDNSenabled").prop("checked",true);
			}
			else
			{
				$("#DDNSenabled").prop("checked",'');
			}
			
			m_szDDNS[0] = $(xmlDoc).find('provider').eq(0).text();
			
			addressingFormatType = $(xmlDoc).find('addressingFormatType').eq(0).text();  
			if(addressingFormatType == 'hostname')
			{
				m_szDDNS[1] = $(xmlDoc).find('hostName').eq(0).text();
			}
			else
			{
				m_szDDNS[1] = $(xmlDoc).find('ipAddress').eq(0).text();
			}
			
			if($(xmlDoc).find('portNo').length > 0)
			{
				$('#portNoDDNS_tr').show();
				m_szDDNS[2] = $(xmlDoc).find('portNo').eq(0).text();
			}
			
			m_szDDNS[3] = $(xmlDoc).find('userName').eq(0).text();
			if(m_szDDNS[3] != "" && m_szDDNS[3] != undefined)
			{
				m_szDDNS[4] = oCheckPassword.m_szDefaultPassword;
			}
			else
			{
				m_szDDNS[4] = ""; 
			}
			
			m_szDDNS[5] = $(xmlDoc).find('deviceDomainName').eq(0).text();
				 
			$("#provider").val(m_szDDNS[0]);
			SelectDDNSType(m_szDDNS[0]);
			EnableDDNS();
		},
		error: function(xhr, textStatus, errorThrown)
		{
			alert(m_szError400);
		}
	});
}
/*************************************************
Function:		SetDDNSInfo
Description:	设置DDNS参数
Input:			无			
Output:			无
return:			无				
*************************************************/
function SetDDNSInfo()
{
	if(!CheackStringLenth($("#serverIPAddress").val(),'ServerIPAddressStips','laServerAdd',64))
	{
		return;
	}
	if(!CheackStringLenth($("#UserName").val(),'UserNametips','geUserName',32))
	{
		return;
	}
	if(!CheackStringLenth($("#Password").val(),'Passwordtips','gePassword',16))
	{
		return;
	}
	if(!CheackStringLenth($("#domainName").val(),'ServerNameDDNStips','laDeviceDomain',64))
	{
		return;
	}
	
	if($("#DDNSenabled").prop("checked") && !$('#UserName').prop("disabled"))
	{
		if($("#Password").val() != $("#ConfirmPassword").val() )
		{
			var szAreaNameInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
			szAreaNameInfo += getNodeValue('jsPwdCheckMismatch');
			$("#SetResultTips").html(szAreaNameInfo);
			return -1;
		}
		if($('#Password').val().length == 0 && $('#UserName').val().length != 0)
		{
			var szPasswordInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
			szPasswordInfo += getNodeValue("gePassword") + getNodeValue("NullTips");
			$("#Passwordtips").html(szPasswordInfo);
			return -1;
		}		
	}
	$("#ConfirmPasswordtips").html('');
	//开始更改
	var szXml = "<?xml version='1.0' encoding='utf-8'?>";
	szXml += "<DDNS><id>1</id>";
	szXml += "<enabled>"+$("#DDNSenabled").prop("checked").toString()+"</enabled>";
	szXml += "<provider>"+$('#provider').val()+"</provider>";
	
	if(!$("#serverIPAddress").prop("disabled"))
	{
		szXml += "<serverAddress>";
		//服务器地址类型
		var strIpAddressType = CheckAddressingType($("#serverIPAddress").val());
		var szTipsInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
		if(strIpAddressType == "hostName")
		{
			if(!$.isDomain($("#serverIPAddress").val()))
			{
				$("#ServerIPAddressStips").html(szTipsInfo + getNodeValue("WrongTips") + getNodeValue("laServerAdd"));
				setTimeout(function(){$("#ServerIPAddressStips").html("");}, 5000);
				return;
			}
			szXml += "<addressingFormatType>hostname</addressingFormatType><hostName>"+$("#serverIPAddress").val().replace(/&/g, "&amp;").replace(/</g, "&lt;")+"</hostName>";
		}
		else if(strIpAddressType == "ipv6Address")
		{
			if(!$.isIPv6($("#serverIPAddress").val()))
			{
				$("#ServerIPAddressStips").html(getNodeValue(szTipsInfo + "WrongTips") + getNodeValue("laServerAdd"));
				setTimeout(function(){$("#ServerIPAddressStips").html("");}, 5000);
				return;
			}
			szXml += "<addressingFormatType>ipaddress</addressingFormatType><ipv6Address>"+$("#serverIPAddress").val()+"</ipv6Address>";
		}
		else
		{
			if(!$.isIpAddress($("#serverIPAddress").val()))
			{
				$("#ServerIPAddressStips").html(szTipsInfo + getNodeValue("WrongTips") + getNodeValue("laServerAdd"));
				setTimeout(function(){$("#ServerIPAddressStips").html("");}, 5000);
				return;
			}
			szXml += "<addressingFormatType>ipaddress</addressingFormatType><ipAddress>"+$("#serverIPAddress").val()+"</ipAddress>";
		}
		szXml += "</serverAddress>";
	}
	
	if($('#portNoDDNS_tr').css('display') && !$('#portNo').prop('disabled'))
	{
		if(!CheackServerIDIntNum($("#portNo").val(),'Porttips','gePort',1,65535))
		{
			return;
		}
		szXml += "<portNo>"+$("#portNo").val()+"</portNo>";
	}
	
	if($('#provider').val().toLocaleLowerCase() != "easyddns" && !$("#domainName").prop("disabled"))
	{
		if(!$.isDomain($("#domainName").val()))
		{
			$("#ServerNameDDNStips2").html(szTipsInfo + getNodeValue("WrongTips") + getNodeValue("laDeviceDomain"));
			setTimeout(function(){$("#ServerNameDDNStips2").html("");}, 5000);
			return;
		}
	}
	szXml += "<deviceDomainName>"+$('#domainName').val().replace(/&/g, "&amp;").replace(/</g, "&lt;")+"</deviceDomainName>";

	szXml += "<userName>"+$('#UserName').val().replace(/&/g, "&amp;").replace(/</g, "&lt;")+"</userName>";

    if($("#Password").val() != "" && $('#Password').val() != oCheckPassword.m_szDefaultPassword)
	{
		szXml += "<password>"+$('#Password').val()+"</password>";
	}
	
	szXml += "</DDNS>";
	var xmlDoc = parseXmlFromStr(szXml);
	//结束更改  
	var szURL = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/DDNS/1";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		error: function(xhr, textStatus, errorThrown)
		{
			if("102" == $(xhr.responseXML).find("Extensions").eq(0).find("detailedStatusCode").eq(0).text())
			{
				var szAreaNameInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
				$("#ServerNameDDNStips2").html(szAreaNameInfo+getNodeValue("jsDomainAlreadyExist"));
				$("#domainName").focus().val($("#domainName").val());
				setTimeout(function(){$("#ServerNameDDNStips2").html("");},5000)
			}
			else
			{
				SaveState(xhr);
			}
		},
		success: function(xmlDoc, textStatus, xhr)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		SelectDDNSType
Description:	选择协议类型
Input:			无			
Output:			无
return:			无				
*************************************************/
function SelectDDNSType(iType)
{
	if(iType == "IPServer")
	{
		$("#serverIPAddress").prop("disabled",false);
		$("#UserName").prop("disabled",true); 
		$("#Password").prop("disabled",true);
		$("#ConfirmPassword").prop("disabled",true);
		$("#domainName").prop("disabled",true); 
		$("#portNo").prop("disabled",true);
	}
	else if(iType == "DynDns" || iType == "NoIpDns" || iType == "DynDNS")
	{
		$("#serverIPAddress").prop("disabled",false);
		$("#UserName").prop("disabled",false); 
		$("#Password").prop("disabled",false); 
		$("#ConfirmPassword").prop("disabled",false);
		$("#domainName").prop("disabled",false); 
		$("#portNo").prop("disabled",true);
	}
	else if(iType == "PeanutHall")
	{
		$("#serverIPAddress").prop("disabled",true);
		$("#domainName").prop("disabled",true); 
		$("#UserName").prop("disabled",false); 
		$("#Password").prop("disabled",false); 
		$("#ConfirmPassword").prop("disabled",false);
		$("#portNo").prop("disabled",true);
	}
	else if(iType.toLocaleLowerCase() == "easyddns")
	{
		$("#serverIPAddress").prop("disabled",false);
		$("#domainName").prop("disabled",false); 
		$("#UserName").prop("disabled",true); 
		$("#Password").prop("disabled",true); 
		$("#ConfirmPassword").prop("disabled",true);
		$("#portNo").prop("disabled",true);
	}
	else
	{
		$("#serverIPAddress").prop("disabled",false);
		$("#UserName").prop("disabled",false); 
		$("#Password").prop("disabled",false); 
		$("#ConfirmPassword").prop("disabled",false);
		$("#domainName").prop("disabled",false); 
		$("#portNo").prop("disabled",true);
	}
	if(iType == m_szDDNS[0])
	{
		$("#domainName").val(m_szDDNS[5]);
		$("#portNo").val(m_szDDNS[2]);
		$("#UserName").val(m_szDDNS[3]);
		if($("#DDNSenabled").prop("checked") && iType != 'IPServer')
		{
			oCheckPassword.checkUserName(m_szDDNS[3], $('#Password'), $('#ConfirmPassword'));
		}
		$("#serverIPAddress").val(m_szDDNS[1]);	
	}
	else
	{
		$("#domainName").val('');
		$("#portNo").val('0');
		$("#UserName").val('');
		$("#Password").val('');
		$("#ConfirmPassword").val('');
		$("#serverIPAddress").val('');
	}
}
/*************************************************
Function:		EnableDDNS
Description:	设置DDNS状态
Input:			无			
Output:			无
return:			无				
*************************************************/
function EnableDDNS()
{
	$("#portNo").prop("disabled",true); 
	if($("#DDNSenabled").prop("checked"))
	{
		$("#provider").prop("disabled",false);   
		$("#UserName").prop("disabled",false); 
		$("#Password").prop("disabled",false);  
		$("#ConfirmPassword").prop("disabled",false);
		$("#domainName").prop("disabled",false);
		$("#serverIPAddress").prop("disabled",false);
		SelectDDNSType($("#provider").val());
	}
	else
	{
		$("#provider").prop("disabled",true);   
		$("#UserName").prop("disabled",true); 
		$("#Password").prop("disabled",true); 
		$("#ConfirmPassword").prop("disabled",true);
		$("#domainName").prop("disabled",true);
		$("#serverIPAddress").prop("disabled",true);
	}
}
/*************************************************
Function:		GetEmailInfo
Description:	获取Email信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function GetEmailInfo()
{
	$.ajax(
	{
		type: "GET",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/Event/notification/mailing",
		beforeSend: function(xhr) 
		{
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) 
		{
			if($(xmlDoc).find('MailingNotification').length > 0)
			{
				if("hostname" == $(xmlDoc).find('addressingFormatType').eq(0).text())
				{
					$("#SMTPServerAddress").val($(xmlDoc).find('hostName').eq(0).text()); 
				}
				else
				{
					if($(xmlDoc).find('ipAddress').length > 0)
					{
						if($(xmlDoc).find('ipAddress').eq(0).text() == '0.0.0.0')
						{
							$('#SMTPServerAddress').val('');
						}
						else
						{
							$("#SMTPServerAddress").val($(xmlDoc).find('ipAddress').eq(0).text());
						}
					}
					else
					{
						$("#SMTPServerAddress").val($(xmlDoc).find('ipv6Address').eq(0).text());
					}
				}
				
				if($(xmlDoc).find('authenticationMode').eq(0).text() == 'none')
				{
					$("#authenticationMode").prop("checked", false);
					$("#UserName").val('');
					$("#Password").val('');
					$("#PwdConfirm").val('');
					oCheckPassword.checkUserName("", $('#Password'), $('#PwdConfirm'));
				}
				else
				{
					$("#authenticationMode").prop("checked", true);
					$("#UserName").val($(xmlDoc).find('accountName').eq(0).text()); 
					$("#Password").val(oCheckPassword.m_szDefaultPassword);
					$("#PwdConfirm").val(oCheckPassword.m_szDefaultPassword);
					oCheckPassword.checkUserName($(xmlDoc).find('accountName').eq(0).text(), $('#Password'), $('#PwdConfirm'));
				}
				EnableAuthen();
				$("#SMTPPort").val($(xmlDoc).find('portNo').eq(0).text()); 
				if($(xmlDoc).find('useSSL').eq(0).text() == 'true')
				{
					$("#SSL").prop("checked",true);
				}
				else
				{
					$("#SSL").prop("checked",false);
				}
				if($(xmlDoc).find('sendInterval').eq(0).text() == '0')
				{
					document.getElementById('MailInterval').selectedIndex = 0;
				}
				else
				{
					$("#MailInterval").val($(xmlDoc).find('sendInterval').eq(0).text());
				}
				
				if($(xmlDoc).find('sendAttachment').eq(0).text() == 'true')
				{
					$("#Attachment").prop("checked",true);
					$("#MailInterval").prop("disabled",false);
				}
				else
				{
					$("#Attachment").prop("checked",false);
					$("#MailInterval").prop("disabled",true);
				}
			}
			$("#SenderName").val($(xmlDoc).find('sender').eq(0).find('name').eq(0).text());
			$("#SenderAddress").val($(xmlDoc).find('sender').eq(0).find('emailAddress').eq(0).text());
			
			for(var i = 0; i < $(xmlDoc).find('receiver').length; i++)
			{
				 $("#ReceiverName" + (i + 1) ).val( $(xmlDoc).find('receiver').eq(i).find('name').eq(0).text() );
                 $("#ReceiverAddress" + (i + 1) ).val( $(xmlDoc).find('receiver').eq(i).find('emailAddress').eq(0).text() );
			}
		},
		error: function(xhr, textStatus, errorThrown)
		{
		}
	});
}
/*************************************************
Function:		SetEmailInfo
Description:	设置Email信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function SetEmailInfo()
{
	if(!CheackStringLenthNull($("#SMTPServerAddress").val(),'SMTPServerAddressStips','laServerAdd',32))
	{
		return;
	}
	if(!CheackServerIDIntNum($("#SMTPPort").val(),'SMTPPorttips','laSMTPPort',1,65535))
	{
		return;
	}
	if(!CheackStringLenth($("#Password").val(),'Passwordtips','gePassword',32))
	{
		return;
	}
	if(!CheackStringLenth($("#SenderName").val(), 'SenderNametips','laSenderName', 32))
	{
		return;
	}
	if(!CheackStringLenth($("#SenderAddress").val(), 'SenderAddresstips','laSenderAddress', 48))
	{
		return;
	}
	if(!CheckEmail($("#SenderAddress").val(), 'SenderAddresstips', 'jsEmailAdd'))
	{
		return;
	}
	if(!CheackStringLenth($("#ReceiverAddress1").val(), 'ReceiverAddresstips1','laReceiverAddress1', 48) || !CheckEmail($("#ReceiverAddress1").val(), 'ReceiverAddresstips1', 'jsEmailAdd'))
	{
		return;
	}
	if(!CheackStringLenth($("#ReceiverAddress2").val(), 'ReceiverAddresstips2','laReceiverAddress2', 48) || !CheckEmail($("#ReceiverAddress2").val(), 'ReceiverAddresstips2', 'jsEmailAdd'))
	{
		return;
	}	
	if($("#authenticationMode").prop("checked"))
	{
		if(!CheackStringLenthNull($("#UserName").val(),'UserNametips','geUserName',32))
		{
			return;
		}
		if($("#Password").val() != $("#PwdConfirm").val() )
		{
			var szAreaNameInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
			szAreaNameInfo += getNodeValue('jsPwdCheckMismatch');
			$("#SetResultTips").html(szAreaNameInfo);
			return -1;
		}
		if($('#Password').val().length == 0 && $('#UserName').val().length != 0)
		{
			var szPasswordInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
			szPasswordInfo += getNodeValue("gePassword") + getNodeValue("NullTips");
			$("#Passwordtips").html(szPasswordInfo);
			return -1;
		}		
	}
	$("#PwdConfirmtips").html('');
	
	var szXml = "<?xml version='1.0' encoding='utf-8'?><MailingNotificationList><MailingNotification><id>1</id>";
	 
	//是否认证
	if($("#authenticationMode").prop("checked"))
	{
		szXml += "<authenticationMode>SMTP</authenticationMode>";
	}
	else
	{
		szXml += "<authenticationMode>none</authenticationMode>";
	}
	
	//服务器地址类型
	var strIpAddressType = CheckAddressingType($("#SMTPServerAddress").val());
	if(strIpAddressType == "hostName")
	{
		szXml += "<addressingFormatType>hostname</addressingFormatType><hostName>"+$("#SMTPServerAddress").val().replace(/&/g, "&amp;").replace(/</g, "&lt;")+"</hostName>";
	}
	else
	{
		szXml += "<addressingFormatType>ipaddress</addressingFormatType><ipAddress>"+$("#SMTPServerAddress").val()+"</ipAddress>";
	}
	
	szXml += "<portNo>"+$("#SMTPPort").val()+"</portNo>";
	
	if($("#authenticationMode").prop("checked"))
	{
		szXml += "<accountName>"+$("#UserName").val()+"</accountName>";
		if($("#Password").val() != "" && $('#Password').val() != oCheckPassword.m_szDefaultPassword)
		{
			szXml += "<password>"+$("#Password").val()+"</password>";
		}
	}
	
	szXml += "<Extensions>";
	szXml += "<useSSL>"+$("#SSL").prop("checked").toString()+"</useSSL>";
	try
	{
		szXml += "<sendInterval>"+$("#MailInterval").val()+"</sendInterval>";
	}
	catch(err)
	{
		szXml += "<sendInterval>0</sendInterval>";
	}
	
	szXml += "<sendAttachment>"+$("#Attachment").prop("checked").toString()+"</sendAttachment>";
	
	szXml += "<sender><name>"+$("#SenderName").val().replace(/&/g, "&amp;").replace(/</g, "&lt;")+"</name><emailAddress>"+$("#SenderAddress").val()+"</emailAddress></sender>";
	
	szXml += "<receiverList>";
	for(var i = 0; i < 2; i++)
	{
		/*if($("#ReceiverName" + (i + 1) ).val() != '' ||  $("#ReceiverAddress" + (i + 1) ).val() != '')*/
		{
			szXml += "<receiver><id>"+(i+1)+"</id><name>"+$("#ReceiverName"+(i + 1)).val()+"</name><emailAddress>"+$("#ReceiverAddress"+(i + 1)).val()+"</emailAddress></receiver>";
		}
	}
	szXml += "</receiverList></Extensions></MailingNotification></MailingNotificationList>";
	
	xmlDoc = parseXmlFromStr(szXml);
	
	var szURL = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/Event/notification/mailing";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		EnableAuthen
Description:	使能服务器认证
Input:			无			
Output:			无
return:			无				
*************************************************/
function EnableAuthen()
{
	if($("#authenticationMode").prop("checked"))
	{
		$("#UserName").prop("disabled",false);   
		$("#Password").prop("disabled",false); 
		$("#PwdConfirm").prop("disabled",false);   
	}
	else
	{
		$("#UserName").prop("disabled",true);   
		$("#Password").prop("disabled",true); 
		$("#PwdConfirm").prop("disabled",true);   
	}
}
/*************************************************
Function:		EnableAttachment
Description:	使能发送间隔
Input:			无			
Output:			无
return:			无				
*************************************************/
function EnableAttachment()
{
	if($("#Attachment").prop("checked"))
	{
		$("#MailInterval").prop("disabled",false);   
	}
	else
	{
		$("#MailInterval").prop("disabled",true);    
	}
}

/*************************************************
Function:		GetQoSInfo
Description:	获取QoS信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function GetQoSInfo()
{
	$.ajax({
		type: "GET",
		url:  m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces/1/qos/dscp",
		timeout: 15000,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) 
		{
			var iLength = $(xmlDoc).find('DSCP').length;
			for(var i = 0; i < iLength; i++)
			{
				switch($(xmlDoc).find('trafficType').eq(i).text())
				{
					case 'devicemanagement':
					{
						$("#ManageDSCP").val($(xmlDoc).find('priorityValue').eq(i).text());
						break;
					}
					case 'commandcontrol':
					{
						$("#EADSCP").val($(xmlDoc).find('priorityValue').eq(i).text());
						break;
					}
					case 'video':
					{
						$("#VideoDSCP").val($(xmlDoc).find('priorityValue').eq(i).text());
						break;
					}
					default:
					{
						break;
					}
				  
				}
			}
		},
		error: function()
		{
			//alert(getNodeValue('NetworkErrorTips'));
		},
		complete:function(XHR, textStatus)
		{
			
		}
	});
}

/*************************************************
Function:		SetQoSInfo
Description:	设置QoS信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function SetQoSInfo()
{
	if(!CheackServerIDIntNum($("#VideoDSCP").val(),'VideoDSCPtips','RangeTips',0,63))
	{
		return;
	}
	if(!CheackServerIDIntNum($("#EADSCP").val(),'EADSCPtips','RangeTips',0,63))
	{
		return;
	}
	if(!CheackServerIDIntNum($("#ManageDSCP").val(),'ManageDSCPtips','RangeTips',0,63))
	{
		return;
	}
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><DSCPList>" + 
	"<DSCP>"+ "<id>1</id><enabled>true</enabled>" + "<priorityValue>"+$("#ManageDSCP").val()+"</priorityValue><trafficType>devicemanagement</trafficType></DSCP>" + 
	"<DSCP>"+ "<id>2</id><enabled>true</enabled>" + "<priorityValue>"+$("#EADSCP").val()+"</priorityValue><trafficType>commandcontrol</trafficType></DSCP>" + 
	"<DSCP>"+ "<id>3</id><enabled>true</enabled>" + "<priorityValue>"+$("#VideoDSCP").val()+"</priorityValue><trafficType>video</trafficType></DSCP>" +
	"</DSCPList>";
	var xmlDoc = parseXmlFromStr(szXml);
	$.ajax({
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces/1/qos/dscp",
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		initNetwork
Description:	初始化网络配置
Input:			无			
Output:			无
return:			无				
*************************************************/
function initNetwork()
{
	//802.1x
	$("#enable8021x").bind("click",function()
	{
		if(this.checked)
		{
			$("#EAPOLVersion").prop("disabled", false);
			$("#userName").prop("disabled", false);
			$("#password8021").prop("disabled", false);
			$("#password8021Confirm").prop("disabled", false);
		}
		else
		{
			$("#EAPOLVersion").prop("disabled", true);
			$("#userName").prop("disabled", true);
			$("#password8021").prop("disabled", true);
			$("#password8021Confirm").prop("disabled", true);
		}
	});
	//SNMP
	$("#enablev1").bind("click",function()
	{
		if(!$(this).prop("checked") && !$("#enablev2c").prop("checked"))
		{
			var self = this;
			$("#snmpv1v2c").find(":input").each(function()
			{
				if(this != self && this != $("#enablev2c")[0])
				{
					$(this).prop("disabled","true");
				}
			});
		}
		else
		{
			$("#snmpv1v2c").find("input").each(function()
			{
				$(this).prop("disabled","");
			});
		}
	});
	$("#enablev2c").bind("click",function()
	{
		if(!$(this).prop("checked") && !$("#enablev1").prop("checked"))
		{
			var self = this;
			$("#snmpv1v2c").find(":input").each(function()
			{
				if(this != self && this != $("#enablev1")[0])
				{
					$(this).prop("disabled","true");
				}
			});
		}
		else
		{
			$("#snmpv1v2c").find("input").each(function()
			{
				$(this).prop("disabled","");
			});
		}
	});
	
	$("#enablev3c").bind("click",function()
	{
		var self = this;
		if(!$(this).prop("checked"))
		{
			$("#snmpv3c").find(":input,select").each(function()
			{
				if(this != self)
				{
					$(this).prop("disabled","true");
				}
			});
		}
		else
		{
			$("#snmpv3c").find("input,select").prop("disabled","");
			
			var szSecValue = $("#rSecurityLevel").val();
			var bAuthAlg = (szSecValue.split("_")[0] == "1");
			var bPrivacyAlg = (szSecValue.split("_")[1] == "1");
			if(bAuthAlg)
			{
				$(document.getElementsByName("rAuthAlg")).prop("disabled", false);
				$("#rAuthPsd").prop("disabled", false);
			}
			else
			{
				$(document.getElementsByName("rAuthAlg")).prop("disabled", true);
				$("#rAuthPsd").prop("disabled", true);
			}
			if(bPrivacyAlg)
			{
				$(document.getElementsByName("rPrivacyAlg")).prop("disabled", false);
				$("#rPrivacyPsd").prop("disabled", false);
			}
			else
			{
				$(document.getElementsByName("rPrivacyAlg")).prop("disabled", true);
				$("#rPrivacyPsd").prop("disabled", true);
			}
			szSecValue = $("#rwSecurityLevel").val();
			bAuthAlg = (szSecValue.split("_")[0] == "1");
			bPrivacyAlg = (szSecValue.split("_")[1] == "1");
			if(bAuthAlg)
			{
				$(document.getElementsByName("rwAuthAlg")).prop("disabled", false);
				$("#rwAuthPsd").prop("disabled", false);
			}
			else
			{
				$(document.getElementsByName("rwAuthAlg")).prop("disabled", true);
				$("#rwAuthPsd").prop("disabled", true);
			}
			if(bPrivacyAlg)
			{
				$(document.getElementsByName("rwPrivacyAlg")).prop("disabled", false);
				$("#rwPrivacyPsd").prop("disabled", false);
			}
			else
			{
				$(document.getElementsByName("rwPrivacyAlg")).prop("disabled", true);
				$("#rwPrivacyPsd").prop("disabled", true);
			}
		}
	});
	$("#rSecurityLevel").bind("change", function()
	{
		var bAuthAlg = (this.value.split("_")[0] == "1");
		var bPrivacyAlg = (this.value.split("_")[1] == "1");
		if(bAuthAlg)
		{
			$(document.getElementsByName("rAuthAlg")).prop("disabled", false);
			$("#rAuthPsd").prop("disabled", false);
		}
		else
		{
			$(document.getElementsByName("rAuthAlg")).prop("disabled", true);
			$("#rAuthPsd").prop("disabled", true);
		}
		if(bPrivacyAlg)
		{
			$(document.getElementsByName("rPrivacyAlg")).prop("disabled", false);
			$("#rPrivacyPsd").prop("disabled", false);
		}
		else
		{
			$(document.getElementsByName("rPrivacyAlg")).prop("disabled", true);
			$("#rPrivacyPsd").prop("disabled", true);
		}
	});
	$("#rwSecurityLevel").bind("change", function()
	{
		var bAuthAlg = (this.value.split("_")[0] == "1");
		var bPrivacyAlg = (this.value.split("_")[1] == "1");
		if(bAuthAlg)
		{
			$(document.getElementsByName("rwAuthAlg")).prop("disabled", false);
			$("#rwAuthPsd").prop("disabled", false);
		}
		else
		{
			$(document.getElementsByName("rwAuthAlg")).prop("disabled", true);
			$("#rwAuthPsd").prop("disabled", true);
		}
		if(bPrivacyAlg)
		{
			$(document.getElementsByName("rwPrivacyAlg")).prop("disabled", false);
			$("#rwPrivacyPsd").prop("disabled", false);
		}
		else
		{
			$(document.getElementsByName("rwPrivacyAlg")).prop("disabled", true);
			$("#rwPrivacyPsd").prop("disabled", true);
		}
	});
	$(":text,:password").addClass("inputwidth");
	$("select").addClass("selectwidth");
	/*******密码框行为********/
	$("#rAuthPsd").bind(
	{
		blur:function()
		{
			if("" != $("#rUserName").val())
			{
				if(this.value == "")
				{
					this.value = "******";
				}
			}
		},
		focus:function()
		{
			if("" != $("#rUserName").val())
			{
				if(this.value == "******")
				{
					this.value = "";
				}
			}
		}
	});
	$("#rPrivacyPsd").bind(
	{
		blur:function()
		{
			if("" != $("#rUserName").val())
			{
				if(this.value == "")
				{
					this.value = "******";
				}
			}
		},
		focus:function()
		{
			if("" != $("#rUserName").val())
			{
				if(this.value == "******")
				{
					this.value = "";
				}
			}
		}
	});
	$("#rwAuthPsd").bind(
	{
		blur:function()
		{
			if("" != $("#rwUserName").val())
			{
				if(this.value == "")
				{
					this.value = "******";
				}
			}
		},
		focus:function()
		{
			if("" != $("#rwUserName").val())
			{
				if(this.value == "******")
				{
					this.value = "";
				}
			}
		}
	});
	$("#rwPrivacyPsd").bind(
	{
		blur:function()
		{
			if("" != $("#rwUserName").val())
			{
				if(this.value == "")
				{
					this.value = "******";
				}
			}
		},
		focus:function()
		{
			if("" != $("#rwUserName").val())
			{
				if(this.value == "******")
				{
					this.value = "";
				}
			}
		}
	});
	
	$("#selPathDepth").bind("change", function()
	{
		switch(this.value)
		{
			case '0':
				$("#selTopPath").prop("disabled", true);
				$("#selSubPath").prop("disabled", true);
				break;
			case '1':
				$("#selTopPath").prop("disabled", false);
				$("#selSubPath").prop("disabled", true);
				break;
			case '2':
				$("#selTopPath").prop("disabled", false);
				$("#selSubPath").prop("disabled", false);
				break;
			default:
				break;
		}
	});
	//WIFI
	$("#wifiChannel").empty().append("<option value='auto' name='aModeAuto'>"+getNodeValue("aModeAuto")+"</option>");
	for(var i = 0; i < 14; i++)
	{
		$("#wifiChannel").append("<option value='"+(i+1)+"'>"+(i+1)+"</option>");
	}
	var oAuthTypeList = $("#dvWifiSetting").find(":radio[name='authenticationType']");
	var oKeyLengthRadioList = $("#dvWifiSetting").find(":radio[name='KeyLength']");
	var oKeyTypeRadioList = $("#dvWifiSetting").find(":radio[name='KeyType']");
	var oEncryKeyRadioList = $("#dvWifiSetting").find(":radio[name='encryptionKey']");
	var oEncryKeyTextList = $("#dvWifiSetting").find(":text[id*='encryptionKey']");
	$("#securityMode").bind("change", function()
	{
		switch (this.value)
		{
			case "disable":
				$("#dvWifiSetting").children("div[class!='displaynone']").each(function(i) {
				    if(i > 3) {
					    $(this).hide();
					}
				});
				break;
			case "WEP":
				$("#dvWifiSetting").children("div[class!='displaynone']").each(function(i) {
					$(this).show();
					if(i === 4 || i > 11) {
					    $(this).hide();
					}
				});
				oEncryKeyRadioList.filter(":checked").click();
				break;
			case "WPA-personal":
			case "WPA2-personal":
				$("#dvWifiSetting").children("div[class!='displaynone']").each(function(i) {
					$(this).show();
					if(i > 4 && i !== 8) {
					    $(this).hide();
					}
				});
				oEncryKeyRadioList.eq(0).click();
			    break;
			case "WPA-enterprise":
			case "WPA2-enterprise":
				$("#dvWifiSetting").children("div[class!='displaynone']").each(function(i) {
					$(this).show();
					if(i > 3 && i < 12) {
					    $(this).hide();
					}
				});
				oEncryKeyRadioList.eq(0).click();
				$("#enterpriseType").change();
			    break;				
			default :
				break;
		}
		$("#dvWifiSetting").children("div:visible[class!='mainparams margintop26']").each(function(i)
		{
			if(i%2 == 0)
			{
				$(this).attr("class", "subparamswhite");
			}
			else
			{
				$(this).attr("class", "subparamsgray");
			}
		});		
		autoResizeIframe();
	});
	$("#enterpriseType").bind("change", function()
	{
		switch (this.value)
		{
			case "EAP-TLS":
				$("#dvWifiSetting").children("div[class!='displaynone']").each(function(i) {
				    if(i > 11) {
					    $(this).show();    
					}
					if(i > 12 && i < 20) {
					    $(this).hide();
					}
				});
				break;
			case "EAP-PEAP":
				$("#dvWifiSetting").children("div[class!='displaynone']").each(function(i) {
				    if(i > 11) {
					    $(this).show();    
					}
					if((i > 17 && i < 22 && i != 19) || (i > 23)) {
					    $(this).hide();
					}
				});
				break;
			case "EAP-TTLS":
				$("#dvWifiSetting").children("div[class!='displaynone']").each(function(i) {
				    if(i > 11) {
					    $(this).show();    
					}
					if((i > 19 && i < 22) || (i > 14 && i < 18) || (i > 23)) {
					    $(this).hide();
					}
				});					
			default :
				break;
		}
		$("#dvWifiSetting").children("div:visible[class!='mainparams margintop26']").each(function(i)
		{
			if(i%2 == 0)
			{
				$(this).attr("class", "subparamswhite");
			}
			else
			{
				$(this).attr("class", "subparamsgray");
			}
		});		
		autoResizeIframe();
	});	
	//密码类型改变事件
	oKeyTypeRadioList.bind("click", function()
	{
		oEncryKeyRadioList.filter(":checked").click();
	});
	//密码长度改变事件
	oKeyLengthRadioList.bind("click", function()
	{
		oEncryKeyRadioList.filter(":checked").click();
	});
	//密码选择单选框点击事件
	oEncryKeyRadioList.bind("click", function()
	{
		$(this).prop("checked", true);
		oEncryKeyTextList.prop("disabled", true);
		oEncryKeyTextList.eq(this.value-1).prop("disabled", false).focus().keyup();
	});
	//密码输入框事件
	oEncryKeyTextList.bind(
	{
		keyup: function()
		{
			var szVal = this.value;
			var szKeyType = oKeyTypeRadioList.filter(":checked").val();
			var szKeyLength = oKeyLengthRadioList.filter(":checked").val();
			if($("#securityMode").val() == "WEP")
			{
				if("HEX" == szKeyType) //16进制
				{
					if("64" == szKeyLength)  //64位
					{
						szVal = szVal.substring(0, 10);
					}
					else   //128位
					{
						szVal = szVal.substring(0, 26);
					}
					this.value = szVal.replace(/[^0-9a-fA-F]/g,"");
				}
				else    //ASCII码
				{
					if("64" == szKeyLength)  //64位
					{
						szVal = szVal.substring(0, 5);
					}
					else   //128位
					{
						szVal = szVal.substring(0, 13);
					}
					this.value = szVal;
				}
			}
			else
			{
				szVal = szVal.substring(0, 63);
			}
		}
	});
}
/*************************************************
Function:		Get8021xCab
Description:	获取8021x能力
Input:			无			
Output:			无
return:			无				
*************************************************/
function Get8021xCab()
{
	$.ajax({
		type: "GET",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces/1/ieee802.1x/capabilities",
		timeout: 15000,
		async: false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) 
		{
			//协议类型
			$("#ProtocolType").empty();
			var ProtocolType = xmlDoc.documentElement.getElementsByTagName('authenticationProtocolType')[0].getAttribute("opt").split(",");		
			for(var i = 0; i < ProtocolType.length; i++)
			{
				$("<option value='"+ ProtocolType[i] +"'>"+ ProtocolType[i] +"</option>").appendTo("#ProtocolType");
			}
			if(ProtocolType.length <= 1)
			{
				$("#ProtocolType").prop("disabled", true);
			}
			/*//认证方法
			$("#AuthMethodTr").show();
			var AuthMethods = xmlDoc.documentElement.getElementsByTagName('innerTTLSAuthenticationMethod')[0].getAttribute("opt").split(",");
			for(var i = 0; i < AuthMethods.length; i++)
			{
				$("<option value='"+ AuthMethods[i] +"'>"+ AuthMethods[i] +"</option>").appendTo("#AuthMethod");
			}
			if(AuthMethods.length <= 1)
			{
				$("#AuthMethod").prop("disabled", true);
			}
			if("EAP-TTLS" == $("#ProtocolType").val())
			{
				$("#AuthMethod").val(xmlDoc.documentElement.getElementsByTagName('innerTTLSAuthenticationMethod')[0].childNodes[0].nodeValue);
			}
			else
			{
				$("#AuthMethodTr").hide();
			}*/
			//Version
			var VersionType = xmlDoc.documentElement.getElementsByTagName('EAPOLVersion')[0].getAttribute("opt").split(",");
			$("#EAPOLVersion").empty();
			for(var i = 0; i < VersionType.length; i++)
			{
				$("<option value='"+ VersionType[i] +"'>"+ VersionType[i] +"</option>").appendTo("#EAPOLVersion");
			}
			if(VersionType.length <= 1)
			{
				$("#EAPOLVersion").prop("disabled", true);
			}
		},
		error: function()
		{
			//alert(getNodeValue('NetworkErrorTips'));
		}
	});
}
/*************************************************
Function:		Get8021xInfo
Description:	获取8021x信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function Get8021x()
{
	$.ajax({
		type: "GET",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces/1/ieee802.1x",
		timeout: 15000,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) 
		{
			if("true" == $(xmlDoc).find('enabled').eq(0).text())
			{
				$("#enable8021x").prop("checked", true);
				$("#EAPOLVersion").prop("disabled", false);
				$("#userName").prop("disabled", false);
				$("#password8021").prop("disabled", false);
				$("#password8021Confirm").prop("disabled", false);
			    $("#ProtocolType").val($(xmlDoc).find('authenticationProtocolType').eq(0).text());
			    $("#EAPOLVersion").val($(xmlDoc).find('EAPOLVersion').eq(0).text());				
			}
			else
			{
				$("#enable8021x").prop("checked", false);
				$("#EAPOLVersion").prop("disabled", true);
				$("#userName").prop("disabled", true);
				$("#password8021").prop("disabled", true);
				$("#password8021Confirm").prop("disabled", true);
			}
			//用户名
			try
			{
				$("#userName").val($(xmlDoc).find("userName").eq(0).text());
				oCheckPassword.checkUserName($(xmlDoc).find("userName").eq(0).text(), $('#password8021'), $('#password8021Confirm'));
			}
			catch(e)
			{
				$("#userName").val("");
			}
		},
		error: function()
		{
			//alert(getNodeValue('NetworkErrorTips'));
		}
	});
}

/*************************************************
Function:		Set8021x
Description:	设置8021x信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function Set8021x()
{
	var szXml = "";
	if(!$("#enable8021x").prop("checked"))
	{
		szXml = "<?xml version='1.0' encoding='UTF-8'?><IEEE802_1x version='1.0' xmlns='urn:psialliance-org'>"+
		"<enabled>false</enabled>"+
		"<authenticationProtocolType></authenticationProtocolType>"+
		"<innerTTLSAuthenticationMethod></innerTTLSAuthenticationMethod>"+
		"<innerEAPProtocolType></innerEAPProtocolType>"+
		"<validateServerEnabled></validateServerEnabled>"+
		"<userName></userName>"+
		"<password></password>"+
		"<anonymousID></anonymousID>"+
		"<autoPACProvisioningEnabled></autoPACProvisioningEnabled>"+
		"<Extensions><EAPOLVersion></EAPOLVersion></Extensions></IEEE802_1x>";
	}
	else
	{
		if($("#userName").val() == "")
		{
			$("#userNametips").html(getNodeValue("geUserName")+getNodeValue("NullTips"));
			return;
		}
		if($("#password8021").val() == "")
		{
			$("#passwordtips").html(getNodeValue("gePassword")+getNodeValue("NullTips"));
			return;
		}
		if(!CheackStringLenth($("#userName").val(),'userNametips','geUserName',32))
		{
			return;
		}
		if(!CheackStringLenth($("#password8021").val(),'passwordtips','gePassword',16))
		{
			return;
		}
		if($("#password8021").val() != $("#password8021Confirm").val() )
		{
			var szAreaNameInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
			szAreaNameInfo += getNodeValue('jsPwdCheckMismatch');
			$("#SetResultTips").html(szAreaNameInfo);
			return -1;
		}		
		szXml = "<?xml version='1.0' encoding='UTF-8'?><IEEE802_1x version='1.0' xmlns='urn:psialliance-org'>"+
		"<enabled>true</enabled>"+
		"<authenticationProtocolType>"+$("#ProtocolType").val()+"</authenticationProtocolType>"+
		"<innerTTLSAuthenticationMethod></innerTTLSAuthenticationMethod>"+
		"<innerEAPProtocolType></innerEAPProtocolType>"+
		"<validateServerEnabled></validateServerEnabled>"+
		"<userName>"+$("#userName").val()+"</userName>";
		if($("#password8021").val() != "" && $('#password8021').val() != oCheckPassword.m_szDefaultPassword)
		{
		    szXml += "<password>"+$("#password8021").val()+"</password>";
		}
		szXml += "<anonymousID></anonymousID>"+
		"<autoPACProvisioningEnabled>true</autoPACProvisioningEnabled>"+
		"<Extensions><EAPOLVersion>"+$("#EAPOLVersion").val()+"</EAPOLVersion></Extensions></IEEE802_1x>";
	}
	var xmlDoc = parseXmlFromStr(szXml);
	
	$.ajax({
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces/1/ieee802.1x",
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}

/*************************************************
Function:		initPortConfig
Description:	初始化IpConfig页面
Input:			无
Output:			无
return:			无				
*************************************************/
function initPortConfig()
{
    getPortInfo();
	autoResizeIframe();
}
/*************************************************
Function:		getPortInfo
Description:	获取端口号信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function getPortInfo()
{
    getHttpPortInfo();
	getRtspPortInfo();
}
/*************************************************
Function:		setPortInfo
Description:	设置端口号信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function setPortInfo()
{
	if(!CheackServerIDIntNum($("#inputHttpPort").val(),'HttpPortTips','jsHttpPortParam',1,65535))
	{		
	    return;
	}
	if(!CheackServerIDIntNum($("#inputRtspPort").val(),'RtspPortTips','jsRtspPortParam',1,65535))
	{
	    return;
	}
	if(!CheackServerIDIntNum($("#inputHttpsPort").val(),'HttpsPortTips','jsHttpsPortParam',1,65535))
	{
	    return;
	}	
	if(!CheackServerIDIntNum($("#inputSDKPort").val(),'SDKPortTips','laSDKPort',2000,65535))
	{
	    return;
	}
    if ($("#inputSDKPort").val() === $("#inputHttpPort").val() || $("#inputSDKPort").val() === $("#inputRtspPort").val() || $("#inputSDKPort").val() === $("#inputHttpsPort").val() || $("#inputRtspPort").val() === $("#inputHttpPort").val() || $("#inputRtspPort").val() === $("#inputHttpsPort").val() || $("#inputHttpPort").val() === $("#inputHttpsPort").val()) {
        var szErrorInfo = m_szErrorState + getNodeValue("jsPortConflict");
        $("#SetResultTips").html(szErrorInfo);
        setTimeout(function () {
            $("#SetResultTips").html("");
        }, 5000);  //5秒后自动清除
        return;
    }
	
	if( ($('#divHttpPort').css('display') != "none" || $('#divHttpsPort').css('display') != "none"))
	{
		setHttpPortInfo();
	}
}
/*************************************************
Function:		getHttpPortInfo
Description:	获取HTTP端口号
Input:			无			
Output:			无
return:			无				
*************************************************/
function getHttpPortInfo()
{ 
	$.ajax({
		type: "GET",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Security/AAA/adminAccesses",
		async: true,
		timeout: 15000,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) 
		{
			var oPortsArray = $(xmlDoc).find('AdminAccessProtocol');
			for(var i = 0; i < oPortsArray.length; i++){
				switch (oPortsArray.eq(i).find("protocol").eq(0).text()){
					case 'HTTP':
						$("#divHttpPort").show();
				    	$("#inputHttpPort").val(oPortsArray.eq(i).find("portNo").eq(0).text());
						break;
					case 'HTTPS':
						$("#divHttpsPort").show();
				    	$("#inputHttpsPort").val(oPortsArray.eq(i).find("portNo").eq(0).text());
						break;
					case 'SDK':
						$("#divSDKPort").show();
				    	$("#inputSDKPort").val(oPortsArray.eq(i).find("portNo").eq(0).text());
						break;
					default:
						break;
				}
			}
		},
		error: function(xhr, textStatus, errorThrown)
		{
			$("#divHttpsPort").hide();
			$("#divHttpPort").hide();
			$("#divSDKPort").hide();
		}
	});	
}
/*************************************************
Function:		setHttpPortInfo
Description:	设置Http和Https端口
Input:			无
Output:			无
return:			无
*************************************************/

function setHttpPortInfo()
{
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><AdminAccessProtocolList>";
	if($('#divHttpPort').css('display') != "none"){
		szXml += "<AdminAccessProtocol><id>1</id><enabled>true</enabled><protocol>HTTP</protocol><portNo>"+$("#inputHttpPort").val()+"</portNo></AdminAccessProtocol>";
	}
	if($('#divHttpsPort').css('display') != "none"){
        szXml += "<AdminAccessProtocol><id>2</id><enabled>true</enabled><protocol>HTTPS</protocol><portNo>"+$("#inputHttpsPort").val()+"</portNo></AdminAccessProtocol>";
	}
	if($('#divSDKPort').css('display') != "none"){
		 szXml += "<AdminAccessProtocol><id>3</id><enabled>true</enabled><protocol>SDK</protocol><portNo>"+$("#inputSDKPort").val()+"</portNo></AdminAccessProtocol>";
	}
	szXml += "</AdminAccessProtocolList>";
	var xmlDoc = parseXmlFromStr(szXml);
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		async: true,
		timeout: 15000,
		url: m_lHttp+m_szHostName+":"+m_lHttpPort+"/PSIA/Security/AAA/adminAccesses",
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus){
			// var xmlDoc =xhr.responseXML;
			// var state = $(xmlDoc).find('statusCode').eq(0).text();
			// if(!g_bIsErorr){
			// 	if(xhr.status!=200){
			// 		g_bIsErorr=true;
			// 	}
			// 	if("7" == state) {	//Reboot Required
			// 		if(g_bIsRestart){
			// 			g_bIsRestart = false;
			// 			SaveState(xhr);
			// 		}
			// 	} else{
			// 		SaveState(xhr);
			// 	}
			// }
			g_bHttpXhr=xhr;
			if($('#divRtspPort').css('display') != "none")
			{
				setRtspPortInfo();
			}
			
		}
	});	
}
/*************************************************
Function:		getRtspPortInfo
Description:	获取RTSP端口
Input:			无
Output:			无
return:			无
*************************************************/
function getRtspPortInfo()
{
	$.ajax({
		type: "GET",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Streaming/channels/101",
		async: true,
		timeout: 15000,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) 
		{
			g_oXmlRtspPort = xmlDoc;
			if($(xmlDoc).find('rtspPortNo').length > 0)
			{
			    $("#divRtspPort").show();
				$("#inputRtspPort").val($(xmlDoc).find('rtspPortNo').eq(0).text());
			}
		},
		error: function(xhr, textStatus, errorThrown)
		{

		}
	});	
}
/*************************************************
Function:		setRtspPortInfo
Description:	设置RTSP端口
Input:			无
Output:			无
return:			无
*************************************************/
function setRtspPortInfo()
{
	var xmlDoc = parseXmlFromStr(xmlToStr(g_oXmlRtspPort));
	if($('#divRtspPort').css('display') != "none")
	{
        $(xmlDoc).find('rtspPortNo').eq(0).text($("#inputRtspPort").val());
	}
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		async: true,
		timeout: 15000,
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Streaming/channels/101",
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			var xmlDoc =xhr.responseXML;
			var state = $(xmlDoc).find('statusCode').eq(0).text();
			
			if(g_bHttpXhr.status!=200){
				SaveState(g_bHttpXhr);
			}else{
				if(xhr.status!=200){
					SaveState(xhr);
				}else{
					var xmlHttpXhr =g_bHttpXhr.responseXML;
				    var httpstate = $(xmlHttpXhr).find('statusCode').eq(0).text();
					if("7"==httpstate){
						SaveState(g_bHttpXhr)
					}else{
						SaveState(xhr);
					}
				}
				
			}
		}
	});		
}
/*************************************************
Function:		initDDNS
Description:	初始化initDDNS页面
Input:			无			
Output:			无
return:			无				
*************************************************/
function initDDNS()
{
    GetDDNSInfo();
	autoResizeIframe();
}
/*************************************************
Function:		initPPPOE
Description:	初始化initPPPOE页面
Input:			无			
Output:			无
return:			无				
*************************************************/
function initPPPOE()
{
    GetPPPOEInfo();	
	autoResizeIframe();
}
/*************************************************
Function:		init8021x
Description:	初始化8021x页面
Input:			无			
Output:			无
return:			无				
*************************************************/
function init8021x()
{
	Get8021xCab();
	Get8021x();
	autoResizeIframe();
}
/*************************************************
Function:		initQos
Description:	初始化QoS页面
Input:			无			
Output:			无
return:			无				
*************************************************/
function initQos()
{
    GetQoSInfo();
	autoResizeIframe();
}

/*************************************************
Function:		initSNMP
Description:	初始化SNMP页面
Input:			无			
Output:			无
return:			无				
*************************************************/
function initSNMP()
{
    GetSNMPInfo();
}

/*************************************************
Function:		GetSNMPInfo
Description:	获取SNMP信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function GetSNMPInfo()
{
	$.ajax({
		type: "GET",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces/1/snmp",
		timeout: 15000,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) 
		{
			g_oSNMPXml = xmlDoc;
			//SNMPv1v2c
			if($(xmlDoc).find('SNMPv2c').length > 0)
			{
				$("#snmpv1v2c").show();
				var oSNMPv2c = $(xmlDoc).find('SNMPv2c').eq(0);
				$("#enablev2c")[0].checked = (oSNMPv2c.find('enabled').eq(0).text() == "true"?true:false);
				$("#enablev1")[0].checked = (oSNMPv2c.find('v1Enabled').eq(0).text() == "true"?true:false);
				$("#rwCommunity").val(oSNMPv2c.find('writeCommunity').eq(0).text());
				$("#rCommunity").val(oSNMPv2c.find('readCommunity').eq(0).text());
				if("hostname" == oSNMPv2c.find("addressingFormatType").eq(0).text())
				{
					$("#trapIP").val(oSNMPv2c.find('hostName').eq(0).text());
				}
				else
				{
					if(0 != oSNMPv2c.find("ipAddress").length)
					{
						$("#trapIP").val(oSNMPv2c.find("ipAddress").eq(0).text());
					}
					else
					{
						$("#trapIP").val(oSNMPv2c.find("ipv6Address").eq(0).text());
					}
				}
				$("#trapPort").val(oSNMPv2c.find("portNo").eq(0).text());
				if(oSNMPv2c.find('communityString').length > 0)
				{
					$("#trapCommunityArea").show();
					$("#trapCommunity").val(oSNMPv2c.find('communityString').eq(0).text());
				}
			}
			else
			{
				$("#snmpv1v2c").hide();
			}
			//SNMPv3c
			if($(xmlDoc).find('SNMPAdvanced').length > 0)
			{
				$("#snmpv3c").show();
				var oSNMPv3c = $(xmlDoc).find('SNMPAdvanced').eq(0);
				$("#enablev3c")[0].checked = (oSNMPv3c.find('enabled').eq(0).text() == "true"?true:false);
				//仅读用户
				$("#rUserName").val(oSNMPv3c.find('userName').eq(0).text());
				var szRAuthAlg = oSNMPv3c.find('snmpAuthenticationMethod').eq(0).text();
				var szRPrivacyAlg = oSNMPv3c.find('snmpPrivacyMethod').eq(0).text();
				if(szRAuthAlg == "none")
				{
					$("#rSecurityLevel").val("0_0");
					$(document.getElementsByName("rAuthAlg")).prop("disabled", true);
					$(document.getElementsByName("rPrivacyAlg")).prop("disabled", true);
					$("#rAuthPsd").prop("disabled", true);
					$("#rPrivacyPsd").prop("disabled", true);
				}
				else
				{
					$(document.getElementsByName("rAuthAlg")).each(function()
					{
						if(this.value == szRAuthAlg)
						{
							this.checked = true;
							return;
						}
					});
					if(szRPrivacyAlg == "none")
					{
						$("#rSecurityLevel").val("1_0");
						$(document.getElementsByName("rPrivacyAlg")).prop("disabled", true);
						$("#rPrivacyPsd").prop("disabled", true);
					}
					else
					{
						$(document.getElementsByName("rPrivacyAlg")).each(function()
						{
							if(this.value == szRPrivacyAlg)
							{
								this.checked = true;
								return;
							}
						});
						$("#rSecurityLevel").val("1_1");
					}
				}
				//读写用户
				$("#rwUserName").val(oSNMPv3c.find('userName').eq(1).text());
				var szRwAuthAlg = oSNMPv3c.find('snmpAuthenticationMethod').eq(1).text();
				var szRwPrivacyAlg = oSNMPv3c.find('snmpPrivacyMethod').eq(1).text();
				if(szRwAuthAlg == "none")
				{
					$(document.getElementsByName("rwAuthAlg")).prop("disabled", true);
					$(document.getElementsByName("rwPrivacyAlg")).prop("disabled", true);
					$("#rwSecurityLevel").val("0_0");
					$("#rwAuthPsd").prop("disabled", true);
					$("#rwPrivacyPsd").prop("disabled", true);
				}
				else
				{
					$(document.getElementsByName("rwAuthAlg")).each(function()
					{
						if(this.value == szRwAuthAlg)
						{
							this.checked = true;
							return;
						}
					});
					if(szRwPrivacyAlg == "none")
					{
						$("#rwSecurityLevel").val("1_0");
						$(document.getElementsByName("rwPrivacyAlg")).prop("disabled", true);
						$("#rwPrivacyPsd").prop("disabled", true);
					}
					else
					{
						$(document.getElementsByName("rwPrivacyAlg")).each(function()
						{
							if(this.value == szRwPrivacyAlg)
							{
								this.checked = true;
								return;
							}
						});
						$("#rwSecurityLevel").val("1_1");
					}
				}
				
				if("" != $("#rUserName").val())
				{
					$("#rAuthPsd").val("******");
					$("#rPrivacyPsd").val("******");
				}
				if("" != $("#rwUserName").val())
				{
					$("#rwAuthPsd").val("******");
					$("#rwPrivacyPsd").val("******");
				}
				if(!$("#enablev2c")[0].checked && !$("#enablev1")[0].checked)
				{
					$("#snmpv1v2c").find(":input").each(function()
					{
						if(this != $("#enablev1")[0] && this != $("#enablev2c")[0])
						{
							$(this).prop("disabled","true");
						}
					});
				}
				if(!$("#enablev3c")[0].checked)
				{
					$("#snmpv3c").find(":input,select").each(function()
					{
						if(this != $("#enablev3c")[0])
						{
							$(this).prop("disabled","true");
						}
					});
				}
			}
			else
			{
				$("#snmpv3c").hide();
			}
			autoResizeIframe();
			$("#snmpPort").val($(xmlDoc).find('listenPort').last().text());
		},
		error: function()
		{
			//alert(getNodeValue('NetworkErrorTips'));
		}
	});
}

/*************************************************
Function:		SetSNMPInfo
Description:	设置SNMP信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function SetSNMPInfo()
{
	if(!$("#enablev1")[0].checked && !$("#enablev2c")[0].checked && !$("#enablev3c")[0].checked)
	{
		alert(getNodeValue("jsOneLeast"));
		return;
	}
	if(!CheackServerIDIntNum($("#snmpPort").val(),"snmpPortTips","gePort",1,65535))
	{
		$("#snmpPort").focus();
		return;
	}
	if($("#enablev2c")[0].checked || $("#enablev1")[0].checked)
	{
		if(!CheackServerIDIntNum($("#trapPort").val(),"trapPortTips","gePort",1,65535))
		{
			$("#trapPort").focus();
			return;
		}
		if(!CheckIPAddress($("#trapIP").val(),"trapIPTips","jsTrapIp"))
		{
			$("#trapIP").focus();
			return;
		}
		if(!CheckUserNamePlus($("#rwCommunity").val(),"rwCommunityTips","laRwCommunity",0))
		{
			$("#rwCommunity").focus();
			return;
		}
		if(!CheckUserNamePlus($("#rCommunity").val(),"rCommunityTips","laRCommunity",0))
		{
			$("#rCommunity").focus();
			return;
		}
		if(!CheckUserNamePlus($("#trapCommunity").val(),"trapCommunityTips","laTrapCommunity",0))
		{
			$("#trapCommunity").focus();
			return;
		}
	}
	if($("#enablev3c")[0].checked)
	{
		if(!CheckUserNamePlus($("#rUserName").val(),"rUserNameTips","laRUserName",0))
		{
			$("#rUserName").focus();
			return;
		}
		if(!CheckUserNamePlus($("#rwUserName").val(),"rwUserNameTips","laRwUserName",0))
		{
			$("#rwUserName").focus();
			return;
		}
		//读用户安全级别
		var szRSecurityLevel = $("#rSecurityLevel").val();
		var bRAuthAlg = (szRSecurityLevel.split("_")[0] == "1");
		var bRPrivacyAlg = (szRSecurityLevel.split("_")[1] == "1");
		if(bRAuthAlg)
		{
			if(!CheackStringLenthNull($("#rAuthPsd").val(),"rAuthPsdTips","laAuthPsd",16))
			{
				$("#rAuthPsd").focus();
				return;
			}
		}
		if(bRPrivacyAlg)
		{
			if(!CheackStringLenthNull($("#rPrivacyPsd").val(),"rPrivacyPsdTips","laPrivacyPsd",16))
			{
				$("#rPrivacyPsd").focus();
				return;
			}
		}
		//读写用户安全级别
		var szRwSecurityLevel = $("#rwSecurityLevel").val();
		var bRwAuthAlg = (szRwSecurityLevel.split("_")[0] == "1");
		var bRwPrivacyAlg = (szRwSecurityLevel.split("_")[1] == "1");
		if(bRwAuthAlg)
		{
			if(!CheackStringLenthNull($("#rwAuthPsd").val(),"rwAuthPsdTips","laAuthPsd",16))
			{
				$("#rwAuthPsd").focus();
				return;
			}
		}
		if(bRwPrivacyAlg)
		{
			if(!CheackStringLenthNull($("#rwPrivacyPsd").val(),"rwPrivacyPsdTips","laPrivacyPsd",16))
			{
				$("#rwPrivacyPsd").focus();
				return;
			}
		}
	}
	var xmlDoc = g_oSNMPXml;
	if(!$("#enablev2c")[0].checked && !$("#enablev1")[0].checked)
	{
		$(xmlDoc).find('SNMPv2c').eq(0).find('enabled').eq(0).text("false");
		$(xmlDoc).find('SNMPv2c').eq(0).find('v1Enabled').eq(0).text("false");
	}
	else
	{
		var oSNMPv2c = xmlDoc.createElement("SNMPv2c");
		
		var Element = xmlDoc.createElement("notificationEnabled");
		var text = xmlDoc.createTextNode("true");
		Element.appendChild(text);
		oSNMPv2c.appendChild(Element);
		
		var oTrapReceiverList = xmlDoc.createElement("SNMPTrapReceiverList");
		var oTrapReceiver = xmlDoc.createElement("SNMPTrapReceiver");
		oTrapReceiverList.appendChild(oTrapReceiver);
		
		Element = xmlDoc.createElement("id");
		text = xmlDoc.createTextNode("1");
		Element.appendChild(text);
		oTrapReceiver.appendChild(Element);
		
		var oReceiverAddress = xmlDoc.createElement("ReceiverAddress");
		
		var strIpAddressType = CheckAddressingType($("#trapIP").val());
		if(strIpAddressType == "hostName")
		{
			Element = xmlDoc.createElement("addressingFormatType");
			text = xmlDoc.createTextNode("hostname");
			Element.appendChild(text);
			oReceiverAddress.appendChild(Element);
			
			Element = xmlDoc.createElement("hostName");
			text = xmlDoc.createTextNode($("#trapIP").val());
			Element.appendChild(text);
			oReceiverAddress.appendChild(Element);
			
			Element = xmlDoc.createElement("portNo");
			text = xmlDoc.createTextNode($("#trapPort").val());
			Element.appendChild(text);
			oReceiverAddress.appendChild(Element);
		}
		else if(strIpAddressType == "ipv6Address")
		{
			Element = xmlDoc.createElement("addressingFormatType");
			text = xmlDoc.createTextNode("ipaddress");
			Element.appendChild(text);
			oReceiverAddress.appendChild(Element);
			
			Element = xmlDoc.createElement("ipv6Address");
			text = xmlDoc.createTextNode($("#trapIP").val());
			Element.appendChild(text);
			oReceiverAddress.appendChild(Element);
			
			Element = xmlDoc.createElement("portNo");
			text = xmlDoc.createTextNode($("#trapPort").val());
			Element.appendChild(text);
			oReceiverAddress.appendChild(Element);
		}
		else
		{
			Element = xmlDoc.createElement("addressingFormatType");
			text = xmlDoc.createTextNode("ipaddress");
			Element.appendChild(text);
			oReceiverAddress.appendChild(Element);
			
			Element = xmlDoc.createElement("ipAddress");
			text = xmlDoc.createTextNode($("#trapIP").val());
			Element.appendChild(text);
			oReceiverAddress.appendChild(Element);
			
			Element = xmlDoc.createElement("portNo");
			text = xmlDoc.createTextNode($("#trapPort").val());
			Element.appendChild(text);
			oReceiverAddress.appendChild(Element);
		}
		oTrapReceiver.appendChild(oReceiverAddress);
		
		Element = xmlDoc.createElement("notificationType");
		text = xmlDoc.createTextNode("trap");
		Element.appendChild(text);
		oTrapReceiver.appendChild(Element);
		
		if("none" != $("#trapCommunityArea").css("display"))
		{
			Element = xmlDoc.createElement("communityString");
			text = xmlDoc.createTextNode($("#trapCommunity").val());
			Element.appendChild(text);
			oTrapReceiver.appendChild(Element);
		}
		oSNMPv2c.appendChild(oTrapReceiverList);
		
		var oSNMPv2cExt = xmlDoc.createElement("Extensions");
		var oSNMPv2cSelf = xmlDoc.createElement("selfExt");
		
		Element = xmlDoc.createElement("enabled");
		text = xmlDoc.createTextNode($("#enablev2c")[0].checked.toString());
		Element.appendChild(text);
		oSNMPv2cSelf.appendChild(Element);
		
		Element = xmlDoc.createElement("v1Enabled");
		text = xmlDoc.createTextNode($("#enablev1")[0].checked.toString());
		Element.appendChild(text);
		oSNMPv2cSelf.appendChild(Element);
		
		Element = xmlDoc.createElement("writeCommunity");
		text = xmlDoc.createTextNode($("#rwCommunity").val());
		Element.appendChild(text);
		oSNMPv2cSelf.appendChild(Element);
		
		Element = xmlDoc.createElement("readCommunity");
		text = xmlDoc.createTextNode($("#rCommunity").val());
		Element.appendChild(text);
		oSNMPv2cSelf.appendChild(Element);
		
		oSNMPv2cExt.appendChild(oSNMPv2cSelf);
		oSNMPv2c.appendChild(oSNMPv2cExt);
		
		xmlDoc.documentElement.replaceChild(oSNMPv2c, xmlDoc.documentElement.getElementsByTagName("SNMPv2c")[0]);
	}
	if($("#enablev3c")[0].checked)
	{
		//读用户认证算法
		var szRAuthAlg = "";
		if(bRAuthAlg)
		{
			$(document.getElementsByName("rAuthAlg")).each(function()
			{
				if(this.checked)
				{
					szRAuthAlg = this.value;
					return false;
				}
			});
		}
		else
		{
			szRAuthAlg = "none";
		}
		//读用户私钥算法
		var szRPrivacyAlg = "";
		if(bRPrivacyAlg)
		{
			$(document.getElementsByName("rPrivacyAlg")).each(function()
			{
				if(this.checked)
				{
					szRPrivacyAlg = this.value;
					return false;
				}
			});
		}
		else
		{
			szRPrivacyAlg = "none";
		}
		//读写用户认证算法
		var szRwAuthAlg = "";
		if(bRwAuthAlg)
		{
			$(document.getElementsByName("rwAuthAlg")).each(function()
			{
				if(this.checked)
				{
					szRwAuthAlg = this.value;
					return false;
				}
			});
		}
		else
		{
			szRwAuthAlg = "none";
		}
		//读写用户私钥算法
		var szRwPrivacyAlg = "";
		if(bRwPrivacyAlg)
		{
			$(document.getElementsByName("rwPrivacyAlg")).each(function()
			{
				if(this.checked)
				{
					szRwPrivacyAlg = this.value;
					return false;
				}
			});
		}
		else
		{
			szRwPrivacyAlg = "none";
		}
		
		var oSNMPv3  = xmlDoc.createElement("SNMPAdvanced");
		
		var Element = xmlDoc.createElement("localEngineID");
		oSNMPv3.appendChild(Element);
		
		var oUserList = xmlDoc.createElement("SNMPUserList");
		var oRUser = xmlDoc.createElement("SNMPUser");
		var oRwUser = xmlDoc.createElement("SNMPUser");
		//读用户
		Element = xmlDoc.createElement("id");
		var text = xmlDoc.createTextNode("1");
		Element.appendChild(text);
		oRUser.appendChild(Element);
		
		Element = xmlDoc.createElement("userName");
		text = xmlDoc.createTextNode($("#rUserName").val());
		Element.appendChild(text);
		oRUser.appendChild(Element);
		
		Element = xmlDoc.createElement("remoteEngineID");
		oRUser.appendChild(Element);
		
		Element = xmlDoc.createElement("snmpAuthenticationMethod");
		text = xmlDoc.createTextNode(szRAuthAlg);
		Element.appendChild(text);
		oRUser.appendChild(Element);
		if($("#rAuthPsd").val() != "******")
		{
			Element = xmlDoc.createElement("snmpAuthenticationPassword");
			text = xmlDoc.createTextNode($("#rAuthPsd").val());
			Element.appendChild(text);
			oRUser.appendChild(Element);
		}
		
		Element = xmlDoc.createElement("snmpPrivacyMethod");
		text = xmlDoc.createTextNode(szRPrivacyAlg);
		Element.appendChild(text);
		oRUser.appendChild(Element);
		if($("#rPrivacyPsd").val() != "******")
		{
			Element = xmlDoc.createElement("snmpPrivacyPassword");
			text = xmlDoc.createTextNode($("#rPrivacyPsd").val());
			Element.appendChild(text);
			oRUser.appendChild(Element);
		}
		//写用户
		Element = xmlDoc.createElement("id");
		var text = xmlDoc.createTextNode("2");
		Element.appendChild(text);
		oRwUser.appendChild(Element);
		
		Element = xmlDoc.createElement("userName");
		text = xmlDoc.createTextNode($("#rwUserName").val());
		Element.appendChild(text);
		oRwUser.appendChild(Element);
		
		Element = xmlDoc.createElement("remoteEngineID");
		oRwUser.appendChild(Element);
		
		Element = xmlDoc.createElement("snmpAuthenticationMethod");
		text = xmlDoc.createTextNode(szRwAuthAlg);
		Element.appendChild(text);
		oRwUser.appendChild(Element);
		if($("#rwAuthPsd").val() != "******")
		{
			Element = xmlDoc.createElement("snmpAuthenticationPassword");
			text = xmlDoc.createTextNode($("#rwAuthPsd").val());
			Element.appendChild(text);
			oRwUser.appendChild(Element);
		}
		
		Element = xmlDoc.createElement("snmpPrivacyMethod");
		text = xmlDoc.createTextNode(szRwPrivacyAlg);
		Element.appendChild(text);
		oRwUser.appendChild(Element);
		if($("#rwPrivacyPsd").val() != "******")
		{
			Element = xmlDoc.createElement("snmpPrivacyPassword");
			text = xmlDoc.createTextNode($("#rwPrivacyPsd").val());
			Element.appendChild(text);
			oRwUser.appendChild(Element);
		}
		
		oUserList.appendChild(oRUser);
		oUserList.appendChild(oRwUser);
		oSNMPv3.appendChild(oUserList);
		
		var oExt = xmlDoc.createElement("Extensions");
		var oSelf = xmlDoc.createElement("selfExt");
		Element = xmlDoc.createElement("enabled");
		text = xmlDoc.createTextNode($("#enablev3c")[0].checked.toString());
		Element.appendChild(text);
		oSelf.appendChild(Element);
		oExt.appendChild(oSelf);
		
		oSNMPv3.appendChild(oExt);
		
		xmlDoc.documentElement.replaceChild(oSNMPv3, xmlDoc.documentElement.getElementsByTagName("SNMPAdvanced")[0]);
	}
	else
	{
		$(xmlDoc).find('SNMPAdvanced').eq(0).find('enabled').eq(0).text("false");
	}
	$(xmlDoc).find('SNMPAdvanced').eq(0).next().find('listenPort').eq(0).text($("#snmpPort").val());
	
	$.ajax({
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces/1/snmp",
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}

/*************************************************
Function:		initWIFI
Description:	初始化WIFI页面
Input:			无			
Output:			无
return:			无				
*************************************************/
function initWIFI() {
	$("#dvWifiSetting").children("div:visible[class!='mainparams margintop26']").each(function(i) {
		if($(this).hasClass("subparamswhite") || $(this).hasClass("subparamsgray")) {
			return false;
		}
		if(i%2 == 0) {
			$(this).attr("class", "subparamswhite");
		}
		else {
			$(this).attr("class", "subparamsgray");
		}
	});
	var szInfo = getNodeValue('laPlugin');
	if(checkPlugin('0', szInfo)) {
		if(!CompareFileVersion()) {
			UpdateTips();
		}
	}
	m_PreviewOCX = document.getElementById("PreviewActiveX");
	getWIFIList();
	getWIFI();
	getWIFI8021x();
	getWPSEnable();
}
/*************************************************
Function:		getWIFI
Description:	获取WIFI列表
Input:			无			
Output:			无
return:			无				
*************************************************/
function getWIFIList() {
	$.ajax({
		type: "GET",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Wireless/Interfaces/1/accessPointList",
		timeout: 15000,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) {
			var oAccessPoint = $(xmlDoc).find("accessPoint");
			var iLen = oAccessPoint.length;
			var szSSID = "";
			var szMode = "";
			var szSecurityMode = "";
			var szChannel = "";
			var szSignal = "";
			var szSpeed = "";
			$("#dvWifiList").empty();
			for(var i = 0; i < iLen; i++) {
				szSSID = oAccessPoint.eq(i).find("ssid").eq(0).text();
				szMode = oAccessPoint.eq(i).find("wirelessNetworkMode").eq(0).text();
				szSecurityMode = oAccessPoint.eq(i).find("securityMode").eq(0).text();
				szChannel = oAccessPoint.eq(i).find("channel").eq(0).text();
				szSignal = oAccessPoint.eq(i).find("signalStrength").eq(0).text();
				szSpeed = oAccessPoint.eq(i).find("speed").eq(0).text();
				insertOneWIFI((i+1), szSSID, szMode, szSecurityMode, szChannel, szSignal, szSpeed);
			}
		}
	});
}
/*************************************************
Function:		insertOneWIFI
Description:	插入一个WIFI信息
Input:			iIndex : 序号	
                szSSID : 网络ID
				szMode : 工作模式
				szSecurityMode : 加密模式
				szChannel : 频道
				szSignal : 信号强度
				szSpeed : 速度			
Output:			无
return:			无				
*************************************************/
function insertOneWIFI(iIndex, szSSID, szMode, szSecurityMode, szChannel, szSignal, szSpeed) {
	$('<div><span class="wifiline width54"><label>'+iIndex+'</label></span><span class="wifiline width156"><label>'+(szSSID==""?"&nbsp;":szSSID)+'</label></span><span class="wifiline width100"><label>'+szMode+'</label></span><span class="wifiline width100"><label>'+(szSecurityMode=="disable"?"NONE":szSecurityMode)+'</label></span><span class="wifiline width65"><label>'+szChannel+'</label></span><span class="wifiline width85"><label>'+szSignal+'</label></span><span class="wifiline width75"><label>'+szSpeed+'</label></span></div>').appendTo("#dvWifiList").bind({
		click:function() {		
			if(!$(this).hasClass("wifilistselect")) {
				$(this).siblings(".wifilistselect").removeClass().addClass(iIndex%2 == 0?"wifilisteven":"wifilistodd");
				$(this).removeClass().addClass("wifilistselect");
			}			
			$("#teSSID").val(szSSID);
			$("#txtWPSSSID").val(szSSID);
			$("#wifiChannel").val(szChannel);
			$("#dvWifiSetting").find(":radio[name='networkMode'][value='"+szMode+"']").prop("checked", true);
			$("#securityMode").val(szSecurityMode).change();
		},
		mouseover:function() {
			if(!$(this).hasClass("wifilistselect")) {
			    $(this).removeClass().addClass("wifilistenter");
			}
		},
		mouseout:function() {
			if(!$(this).hasClass("wifilistselect")) {
			    $(this).removeClass().addClass(iIndex%2 == 0?"wifilisteven":"wifilistodd");
			}
		}
	}).addClass((iIndex%2 == 0?"wifilisteven":"wifilistodd")).attr("title",getNodeValue(''));
}
/*************************************************
Function:		getWIFI
Description:	获取WIFI信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function getWIFI() {
	$.ajax({
		type: "get",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces/2/wireless",
		timeout: 15000,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) {
			$("#teSSID").val($(xmlDoc).find("ssid").eq(0).text());
			$("#wifiChannel").val($(xmlDoc).find("channel").eq(0).text());
			$("#dvWifiSetting").find(":radio[name='networkMode'][value='"+$(xmlDoc).find("wirelessNetworkMode").eq(0).text()+"']").prop("checked", true);
			var szSecurityMode = $(xmlDoc).find("securityMode").eq(0).text();
			$("#securityMode").val(szSecurityMode).change();
			if("WEP" == szSecurityMode) {
				$("#dvWifiSetting").find(":radio[name='authenticationType'][value='"+$(xmlDoc).find("WEP").eq(0).find("authenticationType").eq(0).text()+"']").prop("checked", true);
				$("#dvWifiSetting").find(":radio[name='encryptionKey'][value='"+$(xmlDoc).find("WEP").eq(0).find("defaultTransmitKeyIndex").eq(0).text()+"']").prop("checked", true).click();
				$("#dvWifiSetting").find(":radio[name='KeyLength'][value='"+$(xmlDoc).find("WEP").eq(0).find("wepKeyLength").eq(0).text()+"']").prop("checked", true);
				$("#dvWifiSetting").find(":radio[name='KeyType'][value='"+$(xmlDoc).find("keyType").eq(0).text()+"']").prop("checked", true);
				if($(xmlDoc).find("keyType").eq(0).text() === "HEX") {
					var oEncryptionKeyList = $(xmlDoc).find("WEP").eq(0).find("encryptionKey");
					for(var i = 0; i < oEncryptionKeyList.length; i++) {
						$("#encryptionKey"+(i+1)).val(oEncryptionKeyList.eq(i).text());
					}
				} else {
					var oASCIIKeyList = $(xmlDoc).find("WEP").eq(0).find("ASCIIKey");
					for(var i = 0; i < oASCIIKeyList.length; i++) {
						$("#encryptionKey"+(i+1)).val(oASCIIKeyList.eq(i).text());
					}				
				}
				autoResizeIframe();
			} else if("disable" == szSecurityMode) {
			
			} else {
				$("#algorithmType").val($(xmlDoc).find("WPA").eq(0).find("algorithmType").eq(0).text());
				$("#dvWifiSetting").find(":text[id*='encryptionKey']").eq(0).val($(xmlDoc).find("WPA").eq(0).find("sharedKey").eq(0).text());
			}
		}
	});
}
/*************************************************
Function:		getWIFI8021x
Description:	获取WIFI版本相关信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function getWIFI8021x() {
	$.ajax({
		type: "get",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces/2/ieee802.1x",
		timeout: 15000,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) {
			$("#enterpriseType").val($(xmlDoc).find("authenticationProtocolType").eq(0).text());
			$("#wifiUser").val($(xmlDoc).find("userName").eq(0).text());
			if($("#wifiUser").val() != "") {
				$("#wifiPassword").val(oCheckPassword.m_szDefaultPassword);
			} else {
			    $("#wifiPassword").val("");
			}
			$("#PEAPVersion").val($(xmlDoc).find("PEAPVersion").eq(0).text());
			$("#PEAPLabel").val($(xmlDoc).find("PEAPLabel").eq(0).text());
			$("#innerEAPProtocolType").val($(xmlDoc).find("innerEAPProtocolType").eq(0).text());
			$("#innerAuthenticationMode").val($(xmlDoc).find("innerTTLSAuthenticationMethod").eq(0).text());
			$("#anonymousID").val($(xmlDoc).find("anonymousID").eq(0).text());
			$("#enterprise1Identify").val($(xmlDoc).find("userName").eq(0).text());
			$("#anonymousID").val($(xmlDoc).find("anonymousID").eq(0).text());
			if($("#enterprise1Identify").val() != "") {
				$("#privateKeyPassword").val(oCheckPassword.m_szDefaultPassword);
			} else {
			    $("#privateKeyPassword").val("");
			}			
			$("#wifiEAPOLVersion").val($(xmlDoc).find("EAPOLVersion").eq(0).text());
			if($("#securityMode").val() == "WPA-enterprise" || $("#securityMode").val() == "WPA2-enterprise") {
			    $("#enterpriseType").change();
			}
		}
	});
}
/*************************************************
Function:		getWPSEnable
Description:	获取WPS使能
Input:			无			
Output:			无
return:			无				
*************************************************/
function getWPSEnable() {
	$.ajax({
		type: "get",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Wireless/Interface/1/WPS",
		timeout: 15000,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) {
			$("#checkEnableWPS").prop("checked", $(xmlDoc).find("enable").eq(0).text() === "true" ? true : false);
			getDevicePinCode();
			enableWPS();
		}
	});
}
/*************************************************
Function:		setWPSEnable
Description:	设置WPS使能
Input:			无			
Output:			无
return:			无				
*************************************************/
function setWPSEnable() {
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><WPS><enable>" + $("#checkEnableWPS").prop("checked").toString() + "</enable></WPS>";
	var xmlDoc = parseXmlFromStr(szXml);
	$.ajax({
		type: "put",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Wireless/Interface/1/WPS",
		timeout: 15000,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		processData: false,
		data: xmlDoc,
		success: function(xmlDoc, textStatus, xhr) {
			
		},
		complete:function(xhr, textStatus) {
			if($(xhr.responseXML).find('statusCode').eq(0).text() !== "1") {
				g_oXhr = xhr;
			}
		}
	});	
}
/*************************************************
Function:		getDevicePinCode
Description:	获取PinCode
Input:			无			
Output:			无
return:			无				
*************************************************/
function getDevicePinCode() {
	$.ajax({
		type: "get",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Wireless/Interface/1/WPS/devicePinCode",
		timeout: 15000,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) {
			$("#devicePinCode").val(xhr.responseText);		
		}
	});
}
/*************************************************
Function:		generagePINCode
Description:	生成PINCode
Input:			无			
Output:			无
return:			无				
*************************************************/
function generagePINCode() {
	$.ajax({
		type: "put",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Wireless/Interface/1/WPS/devicePinCodeUpdate",
		timeout: 15000,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) {
			getDevicePinCode();	
		}
	});
}
/*************************************************
Function:		chooseConnectMode
Description:	选择WPS连接方式
Input:			无			
Output:			无
return:			无				
*************************************************/
function chooseConnectMode(iType) {
	if(iType === 0) {
		$("#txtApPinCode").prop("disabled", true);
		$("#txtWPSSSID").prop("disabled", true);
		$("#btnManuConnect").prop("disabled", true);
		$("#btnAutoConnect").prop("disabled", false);
		$("#radioManuConnect").prop("checked", false);
		$("#radioAutoConnect").prop("checked", true);
	} else {
		$("#btnAutoConnect").prop("disabled", true);
		$("#txtApPinCode").prop("disabled", false);
		$("#txtWPSSSID").prop("disabled", false);
		$("#btnManuConnect").prop("disabled", false);
		$("#radioManuConnect").prop("checked", true);
		$("#radioAutoConnect").prop("checked", false);
	}
}
/*************************************************
Function:		enableWPS
Description:	启用WPS
Input:			无			
Output:			无
return:			无				
*************************************************/
function enableWPS() {
	if(!$("#checkEnableWPS").prop("checked")) {
		$("#wpsSetting").find("input[type!='checkbox']").each(function(i) {
			$(this).prop("disabled", true);
		});
	} else {
		$("#wpsSetting").find("input[type!='checkbox']").each(function(i) {
			$(this).prop("disabled", false);
			if($("#radioAutoConnect").prop("checked")) {
			    chooseConnectMode(0);
			} else {
			    chooseConnectMode(1);
			}
		});	    
	}
}
/*************************************************
Function:		pbcConnect
Description:	PBC连接
Input:			无			
Output:			无
return:			无				
*************************************************/
function pbcConnect() {
	$.ajax({
		type: "PUT",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Wireless/Interface/1/WPS/AutoConnect",
		timeout: 120000,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
			$("#pbcConnectTips").html(getNodeValue("jsConnecting"));
		},
		success: function(xmlDoc, textStatus, xhr) {
			$("#pbcConnectTips").html(getNodeValue("jsConnectSuc"));
			setTimeout(function () {
			    $("#pbcConnectTips").html("");
			}, 5000);
		},
		error: function(){
			$("#pbcConnectTips").html(getNodeValue("jsConnectFail"));
			setTimeout(function () {
			    $("#pbcConnectTips").html("");
			}, 5000);
		}
	});
}
/*************************************************
Function:		uploadCertificate
Description:	上传证书
Input:			无			
Output:			无
return:			无				
*************************************************/
function uploadCertificate(iType) {
	if(m_PreviewOCX === null) {
	    return;
	}
	var szUrl = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Security/deviceCertificate";
	if(iType === 0) {
		if(0 !== m_PreviewOCX.HWP_UploadFile(szUrl, m_szUserPwdValue, $("#certificatePath1").val(), "application/x-x509-ca-cert", 0)) {
			return;
		} else {
			$("#certificateTips1").html(getNodeValue("jsUploadSuc"));
			setTimeout(function () {
			    $("#certificateTips1").html("");
			}, 5000);			
		}
	} else if(iType === 1) {
		if(0 !== m_PreviewOCX.HWP_UploadFile(szUrl, m_szUserPwdValue, $("#certificatePath2").val(), "application/x-x509-client-cert", 0)) {
			return;
		} else {
			$("#certificateTips2").html(getNodeValue("jsUploadSuc"));
			setTimeout(function () {
			    $("#certificateTips2").html("");
			}, 5000);
		}	    
	} else {
		if(0 !== m_PreviewOCX.HWP_UploadFile(szUrl, m_szUserPwdValue, $("#certificatePath3").val(), "application/x-x509-client-key", 0)) {
			return;
		} else {
			$("#certificateTips3").html(getNodeValue("jsUploadSuc"));
			setTimeout(function () {
			    $("#certificateTips3").html("");
			}, 5000);
		}	    
	}
}
/*************************************************
Function:		manuConnect
Description:	手动连接
Input:			无			
Output:			无
return:			无				
*************************************************/
function manuConnect() {
	if(!CheckDeviceName($("#txtWPSSSID").val(),"spWPSSSIDTips", 0)) {
		return;
	}
	if(!CheckDeviceName($("#txtApPinCode").val(),"manuConnectTips", 0)) {
		return;
	}	
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><WpsApPincode><ssid>" + $("#txtWPSSSID").val() + "</ssid><pinCode>" + $("#txtApPinCode").val() + "</pinCode></WpsApPincode>";
	var xmlDoc = parseXmlFromStr(szXml);
	$.ajax({
		type: "PUT",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Wireless/Interface/1/WPS/ApPinCode",
		timeout: 120000,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
			$("#manuConnectTips").html(getNodeValue("jsConnecting"));
		},
		processData: false,
		data: xmlDoc,
		success: function(xmlDoc, textStatus, xhr) {
			$("#manuConnectTips").html(getNodeValue("jsConnectSuc"));
			setTimeout(function () {
			    $("#manuConnectTips").html("");
			}, 5000);			
		},
		error: function(){
			$("#manuConnectTips").html(getNodeValue("jsConnectFail"));
			setTimeout(function () {
			    $("#manuConnectTips").html("");
			}, 5000);
		}
	});
}
/*************************************************
Function:		setWIFI
Description:	设置WIFI信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function setWIFI() {
	g_oXhr = null;
	var oAuthTypeList = $("#dvWifiSetting").find(":radio[name='authenticationType']");
	var oKeyLengthRadioList = $("#dvWifiSetting").find(":radio[name='KeyLength']");
	var oKeyTypeRadioList = $("#dvWifiSetting").find(":radio[name='KeyType']");
	var oEncryKeyRadioList = $("#dvWifiSetting").find(":radio[name='encryptionKey']");
	var oEncryKeyTextList = $("#dvWifiSetting").find(":text[id*='encryptionKey']");
	if(!CheckDeviceName($("#teSSID").val(),"spSSIDTips", false)) {
		$("#teSSID").focus();
		setTimeout(function(){$("#spSSIDTips").html("");}, 5000);
		return;
	}
	if($("#securityMode").val() == "WEP" || $("#securityMode").val() == "WPA-personal" || $("#securityMode").val() == "WPA2-personal") {
		if(!checkEncryptionKeyLength(oEncryKeyTextList.get(parseInt(oEncryKeyRadioList.filter(":checked").val(),10)-1), "spEncryptKeyTips"+oEncryKeyRadioList.filter(":checked").val())) {
			return;
		}
	}
	if($("#securityMode").val() == "WPA-enterprise" || $("#securityMode").val() == "WPA2-enterprise") {
		//EAP-TLS
		if($("#enterpriseType").val() == "EAP-TLS") {
			if(!CheckDevUserName($("#enterprise1Identify").val(), "identifyTips", "laIdentify", 0)) {
				return;
			}
			if(!CheackStringLenth($("#enterprise1Identify").val(), 'identifyTips', 'laIdentify', 32)) {
				return;
			}
			if(!CheckDevUserName($("#privateKeyPassword").val(), "identifyPasswordTips", "laPrivateKeyPassword", 0)) {
				return;
			}
			if(!CheackStringLenth($("#privateKeyPassword").val(), 'identifyPasswordTips', 'laPrivateKeyPassword', 32)) {
				return;
			}	
		}
		//EAP-PEAP, EAP-TTLS
		if($("#enterpriseType").val() == "EAP-PEAP" || $("#enterpriseType").val() == "EAP-TTLS") {
			if(!CheckDevUserName($("#wifiUser").val(), "wifiUserTips", "geUserName", 0)) {
				return;
			}
			if(!CheackStringLenth($("#wifiUser").val(), 'wifiUserTips', 'geUserName', 32)) {
				return;
			}
			if(!CheckDevUserName($("#wifiPassword").val(), "wifiPasswordTips", "gePassword", 0)) {
				return;
			}
			if(!CheackStringLenth($("#wifiPassword").val(), 'wifiPasswordTips', 'gePassword', 32)) {
				return;
			}
			if(!CheackStringLenth($("#anonymousID").val(), 'anonymousIDTips', 'laAnonymousID', 32)) {
				return;
			}			
		}
	}
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><Wireless version='1.0' xmlns='urn:psialliance-org'><enabled>true</enabled><wirelessNetworkMode>"+$("#dvWifiSetting").find(":radio[name='networkMode']").filter(":checked").val()+"</wirelessNetworkMode><channel>auto</channel><ssid>"+$("#teSSID").val()+"</ssid><wmmEnabled>false</wmmEnabled><WirelessSecurity><securityMode>"+$("#securityMode").val()+"</securityMode>";
	if($("#securityMode").val() == "WEP") {
		var szKeyType = $("#dvWifiSetting").find(":radio[name='KeyType']").filter(":checked").val();
		szXml += "<WEP><authenticationType>"+oAuthTypeList.filter(":checked").val()+"</authenticationType><defaultTransmitKeyIndex>" + oEncryKeyRadioList.filter(":checked").val() + "</defaultTransmitKeyIndex><wepKeyLength>"+oKeyLengthRadioList.filter(":checked").val()+"</wepKeyLength>";
		szXml += "<keyType>" +  szKeyType + "</keyType>";
		
		if(szKeyType == "HEX") {
			szXml += "<EncryptionKeyList>";
			for(var i = 0; i < oEncryKeyTextList.length; i++) {
				szXml += "<encryptionKey>" + oEncryKeyTextList.eq(i).val() + "</encryptionKey>"
			}
			szXml += "</EncryptionKeyList>";
		} else {
			szXml += "<ASCKeyList>";
			for(var i = 0; i < oEncryKeyTextList.length; i++) {
				szXml += "<ASCIIKey>" + oEncryKeyTextList.eq(i).val() + "</ASCIIKey>"
			}
			szXml += "</ASCKeyList>";
		}
	    szXml += "</WEP>";
	} else if($("#securityMode").val() == "disable") {
		
	} else {
		if($("#securityMode").val() == "WPA-enterprise" || $("#securityMode").val() == "WPA2-enterprise") {
			szXml += "<WPA><algorithmType>"+$("#algorithmType").val()+"</algorithmType></WPA>"; 
		} else {
		    szXml += "<WPA><algorithmType>"+$("#algorithmType").val()+"</algorithmType><sharedKey>"+oEncryKeyTextList.eq(0).val()+"</sharedKey><wpaKeyLength>"+oEncryKeyTextList.eq(0).val().length+"</wpaKeyLength></WPA>";
		}
	}
	szXml += "</WirelessSecurity></Wireless>";
	var xmlDoc = parseXmlFromStr(szXml);
	$.ajax({
		type: "PUT",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces/2/wireless",
		timeout: 15000,
		async: false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		processData: false,
		data: xmlDoc,
		success: function(xmlDoc, textStatus, xhr) {
			if($("#securityMode").val() == "WPA-enterprise" || $("#securityMode").val() == "WPA2-enterprise") {
				//EAP-TLS
				if($("#enterpriseType").val() == "EAP-TLS") {
					setWIFI8021x("EAP-TLS");	
				}
				//EAP-PEAP
				if($("#enterpriseType").val() == "EAP-PEAP") {
					setWIFI8021x("EAP-PEAP");		
				}
				//EAP-TTLS
				if($("#enterpriseType").val() == "EAP-TTLS") {
					setWIFI8021x("EAP-TTLS");	
				}
			}
			setWPSEnable();
		},
		complete:function(xhr, textStatus) {
			if(g_oXhr !== null) {
			    SaveState(g_oXhr);
			} else {
			    SaveState(xhr);
			}
		}
	});
}
/*************************************************
Function:		setWIFI8021x
Description:	设置wifi相关的8021x信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function setWIFI8021x(szType) {	
	var szXml = "";
	if(szType === "EAP-TLS") {		
	    szXml = "<?xml version='1.0' encoding='UTF-8' ?><IEEE802_1x><enabled>true</enabled>" +
        "<authenticationProtocolType>" + $("#enterpriseType").val() + "</authenticationProtocolType>" + 
        "<userName>" + $("#enterprise1Identify").val() + "</userName>";
		if($("#wifiPassword").val() != oCheckPassword.m_szDefaultPassword) {
		    szXml += "<password>" + $("#privateKeyPassword").val() + "</password>";
		}
        szXml += "<Extensions><EAPOLVersion>" + $("#wifiEAPOLVersion").val() + "</EAPOLVersion></Extensions></IEEE802_1x>";		
	} else if(szType === "EAP-PEAP") {
	    szXml = "<?xml version='1.0' encoding='UTF-8' ?><IEEE802_1x><enabled>true</enabled>" +
        "<authenticationProtocolType>" + $("#enterpriseType").val() + "</authenticationProtocolType>" + 
        "<innerEAPProtocolType>" + $("#innerEAPProtocolType").val() + "</innerEAPProtocolType>" + 
        "<userName>" + $("#wifiUser").val() + "</userName>";
		if($("#wifiPassword").val() != oCheckPassword.m_szDefaultPassword) {
		    szXml += "<password>" + $("#wifiPassword").val() + "</password>";
		}
		szXml += "<anonymousID>" + $("#anonymousID").val() + "</anonymousID>" +
        "<Extensions><EAPOLVersion>" + $("#wifiEAPOLVersion").val() + "</EAPOLVersion>" +
		"<PEAPVersion>" + $("#PEAPVersion").val() + "</PEAPVersion>" +
		"<PEAPLabel>" + $("#PEAPLabel").val() + "</PEAPLabel>" +
		"</Extensions></IEEE802_1x>";		
	} else {
	    szXml = "<?xml version='1.0' encoding='UTF-8' ?><IEEE802_1x><enabled>true</enabled>" +
        "<authenticationProtocolType>" + $("#enterpriseType").val() + "</authenticationProtocolType>" + 
        "<innerTTLSAuthenticationMethod>" + $("#innerAuthenticationMode").val() + "</innerTTLSAuthenticationMethod>" + 
        "<userName>" + $("#wifiUser").val() + "</userName>";
		if($("#wifiPassword").val() != oCheckPassword.m_szDefaultPassword) {
		    szXml += "<password>" + $("#wifiPassword").val() + "</password>";
		}
		szXml += "<anonymousID>" + $("#anonymousID").val() + "</anonymousID>" +
        "<Extensions><EAPOLVersion>" + $("#wifiEAPOLVersion").val() + "</EAPOLVersion></Extensions></IEEE802_1x>";
	}
	var xmlDoc = parseXmlFromStr(szXml);
	$.ajax({
		type: "put",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces/2/ieee802.1x",
		timeout: 15000,
		async: false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		processData: false,
		data: xmlDoc,
		success: function(xmlDoc, textStatus, xhr) {
			
		},
		complete:function(xhr, textStatus) {
			if($(xhr.responseXML).find('statusCode').eq(0).text() !== "1") {
				g_oXhr = xhr;
			}
		}
	});
}
/*************************************************
  Function:    	checkEncryptionKeyLength
  Description:	检查输入密钥长度是否合法
  Input:        szStr:传入的参数
  				tipsId:提示信息
  Output:      	无
  Return:		bool:true false
*************************************************/
function checkEncryptionKeyLength(obj, tipsId) {
	var szTipsInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
	var iTipsLen = szTipsInfo.length;
	var szVal = $(obj).val();
	var szKeyType = $("#dvWifiSetting").find(":radio[name='KeyType']").filter(":checked").val();
	var szKeyLength = $("#dvWifiSetting").find(":radio[name='KeyLength']").filter(":checked").val();
	if($("#securityMode").val() == "WEP") {
		//16进制
		if("HEX" == szKeyType) {
			//64位
			if("64" == szKeyLength) {
				if(szVal.length < 10) {
					szTipsInfo += getNodeValue("jsTenHex");
				}
			//128位
			} else {
				if(szVal.length < 26) {
					szTipsInfo += getNodeValue("jsXXVIHex");
				}
			}
		//ASCII码
		} else {
			//64位
			if("64" == szKeyLength) {
				if(szVal.length < 5) {
					szTipsInfo += getNodeValue("jsFiveASCII");
				}
			//128位
			} else {
				if(szVal.length < 13) {
					szTipsInfo += getNodeValue("jsTenASCII");
				}
			}
		}
	} else {
		if(szVal.length < 8) {
			szTipsInfo += getNodeValue("jsEightMoreChar");
		}
	}
	if(szTipsInfo.length > iTipsLen) {
		$("#" + tipsId).html(szTipsInfo); 
		$(obj).focus().val(szVal);
		setTimeout(function(){$("#" + tipsId).html("");}, 5000);
		return false;
	} else {
		$("#" + tipsId).html(""); 
		return true;
	}
}
/*************************************************
Function:		SelectWindowTd
Description:	选中某个命名项
Input:			无
Output:			无
return:			无
*************************************************/
SelectWindowTd = function(event)
{
   event = event?event:(window.event?window.event:null);
   var ObjTable = event.srcElement?event.srcElement:event.target;
   if(ObjTable.tagName == "TD")
   {
      while(ObjTable.tagName != "TR")
	  {
		  ObjTable = ObjTable.parentNode;
	  }
      ObjParent = ObjTable.parentNode;
      var m_iSelFileIndex = ObjTable.rowIndex - 1;
      if(m_iSelFileIndex == -1)
      {
	      return;
      }
	  while(ObjParent.tagName!="TABLE")
	  {
	      ObjParent = ObjParent.parentNode;
		  if(m_iSelectItem >=  0)
		  {
			  $("#itemtdA" + (m_iSelectItem + 1)).css({ color: "#39414A", background: "#ffffff" });
		      $("#itemtdB" + (m_iSelectItem + 1)).css({ color: "#39414A", background: "#ffffff" });
		      $("#itemtdC" + (m_iSelectItem + 1)).css({ color: "#39414A", background: "#ffffff" });
			  m_strItem[m_iSelectItem] = $("#ItemElement"+ (m_iSelectItem + 1)).val();
			  if($("#ItemElement"+ (m_iSelectItem + 1)).val()=="custom"){
			      m_strCustomStr[m_iSelectItem] = $("#customStr"+ (m_iSelectItem + 1)).val();
			  }
              //+ "<div style='display: none'><input type='hidden' id='itemtdC"+(m_iSelectItem + 1)+"' value='"+ m_strItem[m_iSelectItem] +"Item'/></div>"
              sz_itemInfo = getNodeValue(m_strItem[m_iSelectItem] + "Item");
			  //$("#itemtdC" + (m_iSelectItem + 1)).html(sz_itemInfo);
			  sz_itemInfo += "<input class='displaynone width75' id='customStr" + (m_iSelectItem + 1) + "' maxlength='32'/>";			  
              $("#itemtdC" + (m_iSelectItem + 1)).attr("name",m_strItem[m_iSelectItem]);
			  var szItem = $("#ItemElement"+ (m_iSelectItem + 1)).val();
			  var szCustomStr = $("#customStr"+ (m_iSelectItem + 1)).val();
			  $("#itemtdC" + (m_iSelectItem + 1)).html(sz_itemInfo);
			  if( szItem == "custom"){
				$("#customStr"+ (m_iSelectItem + 1)).show().val(szCustomStr);
			  }	
			
		   }

		   for(var i = 1;i < ObjParent.rows.length;i ++)
		   {
			    if(ObjTable.rowIndex == i)
				{
					$("#itemtdA" + i).css({ color: "#ffffff", background: "#316ac5" });
		            $("#itemtdB" + i).css({ color: "#ffffff", background: "#316ac5" });
		            $("#itemtdC" + i).css({ color: "#ffffff", background: "#316ac5" });

                    var szInfo = "<select name='ItemElement"+ i +"' id='ItemElement"+ i +"' class='ftpinputwidth' onchange='changeWindowTd("+i+")'><option value='none'>" + getNodeValue("noneItem") +"</option><option value='deviceName'>"+ getNodeValue("deviceNameItem") + "</option><option value='deviceNo'>"+ getNodeValue("deviceNoItem") + "</options><option value='deviceIP'>"+ getNodeValue("deviceIPItem") + "</options><option value='channelName'>"+ getNodeValue("channelNameItem") + "</options><option value='channelNo'>"+ getNodeValue("channelNoItem") + "</options><option value='time'>"+ getNodeValue("timeItem") + "</options><option value='plateNo'>"+ getNodeValue("plateNoItem") +"</options><option value='plateColor'>"+ getNodeValue("plateColorItem") + "</options><option value='laneNo'>"+ getNodeValue("laneNoItem") + "</options><option value='carSpeed'>"+ getNodeValue("carSpeedItem") + "</options><option value='positionInfo1'>"+ getNodeValue("positionInfo1Item") + "</options><option value='pictureNo'>"+ getNodeValue("pictureNoItem") + "</options><option value='CarNo'>"+ getNodeValue("CarNoItem") + "</options><option value='speedLimit'>"+ getNodeValue("speedLimitItem") + "</options><option value='illegalCode'>"+ getNodeValue("illegalCodeItem") + "</options><option value='siteNo'>"+ getNodeValue("siteNoItem") + "</options><option value='directionNo'>"+ getNodeValue("directionNoItem") + "</options><option value='carColor'>"+ getNodeValue("carColorItem") + "</options><option value='platePosition'>"+ getNodeValue("platePositionItem") + "</options><option value='carType'>"+ getNodeValue("carTypeItem") + "</options><option value='illegalType'>"+ getNodeValue("illegalTypeItem") + "</options><option value='custom'>"+ getNodeValue("customItem") + "</options></select>"+"<input class='displaynone width75' id='customStr"+i+"' maxlength='32'/>";
					$("#itemtdC" + i).html(szInfo);
					$("#ItemElement"+i).val(m_strItem[i-1]);//赋值为之前的值
					$("#customStr"+i).val(m_strCustomStr[i-1]);
					m_iSelectItem = i - 1;
				}
			}
	    }
    }
}
/*************************************************
 Function:        Init28181
 Description:    初始化28181配置
 Input:            无
 Output:            无
 return:            无
 *************************************************/
Cfg28181.prototype.Init28181 = function() {
    //初始化码流类型
    if (window.parent.g_bIsSupportThreeStream) {
        if ($("#sel28181Stream option").length === 2) {
            $("#sel28181Stream").append("<option value='3' name='StreamTypeInOpt4'>" + getNodeValue('StreamTypeInOpt4') + "</option>");
        }
    }

    //绑定点击事件
    var that = this;
    $("#ch28181Enable").bind("click", function() {
        that.Enable28181();
    });

    this.Get28181Capabilities();
    this.Get28181Cfg();
    this.GetSIPInfo();
    this.Enable28181();
}

/*************************************************
 Function:        Get28181Capabilities
 Description:    获取28181能力
 Input:            无
 Output:            无
 return:            无
 *************************************************/
Cfg28181.prototype.Get28181Capabilities = function () {
    var szURL = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/SIP/1/capabilities";
    var that = this;

    $.ajax({
        type:"GET",
        url:szURL,
        timeout:15000,
        async:true,
        beforeSend:function (xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success:function (xmlDoc, textStatus, xhr) {
            that.m_xmlCfg281281Capa = xmlDoc;
            //获取能力，一些参数按照能力来设置

            var max = -1;
            var min = -1;

            //本地端口
            $("#teLocalSIPPort").unbind().bind({
                blur:function() {
                    max = parseInt($(that.m_xmlCfg281281Capa).find("localPort").attr("max"), 10);
                    min = parseInt($(that.m_xmlCfg281281Capa).find("localPort").attr("min"), 10);
                    CheackServerIDIntNum($("#teLocalSIPPort").val(), 'LocalSIPPortTips', 'laLocalSIPPort', isNaN(min)?1024:min, isNaN(max)?65535:max);
                }
            });

            //SIP服务器端口
            $("#teSIPServerPort").unbind().bind({
                blur:function() {
                    max = parseInt($(that.m_xmlCfg281281Capa).find("registrarPort").attr("max"), 10);
                    min = parseInt($(that.m_xmlCfg281281Capa).find("registrarPort").attr("min"), 10);
                    CheackServerIDIntNum($("#teSIPServerPort").val(), 'SIPServerPortTips', 'laSIPServerPort', isNaN(min)?1024:min, isNaN(max)?65535:max);
                }
            });

            //注册有效期
            $("#teSIPExpiration").unbind().bind({
                blur:function() {
                    max = parseInt($(that.m_xmlCfg281281Capa).find("expires").attr("max"), 10);
                    min = parseInt($(that.m_xmlCfg281281Capa).find("expires").attr("min"), 10);
                    CheackServerIDIntNum($("#teSIPExpiration").val(), 'SIPExpirationTips', 'laSIPExpiration', isNaN(min)?30:min, isNaN(max)?100000:max, getNodeValue('optionSecond'))
                }
            });

            //心跳周期
            $("#teHeartBeatPeriod").unbind().bind({
                blur:function() {
                    max = parseInt($(that.m_xmlCfg281281Capa).find("heartbeatTime").attr("max"), 10);
                    min = parseInt($(that.m_xmlCfg281281Capa).find("heartbeatTime").attr("min"), 10);
                    CheackServerIDIntNum($("#teHeartBeatPeriod").val(), 'HeartBeatPeriodTips', 'laHeartBeatPeriod', isNaN(min)?5:min, isNaN(max)?255:max, getNodeValue('optionSecond'))
                }
            });

            //最大心跳超时次数
            $("#teMaxHeartBeatTimeout").unbind().bind({
                blur:function() {
                    max = parseInt($(that.m_xmlCfg281281Capa).find("heartbeatCount").attr("max"), 10);
                    min = parseInt($(that.m_xmlCfg281281Capa).find("heartbeatCount").attr("min"), 10);
                    CheackServerIDIntNum($("#teMaxHeartBeatTimeout").val(), 'MaxHeartBeatTimeoutTips', 'laMaxHeartBeatTimeout', isNaN(min)?3:min, isNaN(max)?255:max, '')
                }
            });
        }
    });
}

/*************************************************
 Function:        Get28181Cfg
 Description:    获取28181配置信息
 Input:            无
 Output:            无
 return:            无
 *************************************************/
Cfg28181.prototype.Get28181Cfg = function () {
    var szURL = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/SIP";
    var that = this;
    $.ajax({
        type:"GET",
        url:szURL,
        timeout:15000,
        async:true,
        beforeSend:function (xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success:function (xmlDoc, textStatus, xhr) {
            that.m_xmlCfg281281 = xmlDoc;
            var xmlGB28181 = $(xmlDoc).find("GB28181").eq(0);

            $("#ch28181Enable").prop("checked", xmlGB28181.find("enabled").eq(0).text() == "true");

            $("#teLocalSIPPort").val($(xmlDoc).find("localPort").eq(0).text());
            $("#teSIPServerID").val(xmlGB28181.find("serverId").eq(0).text());
            $("#teSIPSeverDomain").val(xmlGB28181.find("serverDomain").eq(0).text());
            $("#teSIPServerAddr").val(xmlGB28181.find("registrar").eq(0).text());
            $("#teSIPServerPort").val(xmlGB28181.find("registrarPort").eq(0).text());
            $("#teSIPUserName").val(xmlGB28181.find("userName").eq(0).text());
            $("#teSIPAuthenticationID").val(xmlGB28181.find("authID").eq(0).text());

            oCheckPassword.checkUserName(xmlGB28181.find("userName").eq(0).text(), $('#teSIPAuthenticationPswd'), $('#teSIPAuthenticationPswdConfirm'));
            $("#teSIPAuthenticationPswd").val(oCheckPassword.m_szDefaultPassword);
            $("#teSIPAuthenticationPswdConfirm").val(oCheckPassword.m_szDefaultPassword);

            $("#teSIPExpiration").val(xmlGB28181.find("expires").eq(0).text());
            $("#teHeartBeatPeriod").val(xmlGB28181.find("heartbeatTime").eq(0).text());
            $("#teMaxHeartBeatTimeout").val(xmlGB28181.find("heartbeatCount").eq(0).text());
            $("#sel28181Stream").val($(xmlDoc).find("streamID").eq(0).text());

            that.Enable28181();
        }
    });
}

/*************************************************
 Function:        GetSIPInfo
 Description:    获取报警编码ID信息
 Input:            无
 Output:            无
 return:            无
 *************************************************/
Cfg28181.prototype.GetSIPInfo = function () {
    var szURL = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/SIP/1/SIPInfo";
    var that = this;

    $.ajax({
        type:"GET",
        url:szURL,
        timeout:15000,
        async:true,
        beforeSend:function (xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success:function (xmlDoc, textStatus, xhr) {
            that.m_xmlSIPInfo = xmlDoc;
            $("#teCameraID").val($(xmlDoc).find("videoID").eq(0).text());

            //插入报警编码ID
            $("#dvAlarmInList").html("");
            $(xmlDoc).find("AlarmIn").each(function() {
                $("<div><span class='SIPAlarmIDfirstspan'><label>"+ $(this).find("id").text() + "</label></span><span class='SIPAlarmIDsecondspan textOverLengthHide' title='"+ $(this).find("alarmInID").text() +"'><label>" + $(this).find("alarmInID").text() + "</label></span></div>").appendTo("#dvAlarmInList").bind({

                    mouseover: function() {
                        $(this).siblings(".select").each(function(){
                            $(this).removeClass("select");
                        });
                        $(this).addClass("select");
                    }
                });
            });

            //如果协议中没有报警ID，则隐藏整个DIV
            if("" == $("#dvAlarmInList").html()) {
                $("#dvAlarmInEncode").hide();
            } else {
                $("#dvAlarmInEncode").show();
            }

            $("#dvAlarmInList").find(".SIPAlarmIDsecondspan").each(function() {
                $(this).bind({
                    click: function() {
                        //没有勾选使能，就不弹出编辑框
                        if(!$("#ch28181Enable").prop("checked")) {
                            return;
                        }

                        //显示编辑框，并且定位位置
                        $("#dvSIPEditText").show();
                        $("#dvSIPEditText").css({"left":$(this).offset().left+"px", "top":$(this).offset().top+"px",width:$(this).width()+"px",height:$(this).height()+"px"});
                        $("#SIPAlarmInIDText").css({width:$(this).width()-4+"px",height:$(this).height()-4+"px","padding-left":"5px"});
                        $("#SIPAlarmInIDText").focus();
                        $("#SIPAlarmInIDText").val($(this).find("label").eq(0).text());

                        //显示所选择的一列的内容
                        var that = this;
                        $("#SIPAlarmInIDText").unbind().bind({
                            blur: function () {
                                $(that).find("label").text($("#SIPAlarmInIDText").val());
                                $(that).prop("title", $("#SIPAlarmInIDText").val());
                                $("#dvSIPEditText").hide();
                            }
                        });
                    }
                });
            });
            autoResizeIframe();
        }
    });
}

/*************************************************
 Function:        Enable28181
 Description:    使能28181配置
 Input:            无
 Output:            无
 return:            无
 *************************************************/
Cfg28181.prototype.Enable28181 = function () {
    $("#dv28181Cfg").find("input").prop("disabled", !$("#ch28181Enable").prop("checked"));
    $("#dv28181Cfg").find("select").prop("disabled", !$("#ch28181Enable").prop("checked"));

    $("#ch28181Enable").prop("disabled", false);
}

/*************************************************
 Function:        CheckParamInfo
 Description:    检测参数合法性
 Input:            无
 Output:            无
 return:            成功：true，失败：false
 *************************************************/
Cfg28181.prototype.CheckParamInfo = function () {
    var iMax = -1;
    var iMin = -1;

    //本地端口
    iMax = parseInt($(this.m_xmlCfg281281Capa).find("localPort").attr("max"), 10);
    iMin = parseInt($(this.m_xmlCfg281281Capa).find("localPort").attr("min"), 10);
    if(!CheackServerIDIntNum($("#teLocalSIPPort").val(), 'LocalSIPPortTips', 'laLocalSIPPort', isNaN(iMin)?1024:iMin, isNaN(iMax)?65535:iMax)) {
        return false;
    }

    if (!CheackStringLenthNull($("#teSIPServerID").val(), 'SIPServerIDTips', 'laSIPServerID', 64)) {
        return false;
    }

    if (!CheackStringLenthNull($("#teSIPSeverDomain").val(), 'SIPSeverDomainTips', 'laSIPSeverDomain', 128)) {
        return false;
    }

    //SIP的IP地址要求能够输入域名，所以不进行IP地址合法性检测
//    if (!CheckDIPadd($("#teSIPServerAddr").val(), 'SIPServerAddrTips', 'laSIPServerAddr')) {
//        return false;
//    }

    if (!CheackStringLenthNull($("#teSIPServerAddr").val(), 'SIPServerAddrTips', 'laSIPServerAddr', 128)) {
        return false;
    }

    //SIP服务器端口
    iMax = parseInt($(this.m_xmlCfg281281Capa).find("registrarPort").attr("max"), 10);
    iMin = parseInt($(this.m_xmlCfg281281Capa).find("registrarPort").attr("min"), 10);
    if(!CheackServerIDIntNum($("#teSIPServerPort").val(), 'SIPServerPortTips', 'laSIPServerPort', isNaN(iMin)?1024:iMin, isNaN(iMax)?65535:iMax)) {
        return false;
    }

    if (!CheackStringLenthNull($("#teSIPUserName").val(), 'SIPUserNameTips', 'laSIPUserName', 64)) {
        return false;
    }

    if (!CheackStringLenthNull($("#teSIPAuthenticationID").val(), 'SIPAuthenticationIDTips', 'laSIPAuthenticationID', 64)) {
        return false;
    }

    if (!CheackStringLenthNull($("#teSIPAuthenticationPswd").val(), 'SIPAuthenticationPswdTips', 'laSIPAuthenticationPswd', 32)) {
        return false;
    }

    if (!CheackStringLenthNull($("#teSIPAuthenticationPswdConfirm").val(), 'SIPAuthenticationPswdConfirmTips', 'laCheckPwd', 32)) {
        return false;
    }

    if ($("#teSIPAuthenticationPswd").val() != $("#teSIPAuthenticationPswdConfirm").val()) {
        showErrorTips("SIPAuthenticationPswdConfirmTips", getNodeValue('jsPwdCheckMismatch'));
        return false;
    }

    //注册有效期
    iMax = parseInt($(this.m_xmlCfg281281Capa).find("expires").attr("max"), 10);
    iMin = parseInt($(this.m_xmlCfg281281Capa).find("expires").attr("min"), 10);
    if (!CheackServerIDIntNum($('#teSIPExpiration').val(), 'SIPExpirationTips', 'laSIPExpiration', isNaN(iMin)?30:iMin, isNaN(iMax)?10000:iMax, getNodeValue("optionSecond"))) {
        return false;
    }

    //心跳周期
    iMax = parseInt($(this.m_xmlCfg281281Capa).find("heartbeatTime").attr("max"), 10);
    iMin = parseInt($(this.m_xmlCfg281281Capa).find("heartbeatTime").attr("min"), 10);
    if (!CheackServerIDIntNum($('#teHeartBeatPeriod').val(), 'HeartBeatPeriodTips', 'laHeartBeatPeriod', isNaN(iMin)?5:iMin, isNaN(iMax)?255:iMax, getNodeValue("optionSecond"))) {
        return false;
    }

    //心跳次数
    iMax = parseInt($(this.m_xmlCfg281281Capa).find("heartbeatCount").attr("max"), 10);
    iMin = parseInt($(this.m_xmlCfg281281Capa).find("heartbeatCount").attr("min"), 10);
    if (!CheackServerIDIntNum($('#teMaxHeartBeatTimeout').val(), 'MaxHeartBeatTimeoutTips', 'laMaxHeartBeatTimeout', isNaN(iMin)?3:iMin, isNaN(iMax)?255:iMax, "")) {
        return false;
    }

    if (!CheackStringLenthNull($("#teCameraID").val(), 'CameraIDTips', 'laCameraID', 64)) {
        return false;
    }

    return true;
}
/*************************************************
 Function:        SetCfg28181
 Description:    设置28181参数
 Input:            无
 Output:            无
 return:            无
 *************************************************/
Cfg28181.prototype.SetCfg28181 = function() {
    var szURL = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/SIP";
    var xmlGB28181 = $(this.m_xmlCfg281281).find("GB28181").eq(0);

    if($("#ch28181Enable").prop("checked")){
    	if(!this.CheckParamInfo()) {
	        return;
	    }
    }

    xmlGB28181.find("enabled").eq(0).text($("#ch28181Enable").prop("checked")?"true":"false");

    $(this.m_xmlCfg281281).find("localPort").eq(0).text($("#teLocalSIPPort").val());
    xmlGB28181.find("serverId").eq(0).text($("#teSIPServerID").val());
    xmlGB28181.find("serverDomain").eq(0).text($("#teSIPSeverDomain").val());
    xmlGB28181.find("registrar").eq(0).text($("#teSIPServerAddr").val());
    xmlGB28181.find("registrarPort").eq(0).text($("#teSIPServerPort").val());
    xmlGB28181.find("userName").eq(0).text($("#teSIPUserName").val());
    xmlGB28181.find("authID").eq(0).text($("#teSIPAuthenticationID").val());

    if ($('#teSIPAuthenticationPswd').val() != ""
    	 && $('#teSIPAuthenticationPswd').val() != oCheckPassword.m_szDefaultPassword) {
    	//验证28181的sip密码 begin
		var pwd = $('#teSIPAuthenticationPswd').val(); 
		try{ 
			var obj = x2js.xml_str2json(xmlToStr(this.m_xmlCfg281281)); 
			if(obj){ 
				var gbObj = obj['SIPServerList']['SIPServer']['GB28181']; 
				if (gbObj) { 
					gbObj.password = pwd; 

					this.m_xmlCfg281281 = x2js.json2xml(obj); 
				}; 
			} 
		}catch(e){ 
		} 
    }
    
	///end

    xmlGB28181.find("expires").eq(0).text( $("#teSIPExpiration").val());
    xmlGB28181.find("heartbeatTime").eq(0).text($("#teHeartBeatPeriod").val());
    xmlGB28181.find("heartbeatCount").eq(0).text($("#teMaxHeartBeatTimeout").val());
    $(this.m_xmlCfg281281).find("streamID").eq(0).text($("#sel28181Stream").val());

    var that = this;
    that.m_bNeedReboot = false; //保存参数前先把这个参数置为FALSE
    $.ajax({
        type:"PUT",
        url:szURL,
        timeout:15000,
        beforeSend:function (xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        processData:false,
        data:that.m_xmlCfg281281,
        complete:function (xhr, textStatus) {
            //SaveState(xhr);
        },
        success:function (xmlDoc, textStatus, xhr) {
            //成功后，先判断是否需要重启
            var state = $(xhr.responseXML).find('statusCode').eq(0).text();
            if(7 == state) {
                that.m_bNeedReboot = true;
            }
            that.SetSIPInfo();
        },
        error:function (xhr, textStatus, errorThrown) {
            SaveState(xhr);
        }
    });
}
/*************************************************
 Function:        SetSIPInfo
 Description:    保存报警编码ID参数
 Input:            无
 Output:            无
 return:            无
 *************************************************/
Cfg28181.prototype.SetSIPInfo = function () {
    var szURL = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/SIP/1/SIPInfo";
    var that = this;

    $(this.m_xmlSIPInfo).find("videoID").eq(0).text($("#teCameraID").val());
    $(this.m_xmlSIPInfo).find("alarmInID").each(function(index) {
        $(this).text($("#dvAlarmInList").find(".SIPAlarmIDsecondspan").eq(index).find("label").eq(0).text());
    });

    $.ajax({
        type:"PUT",
        url:szURL,
        timeout:15000,
        beforeSend:function (xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        processData:false,
        data:that.m_xmlSIPInfo,
        success:function (xmlDoc, textStatus, xhr) {
            //如果之前保存的参数需要重启，则提示重启
            if(that.m_bNeedReboot) {
                pr(Maintain).confirmAndRestart();
                $("#SetResultTips").html(m_szSuccessState + m_szSuccess5);
                g_iSaveResTimer = setTimeout(function () {
                    $("#SetResultTips").html("");
                }, 5000);
            } else {
                SaveState(xhr);
            }
        },
        error:function (xhr, textStatus, errorThrown) {
            SaveState(xhr);
        }
    });
}
function changeWindowTd(index){
    if($('#ItemElement'+index).val() == 'custom'){
		$('#customStr'+index).css('display','inline-block');
	} else {$('#customStr'+index).css('display','none');}
}