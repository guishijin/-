var BWLDict = {
	listType: {
		"0": "白名单",
		"1": "黑名单"
	},
	plateColor: {
		"0": "蓝",
        "1": "黄",
        "2": "白",
        "3": "黑",
        "4": "绿",
        "255": "其他"
	},
	plateType: {
		"0": "标准民用车与军车",
        "1": "02式民用车牌",
        "2": "武警车",
        "3": "警车",
        "4": "民用车双行尾牌",
        "5": "使馆车牌",
        "6": "农用车牌",
        "7": "摩托车车牌"
	}
}

function GetListType(str) {
	var ret = 1;
	_.each(BWLDict.listType, function (val, key) {
		if (val == str) {
			ret = key;
			return;
		};
	});
	return ret;
}

function GetPlateColor (str) {
	var ret = 255;
	_.each(BWLDict.plateColor, function (val, key) {
		if (str.indexOf(val) >= 0) {
			ret = key;
			return;
		};
	});
	return ret;
}

function GetPlateType (str) {
	var ret = 255;
	_.each(BWLDict.plateType, function (val, key) {
		if (str == val) {
			ret = key;
			return;
		};
	});
	return ret;
}

