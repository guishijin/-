var SnapParam = {
	tabs: null	// 保存System配置页面的tabs对象引用
};
/*************************************************
 黑白名单设置类
 *************************************************/
function BlackWhiteList() {
    this.g_iNowPage = 1;  //当前页面
    this.g_iHavePage = 0;  //有几页
    this.g_iBWLPerNum = 10;  //默认每次搜索数量10条
    this.g_iStartSearChNo = 0;   //默认搜索其实索引
    this.g_iTotalNum = 0;   //总条目数
    this.g_iSaveMode = -1;  // 0-添加 1-修改
    SingletonInheritor.implement(this);
}
SingletonInheritor.declare(BlackWhiteList);
pr(BlackWhiteList).update = function () {
    $('#SetResultTips').html('');
    $("#SaveConfigBtn").hide();
    HWP.Stop(0);
    g_transStack.clear();
    var that = this;
    that.setLxd(parent.translator.getLanguageXmlDoc(["SnapParam", "BlackWhiteList"]));
    parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
    parent.translator.translatePage(that.getLxd(), document);
    //清理下列表
    RefreshBWLTable();

    initTempPlugin("importPlugin", "importPluginActiveX");

    setTimeout(function () {
        ia(BlackWhiteList).SearchInfo(0);
    }, 500);
}


function buildVCL (para) {
    if (!para) {
        return null;
    };

    if (!$.isArray(para)) {
        para = [para];
    };

    var obj = {
        SetVCLData: {
            VCLDataList: {
                singleVCLData: []
            }
        }
    }

    var arr = [];

    var isTimeFault = false;

    for (var i = 0; i < para.length; i++) {
        var p = para[i];
        if(!p){
            continue;
        }

        var tp = {id: i};

        $.each(['runNum', 'listType',
         'plateNum', 'plateColor', 'plateType', 'cardNo', 
         'startTime', 'endTime'], function (idx, n) {
            if (typeof p[n] != "undefined" && p[n] != null) {
                tp[n] = p[n];     
            };
         });

        if (!tp.startTime) {
            tp.startTime = '0000-00-00T00:00:00Z';
        }
        if (!tp.endTime) {
            tp.endTime = '0000-00-00T00:00:00Z';
        };

        if (tp.endTime < tp.startTime) {
            isTimeFault = true;
        };

        arr.push(tp);
    };

    obj.SetVCLData.VCLDataList.singleVCLData = arr;

    return {
        xml: x2js.json2xml_str(obj, true),
        isTimeFault: isTimeFault
    }; 
}

/*************************************************
 Function:		SaveBWLInfo
 Description:	添加和修改后保存数据
 Output:			无
 return:			无
 *************************************************/
pr(BlackWhiteList).SaveBWLInfo = function() {
    if (this.timeTo) {
        clearTimeout(this.timeTo);
        this.timeTo = null;
    };
    if (0 == this.g_iSaveMode) {  //增加
        //检测车牌号和卡号
        if (!CheackStringLenthNull($("#editPlateNo").val(),"CheckResultTips","plateNoItem",16)) {
            return;
        }
    } else if (1 == this.g_iSaveMode) {  //修改

    } else {
        return;
    }
    //检测卡号
    if (!CheackStringLenth($("#editCardNo").val(), 'CheckResultTips', 'laCardNo',48)) {
        return;
    }



    var szStartTime = "0000-00-00T00:00:00Z";
    var szEndTime = "0000-00-00T00:00:00Z";
    if ($("#editCheckSet").prop('checked')) {
        szStartTime = checkDateValue($("#editSelStartTime").val(), 1);
        szEndTime = checkDateValue($("#editSelEndTime").val(), 1);

        if (szStartTime > szEndTime) {
            $('#CheckResultTips').text('开始时间不能晚于结束时间！');
            var self = this;
            this.timeTo = setTimeout(function(){
                $('#CheckResultTips').text('');
                self.timeTo = null;
            }, 3000);
            return;
        };
    }

    var x = buildVCL({
        runNum: 0,
        plateNum: $("#editPlateNo").val(),
        listType: $("#editSelListProp").val() ,
        plateColor: $("#editSelPlateColor").val(),
        plateType:  $("#editSelPlateType").val(),
        cardNo: $("#editCardNo").val(),
        startTime: szStartTime,
        endTime: szEndTime
    });

    if (x) {
        x = x.xml;
    };
    var xmlDoc = parseXmlFromStr(x);

    var bOk = false;
    var szTips = "";
    $.ajax({
        type: "PUT",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/Entrance/VCL",
        async: false,
        timeout: syncTime,
        processData: false,
        data: xmlDoc,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function() {
            bOk = true;
            szTips = m_szSuccess1;
        },
        error: function() {
            szTips = m_szError1;
        }
    });
    $.modal.impl.close();
    alert(szTips);
    if (bOk) {
        this.SearchInfo(2);
    }
}


/*************************************************
 Function:		GetPlateTypeByID
 Description:	将车牌类型索引转换成翻译
 Output:			无
 return:			车牌类型翻译
 *************************************************/
function getBWListTypeByID(iID) {
    var _index = parseInt(iID, 10);
    var szType = "";
    switch (_index) {
        case 0:
            szType = getNodeValue("laWhiteList");
            break;
        case 1:
            szType = getNodeValue("laBlackList");
            break;
    }
    return szType;
}
/*************************************************
 Function:		getPlateColorByID
 Description:	将车牌颜色索引转换成翻译
 Output:			无
 return:			车牌颜色翻译
 *************************************************/
function getPlateColorByID(iID) {
    var _index = parseInt(iID, 10);
    var szType = "";
    switch (_index) {
        case 0:
            szType = getNodeValue("jsblue");
            break;
        case 1:
            szType = getNodeValue("jsyellow");
            break;
        case 2:
            szType = getNodeValue("jswhite");
            break;
        case 3:
            szType = getNodeValue("jsblack");
            break;
        case 4:
            szType = getNodeValue("jsgreen");
            break;
        case 255:
            szType = getNodeValue("Other");
            break;
        default :
            szType = getNodeValue("Other");
            break;
    }
    return szType;
}

/*************************************************
 Function:		GetPlateTypeByID
 Description:	将车牌类型索引转换成翻译
 Output:			无
 return:			车牌类型翻译
 *************************************************/
function getPlateTypeByID(iID) {
    var _index = parseInt(iID, 10);
    var szType = "";
    switch (_index) {
        case 0:
            szType = getNodeValue("jsPlateType1");
        break;
        case 1:
            szType = getNodeValue("jsPlateType2");
        break;
        case 2:
            szType = getNodeValue("jsPlateType3");
        break;
        case 3:
            szType = getNodeValue("jsPlateType4");
        break;
        case 4:
            szType = getNodeValue("jsPlateType5");
        break;
        case 5:
            szType = getNodeValue("jsPlateType6");
        break;
        case 6:
            szType = getNodeValue("jsPlateType7");
        break;
        case 7:
            szType = getNodeValue("jsPlateType8");
        break;
        default :
        break;
    }
    return szType;
}

//检测是否需可以使用删除和编辑按钮
function checkBWLBtnState() {
    var iLen = document.getElementById("bwlistTable").rows.length;
    if (iLen > 1 && g_iSelectBWLIndex >= 0) {
        $("#ModifyBWLBtn").prop('disabled', false);
    } else {
        $("#ModifyBWLBtn").prop('disabled', true);
    }
}

//iMode: 0-从设备获取时转成本地显示  1-从本地获取转成设备所需 2-从列表取出来，放入弹出框中
function checkDateValue(szDateInfo, iMode) {
    var szDate = "";
    if (0 == iMode) {
        if ((szDateInfo != null ) && (typeof szDateInfo != "undefined") && (szDateInfo.length > 0)) {  //有效
            if ( "0000-00-00T00:00:00Z" != szDateInfo && "0" != szDateInfo ) {
                szDate = szDateInfo.replace('T', ' ').replace('Z','');
            }
        }
    } else if (1 == iMode) { //本地获取时若为空，则可以转换成为0或者0000-00-00T00:00:00Z
        if ((szDateInfo != null ) && (typeof szDateInfo != "undefined") && (szDateInfo.length > 0)) {  //有效
            szDate = szDateInfo + "Z";
        } else {
            szDate = "0000-00-00T00:00:00Z";
        }
    } else if (2 == iMode) {
        if ((szDateInfo != null ) && (typeof szDateInfo != "undefined") && (szDateInfo.length > 0)) {  //有效
            szDate = szDateInfo.replace(' ', 'T');
        } else {
            szDate = "";
        }
    }
    return szDate;
}

//检测是否选择了黑名单，黑名单需禁用启用有效时间的
function checkIsBlackList() {
   if (1 == parseInt($("#editSelListProp").val(), 10)) {  //黑名单
       $("#editCheckSet").prop('checked', false).prop('disabled', true);
   } else {
       $("#editCheckSet").prop('disabled', false);
   }
   EnabledStartTimeSet(); //检测下是否启用或者禁用时间选择
}

pr(BlackWhiteList).ShowImportBWLWnd = function() {
    $("#ImportBWLWnd").modal();

    this.bOpenFileBrowsing = false; // 解决Linux下Firefox的非模态

}

pr(BlackWhiteList).ImportTips = function (msg) {
    $('#ImportBWLWnd #ImportResultTips').html(msg);
}


pr(BlackWhiteList).BroswerFile = function () {
    this.ImportTips("");

    var ocx = $('#importPluginActiveX')[0];
    if (!ocx) {
        this.ImportTips(getNodeValue("tipsInstallPlugin"));
        return;
    };

    if (this.bOpenFileBrowsing) {
        return;
    }

    this.bOpenFileBrowsing = true;

    var that = this;
    var szPath = null;
    try {
        szPath = ocx.HWP_OpenFileBrowser(1, "");
    } catch (e) {}
    setTimeout(function() { 
        that.bOpenFileBrowsing = false; 
    }, 10); // 解决Linux下Chrome的click记忆
    

    if(szPath.length > 100)
    {
        this.ImportTips(getNodeValue('tipsTooLong'));
        return;
    }

    if (!szPath.match(/\.xls(x?)$/gi)) {
        this.ImportTips(getNodeValue('tipsNotExcelFile'));
        return;
    };

    $('#importFilePath').val(szPath);
}



pr(BlackWhiteList).DoImport = function () {
    var filePath = $('#importFilePath').val();
    if (!filePath) {
        return ;
    };

    var self = this;

    self.stopImport = false;

    this.ImportTips("");

    var ocx = $('#importPluginActiveX')[0];
    if (!ocx) {
        this.ImportTips(getNodeValue("tipsInstallPlugin"));
        return;
    };

    this.ImportTips("开始读取文件...");
    
    ocx.HWP_ImportSurveilData(filePath);

    var startPos = 0;
    var page = 100;

    
    var vclXml, vclJson, vclList;

    getVCLFromOcx(startPos, page);

    function getVCLFromOcx () {
        if (self.stopImport) {
            return;
        };
        vclXml = ocx.HWP_GetSurveilData(startPos, page);
        vclJson = x2js.xml_str2json(vclXml);

        vclList = vclJson.Root.DataList.Data_asArray;
        if(vclList && vclList.length && vclList.length <= page){ 
            $.when(sendVCL(vclList)).done(function (result) {
                startPos += vclList.length;

                self.ImportTips("已完成"+startPos+"条");
                getVCLFromOcx(startPos, page);

                // if (vclList.length < page) {  // 最后一页
                //     self.ImportTips("已经完成导入，共"+startPos+"条");
                // }else{
                //     self.ImportTips("已完成"+startPos+"条");
                //     getVCLFromOcx(startPos, page);
                // }    
            }).fail(function (result) {
                if (!result) {
                    result = "导入时出现问题，已终止";
                };
                self.ImportTips(m_szErrorState+result);

                setTimeout(function () {
                    ia(BlackWhiteList).SearchInfo(0);
                }, 500);
            });
        }else{  // 已经没有数据了
            self.ImportTips(m_szSuccessState+"已经完成，共"+startPos+"条");
            setTimeout(function () {
                ia(BlackWhiteList).SearchInfo(0);
            }, 500);
        }
    }

    function sendVCL (dataList) {
        var dtd = $.Deferred(); 

        if (dataList.length) {
            _log("dataList.length="+dataList.length+",first PlateNo："+dataList[0].plateNum);    
        }else{
            _log("dataList.length=0"+dataList.length);
        }
        

        for (var i = 0; i < dataList.length; i++) {
            var d = dataList[i];
            d.id = i;
            d.runNum = 0;

            d.listType = GetListType(d.listType);
            d.plateColor = GetPlateColor(d.plateColor);
            d.plateType = GetPlateType(d.plateType);

        };

        var xml = buildVCL(dataList);
        
        if (xml && xml.isTimeFault) {
            dtd.reject("结束时间不能早于开始时间。");
            return dtd.promise();;
        };

        if (xml) {
            xml = xml.xml;
        };



        $.ajax({
            type: "PUT",
            url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/Entrance/VCL",
            timeout: syncTime,
            processData: false,
            data: xml,
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            success: function() {
                dtd.resolve();
            },
            error: function() {
                dtd.reject();
            }
        });

        return dtd.promise(); 
    }
}



pr(BlackWhiteList).CancelImport = function () {
    this.stopImport = true;
    $.modal.impl.close();
}

//显示修改或者添加窗口
pr(BlackWhiteList).ShowBWLWnd = function(iType) {
    var szTips = ""
    var iIndex = 1;
    $("#BWLOperationWnd").modal();

    if (0 == iType) {  //添加
        szTips = getNodeValue("AddDigitalIpBtn");
    } else if (1 == iType) {  //修改
        szTips = getNodeValue("laEdit");
        iIndex = ($("#bwlistTable").find('tr').eq(g_iSelectBWLIndex+1).find('td').eq(0).html()); //获取索引
        $("#editPlateNo").val($("#BWLtdB" + iIndex).prop('name')).prop('disabled',true); //车牌号
        $("#editSelListProp").val($("#BWLtdC" + iIndex).prop('name')); //名单属性
        $("#editSelPlateType").val($("#BWLtdD" + iIndex).prop('name')); //车牌类型
        $("#editSelPlateColor").val($("#BWLtdE" + iIndex).prop('name')).prop('disabled',true); //车牌颜色
        $("#editCardNo").val($("#BWLtdF" + iIndex).prop('name'));  //卡号
        var szStartTime = $("#BWLtdG" + iIndex).html();  //开始时间
        var szEndTime = $("#BWLtdH" + iIndex).html();  //结束时间
        if ((szStartTime != null ) && (typeof szStartTime != "undefined") && (szStartTime.length > 0) ) {
            $("#editCheckSet").prop('checked', true); //是否开启时间设置
            $("#editSelStartTime").val(checkDateValue(szStartTime, 2));
            $("#editSelEndTime").val(checkDateValue(szEndTime, 2));
        }
    } else {
        return;
    }
    this.g_iSaveMode = iType;  //记录操作类型
    $("#spnEditTitle").html(szTips);  //设置提示
    checkIsBlackList();
}

/*************************************************
 Function:		RefreshBWLTable
 Description:	清理下table
 Input:             无
 Output:			无
 return:			无
 *************************************************/
function RefreshBWLTable() {
    var RowNum = document.getElementById("bwlistTable").rows.length;
    for(var i = 1; i < RowNum; i++) {
        document.getElementById("bwlistTable").deleteRow(1);
    }
    //底部翻页
    document.getElementById("bwlListpage").innerHTML = getNodeValue('TotalTips') + "0" +  getNodeValue('TiaoTips') + "&nbsp;&nbsp;<span class='bottompagespan'>" +
        getNodeValue('jsFirstPageTips') + "</span>&nbsp;&nbsp;<span class='bottompagespan'>" + getNodeValue('jsPrevPageTips') +
        "</span>&nbsp;"+ "0/0" +"&nbsp;<span class='bottompagespan'>" + getNodeValue('jsNextPageTips') +
        "</span>&nbsp;&nbsp;<span class='bottompagespan'>" + getNodeValue('jsLastPageTips') + "</span>&nbsp;&nbsp;";
    //修改按钮重置
    checkBWLBtnState();
}
/*************************************************
 Function:		SearchInfo
 Description:	搜索符合条件的黑白名单
 Input:   iType:0-搜索按钮   1-翻页搜索  2-添加，删除，修改
 Output:			无
 return:			无
 *************************************************/
pr(BlackWhiteList).SearchInfo = function(iType) {
    //禁用修改按钮
    $("#ModifyBWLBtn").prop("disabled", true);
    //搜索前先清理
    RefreshBWLTable();
    //显示加载等待界面
    if (2 == iType || 0 == iType) { //修改后，或者搜索按钮，都从第一条搜起
        this.g_iStartSearChNo = 0;
    }

    //检测有效性
    if (!CheackStringLenth($("#inPlateNo").val(),"CheckResultTips","plateNoItem", parseInt($("#inPlateNo").attr('maxLength'),10))) {
        $("#inPlateNo").val("");
        return;
    }

    if (!CheackStringLenth($("#inCardNo").val(), '', '', parseInt($("#inCardNo").attr('maxLength'),10))) {
        $("#inCardNo").val("");
        return;
    }

    var szDoc = "<VCLGetCond><getVCLNum>"+this.g_iBWLPerNum +"</getVCLNum><startOffSet>"+ this.g_iStartSearChNo +"</startOffSet>";
    szDoc += "<getVCLCond>"+ $("#selOptType").val() +"</getVCLCond><listType>"+$("#selListProp").val()+"</listType>";
    szDoc += "<plateNum>"+$("#inPlateNo").val()+"</plateNum><cardNo>"+$("#inCardNo").val()+"</cardNo></VCLGetCond>";
    var xmlDoc = parseXmlFromStr(szDoc);
    var that = this;
    $.ajax({
        type: "POST",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/Entrance/VCL",
        async: false,
        timeout: syncTime,
        processData: false,
        data: xmlDoc,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        error: function(xmlDoc, textStatus, xhr) {
            alert(getNodeValue("jsSearchError"));
        },
        success: function(xmlDoc, textStatus, xhr) {
            var iLen = $(xmlDoc).find("singleVCLData").length;
            var vclList = $(xmlDoc).find("singleVCLData");
            that.g_iTotalNum = parseInt($(xmlDoc).find("totalNum").eq(0).text(), 10);
            var iIndex = 0;  //序号
            var szPlateNum = "";  //车牌号
            var szListType = ""; //黑白名单类型
            var szPlateType = "";  //车牌类型
            var szPlateColor = ""; //车牌颜色
            var szCardNo = "";  //卡号
            var szStartTime = ""; //有效开始时间
            var szEndTime = "";  //有效结束时间
            for(var i = 0; i < iLen; i++) {
                iIndex = i + 1 + that.g_iStartSearChNo;
                szPlateNum = vclList.find('plateNum').eq(i).text();
                szListType = vclList.find('listType').eq(i).text();
                szPlateType = vclList.find('plateType').eq(i).text();
                szPlateColor = vclList.find('plateColor').eq(i).text();
                szCardNo = vclList.find('cardNo').eq(i).text();
                szStartTime = checkDateValue(vclList.find('startTime').eq(i).text(), 0);
                szEndTime = checkDateValue(vclList.find('endTime').eq(i).text(), 0);

                InsertBWList(iIndex, szPlateNum, szListType, szPlateType,szPlateColor, szCardNo,szStartTime, szEndTime);
            }
            if (iLen > 0) {  //有数据
                if (that.g_iTotalNum >= 0 ) {
                    if( (that.g_iTotalNum % that.g_iBWLPerNum) == 0 ) {
                        that.g_iHavePage = parseInt(that.g_iTotalNum/that.g_iBWLPerNum);
                    }  else {
                        that.g_iHavePage = parseInt(that.g_iTotalNum/that.g_iBWLPerNum)+1;
                    }
                    that.g_iNowPage = parseInt(that.g_iStartSearChNo/that.g_iBWLPerNum,10) + 1;
                    //底部翻页
                    document.getElementById("bwlListpage").innerHTML = getNodeValue('TotalTips') + that.g_iTotalNum +  getNodeValue('TiaoTips') +
                        "&nbsp;&nbsp;<span class='bottompagespan' onclick='ia(BlackWhiteList).FirstPage();'>" + getNodeValue('jsFirstPageTips') +
                        "</span>&nbsp;&nbsp;<span class='bottompagespan' onclick='ia(BlackWhiteList).LastPage();'>" + getNodeValue('jsPrevPageTips') +
                        "</span>&nbsp;"+ that.g_iNowPage +"/"+ that.g_iHavePage  +"&nbsp;<span class='bottompagespan' onclick='ia(BlackWhiteList).NextPage();'>" + getNodeValue('jsNextPageTips') +
                        "</span>&nbsp;&nbsp;<span class='bottompagespan' onclick='ia(BlackWhiteList).AfterPage();'>" + getNodeValue('jsLastPageTips') + "</span>&nbsp;&nbsp;";
                } else {
                    //底部翻页
                    document.getElementById("bwlListpage").innerHTML = getNodeValue('TotalTips') + "0" +  getNodeValue('TiaoTips') + "&nbsp;&nbsp;<span class='bottompagespan'>" +
                        getNodeValue('jsFirstPageTips') + "</span>&nbsp;&nbsp;<span class='bottompagespan'>" + getNodeValue('jsPrevPageTips') +
                        "</span>&nbsp;"+ "0/0" +"&nbsp;<span class='bottompagespan'>" + getNodeValue('jsNextPageTips') +
                        "</span>&nbsp;&nbsp;<span class='bottompagespan'>" + getNodeValue('jsLastPageTips') + "</span>&nbsp;&nbsp;";
                }
            }
            //autoResizeIframe();
            if (0 == iType) {
                //alert(getNodeValue("jsSearchFinish"));
            }
        }
    });
}

pr(BlackWhiteList).AfterPage = function() {
    if(this.g_iNowPage == this.g_iHavePage) {
        return ;
    }
    this.g_iStartSearChNo = parseInt(this.g_iBWLPerNum * (this.g_iHavePage-1) ,10);
    this.SearchInfo(1);
}
/*************************************************
 Function:		FirstPage
 Description:	进入第一页
 Output:			无
 return:			无
 *************************************************/
pr(BlackWhiteList).FirstPage = function() {
    if(this.g_iNowPage == 1) {
        return ;
    }
    //改变索引值,
    this.g_iStartSearChNo = 0;
    this.SearchInfo(1);
}

//上一页
pr(BlackWhiteList).LastPage = function() {
    if(this.g_iNowPage == 1) {
        return ;
    }
    this.g_iStartSearChNo = parseInt((this.g_iNowPage-2)*10,10);
    this.SearchInfo(1);
}

//下一页
pr(BlackWhiteList).NextPage = function() {
    if(this.g_iNowPage == this.g_iHavePage) {
        return;
    }
    this.g_iStartSearChNo = parseInt(this.g_iNowPage*10,10);
    this.SearchInfo(1);
}

/*************************************************
 Function:		DelInfo
 Description:	删除信息
 Output:			无
 return:			无
 *************************************************/
pr(BlackWhiteList).DelInfo = function() {

    if (!confirm(getNodeValue("confirmDelBWL"))) {
        return;
    };

    //禁用修改按钮
    $("#ModifyBWLBtn").prop("disabled", true);
    //搜索前先清理
    var RowNum = document.getElementById("bwlistTable").rows.length - 1;
    if (RowNum <= 0) {
        return;
    }

    var iDelType = parseInt($("#selDelType").val(), 10);
    var szInput = $("#txtDelInput").val();
    var iPlateColor = parseInt($("#selDelColor").val(), 10);
    var iPlateType = parseInt($("#selDelPlateType").val(), 10);
    var szDoc = "";
    if (0 == iDelType) {  //删除全部
        szDoc = "<VCLDelCond><delVCLCond>"+iDelType+"</delVCLCond></VCLDelCond>";
    } else if (5 == iDelType) { //根据车牌号和车牌颜色
        szInput = $("#dvCardAndColor input").eq(0).val();
        iPlateColor = $("#dvCardAndColor select").eq(0).val();
        szDoc = "<VCLDelCond><delVCLCond>"+iDelType+"</delVCLCond>";
        szDoc += "<plateNum>"+ szInput +"</plateNum><plateColor>"+iPlateColor+"</plateColor></VCLDelCond>";
    } else {
        szDoc = "<VCLDelCond><delVCLCond>"+iDelType+"</delVCLCond>";
        szDoc += "<plateNum>"+ szInput +"</plateNum><plateColor>"+iPlateColor+"</plateColor>";
        szDoc += "<plateType>"+ iPlateType +"</plateType><cardNo>"+szInput+"</cardNo></VCLDelCond>";
    }

    var xmlDoc = parseXmlFromStr(szDoc);
    var that = this;
    $.ajax({
        type: "DELETE",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/Entrance/VCL",
        async: false,
        timeout: syncTime,
        processData: false,
        data: xmlDoc,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function() {
//            alert(getNodeValue("jsDelOK"));
            that.SearchInfo(2);
        },
        error: function() {
            alert(getNodeValue("jsDelError"));
        }
    });

}
/*************************************************
 Function:		EnabledStartTimeSet
 Description:	启用开始时间设置
 Output:			无
 return:			无
 *************************************************/
function EnabledStartTimeSet() {
    var bUse = true;
    if ( $("#editCheckSet").prop('checked') ) {
        bUse = false;
    }
    $("#editSelStartTime").prop('disabled', bUse);
    $("#editSelEndTime").prop('disabled', bUse);
}

/*************************************************
 Function:		checkBWLFactor
 Description:	更具检索条件替换所需要输入或者下拉条件
 Output:			无
 return:			无
 *************************************************/
function checkBWLFactor() {
    var iType = $("#selOptType").val();
    $("#inPlateNo").val("");
    $("#inCardNo").val("");
    $("#selListProp").val(0);
    if (1 == iType) { //车牌号
        $("#inPlateNo").prop('disabled', false);
        $("#inPlateNo").show();
        $("#inCardNo").hide();
        $("#selListProp").hide();
    } else if (2 == iType) { //卡号
        $("#inPlateNo").hide();
        $("#inCardNo").show();
        $("#selListProp").hide();
    } else if (3 == iType) { //名单属性
        $("#inPlateNo").hide();
        $("#inCardNo").hide();
        $("#selListProp").show();

    } else { //全部，隐藏车牌和名单，警用车牌输入
        $("#inPlateNo").prop('disabled', true);
        $("#inPlateNo").show();
        $("#inCardNo").hide();
        $("#selListProp").hide();
    }
}

/*************************************************
 Function:		checkBWLDelFactor
 Description:	根据条件显示删除输入框或下拉框
 Output:			无
 return:			无
 *************************************************/
function checkBWLDelFactor() {
    var iType = $("#selDelType").val();
    $(".dvKeyWord").hide();
    $("#dvCardAndColor").hide();
    $("#txtDelInput").val('');
    if (0 == iType) { //全部删除 --显示关键字框，清空且禁用
        $(".dvKeyWord").show();
        $("#selDelColor").hide();
        $("#selDelPlateType").hide();
        $("#txtDelInput").show().prop('disabled', true);
    } else if (1 == iType) { //车牌号码
        $(".dvKeyWord").show();
        $("#txtDelInput").prop('maxLength', 16);
        $("#selDelColor").hide();
        $("#selDelPlateType").hide();
        $("#txtDelInput").show().prop('disabled', false);
    }
    else if (2 == iType) {  //卡号
        $(".dvKeyWord").show();
        $("#txtDelInput").prop('maxLength', 48);
        $("#selDelColor").hide();
        $("#selDelPlateType").hide();
        $("#txtDelInput").show().prop('disabled', false);
    }
    else if (3 == iType) { //车牌颜色
        $(".dvKeyWord").show();
        $("#selDelColor").show().val(0);
        $("#selDelPlateType").hide();
        $("#txtDelInput").hide();
    } else if (4 == iType) { //车牌类型
        $(".dvKeyWord").show();
        $("#selDelColor").hide();
        $("#selDelPlateType").show().val(0);
        $("#txtDelInput").hide();
    } else if (5 == iType) {
        $("#dvCardAndColor").show();
        $("#dvCardAndColor input").val('');
        $("#dvCardAndColor select").val(0);
    }
}

/*************************************************
 Function:		SelectBWLTd
 Description:	选中某行黑白名单
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function SelectBWLTd(event) {
    event = event?event:(window.event?window.event:null);
    var ObjTable = event.srcElement?event.srcElement:event.target;
    if(ObjTable.tagName == "TD") {
        while(ObjTable.tagName != "TR") {
            ObjTable = ObjTable.parentNode;
        }
    }
    var m_iSelIndex = ObjTable.rowIndex - 1;
    g_iSelectBWLIndex = m_iSelIndex;  //记录索引
    if(m_iSelIndex == -1) {
        return;
    }
    if(null != g_iSeledBWLTrObj) {
        if((g_iSeledBWLTrObj.rowIndex % 2) != 0) {
            g_iSeledBWLTrObj.style.backgroundColor = "#f6f6f6";
        } else {
            g_iSeledBWLTrObj.style.backgroundColor = "#ebebeb";//ObjTable.bgColor="#f5f5f5" ;
        }
        g_iSeledBWLTrObj.style.color = "#39414A";
    }
    ObjTable.style.backgroundColor = '#762727';
    ObjTable.style.color = '#ffffff';
    g_iSeledBWLTrObj = ObjTable;

    checkBWLBtnState();  //重置下按钮状态
}

/*************************************************
 Function:		InsertBWList
 Description:	插入黑白名单信息到List中
 Input:			iNo：序号
 plateNo : 车牌号码
 ListProp : 名单类型
 PlateType : 车牌类型
 plateColorItem : 车牌颜色
 CardNo ： 卡号
 StartTime ： 有效开始时间
 EndTime : 有效结束时间
 Output:			无
 return:			无
 *************************************************/
function InsertBWList(iNo,plateNo,ListProp,PlateType,plateColorItem,CardNo,StartTime,EndTime) {
    var ObjTr;
    var ObjTd;
    ObjTr = document.getElementById("bwlistTable").insertRow(document.getElementById("bwlistTable").rows.length);
    ObjTr.style.height = '29px';
    ObjTr.style.cursor = "pointer";
    ObjTr.align = "center";
    ObjTr.onmouseover=LogHighLight;
    ObjTr.onmouseout=LogRecoveryLight;
    if((iNo%2) != 0) {
        ObjTr.bgColor="#f6f6f6" ;
    } else {
        ObjTr.bgColor="#ebebeb" ;
    }
    ObjTr.style.color = "#39414A";
    for(j = 0;j < document.getElementById("bwlistTable").rows[0].cells.length;j++) {
        ObjTd = ObjTr.insertCell(j);
        switch(j)
        {
            case 0:
                //ObjTd.innerHTML = getDivForOverLen(38, iNo);
                ObjTd.innerHTML = iNo;
                ObjTd.id = "BWLtdA"+ iNo;
                ObjTd.align = "center";
                ObjTd.style.width = "38px";
                break;
            case 1:
                ObjTd.innerHTML = getDivForOverLen(78, plateNo);
                ObjTd.id = "BWLtdB"+ iNo;
                ObjTd.name = plateNo;
                ObjTd.title = plateNo;
                ObjTd.align = "center";
                //ObjTd.style.width = "97px";
                break;
            case 2:
                ObjTd.innerHTML = getBWListTypeByID(ListProp);
                ObjTd.id = "BWLtdC"+ iNo
                ObjTd.name = ListProp;
                ObjTd.align = "center";
                ObjTd.style.width = "70px";
                break;
            case 3:
                ObjTd.innerHTML = getPlateTypeByID(PlateType);
                ObjTd.id = "BWLtdD"+ iNo;
                ObjTd.name = PlateType;  //利用name后续用于获取正真的值
                ObjTd.align = "center";
                ObjTd.style.width = "103px";
                break;
            case 4:
                ObjTd.innerHTML = getPlateColorByID(plateColorItem);
                ObjTd.id = "BWLtdE"+ iNo;
                ObjTd.name = plateColorItem;
                ObjTd.align = "center";
                ObjTd.style.width = "104px";
                break;
            case 5:
                ObjTd.innerHTML = getDivForOverLen(90, CardNo);
                ObjTd.id = "BWLtdF"+ iNo;
                ObjTd.name = CardNo;
                ObjTd.title = CardNo;
                ObjTd.align = "center";
                //ObjTd.style.width = "";
                break;
            case 6:
                ObjTd.innerHTML = StartTime;
                ObjTd.id = "BWLtdG"+ iNo;
                ObjTd.style.width = "113px";
                break;
            case 7:
                ObjTd.innerHTML = EndTime;
                ObjTd.id = "BWLtdH"+ iNo;
                ObjTd.style.width = "113px";
                break;
            default:
                break;
        }
    }
}

//防止td中过长，直接用DIV替换
function getDivForOverLen(iWidth, szTips) {
    var szDiv = "<div class='hideoverlen' style='width:"+ parseInt(iWidth,10) +"px'>"+ szTips +"</div>";
    return szDiv;
}

/*************************************************
 Function:		LogHighLight
 Description:	日志行高亮
 Input:			无
 Output:			无
 return:			无
 *************************************************/
var g_strFormerBgColor; //记录原来背景颜色
var g_iSeledBWLTrObj = null; //记录之前选中的行对象
var g_iSelectBWLIndex = -1; //当前所选行索引
function LogHighLight() {
    var obj = this;
    if(g_iSeledBWLTrObj == obj || obj.tagName != "TR")
    {
        return;
    }
    g_strFormerBgColor = obj.style.backgroundColor;
    obj.style.backgroundColor = "#fbfbc2";
}

/*************************************************
 Function:		LogRecoveryLight
 Description:	日志行恢复背景色
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function LogRecoveryLight() {
    var obj = this;
    if(g_iSeledBWLTrObj == obj || obj.tagName != "TR")
    {
        return;
    }
    obj.style.backgroundColor = g_strFormerBgColor;
}

/*************************************************
抓图设置类
*************************************************/
function SnapSetting() {
	this.m_iPlateBright = 0;
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(SnapSetting);
/*************************************************
 Function:		update
 Description:	更新抓图配置信息
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(SnapSetting).update = function () {
	$('#SetResultTips').html('');
	$("#SaveConfigBtn").show();
	HWP.Stop(0);
	g_transStack.clear();
	var that = this;
	g_transStack.push(function () {
		that.setLxd(parent.translator.getLanguageXmlDoc(["SnapParam", "SnapSetting"]));
		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	}, true);
	$.ajax({
		type: "GET",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1",
		async: false,
		timeout: syncTime,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) {
			$("#inputSnapGain").val($(xmlDoc).find("snapGainLevel").eq(0).text());
			$("#inputSnapSpeed").val($(xmlDoc).find("snapShutterLevel").eq(0).text());
			$("#IsUsePlateBright").prop("checked", $(xmlDoc).find("plateBrightEnabled").eq(0).text() === "true" ? true : false);
			$("#inputPlateExpectedBright").val($(xmlDoc).find("plateExpectedBright").eq(0).text());
			$("#IsUseCorrectFactor").prop("checked", $(xmlDoc).find("correctFactorEnabled").eq(0).text() === "true" ? true : false);
			$("#inputCorrectFactor").val($(xmlDoc).find("correctFactor").eq(0).text());
		}
    });
	autoResizeIframe();
}

//PlateParam
/*************************************************
 牌识参数类
 *************************************************/
function PlateParam() {
    SingletonInheritor.implement(this);
    this.sz_plateParamXmlInfo = null;
}
SingletonInheritor.declare(PlateParam);

/*************************************************
 Function:		update
 Description:	更新I/O输出配置信息
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(PlateParam).update = function () {

    $('#SetResultTips').html('');
    $("#SaveConfigBtn").show();

    g_transStack.clear();
    var that = this;
    g_transStack.push(function(){
        that.setLxd(parent.translator.getLanguageXmlDoc(["SnapParam", "PlateParam"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);

    $.ajax({
        type: "GET",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/PlateRecognitionParam",
        timeout: syncTime,
        async: false,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {
			ia(PlateParam).sz_plateParamXmlInfo = xmlDoc;
            $("#defaultCHN").val($(xmlDoc).find("defaultCHN").eq(0).text());
            

            var $xmlDoc = $(xmlDoc);

            $.each(['farmVehicleEnabled','fuzzyDiscEnabled', 
                'microPlateRegEnabled', 'motorEnabled'], function (i, n) {
                   $.g.setField2('#'+n, $xmlDoc.find(n).eq(0).text(), true); 
                });

   //          $("#colorEnabled").prop("checked", $(xmlDoc).find("colorEnabled").eq(0).text() === "true" ? true : false);
   //          $("#farmVehicleEnabled").prop("checked", $(xmlDoc).find("farmVehicleEnabled").eq(0).text() === "true" ? true : false);
   //          $("#fuzzyDiscEnabled").prop("checked", $(xmlDoc).find("fuzzyDiscEnabled").eq(0).text() === "true" ? true : false);
   //          $("#carLogoEnabled").prop("checked", $(xmlDoc).find("carLogoEnabled").eq(0).text() === "true" ? true : false);
   //          $("#microPlateRegEnabled").prop("checked", $(xmlDoc).find("microPlateRegEnabled").eq(0).text() === "true" ? true : false);
			// $("#motorEnabled").prop("checked", $(xmlDoc).find("motorEnabled").eq(0).text() === "true" ? true : false);

            if($(xmlDoc).find("frontPlateRecoEnabled").eq(0).text() === "true") {
                $(document.getElementsByName("PlateRecoDirection")).eq(0).prop("checked", true);
                $(document.getElementsByName("PlateRecoDirection")).eq(1).prop("checked", false);
            }else{
                $(document.getElementsByName("PlateRecoDirection")).eq(0).prop("checked", false);
                $(document.getElementsByName("PlateRecoDirection")).eq(1).prop("checked", true);
            }
            if($(xmlDoc).find("smallPlateRecoEnabled").eq(0).text() === "true") {
                $(document.getElementsByName("PlateRecoType")).eq(0).prop("checked", true);
                $(document.getElementsByName("PlateRecoType")).eq(1).prop("checked", false);
                ia(PlateParam).changePlateRecoType(0);
            }else{
                $(document.getElementsByName("PlateRecoType")).eq(0).prop("checked", false);
                $(document.getElementsByName("PlateRecoType")).eq(1).prop("checked", true);
                ia(PlateParam).changePlateRecoType(1);
            }
        }
    });
    autoResizeIframe();
}
/*************************************************
 ITC出入口配置类
 *************************************************/
function ITCInletOutletPort() {
    SingletonInheritor.implement(this);
    this.sz_ITCInletOutletPortXmlInfo = null;
	this.sz_frontVehInfoManagStr="";
	this.sz_frontRelayStr="";
    this.sz_frontIOAlarmStr="";
	this.szTipsInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
}
SingletonInheritor.declare(ITCInletOutletPort);

/*************************************************
 Function:		update
 Description:	ITC出入口配置类
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(ITCInletOutletPort).update = function () {

    $('#SetResultTips').html('');
    $("#SaveConfigBtn").hide();

    g_transStack.clear();
    var that = this;
    g_transStack.push(function(){
        that.setLxd(parent.translator.getLanguageXmlDoc(["SnapParam", "ITCInletOutletPort"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);
	
	 ia(ITCInletOutletPort).sz_frontVehInfoManagStr="0";
	 ia(ITCInletOutletPort).sz_frontRelayStr="1";
	 ia(ITCInletOutletPort).sz_frontIOAlarmStr="1";
	 $.ajax({
        type: "GET",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/Entrance/entranceParam",
        timeout: syncTime,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {
            ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo = xmlDoc;
		
            $("#laneNum").val($(xmlDoc).find("laneNum").eq(0).text());
            
			$("#relateTriggerMode").val($(xmlDoc).find("relateTriggerMode").eq(0).text());
			$("#plateNumColorEnable").prop("checked", $(xmlDoc).find("plateNumColorEnable").eq(0).text() == "true" ? true : false);
            $("#plateNumOnlyEnable").prop("checked", $(xmlDoc).find("plateNumOnlyEnable").eq(0).text() == "true" ? true : false);
			
			$("#vehInfoManagNum").val($(xmlDoc).find("vehInfoManagNum").eq(0).text());
			$("#barrierGateOper").val($(xmlDoc).find("barrierGateOper").eq(0).text());
            $("#relayOutAlarmEnable").prop("checked", $(xmlDoc).find("relayOutAlarmEnable").eq(0).text() == "true" ? true : false);
            $("#upAlarmEnable").prop("checked", $(xmlDoc).find("upAlarmEnable").eq(0).text() == "true" ? true : false);
			$("#hostUpAlarmEnable").prop("checked", $(xmlDoc).find("hostUpAlarmEnable").eq(0).text() == "true" ? true : false);
			
            $("#relayNum").val($(xmlDoc).find("relayNum").eq(0).text());
			$("#relayFunction").val($(xmlDoc).find("relayFunction").eq(0).text());
			
			$("#IOAlarmNum").val($(xmlDoc).find("IOAlarmNum").eq(0).text());
			$("#IOAlarmType").val($(xmlDoc).find("IOAlarmType").eq(0).text());

            $("#bEnable").prop("checked", $(xmlDoc).find("bEnable").eq(0).text() == "true" ? true : false);
			
            $.g.setField2('#ctrlMode', $(xmlDoc).find('ctrlMode').eq(0).text());

            setTimeout(function  () {
                ia(ITCInletOutletPort).changebEnable();    
            }, 500);
	   
            autoResizeIframe();		
        }
    });
	 
    
}
/*************************************************
 Function:		submit
 Description:	保存ITC出入口信息
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(ITCInletOutletPort).submit = function(){
    var xmlDoc = ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo;

    $(xmlDoc).find("laneNum").eq(0).text($("#laneNum").val());
    $(xmlDoc).find("bEnable").eq(0).text($("#bEnable").prop("checked").toString());
    $(xmlDoc).find("ctrlMode").eq(0).text($('#ctrlMode').val());
    
	$(xmlDoc).find("relateTriggerMode").eq(0).text($("#relateTriggerMode").val());
    $(xmlDoc).find("plateNumOnlyEnable").eq(0).text($("#plateNumOnlyEnable").prop("checked").toString());
    $(xmlDoc).find("plateNumColorEnable").eq(0).text($("#plateNumColorEnable").prop("checked").toString());
	if($("#vehInfoManagNum").val()=="0"){
		$(xmlDoc).find("vehInfoManagNum").eq(0).text($("#vehInfoManagNum").val())
		$(xmlDoc).find("barrierGateOper").eq(0).text($("#barrierGateOper").val());
        $(xmlDoc).find("relayOutAlarmEnable").eq(0).text($("#relayOutAlarmEnable").prop("checked").toString());
        $(xmlDoc).find("upAlarmEnable").eq(0).text($("#upAlarmEnable").prop("checked").toString());
	    $(xmlDoc).find("hostUpAlarmEnable").eq(0).text($("#hostUpAlarmEnable").prop("checked").toString());
	}
	else if($("#vehInfoManagNum").val()=="1"){
		$(xmlDoc).find("vehInfoManagNum").eq(1).text($("#vehInfoManagNum").val())
		$(xmlDoc).find("barrierGateOper").eq(1).text($("#barrierGateOper").val());
        $(xmlDoc).find("relayOutAlarmEnable").eq(1).text($("#relayOutAlarmEnable").prop("checked").toString());
        $(xmlDoc).find("upAlarmEnable").eq(1).text($("#upAlarmEnable").prop("checked").toString());
	    $(xmlDoc).find("hostUpAlarmEnable").eq(1).text($("#hostUpAlarmEnable").prop("checked").toString());
	}
	else{
		$(xmlDoc).find("vehInfoManagNum").eq(2).text($("#vehInfoManagNum").val())
		$(xmlDoc).find("barrierGateOper").eq(2).text($("#barrierGateOper").val());
        $(xmlDoc).find("relayOutAlarmEnable").eq(2).text($("#relayOutAlarmEnable").prop("checked").toString());
        $(xmlDoc).find("upAlarmEnable").eq(2).text($("#upAlarmEnable").prop("checked").toString());
	    $(xmlDoc).find("hostUpAlarmEnable").eq(2).text($("#hostUpAlarmEnable").prop("checked").toString());
	}
	
	if($("#relayNum").val()=="1"){
		$(xmlDoc).find("relayNum").eq(0).text($("#relayNum").val());
	    $(xmlDoc).find("relayFunction").eq(0).text($("#relayFunction").val());
	}
	if($("#relayNum").val()=="2"){
		$(xmlDoc).find("relayNum").eq(1).text($("#relayNum").val());
	    $(xmlDoc).find("relayFunction").eq(1).text($("#relayFunction").val());
	}
	if($("#relayNum").val()=="3"){
		$(xmlDoc).find("relayNum").eq(2).text($("#relayNum").val());
	    $(xmlDoc).find("relayFunction").eq(2).text($("#relayFunction").val());
	}
	if($("#relayNum").val()=="4"){
		$(xmlDoc).find("relayNum").eq(3).text($("#relayNum").val());
	    $(xmlDoc).find("relayFunction").eq(3).text($("#relayFunction").val());
	}
	if($("#relayNum").val()=="5"){
		$(xmlDoc).find("relayNum").eq(4).text($("#relayNum").val());
	    $(xmlDoc).find("relayFunction").eq(4).text($("#relayFunction").val());
	}
	
	if($("#IOAlarmNum").val()=="1"){
		 $(xmlDoc).find("IOAlarmNum").eq(0).text($("#IOAlarmNum").val());
	     $(xmlDoc).find("IOAlarmType").eq(0).text($("#IOAlarmType").val());
	}
	if($("#IOAlarmNum").val()=="2"){
		$(xmlDoc).find("IOAlarmNum").eq(1).text($("#IOAlarmNum").val());
	    $(xmlDoc).find("IOAlarmType").eq(1).text($("#IOAlarmType").val());
	}
	
	
	if($(xmlDoc).find("IOAlarmType").eq(0).text()==$(xmlDoc).find("IOAlarmType").eq(1).text()&&$(xmlDoc).find("IOAlarmType").eq(0).text()=="1"&&$(xmlDoc).find("IOAlarmType").eq(1).text()=="1"){
		$("#IOAlarmNumTips").html(ia(ITCInletOutletPort).szTipsInfo + getNodeValue("jsOnlyOneFireAlarm"));
		setTimeout(function(){$("#IOAlarmNumTips").html("");},5000);
		return;
	}

    var funcArr = [];
    var num = $('select#relayNum').find('option').length;

    for (var i = 0; i < num; i++) {
        var v = $(xmlDoc).find("relayFunction").eq(i).text();
        funcArr.push(v);
    };

    var tmpObj = {};
    var hasTwice = false;
    for (var i = 0; i <funcArr.length; i++) {
        var v = funcArr[i];
        if (!tmpObj[v]) {
            tmpObj[v] = 1;
        }else{
            tmpObj[v]++;
        }

        if (v != '0' && tmpObj[v] > 1) {
            hasTwice = true;
            break;
        };
    };
    if (hasTwice) {
        $("#relayNumTips").html(ia(ITCInletOutletPort).szTipsInfo + getNodeValue("jsRelayFunctionNotSame"));
        setTimeout(function(){$("#relayNumTips").html("");},5000);
        return;
    };

	// if(($(xmlDoc).find("relayFunction").eq(0).text()==$(xmlDoc).find("relayFunction").eq(1).text()&&$(xmlDoc).find("relayFunction").eq(0).text()!="0"&&$(xmlDoc).find("relayFunction").eq(1).text()!="0")||
	//    ($(xmlDoc).find("relayFunction").eq(0).text()==$(xmlDoc).find("relayFunction").eq(2).text()&&$(xmlDoc).find("relayFunction").eq(0).text()!="0"&&$(xmlDoc).find("relayFunction").eq(2).text()!="0")||
	//    ($(xmlDoc).find("relayFunction").eq(0).text()==$(xmlDoc).find("relayFunction").eq(3).text()&&$(xmlDoc).find("relayFunction").eq(0).text()!="0"&&$(xmlDoc).find("relayFunction").eq(3).text()!="0")||
	//    ($(xmlDoc).find("relayFunction").eq(0).text()==$(xmlDoc).find("relayFunction").eq(4).text()&&$(xmlDoc).find("relayFunction").eq(0).text()!="0"&&$(xmlDoc).find("relayFunction").eq(4).text()!="0")||
	//    ($(xmlDoc).find("relayFunction").eq(1).text()==$(xmlDoc).find("relayFunction").eq(2).text()&&$(xmlDoc).find("relayFunction").eq(1).text()!="0"&&$(xmlDoc).find("relayFunction").eq(2).text()!="0")||
	//    ($(xmlDoc).find("relayFunction").eq(1).text()==$(xmlDoc).find("relayFunction").eq(3).text()&&$(xmlDoc).find("relayFunction").eq(1).text()!="0"&&$(xmlDoc).find("relayFunction").eq(3).text()!="0")||
	//    ($(xmlDoc).find("relayFunction").eq(1).text()==$(xmlDoc).find("relayFunction").eq(4).text()&&$(xmlDoc).find("relayFunction").eq(1).text()!="0"&&$(xmlDoc).find("relayFunction").eq(4).text()!="0")||
	//    ($(xmlDoc).find("relayFunction").eq(2).text()==$(xmlDoc).find("relayFunction").eq(3).text()&&$(xmlDoc).find("relayFunction").eq(2).text()!="0"&&$(xmlDoc).find("relayFunction").eq(3).text()!="0")||
	//    ($(xmlDoc).find("relayFunction").eq(2).text()==$(xmlDoc).find("relayFunction").eq(4).text()&&$(xmlDoc).find("relayFunction").eq(2).text()!="0"&&$(xmlDoc).find("relayFunction").eq(4).text()!="0")||
	//    ($(xmlDoc).find("relayFunction").eq(3).text()==$(xmlDoc).find("relayFunction").eq(4).text()&&$(xmlDoc).find("relayFunction").eq(3).text()!="0"&&$(xmlDoc).find("relayFunction").eq(4).text()!="0")){
	// 	$("#relayNumTips").html(ia(ITCInletOutletPort).szTipsInfo + getNodeValue("jsRelayFunctionNotSame"));
	// 	setTimeout(function(){$("#relayNumTips").html("");},5000);
	// 	return;
	// }
    
    var xmlObj = parseXmlFromStr(xmlToStr(xmlDoc));
    $.ajax({
        type: "put",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/Entrance/entranceParam",
        timeout: syncTime,
        async: false,
        data: xmlObj,
        processData: false,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
		success:function(XmlDoc, textStatus, xhr){
		},
        complete:function(xhr, textStatus) {
            SaveState(xhr);
        }
    });
}
/*************************************************
 Function:		putBarrierGateCtrl
 Description:	发送远程控制道闸xml
 Input:			无
 Output:			无
 return:			无
 *************************************************/
 pr(ITCInletOutletPort).putBarrierGateCtrl= function(){
	    var xmlDoc = new createxmlDoc();
		var instruction = xmlDoc.createProcessingInstruction("xml","version='1.0' encoding='utf-8'");
		xmlDoc.appendChild(instruction);
		
		var object = xmlDoc.createElement("barrierGateCtrl")
		
        var gateNum = $("#barrietGateNumOne").val();
		var element = xmlDoc.createElement("barrietGateNum");
		var text = xmlDoc.createTextNode(gateNum);
		element.appendChild(text);
		object.appendChild(element);
		
		var element = xmlDoc.createElement("barrietGateOper");
		var text = xmlDoc.createTextNode($("#barrietGateOper").val());
		element.appendChild(text); 
		object.appendChild(element);
		
		xmlDoc.appendChild(object);
		
		ia(ITCInletOutletPort).update();
		
	 	if($("#barrietGateOper").val()=="1"||$("#barrietGateOper").val()=="3"){
		if($(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(0).text()=='1'||$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(1).text()=='1'||$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(2).text()=='1'||$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(3).text()=='1'||$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(4).text()=='1'){
			} else {$("#barrietGateOperOKTips").html(ia(ITCInletOutletPort).szTipsInfo + getNodeValue("jsNoOpenGate")); setTimeout(function(){$("#barrietGateOperOKTips").html("");},5000);return;}}
		if($("#barrietGateOper").val()=="0"){
		if($(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(0).text()=='2'||$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(1).text()=='2'||$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(2).text()=='2'||$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(3).text()=='2'||$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(4).text()=='2'){
			} else {$("#barrietGateOperOKTips").html(ia(ITCInletOutletPort).szTipsInfo + getNodeValue("jsNoCloseGate")); setTimeout(function(){$("#barrietGateOperOKTips").html("");},5000);return;}}
		if($("#barrietGateOper").val()=="2"){
		if($(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(0).text()=='3'||$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(1).text()=='3'||$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(2).text()=='3'||$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(3).text()=='3'||$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(4).text()=='3'){
			} else {$("#barrietGateOperOKTips").html(ia(ITCInletOutletPort).szTipsInfo + getNodeValue("jsNoStopGate")); setTimeout(function(){$("#barrietGateOperOKTips").html("");},5000);return;}}
     $.ajax({
        type: "PUT",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/Entrance/barrierGateCtrl",
        timeout: syncTime,
        async: false,
		data: xmlDoc,
		processData: false,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
		 complete:function(xhr, textStatus) {
            SaveState(xhr);
        }
	})
 }
 /*************************************************
 Function:		putLampCtrl
 Description:	发送远程控制道闸xml
 Input:			无
 Output:			无
 return:			无
 *************************************************/
 pr(ITCInletOutletPort).putLampCtrl= function(){
	 	var xmlDoc = new createxmlDoc();
		var instruction = xmlDoc.createProcessingInstruction("xml","version='1.0' encoding='utf-8'");
		xmlDoc.appendChild(instruction);
		
		var object = xmlDoc.createElement("lampCtrl")
		
        var gateNum = $("#barrietGateNumOne").val();
		var element = xmlDoc.createElement("barrietGateNum");
		var text = xmlDoc.createTextNode(gateNum);
		element.appendChild(text);
		object.appendChild(element);
		
		var element = xmlDoc.createElement("lampOper");
		var text = xmlDoc.createTextNode($("#lampOper").val());
		element.appendChild(text); 
		object.appendChild(element);
		
		xmlDoc.appendChild(object);
		
	 if($(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(0).text()=='5'||$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(1).text()=='5'||$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(2).text()=='5'||$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(3).text()=='5'||$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(4).text()=='5'){
	  
	  $.ajax({
        type: "PUT",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/Entrance/lampCtrl",
        timeout: syncTime,
        async: false,
		processData: false,
		data: xmlDoc,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
		 complete:function(xhr, textStatus) {
            SaveState(xhr);
        }
	})
	 } else {$("#lampOperOKTips").html(ia(ITCInletOutletPort).szTipsInfo + getNodeValue("jsNoOftenBrightLamp")); setTimeout(function(){$("#lampOperOKTips").html("");},5000);}
	 
 }
/*************************************************
 Function:		changeVehInfoManagNum
 Description:	改变输入端报警数
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(ITCInletOutletPort).changeVehInfoManagNum = function(strType){
	var frontNum = parseInt(ia(ITCInletOutletPort).sz_frontVehInfoManagStr);
	$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("barrierGateOper").eq(frontNum).text($("#barrierGateOper").val());
	$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayOutAlarmEnable").eq(frontNum).text($("#relayOutAlarmEnable").prop("checked").toString());
	$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("upAlarmEnable").eq(frontNum).text($("#upAlarmEnable").prop("checked").toString());
	$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("hostUpAlarmEnable").eq(frontNum).text($("#hostUpAlarmEnable").prop("checked").toString());
	
	var iIndex = parseInt(strType, 10);
	$("#barrierGateOper").val($(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("barrierGateOper").eq(iIndex).text());
	$("#relayOutAlarmEnable").prop("checked", $(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayOutAlarmEnable").eq(iIndex).text() == "true" ? true : false);
	$("#upAlarmEnable").prop("checked", $(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("upAlarmEnable").eq(iIndex).text() == "true" ? true : false);
	$("#hostUpAlarmEnable").prop("checked", $(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("hostUpAlarmEnable").eq(iIndex).text() == "true" ? true : false);
	
	ia(ITCInletOutletPort).sz_frontVehInfoManagStr=strType;
}
/*************************************************
 Function:		changeRelayNum
 Description:	改变输入端报警数
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(ITCInletOutletPort).changeRelayNum = function(strType){
	var frontNum = parseInt(ia(ITCInletOutletPort).sz_frontRelayStr);
	$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(frontNum-1).text($("#relayFunction").val());
	if(strType=="1"){
		$("#relayFunction").val($(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(0).text());
	} else if (strType=="2"){
		$("#relayFunction").val($(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(1).text());
	} else if (strType=="3"){
		$("#relayFunction").val($(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(2).text());
	} else if (strType=="4"){
		$("#relayFunction").val($(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(3).text());
	} else {
		$("#relayFunction").val($(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("relayFunction").eq(4).text());
	}
	ia(ITCInletOutletPort).sz_frontRelayStr = strType;
}
/*************************************************
 Function:		changeIOAlarmNum
 Description:	改变输入端报警数
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(ITCInletOutletPort).changeIOAlarmNum = function(strType){
	var frontNum = parseInt(ia(ITCInletOutletPort).sz_frontIOAlarmStr);
	$(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("IOAlarmType").eq(frontNum-1).text($("#IOAlarmType").val());
	if(strType == '1'){
		$("#IOAlarmType").val($(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("IOAlarmType").eq(0).text());
	}
    if(strType == '2')
	{
		$("#IOAlarmType").val($(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("IOAlarmType").eq(1).text());
	}
	ia(ITCInletOutletPort).sz_frontIOAlarmStr=strType;
}
/*************************************************
 Function:		changebarrietGateNumOne
 Description:	改变远程控制道闸号
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(ITCInletOutletPort).changebarrietGateNumOne = function(strType){
	if(strType == '1'){
		$("#IOAlarmType").val($(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("IOAlarmType").eq(0).text());
	}
    if(strType == '2')
	{
		$("#IOAlarmType").val($(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("IOAlarmType").eq(1).text());
	}
}
/*************************************************
 Function:		changebarrietGateNumTwo
 Description:	改变常亮灯功能控制道闸号
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(ITCInletOutletPort).changebarrietGateNumTwo = function(strType){
	if(strType == '1'){
		$("#IOAlarmType").val($(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("IOAlarmType").eq(0).text());
	}
    if(strType == '2')
	{
		$("#IOAlarmType").val($(ia(ITCInletOutletPort).sz_ITCInletOutletPortXmlInfo).find("IOAlarmType").eq(1).text());
	}
}
/*************************************************
 Function:		changePlateNumOnlyEnable
 Description:	改变车牌匹配类型
 Input:			无
 Output:		无
 return:		无
 *************************************************/
pr(ITCInletOutletPort).changePlateNumOnlyEnable = function(){
	if($("#plateNumOnlyEnable").prop("checked")){
		$("#plateNumColorEnable").prop("checked",false);
	}
}
/*************************************************
 Function:		changePlateNumColorEnable
 Description:	改变车牌匹配类型
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(ITCInletOutletPort).changePlateNumColorEnable = function(){
	if($("#plateNumColorEnable").prop("checked")){
		$("#plateNumOnlyEnable").prop("checked",false);
	}
}
/*************************************************
 Function:		changebEnable
 Description:	改变出入口参数使用
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(ITCInletOutletPort).changebEnable = function(){
	if(!$("#bEnable").prop("checked")){
	    $("#changebEnable").css("display","none");
	} else {
        $("#changebEnable").css("display","block");
    }
	autoResizeIframe();
}
/*************************************************
 Function:		submit
 Description:	保存牌识参数页面信息
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(PlateParam).submit = function(){

    var xmlDoc = ia(PlateParam).sz_plateParamXmlInfo;

    $(xmlDoc).find("defaultCHN").eq(0).text($("#defaultCHN").val());

    var $xmlDoc = $(xmlDoc);

    $.each(['farmVehicleEnabled','fuzzyDiscEnabled', 
                'microPlateRegEnabled', 'motorEnabled'
                ], function (i, n) {
                    var v = $('#'+n).prop('checked') ? "true" : "false";
                    $xmlDoc.find(n).eq(0).text(v);               
                });

    $(xmlDoc).find("frontPlateRecoEnabled").eq(0).text($(document.getElementsByName("PlateRecoDirection")).eq(0).prop("checked").toString());
    $(xmlDoc).find("rearPlateRecoEnabled").eq(0).text($(document.getElementsByName("PlateRecoDirection")).eq(1).prop("checked").toString());
    $(xmlDoc).find("smallPlateRecoEnabled").eq(0).text($(document.getElementsByName("PlateRecoType")).eq(0).prop("checked").toString());
    $(xmlDoc).find("largePlateRecoEnabled").eq(0).text($(document.getElementsByName("PlateRecoType")).eq(1).prop("checked").toString());
    var xmlObj = parseXmlFromStr(xmlToStr(xmlDoc));
    $.ajax({
        type: "put",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/PlateRecognitionParam",
        timeout: syncTime,
        async: false,
        data: xmlObj,
        processData: false,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        complete:function(xhr, textStatus) {
            SaveState(xhr);
        }
    });

}

/*************************************************
 Function:		changePlateRecoType
 Description:	改变车牌识别类型
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(PlateParam).changePlateRecoType = function (iType) {
    if(iType == 1) {
        $("#microPlateRegEnabled").prop("checked", false);
        $("#microPlateRegEnabled").prop("disabled", true);
    } else {
        $("#microPlateRegEnabled").prop("disabled", false);
    }
}

/*************************************************
I/O输出类
*************************************************/
function IOSetting() {
	SingletonInheritor.implement(this);
    this.x_outputIOXML = null;
    this.p_curTabSize = 0;
    this.p_curTabNum = -1;
    this.p_lastTabNum = -1;
	this.sz_outPutXmlInfo = "";
}
SingletonInheritor.declare(IOSetting);
//获取IO输出模式的能力集
function getIOWorkModeCap(){
    $.ajax({
        type: "GET",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/SyncSignalOutput/capabilities",
        async: false,
        timeout: syncTime,
        dataType:"text",
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {
            var $xml=$(parseXmlFromStr(xmlDoc));
            $("#IOWorkMode").html("");
            var strIOWorkModeCap=$xml.find('IOWorkModeCap').attr("opt");
            if(strIOWorkModeCap){
                var cap=strIOWorkModeCap.split(",");
                var optHtml="";
                for(var i=0;i<cap.length;i++){
                    var c=cap[i];
                    optHtml+="<option value='"+c+"' name='"+c+"IOWorkModeOpt"+"'>"+getNodeValue(c+"IOWorkModeOpt")+"</option>";
                }
                $("#IOWorkMode").html(optHtml);
            }
            
            autoResizeIframe();
        }
    });
} 

/*************************************************
Function:		update
Description:	更新I/O输出配置信息
Input:			无
Output:			无
return:			无
*************************************************/
pr(IOSetting).update = function () {

	if($.browser.msie && parseInt($.browser.version, 10) == 6){
		$("#taSnapOverlay").find("select").hide();
		$("#taSyncLight").find("select").hide();
		$("#taImageMerge").find("select").hide();
		$("#taSnapSetup").find("select").hide();
		$("#taTrafficParam").find("select").hide();
		$("#taIOSetting").find("select").show();
	}
	$('#SetResultTips').html('');
	$("#SaveConfigBtn").show();
    $('#brightnessCopyIOContent').html('');
	HWP.Stop(0);
	g_transStack.clear();
	var that = this;
	g_transStack.push(function () {
		that.setLxd(parent.translator.getLanguageXmlDoc(["SnapParam", "IOSetting"]));
		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	}, true);
	
	$("#IsflashEnabled").bind("click", function() {
		if(!$(this).prop("checked")) {
			$("#StartTime").prop("disabled", true);
			$("#EndTime").prop("disabled", true);
		} else {
			$("#StartTime").prop("disabled", false);
			$("#EndTime").prop("disabled", false);
		}
	});

    getIOWorkModeCap();
	
	$.ajax({
		type: "GET",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/SyncSignalOutput",
		async: false,
		timeout: syncTime,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) {

            ia(IOSetting).x_outputIOXML = xmlDoc;   //SyncSignalOutputList
            ia(IOSetting).sz_outPutXmlInfo = $(xmlDoc).find("SyncSignalOutput");

            var outPutLength = ia(IOSetting).p_curTabSize = $(xmlDoc).find("SyncSignalOutput").length;
            for(var i = outPutLength + 1; i <= 8; i++) {     //得到有几个IO输出 ，最多8个，少于8个的后面依次隐藏。
                $("#liOutputIO" + i).css("display", "none");
            }

            $.g.setField2('#IOWorkMode', $(xmlDoc).find("IOWorkMode").eq(0).text());

			$("#defaultState").val($(xmlDoc).find("defaultStatus").eq(0).text());  //默认状态，已隐藏，不显示。
			$("#outputState").val($(xmlDoc).find("outputState").eq(0).text());      //起效状态
			
            var $aht = $(xmlDoc).find("aheadTime").eq(0);
            var ahtMin = $aht.attr('min');
            var ahtMax = $aht.attr('max');
            if (!ahtMin) {
                ahtMin = '0';
            };
            if (!ahtMax) {
                ahtMax = '1000';
            };
            
            $('#AheadTime').attr('min', ahtMin).attr('max', ahtMax);
            $("#AheadTime").val($aht.text());          //提前时间
			
            $("#ContinueTime").val($(xmlDoc).find("timeDelay").eq(0).text());       //持续时间
			$("#freqMulti").val($(xmlDoc).find("freqMulti").eq(0).text());          //倍频 已隐藏，不显示。
			$("#dutyRate").val($(xmlDoc).find("dutyRate").eq(0).text());            //占空比   已隐藏，不显示。
			
			$("#IspostFlash").prop("checked", $(xmlDoc).find("postFlash").eq(0).text() === "true" ? true : false);
			$("#IsillegalFlash").prop("checked", $(xmlDoc).find("illegalFlash").eq(0).text() === "true" ? true : false);
			$("#IsvideoFlash").prop("checked", $(xmlDoc).find("videoFlash").eq(0).text() === "true" ? true : false);


			if($(xmlDoc).find("detectBrightness").eq(0).text() === "true") { //  自动检测亮度控制闪光灯

                $("#IsdetectBrightness").prop("checked", true);
                $("#brightnessThreldContent").css("display","block");

				sliderBrightnessThreld.wsetValue(parseInt($(xmlDoc).find('brightnessThreld').eq(0).text(), 10));
			    g_transStack.push(function() { sliderBrightnessThreld.setTitle(getNodeValue('laPlateExpectedBright') + ":" + sliderBrightnessThreld.getValue()); }, true);
			}else{
                $("#IsdetectBrightness").prop("checked", false);
                $("#brightnessThreldContent").css("display","none");
                sliderBrightnessThreld.wsetValue(0);
                g_transStack.push(function() { sliderBrightnessThreld.setTitle(getNodeValue('laPlateExpectedBright') + ":" + sliderBrightnessThreld.getValue()); }, true);
            }
            if($(xmlDoc).find("flashEnabled").eq(0).text() === "true"){ //启用闪光灯时间

                $("#IsflashEnabled").prop("checked", true);

                $("#brightnessDateContent").css("display","block");

				$("#StartTime").val($(xmlDoc).find("startHour").eq(0).text() + ":" + $(xmlDoc).find("startMinute").eq(0).text());
			    $("#EndTime").val($(xmlDoc).find("endHour").eq(0).text() + ":" + $(xmlDoc).find("endMinute").eq(0).text());
			}else {
                $("#IsflashEnabled").prop("checked", false);
                $("#brightnessDateContent").css("display","none");
                $("#StartTime").val('');
                $("#EndTime").val('');
            }
            if($(xmlDoc).find("plateBrightness").eq(0).text() === "true"){ //启用车牌亮度

                $("#notDetectBrightness").prop("checked", true);
			}else{
                $("#notDetectBrightness").prop("checked", false);
            }

            ia(IOSetting).changeFMode();

            if(outPutLength > 0){
                ia(IOSetting).copyIOInfoComponent(ia(IOSetting).sz_outPutXmlInfo);
            }
            ia(IOSetting).changeTriggleStatus();
			if(ia(IOSetting).p_curTabNum == -1 || ia(IOSetting).p_curTabNum == 1) {
				ia(IOSetting).p_curTabNum = 1;
                ia(IOSetting).p_lastTabNum = 1;
			} else {	    
				var iCurTab = ia(IOSetting).p_curTabNum;
				ia(IOSetting).p_curTabNum = 1;
				pr(IOSetting).selectOutputContent(iCurTab);
			}

            autoResizeIframe();
		}
    });
	autoResizeIframe();
}

/*************************************************
 Function:		copyIOInfoComponent
 Description:	动态生成复制IO DIV 的信息.
 Input:			xmlDoc    IO输出 list。
 Output:			无
 return:			无
 *************************************************/
pr(IOSetting).copyIOInfoComponent = function(xmlDoc){

    var msg = "";
    var cNo = $("#tabOutPutIOContent .current").html().split(":")[1];

    if(xmlDoc.length > 0){

        var IOLength = xmlDoc.length;
        for(var i=0; i < IOLength; i++){
            var outPutVal = xmlDoc.find("id").eq(i).text();
            if(cNo == outPutVal) continue;
            msg +="<input type='checkbox' class='checkbox' id='outIOOpt" + outPutVal + "' value='"+ outPutVal +"'/>&nbsp;IO" + outPutVal + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
        }
        $('#brightnessCopyIOContent').html(msg);
    }
}

/*************************************************
 Function:		selectOutputContent
 Description:	切换Tab时获取当前tab的信息.
 Input:			iNum    当前Tab ID。
 Output:			无
 return:			无
 *************************************************/
pr(IOSetting).selectOutputContent = function(iNum){

    var iLastIndex = parseInt(ia(IOSetting).p_curTabNum-1);
     if(iNum == iLastIndex+1) {
        return;
     }

     if (ia(IOSetting).p_curTabSize == 4) {
         if (iNum >= 3) {
            $('#dutyRangeSpan').text("[0-15%]")
         }else{
            $('#dutyRangeSpan').text("[0-40%]")
         }    
     };

    $("#tabOutPutIOContent").find("li").each(function() {
        if($(this).children().hasClass("current")) {
            $(this).children().removeClass();
        }
    });
    $("#tabOutPutIOContent").find("li").eq(iNum-1).find("a").eq(0).addClass("current");

    var $xmlDoc = $(ia(IOSetting).x_outputIOXML);
    //保存之前Tab的值
    $xmlDoc.find("IOWorkMode").eq(iLastIndex).text($('#IOWorkMode').val());

    $xmlDoc.find("defaultStatus").eq(iLastIndex).text($("#defaultState").val());
    $xmlDoc.find("outputState").eq(iLastIndex).text($("#outputState").val());
    $xmlDoc.find("aheadTime").eq(iLastIndex).text($("#AheadTime").val());
    $xmlDoc.find("timeDelay").eq(iLastIndex).text($("#ContinueTime").val());
    $xmlDoc.find("freqMulti").eq(iLastIndex).text($("#freqMulti").val());
    $xmlDoc.find("dutyRate").eq(iLastIndex).text($("#dutyRate").val());

    $xmlDoc.find("postFlash").eq(iLastIndex).text($("#IspostFlash").prop("checked") ? "true" : "false");
    $xmlDoc.find("illegalFlash").eq(iLastIndex).text($("#IsillegalFlash").prop("checked") ? "true" : "false");
    $xmlDoc.find("videoFlash").eq(iLastIndex).text($("#IsvideoFlash").prop("checked") ? "true" : "false");

    $xmlDoc.find("detectBrightness").eq(iLastIndex).text($("#IsdetectBrightness").prop("checked") ? "true" : "false");
    $xmlDoc.find("brightnessThreld").eq(iLastIndex).text(sliderBrightnessThreld.getValue());

    $xmlDoc.find("flashEnabled").eq(iLastIndex).text($("#IsflashEnabled").prop("checked") ? "true" : "false");
    $xmlDoc.find("startHour").eq(iLastIndex).text($("#StartTime").val().split(":")[0]);
    $xmlDoc.find("startMinute").eq(iLastIndex).text($("#StartTime").val().split(":")[1]);
    $xmlDoc.find("endHour").eq(iLastIndex).text($("#EndTime").val().split(":")[0]);
    $xmlDoc.find("endMinute").eq(iLastIndex).text($("#EndTime").val().split(":")[1]);
    $xmlDoc.find("plateBrightness").eq(iLastIndex).text($("#notDetectBrightness").prop("checked") ? "true" : "false");

    //获取当前Tab值
    var pv = $xmlDoc.find("IOWorkMode").eq(iNum-1).text();
    $.g.setField2('#IOWorkMode', pv);

    $("#defaultState").val($xmlDoc.find("defaultStatus").eq(iNum-1).text());
    $("#outputState").val($xmlDoc.find("outputState").eq(iNum-1).text());      //起效状态
    $("#AheadTime").val($xmlDoc.find("aheadTime").eq(iNum-1).text());          //提前时间
    $("#ContinueTime").val($xmlDoc.find("timeDelay").eq(iNum-1).text());       //持续时间
    $("#freqMulti").val($xmlDoc.find("freqMulti").eq(iNum-1).text());          //倍频 已隐藏，不显示。
    $("#dutyRate").val($xmlDoc.find("dutyRate").eq(iNum-1).text());            //占空比   已隐藏，不显示。

    $("#IspostFlash").prop("checked", $xmlDoc.find("postFlash").eq(iNum-1).text() === "true" ? true : false);
    $("#IsillegalFlash").prop("checked", $xmlDoc.find("illegalFlash").eq(iNum-1).text() === "true" ? true : false);
    $("#IsvideoFlash").prop("checked", $xmlDoc.find("videoFlash").eq(iNum-1).text() === "true" ? true : false);


    if($xmlDoc.find("detectBrightness").eq(iNum-1).text() === "true") { //启用闪光灯自动使能闪光灯

        $("#IsdetectBrightness").prop("checked", true);

        $("#brightnessThreldContent").css("display","block");

        if($xmlDoc.find('brightnessThreld').eq(iNum-1).text() != 0){
            sliderBrightnessThreld.wsetValue(parseInt( $xmlDoc.find('brightnessThreld').eq(iNum-1).text(), 10));
        }else{
            sliderBrightnessThreld.wsetValue(0);
        }
        g_transStack.push(function() { sliderBrightnessThreld.setTitle(getNodeValue('laPlateExpectedBright') + ":" + sliderBrightnessThreld.getValue()); }, true);
    }else{
        $("#IsdetectBrightness").prop("checked", false);
        $("#brightnessThreldContent").css("display","none");

        sliderBrightnessThreld.wsetValue(0);
    }
    if($xmlDoc.find("flashEnabled").eq(iNum-1).text() === "true"){ //启用闪光灯时间

        $("#IsflashEnabled").prop("checked", true);

        $("#brightnessDateContent").css("display","block");

        if($xmlDoc.find("startHour").eq(iNum-1).text() != ''){
            $("#StartTime").val($xmlDoc.find("startHour").eq(iNum-1).text() + ":" + $xmlDoc.find("startMinute").eq(iNum-1).text());
        }else{
            $("#StartTime").val('');
        }
        if($xmlDoc.find("endHour").eq(iNum-1).text() != ''){
            $("#EndTime").val($xmlDoc.find("endHour").eq(iNum-1).text() + ":" + $xmlDoc.find("endMinute").eq(iNum-1).text());
        }else{
            $("#EndTime").val('');
        }
    }else{
        $("#IsflashEnabled").prop("checked", false);

        $("#brightnessDateContent").css("display","none");

        $("#StartTime").val('');
        $("#EndTime").val('');
    }
    if($xmlDoc.find("plateBrightness").eq(iNum-1).text() === "true"){  //车牌亮度
        $("#notDetectBrightness").prop("checked", true);
    }else{
        $("#notDetectBrightness").prop("checked", false);
    }

    ia(IOSetting).changeFMode();

    ia(IOSetting).p_lastTabNum =ia(IOSetting).p_curTabNum;
    ia(IOSetting).p_curTabNum = iNum;

    ia(IOSetting).changeTriggleStatus();
    ia(IOSetting).copyIOInfoComponent(ia(IOSetting).sz_outPutXmlInfo);
}

/*************************************************
Function:		GetSyncSignalOutputNo
Description:	获取单个I/O输出配置信息    ---- 该方法已作废.
Input:			无
Output:			无
return:			无
*************************************************/
pr(IOSetting).GetSyncSignalOutputNo = function () {
	$("#StartTime").val("");
	$("#EndTime").val("");
    $('#brightnessCopyIOContent').html('');
	$.ajax({
		type: "GET",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/SyncSignalOutput/" + $("#SyncSignalOutputNo").val(),
		async: false,
		timeout: syncTime,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr){

            ia(IOSetting).copyIOInfoComponent(ia(IOSetting).sz_outPutXmlInfo);

			$("#defaultState").val($(xmlDoc).find("defaultStatus").eq(0).text());
			$("#outputState").val($(xmlDoc).find("outputState").eq(0).text());
			$("#AheadTime").val($(xmlDoc).find("aheadTime").eq(0).text());
			$("#ContinueTime").val($(xmlDoc).find("timeDelay").eq(0).text());
			$("#freqMulti").val($(xmlDoc).find("freqMulti").eq(0).text());
			$("#dutyRate").val($(xmlDoc).find("dutyRate").eq(0).text());
			
			$("#IspostFlash").prop("checked", $(xmlDoc).find("postFlash").eq(0).text() === "true" ? true : false);
			$("#IsillegalFlash").prop("checked", $(xmlDoc).find("illegalFlash").eq(0).text() === "true" ? true : false);
			$("#IsvideoFlash").prop("checked", $(xmlDoc).find("videoFlash").eq(0).text() === "true" ? true : false);
			
			if($(xmlDoc).find("detectBrightness").eq(0).text() === "true") {  //自动检测亮度和使能闪光灯是互斥关系但又可以都不启用
				$("#IsdetectBrightness").prop("checked", true);
			    $("#IsflashEnabled").prop("checked", false);
				sliderBrightnessThreld.wsetValue(parseInt($(xmlDoc).find('brightnessThreld').eq(0).text(), 10));
			    g_transStack.push(function() { sliderBrightnessThreld.setTitle(getNodeValue('laPlateExpectedBright') + ":" + sliderBrightnessThreld.getValue()); }, true);
				pr(IOSetting).setDetectMode(0);
			} else if($(xmlDoc).find("flashEnabled").eq(0).text() === "true"){
			    $("#IsdetectBrightness").prop("checked", false);
			    $("#IsflashEnabled").prop("checked", true);
				$("#StartTime").val($(xmlDoc).find("startHour").eq(0).text() + ":" + $(xmlDoc).find("startMinute").eq(0).text());
			    $("#EndTime").val($(xmlDoc).find("endHour").eq(0).text() + ":" + $(xmlDoc).find("endMinute").eq(0).text());
				pr(IOSetting).setDetectMode(1);
			} else {
				$("#IsdetectBrightness").prop("checked", false);
			    $("#IsflashEnabled").prop("checked", false);
				$("#StartTime").prop("disabled", true);
	            $("#EndTime").prop("disabled", true);
			}
		}
    });
}

/*************************************************
 Function:		insertOutputIOData
 Description:	插入详细数据到 全局xml。
 Input:			    无
 Output:			无
 return:			无
 *************************************************/
pr(IOSetting).insertOutputIOData = function (iIndex){

    $(ia(IOSetting).x_outputIOXML).find("IOWorkMode").eq(iIndex).text($('#IOWorkMode').val());
    $(ia(IOSetting).x_outputIOXML).find("defaultStatus").eq(iIndex).text($("#defaultState").val());
    $(ia(IOSetting).x_outputIOXML).find("outputState").eq(iIndex).text($("#outputState").val());
    $(ia(IOSetting).x_outputIOXML).find("aheadTime").eq(iIndex).text($("#AheadTime").val());
    $(ia(IOSetting).x_outputIOXML).find("timeDelay").eq(iIndex).text($("#ContinueTime").val());
    $(ia(IOSetting).x_outputIOXML).find("freqMulti").eq(iIndex).text($("#freqMulti").val());
    $(ia(IOSetting).x_outputIOXML).find("dutyRate").eq(iIndex).text($("#dutyRate").val());

    $(ia(IOSetting).x_outputIOXML).find("postFlash").eq(iIndex).text($("#IspostFlash").prop("checked") ? "true" : "false");
    $(ia(IOSetting).x_outputIOXML).find("illegalFlash").eq(iIndex).text($("#IsillegalFlash").prop("checked") ? "true" : "false");
    $(ia(IOSetting).x_outputIOXML).find("videoFlash").eq(iIndex).text($("#IsvideoFlash").prop("checked") ? "true" : "false");

    $(ia(IOSetting).x_outputIOXML).find("detectBrightness").eq(iIndex).text($("#IsdetectBrightness").prop("checked") ? "true" : "false");
    $(ia(IOSetting).x_outputIOXML).find("brightnessThreld").eq(iIndex).text(sliderBrightnessThreld.getValue());

    $(ia(IOSetting).x_outputIOXML).find("flashEnabled").eq(iIndex).text($("#IsflashEnabled").prop("checked") ? "true" : "false");
    $(ia(IOSetting).x_outputIOXML).find("startHour").eq(iIndex).text($("#StartTime").val().split(":")[0]);
    $(ia(IOSetting).x_outputIOXML).find("startMinute").eq(iIndex).text($("#StartTime").val().split(":")[1]);
    $(ia(IOSetting).x_outputIOXML).find("endHour").eq(iIndex).text($("#EndTime").val().split(":")[0]);
    $(ia(IOSetting).x_outputIOXML).find("endMinute").eq(iIndex).text($("#EndTime").val().split(":")[1]);
    $(ia(IOSetting).x_outputIOXML).find("plateBrightness").eq(iIndex).text($("#notDetectBrightness").prop("checked") ? "true" : "false");
}

/*************************************************
Function:		submit
Description:	设置单个I/O输出配置信息
Input:			无
Output:			无
return:			无
*************************************************/
pr(IOSetting).submit = function () {

    var fMode = $('#IOWorkMode').val();
    var isFlashMode = fMode == 'false';

    //校验页面数据正确性
	if($("#IsflashEnabled").prop("checked")) {

		if($.isEmpty($("#StartTime").val())) {
			var szAreaNameInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
			$("#SetResultTips").html(szAreaNameInfo + getNodeValue("laStartTime") + getNodeValue("NullTips"));
			return;
		}
		if($.isEmpty($("#EndTime").val())) {
			var szAreaNameInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
			$("#SetResultTips").html(szAreaNameInfo + getNodeValue("laEndTime") + getNodeValue("NullTips"));
			return;
		}
	}
	
	if(isFlashMode && !CheackServerIDIntNum($("#AheadTime").val(),"AheadTimetips","laaheadTime",0,4000)) {
        $("#AheadTime").focus();
		return;
    }


    if(isFlashMode && !CheackServerIDIntNum($("#ContinueTime").val(),"ContinueTimetips","laContinueTime",0,10000)) {
        $("#ContinueTime").focus();
		return;
    }


  //   if(isFlashMode && !CheackServerIDIntNum($("#freqMulti").val(),"freqMultitips","lafreqMulti",1,15)) {
  //       $("#freqMulti").focus();
		// return;
  //   }


  //   if(isFlashMode && !CheackServerIDIntNum($("#dutyRate").val(),"dutyRatetips","ladutyRate",0,40)) {
  //       $("#dutyRate").focus();
		// return;
  //   }

    //保存 当前tab页的值 及 保存 复制IO到 指定页的数据
    for(var i = 1; i <= ia(IOSetting).p_curTabSize; i++){

        if($("#outIOOpt" + i).prop("checked") || ia(IOSetting).p_curTabNum == i){
            ia(IOSetting).insertOutputIOData(i-1);
        }
    }
    var xmlObj = parseXmlFromStr(xmlToStr(ia(IOSetting).x_outputIOXML));
	$.ajax({
		type: "put",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/SyncSignalOutput",
		async: false,
		timeout: syncTime,
		processData: false,
		data: xmlObj,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		complete:function(xhr, textStatus) {
			SaveState(xhr);
		}
    });
}

pr(IOSetting).changeDetectBrightnessAutomatic = function (){

    if($('#IsdetectBrightness').prop("checked")){

        $('#notDetectBrightness').prop("checked",false);
        $('#IsflashEnabled').prop("checked",false);
        $("#brightnessDateContent").css("display","none");
        $("#brightnessThreldContent").css("display","block");
    }else{
        $('#brightnessThreldContent').css("display","none");
    }

    autoResizeIframe();
}

pr(IOSetting).changeDetectBrightnessByTime = function (){
    if($('#IsflashEnabled').prop("checked")){

        $('#notDetectBrightness').prop("checked",false);
        $('#IsdetectBrightness').prop("checked",false);
        $("#brightnessDateContent").css("display","block");
        $("#brightnessThreldContent").css("display","none");
    }else{
        $("#brightnessDateContent").css("display","none");
    }
    autoResizeIframe();
}

pr(IOSetting).changeDetectBrightnessMode = function(){
    if($('#notDetectBrightness').prop("checked")){

        $('#IsflashEnabled').prop("checked",false);
        $('#IsdetectBrightness').prop("checked",false);
        $("#brightnessDateContent").css("display","none");
        $("#brightnessThreldContent").css("display","none");
    }
    autoResizeIframe();
}

/*************************************************
 Function:		checkAheadTimeInfo
 Description:	验证起效状态
 Input:			    无
 Output:			无
 return:			无
 *************************************************/
pr(IOSetting).checkAheadTimeInfo = function(){
    var min = $('#AheadTime').attr('min');
    var max = $('#AheadTime').attr('max');

    min = parseInt(min, 10);
    max = parseInt(max, 10);

    if(!CheackServerIDIntNum($("#AheadTime").val(),"AheadTimetips","laaheadTime",min,max)) {
        $("#AheadTime").focus();
    }
}
pr(IOSetting).checkLastTimeInfo = function(){
    if(!CheackServerIDIntNum($("#ContinueTime").val(),"ContinueTimetips","laContinueTime",0,10000)) {
        $("#ContinueTime").focus();
    }
}
pr(IOSetting).checkFreqMultiInfo = function(){
    if(!CheackServerIDIntNum($("#freqMulti").val(),"freqMultitips","lafreqMulti",1,15)) {
        $("#freqMulti").focus();
    }
}
pr(IOSetting).checkDutyRateInfo = function(){
    if (this.p_curTabSize == 4 
        && (this.p_curTabNum > 2)) {

        if(!CheackServerIDIntNum($("#dutyRate").val(),"dutyRatetips","ladutyRate",0,15)) {
            $("#dutyRate").focus();
        }
    }else{
        if(!CheackServerIDIntNum($("#dutyRate").val(),"dutyRatetips","ladutyRate",0,40)) {
            $("#dutyRate").focus();
        }    
    }
    
}

pr(IOSetting).changeFMode = function () {
    var v = $('#IOWorkMode').val();
    var popt = $('#outputState option[value=pulse]');
    if (v == 'flashLight') {
        if($('#taIOSetting #outputState').val() == 'pulse'){
            $('#IOSettingWrapper2').show();
        }else{
            $('#IOSettingWrapper2').hide();
        }
        $('#IOSettingWrapper1').show();
        
        // if (popt.length == 0) {
        //     $('#outputState').append('<option value="pulse" id="outputState1" name="outputState1">'+
        //                                 getNodeValue('outputState1')+
        //                             '</option>');
        // };

        $('#ladetectBrightness').text(getNodeValue("ladetectBrightness"));
        $('#laDetectBrightnessByTime').text(getNodeValue("laDetectBrightnessByTime"));
    }else if (v == 'polarizer') {
        $('#IOSettingWrapper1, #IOSettingWrapper2').hide();
        $('#ladetectBrightness').text(getNodeValue("ladetectBrightnessPZJ"));
        $('#laDetectBrightnessByTime').text(getNodeValue("laDetectBrightnessPZJByTime"));
        
        // popt.remove();
    }else if (v=='continuousLight') {
        $('#IOSettingWrapper1, #IOSettingWrapper2').hide();
        $('#ladetectBrightness').text(getNodeValue("lacontinuousLightPZJ"));
        $('#laDetectBrightnessByTime').text(getNodeValue("lacontinuousLightPZJByTime"));
        
        // popt.remove();
    };

    autoResizeIframe();
}



/*************************************************
 Function:		setDetectMode
 Description:	起效状态改变事件
 Input:			iType: 0 自动检测亮度 1 启用闪光灯时间
 Output:			无
 return:			无
 *************************************************/
pr(IOSetting).changeTriggleStatus = function(){
    if($('#outputState').val() == 'pulse'){
        if($('#IOWorkMode').val()=='flashLight'){
            $('#IOSettingWrapper2').show();
        }

        $('#freqMultiContent').css("display","block");
        $('#dutyRateContent').css("display","block");

        $("#videoSpan").show();
        $("#defaultState").prop('disabled', false);
    }else{
        $('#IOSettingWrapper2').hide();
        $('#aheadTimeContent').css("display","block");
        $('#continueTimeContent').css("display","block");

        $('#freqMultiContent').css("display","none");
        $('#dutyRateContent').css("display","none");
        $("#videoSpan").hide();
        $("#IsvideoFlash").prop('checked', false);

        $("#defaultState").prop('disabled', true);

        var os = $('#outputState').val();
        if (os == 'high') {
            $.g.setField('defaultState', 'low');
        }else if (os == 'low') {
            $.g.setField('defaultState', 'high');
        };
        
    }

    autoResizeIframe();
}

/*************************************************
Function:		setDetectMode
Description:	设置检测亮度模式
Input:			iType: 0 自动检测亮度 1 启用闪光灯时间
Output:			无
return:			无
*************************************************/
pr(IOSetting).setDetectMode = function (iType) {
	if(iType == 0) {
		$("#IsflashEnabled").prop("checked", false);
		$("#StartTime").prop("disabled", true);
	    $("#EndTime").prop("disabled", true);
	} else {		
		$("#IsdetectBrightness").prop("checked", false);
		$("#StartTime").prop("disabled", false);
		$("#EndTime").prop("disabled", false);
	}
}

/*************************************************
信号灯同步类
*************************************************/
function SyncLight() {
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(SyncLight);

SyncLight.IsUseSyncLightInfo = function(){
    if($('#syncPowerEnabled').prop("checked")){
        $('#SyncLightContentDiv').css("display","block");
    }else{
        $('#SyncLightContentDiv').css("display","none");
    }
}
/*************************************************
Function:		update
Description:	更新信号灯同步配置信息
Input:			无
Output:			无
return:			无
*************************************************/
pr(SyncLight).update = function () {
	if($.browser.msie && parseInt($.browser.version, 10) == 6){
		$("#taIOSetting").find("select").hide();
		$("#taSnapOverlay").find("select").hide();
		$("#taImageMerge").find("select").hide();
		$("#taSnapSetup").find("select").hide();
		$("#taTrafficParam").find("select").hide();
		$("#taSyncLight").find("select").show();
	}
	$('#SetResultTips').html('');
	$("#SaveConfigBtn").show();
	HWP.Stop(0);
	g_transStack.clear();
	var that = this;
	g_transStack.push(function () {
		that.setLxd(parent.translator.getLanguageXmlDoc(["SnapParam", "SyncLight"]));
		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	}, true);
    ia(SyncLight).getSyncLightCap();
	$.ajax({
		type: "GET",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/SyncPower",
		async: false,
		timeout: syncTime,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) {
			$("#inputsycnPowerPhases").val($(xmlDoc).find("sycnPowerPhases").eq(0).text());
			$("#syncPowerfrequency").val($(xmlDoc).find("syncPowerfrequency").eq(0).text());
            $.g.setField2('#syncPowerEnabled', $(xmlDoc).find("syncPowerEnabled").eq(0).text() );
            
            SyncLight.IsUseSyncLightInfo();
		}
    });
    autoResizeIframe();
}

pr(SyncLight).getSyncLightCap = function(){

    $.ajax({
        type: "GET",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/SyncPower/capabilities",
        async: false,
        timeout: syncTime,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {

            var powerEnabledArray = $(xmlDoc).find('syncPowerEnabled').eq(0).attr('opt').split(',');
            if(powerEnabledArray.length > 0){
                if(powerEnabledArray.length == 1){

                    $('#syncPowerEnabled').prop("disabled",true);

                    if(powerEnabledArray[0] == 0){
                        $('#syncPowerEnabled').prop("checked", false);
                    }else if(powerEnabledArray[0] == 1){
                        $('#syncPowerEnabled').prop("checked", true);
                    }
                }
            }
        }
    });
}
/*************************************************
Function:		submit
Description:	设置信号灯同步配置信息
Input:			无
Output:			无
return:			无
*************************************************/
pr(SyncLight).submit = function () {
	if(!CheackServerIDIntNum($("#syncPowerfrequency").val(),"SetResultTips","lasyncPowerfrequency",0,255)) {
		$("#syncPowerfrequency").focus();
		return;
	}
    var syncEnabled = "";
    if($("#syncPowerEnabled").prop('checked')){
        syncEnabled ="true";
    }else{
        syncEnabled ="false";
    }
	
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><SyncPower version='1.0' xmlns='http://www.hikvision.com/ver10/XMLSchema'>";
	szXml += "<syncPowerEnabled>"+syncEnabled+"</syncPowerEnabled>";
	szXml += "<sycnPowerPhases>"+$('#inputsycnPowerPhases').val()+"</sycnPowerPhases>";
	szXml += "<syncPowerfrequency>"+$('#syncPowerfrequency').val()+"</syncPowerfrequency>";
	szXml += "</SyncPower>";

	var xmlDoc = parseXmlFromStr(szXml);
	$.ajax({
		type: "put",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/SyncPower",
		timeout: syncTime,
		processData: false,
		data: xmlDoc,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		complete:function(xhr, textStatus) {
			SaveState(xhr);
		}
    });
}

/*************************************************
图片合成类
*************************************************/
var m_iPicHeight = 1200;
function ImageMerge() {
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(ImageMerge);
ImageMerge.IsUseMergeImageInfo = function(){
    if($('#isMerge').prop("checked")){
        $('#mergeImageContent').css("display","block");
    }else{
        $('#mergeImageContent').css("display","none");
    }
    autoResizeIframe();
}
/*************************************************
Function:		update
Description:	更新图片合成参数信息
Input:			无
Output:			无
return:			无
*************************************************/
pr(ImageMerge).update = function () {
	if($.browser.msie && parseInt($.browser.version, 10) == 6){
		$("#taIOSetting").find("select").hide();
		$("#taSnapOverlay").find("select").hide();
		$("#taSnapSetup").find("select").hide();
		$("#taSyncLight").find("select").hide();
		$("#taTrafficParam").find("select").hide();
		$("#taImageMerge").find("select").show();
	}
	$('#SetResultTips').html('');
	$("#SaveConfigBtn").show();

	HWP.Stop(0);
	g_transStack.clear();
	var that = this;
	g_transStack.push(function () {
		that.setLxd(parent.translator.getLanguageXmlDoc(["SnapParam", "ImageMerge"]));
		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	}, true);
	
	$.ajax({
		   type: 'GET',
		   url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/ITCStatus",
		   beforeSend: function(xhr) {
			   xhr.setRequestHeader("If-Modified-Since", "0"); 
			   
			   xhr.setRequestHeader("Content-Type", "text/xml");
		   },
		   success: function(xmlDoc, textStatus, xhr) {
			   m_iPicHeight = $(xmlDoc).find("snapResolutionHeight").eq(0).text();
		   }
	});
	
	$.ajax({
		type: "GET",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/ImageMerge",
		async: false,
		timeout: syncTime,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) {
			$("#isMerge").prop("checked", $(xmlDoc).find("isMerge").eq(0).text() == "true"? true:false);
			$("#oneMergeType").val($(xmlDoc).find("oneMergeType").eq(0).text());
			$("#twoMergeType").val($(xmlDoc).find("twoMergeType").eq(0).text());
			$("#threeMergeType").val($(xmlDoc).find("threeMergeType").eq(0).text());
			sliderMergeJPEGQuality.wsetValue(parseInt($(xmlDoc).find('jpegQuality').eq(0).text(), 10));
			g_transStack.push(function() {sliderMergeJPEGQuality.setTitle(getNodeValue('laJpegQuality') + ":" + sliderMergeJPEGQuality.getValue()); }, true);
			
            $("#closeupIndex").val($(xmlDoc).find("closeupIndex").eq(0).text());
			$("#mergeMaxSize").val($(xmlDoc).find("mergeMaxSize").eq(0).text());
			$("#positionOffset").val($(xmlDoc).find("positionOffset").eq(0).text());
			
            var scale = $(xmlDoc).find('closeupScale').text();
            if (scale) {
                scale = parseInt(scale);
                setTimeout(function () {
                    SetSliderValue('closeupScaleSlider', scale);    
                }, 100);
            };

			var stroneMergeType = $(xmlDoc).find("oneMergeType").eq(0).text();
			$("input[type='radio'][cmt_value='" + stroneMergeType + "']").prop("checked",true);
			var o = $("#oneMergeType-div :radio:checked:first");
			var value = o.attr("cmt_value");
			var name = o.attr("cmt_name");
			$("#oneMergeTypeStr").val(name+"("+value+")");
			
			$("input[type='radio'][cmt_value='"+$(xmlDoc).find("twoMergeType").eq(0).text()+"']").prop("checked",true);
			var o = $("#twoMergeType-div :radio:checked:first");
			var value = o.attr("cmt_value");
			var name = o.attr("cmt_name");
			$("#twoMergeTypeStr").val(name+"("+value+")");
			
			var strthreeMergeType = $(xmlDoc).find("threeMergeType").eq(0).text();
			$("input[type='radio'][cmt_value='"+$(xmlDoc).find("threeMergeType").eq(0).text()+"']").prop("checked",true);
			var o = $("#threeMergeType-div :radio:checked:first");
			var value = o.attr("cmt_value");
			var name = o.attr("cmt_name");
			$("#threeMergeTypeStr").val(name+"("+value+")");
			
            ImageMerge.IsUseMergeImageInfo();
		}
    });
}
/*************************************************
Function:		submit
Description:	设置图片合成参数信息
Input:			无
Output:			无
return:			无
*************************************************/
pr(ImageMerge).submit = function () {
	//数据校验
	if($("#isMerge").prop("checked")) {
		if(!CheackServerIDIntNum($("#closeupIndex").val(),"closeupIndextips","lacloseupIndex",1,3)) {
			$("#closeupIndex").focus();
			return;
		}
		/*if(!CheackServerIDIntNum($("#mergeMaxSize").val(),"mergeMaxSizetips","lamergeMaxSize",30,10240)) {
			$("#mergeMaxSize").focus();
			return;
		}*/
	}
	if(!CheackServerIDIntNum($("#positionOffset").val(),"positionOffsettips","lapositionOffset",50,(m_iPicHeight-1))) {
		$("#positionOffset").focus();
		return;
	}
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><ImageMerge>";
	szXml += "<isMerge>" + $("#isMerge").prop("checked").toString() + "</isMerge>";
	szXml += "<oneMergeType>" + $("#oneMergeType").val() + "</oneMergeType>";
	szXml += "<twoMergeType>" + $("#twoMergeType").val() + "</twoMergeType>";
	szXml += "<threeMergeType>" + $("#threeMergeType").val() + "</threeMergeType>";
//	szXml += "<jpegQuality>" + sliderMergeJPEGQuality.getValue() + "</jpegQuality>";
	szXml += "<closeupIndex>" + $("#closeupIndex").val() + "</closeupIndex>";

    var scale = GetSliderValue('closeupScaleSlider');
    if (scale != '') {
        szXml += "<closeupScale>"+scale+"</closeupScale>"
    };

//	szXml += "<mergeMaxSize>" + $("#mergeMaxSize").val() + "</mergeMaxSize>";
	szXml += "<positionOffset>" + $("#positionOffset").val() + "</positionOffset></ImageMerge>";
	var xmlDoc = parseXmlFromStr(szXml);
	$.ajax({
		type: "put",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/ImageMerge",
		timeout: syncTime,
		processData: false,
		data: xmlDoc,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		complete:function(xhr, textStatus) {
			SaveState(xhr);
		}
    });
}
/*************************************************
Function:		SnapParamInitSlider
Description:	创建抓拍参数页面的滑动条
Input:			无
Output:			无
return:			无
*************************************************/
function SnapParamInitSlider() {
	/*sliderJPEGQuality = new neverModules.modules.slider(
	{targetId: "JpegQualitySlider",
	sliderCss: "imageslider1",
	barCss: "imageBar2",
	boxCss: "boxBar",
	bBox:true,
	min: 0,
	max: 100,
	hints:""
	});
	sliderJPEGQuality.create();
	
	sliderJPEGQuality.onchange = function () {
		sliderJPEGQuality.setTitle(sliderJPEGQuality.getValue());
	};*/

	sliderBrightnessThreld = new neverModules.modules.slider(
	{targetId: "BrightnessThreld",
	sliderCss: "imageslider1",
	barCss: "imageBar2",
	boxCss: "boxBar",
	bBox:true,
	min: 0,
	max: 100,
	hints:""
	});
	sliderBrightnessThreld.create();
	
	sliderBrightnessThreld.onchange = function (){
		sliderBrightnessThreld.setTitle(sliderBrightnessThreld.getValue());
	};
	
	sliderMergeJPEGQuality = new neverModules.modules.slider(
	{targetId: "MergeJpegQualitySlider",
	sliderCss: "imageslider1",
	barCss: "imageBar2",
	boxCss: "boxBar",
	bBox:true,
	min: 0,
	max: 100,
	hints:""
	}); 
	sliderMergeJPEGQuality.create();
	
	sliderMergeJPEGQuality.onchange = function () {
		sliderMergeJPEGQuality.setTitle(sliderMergeJPEGQuality.getValue());
	};

    InitSlider2();
}

/*************************************************
Function:		getCompressTypes
Description:	图片合成提示信息定义
Input:			无
Output:			无
return:			无
*************************************************/
var getCompressTypes = function(){
	var ret = {
		1: [{name: getNodeValue("oneMergeTypeOpt1"), value: 101},
			{name: getNodeValue("oneMergeTypeOpt2"), value: 102},
			{name: getNodeValue("oneMergeTypeOpt3"), value: 103},
			{name: getNodeValue("oneMergeTypeOpt4"), value: 104},
			{name: getNodeValue("NullMergeType"), value: 'noUse'}],
		2: [{name: getNodeValue("twoMergeTypeOpt1"), value: 201},
	        {name: getNodeValue("twoMergeTypeOpt2"), value: 202},

            {name: getNodeValue("twoMergeTypeOpt3"), value: 203},
            {name: getNodeValue("twoMergeTypeOpt4"), value: 204},
            {name: getNodeValue("twoMergeTypeOpt5"), value: 205},
            {name: getNodeValue("twoMergeTypeOpt6"), value: 206},
            {name: getNodeValue("twoMergeTypeOpt7"), value: 207},
            {name: getNodeValue("twoMergeTypeOpt8"), value: 208},
            {name: getNodeValue("twoMergeTypeOpt9"), value: 209},
            {name: getNodeValue("twoMergeTypeOpt10"), value: 210},

			{name: getNodeValue("NullMergeType"), value: 'noUse'}],	        
	    3: [{name: getNodeValue("threeMergeTypeOpt1"), value: 301},
		    {name: getNodeValue("threeMergeTypeOpt2"), value: 302},
		    {name: getNodeValue("threeMergeTypeOpt3"), value: 303},
		    {name: getNodeValue("threeMergeTypeOpt4"), value: 304},
		    {name: getNodeValue("threeMergeTypeOpt5"), value: 305},
		    {name: getNodeValue("threeMergeTypeOpt6"), value: 306},
		    {name: getNodeValue("threeMergeTypeOpt7"), value: 307},
		    {name: getNodeValue("threeMergeTypeOpt8"), value: 308},

            {name: getNodeValue("threeMergeTypeOpt9"), value: 309},
            {name: getNodeValue("threeMergeTypeOpt10"), value: 310},
            {name: getNodeValue("threeMergeTypeOpt11"), value: 311},
            {name: getNodeValue("threeMergeTypeOpt12"), value: 312},

            {name: getNodeValue("threeMergeTypeOpt13"), value: 313},
            {name: getNodeValue("threeMergeTypeOpt14"), value: 314},
            {name: getNodeValue("threeMergeTypeOpt15"), value: 315},
            {name: getNodeValue("threeMergeTypeOpt16"), value: 316},
            {name: getNodeValue("threeMergeTypeOpt17"), value: 317},
            {name: getNodeValue("threeMergeTypeOpt18"), value: 318},
            {name: getNodeValue("threeMergeTypeOpt19"), value: 319},
            {name: getNodeValue("threeMergeTypeOpt20"), value: 320},

			{name: getNodeValue("NullMergeType"), value: 'noUse'}]
	};
	for(var t in ret){
		if(ret[t]){
			for (var i = 0; i < ret[t].length; i++) {
				ret[t][i].pic = '../images/compress-type/'+ret[t][i].value+'.png';
			};	
		}
	}
	return ret;
};

/*************************************************
Function:		compTypeFocus
Description:	显示图片合成提示信息
Input:			ctId: 输入框ID
Output:			无
return:			无
*************************************************/
function compTypeFocus(ctId){
	return function(){
		$("input[type='radio'][cmt_value='"+$("#"+ctId).val()+"']").prop("defaultChecked", true).prop("checked",true);
		$.dialog({
			content: $('#'+ctId+'-div')[0],
			lock: true,
			ok: function(w){
				var o = $("#"+ctId+"-div :radio:checked:first");
				var value = o.attr("cmt_value");
				var name = o.attr("cmt_name");
				$("#"+ctId+"Str").val(name+"("+value+")");
				$("#"+ctId+"").val(value);
				
				return true;
			},
			okVal:getNodeValue("laSaveBtn"),
			cancel:function(){return true;},
			cancelVal:getNodeValue("laCancel")
		});
	}
}

/*************************************************
Function:		generateCompressTypeTip
Description:	显示图片合成提示信息
Input:			ctId: 输入框ID
                colnum: 每行显示个数
				compTypes: 合成类型
Output:			无
return:			无
*************************************************/
function generateCompressTypeTip(ctId, colnum, compTypes){
	var tableId = ctId+"-table";
	$("#" + tableId).html("");
	var tbc = [];
	tbc.push('<tr>');
	var col = 0;
	var cmtNum = compTypes.length;
	var eleNum;
	if(cmtNum % colnum == 0){
		eleNum = cmtNum;
	}else{
		eleNum = (Math.floor(cmtNum/colnum) + 1)*colnum;
	}
	for(var i=0; i<eleNum; i++){
		if(col >= colnum){
			col = 0;
			tbc.push('</tr><tr>');
		}
		if(i >= cmtNum){
			tbc.push('<td>&nbsp;</td>');
		}else{
			var c = compTypes[i];
			tbc.push('<td>');
			tbc.push('<img src="'+c.pic+'"/><br/>');
			tbc.push('<input type="radio" name="'+tableId+'_cmt_radio" cmt_value="'+c.value+'" cmt_name="'+c.name+'">'+c.name+'</input>')
			tbc.push('</td>');
		}
		col++;
	}
	tbc.push("</tr>");
	
	$('#'+tableId).append(tbc.join(""));
}

/*************************************************
 Function:		BaseVideoSettings
 Description:	构造函数，Singleton派生类
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function BaseVideoSettings() {
    SingletonInheritor.implement(this);
    this.g_presetModeParam = -1;
	this.icrModeType = -1;
}
SingletonInheritor.declare(BaseVideoSettings);


pr(BaseVideoSettings).initCSS = function(){
    VideoEventBind();
    InitVideoSlider();
    $("#chEnableDehaze").click(function()
    {
        if($(this).prop("checked"))
        {
            if(g_IsSupportDehazeLevel)
            {
                $("#dvDehazeLevel").show();
            }
        }
        else
        {
            $("#dvDehazeLevel").hide();
        }
    });
    //如果是球机
    if(window.parent.g_bIsIPDome)
    {
        $("#laIrisMode").attr("name", "laExposureType").html(getNodeValue("laExposureType"));
        $("#laShutter").attr("name", "laShutterLevel").html(getNodeValue("laShutterLevel"));
        $("#IrisMode").change(function()
        {
            if("auto"==this.value && "auto"==$("#DayNightFilterType").val())
            {
                if(g_IsSupportDayNightLevel)
                {
                    $("#DayToNightFilterLevel_tr").show();
                }
            }
            else
            {
                $("#DayToNightFilterLevel_tr").hide();
            }
            if(this.value != "ShutterFirst" && this.value != "manual")
            {
                $("#Shutter_tr").hide();
            }
            else
            {
                if(g_bSupportShutter)
                {
                    $("#Shutter_tr").show();
                }
            }
            if(this.value != "IrisFirst" && this.value != "manual")
            {
                $("#IrisLevel_tr").hide();
            }
            else
            {
                if(g_bSupportIris)
                {
                    $("#IrisLevel_tr").show();
                }
            }
            if(this.value == "manual" || this.value == "gainFirst")
            {
                if(isSupportGain)
                {
                    $("#VideoGain_tr").show();
                }
            }
            else
            {
                $("#VideoGain_tr").hide();
            }
        });
        $("#DayNightFilterType").change(function()
        {
            if("auto"==this.value && "auto"==$("#IrisMode").val())
            {
                if(g_IsSupportDayNightLevel)
                {
                    $("#DayToNightFilterLevel_tr").show();
                }
            }
            else
            {
                $("#DayToNightFilterLevel_tr").hide();
            }
        });
        $("#selSharpnessMode").change(function()
        {
            if(this.value == "manual")
            {
                if(g_bSupportSharpness)
                {
                    $("#Sharpness_tr").show();
                }
            }
            else
            {
                $("#Sharpness_tr").hide();
            }
            SetSharpness();
        });
    }
    else//非球机下不同的关联关系
    {
        $("#DayNightFilterType").change(function()
        {
            if(this.value != "auto")
            {
                if(isSupportGain)
                {
                    $("#VideoGain_tr").show();
                }
            }
            else
            {
                $("#VideoGain_tr").hide();
            }
        });
    }
}

ia(BaseVideoSettings).showPicAdvanceInfo = function(){

    if($('#picParamMainContentDiv').css('display') == 'none'){
        $('#picParamMainContentDiv').css('display','block');
    }else{
        $('#picParamMainContentDiv').css('display','none');
    }
    autoResizeIframe();
}

pr(BaseVideoSettings).update = function(){
    /*if ($("#CoverStartMapbutton").val() != getNodeValue('CoverStartMapbutton'))
    {
        HWP.SetDrawStatus(false);
    }*/

    $("#SaveConfigBtn").hide();
    $("#SetResultTips").html("");
    $('#picParamMainContentDiv').css('display','block');

    var that = this;
    g_transStack.clear();
    g_transStack.push(function() {
        that.setLxd(parent.translator.getLanguageXmlDoc(["SnapParam", "BaseVideoSettings"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
    }, true);
    g_transStack.push(function() { parent.translator.translatePage(that.getLxd(), document); }, false);
    GetFrontParaConfig(); //获取前端参数
    $('#imageRight1').parent().append("<div class='clear'></div>");

//    ia(BaseVideoSettings).showPicAdvanceInfo();
    $('#picParamMainContentDiv').css('display','none');
    autoResizeIframe();
}

pr(BaseVideoSettings).showAdvanceVideoSetting = function(){
    $('#imageLeft1').hide();
    $('#videoAdvanceSettingDiv').modal();
    ia(BaseVideoSettings).changeICRMode();

    $.ajax(
        {
            type: "GET",
            url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1",
            async: false,
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            success: function(xmlDoc, textStatus, xhr)
            {
                //是否启用ICR配置
                if($(xmlDoc).find("ICRCtrl_Preset").length > 0 || $(xmlDoc).find("ICRCtrl_Mode").length > 0){


                    $('#icrModeOpts').val($(xmlDoc).find('ICRMode').eq(0).text());

                    if($(xmlDoc).find("ICRCtrl_Preset").length > 0){  //预置点个数大于0

                        var presentLength = $(xmlDoc).find('PresetList').eq(0).find('Preset').length;

                        if(presentLength > 0){
                            var persetId = $(xmlDoc).find('PresetList').eq(0).find('PresetId').eq(0).text();
                            var presetVal = $(xmlDoc).find('PresetList').eq(0).find('PresetVal').eq(0).text();
                            if($('#icrModeOpts').val() == '1'){
                                $('#presetInfo1').val(presetVal);
                            }else if($('#icrModeOpts').val() == '2'){
                                $('#presetInfoList1').val(presetVal);
                            }else if($('#icrModeOpts').val() == '3'){
                                $('#presetInfoOpt1').val(presetVal);
                            }
                        }

                        $("<option id='presetTypeTR1Opt1' value='0'>" + getNodeValue("laNonePreset") + "</option><option id='presetTypeTR1Opt2' value='1'>" + getNodeValue("laPresetOne") + "</option>").appendTo('#presetTypeTR1');
                        $('#presetTypeTR1').val($(xmlDoc).find('timeSwitchList').eq(0).find('PresetNo').eq(0).text());
                        $('#ircStartTimeTR1_preset').val($(xmlDoc).find('timeSwitchList').eq(0).find('startHour').eq(0).text() + ':' + $(xmlDoc).find('timeSwitchList').eq(0).find('startMinute').eq(0).text());
                        $('#ircEndTimeTR1_preset').val($(xmlDoc).find('timeSwitchList').eq(0).find('endHour').eq(0).text() + ':' + $(xmlDoc).find('timeSwitchList').eq(0).find('endMinute').eq(0).text());

                        $("<option id='presetTypeTR2Opt1' value='0'>" + getNodeValue("laNonePreset") + "</option><option id='presetTypeTR2Opt2' value='1'>" + getNodeValue("laPresetOne") + "</option>").appendTo('#presetTypeTR2');
                        $('#presetTypeTR2').val($(xmlDoc).find('timeSwitchList').eq(0).find('PresetNo').eq(1).text());
                        $('#ircStartTimeTR2_preset').val($(xmlDoc).find('timeSwitchList').eq(0).find('startHour').eq(1).text() + ':' + $(xmlDoc).find('timeSwitchList').eq(0).find('startMinute').eq(1).text());
                        $('#ircEndTimeTR2_preset').val($(xmlDoc).find('timeSwitchList').eq(0).find('endHour').eq(1).text() + ':' + $(xmlDoc).find('timeSwitchList').eq(0).find('endMinute').eq(1).text());

                        $("<option id='presetTypeTR3Opt1' value='0'>" + getNodeValue("laNonePreset") + "</option><option id='presetTypeTR3Opt2' value='1'>" + getNodeValue("laPresetOne") + "</option>").appendTo('#presetTypeTR3');
                        $('#presetTypeTR3').val($(xmlDoc).find('timeSwitchList').eq(0).find('PresetNo').eq(2).text());
                        $('#ircStartTimeTR3_preset').val($(xmlDoc).find('timeSwitchList').eq(0).find('startHour').eq(2).text() + ':' + $(xmlDoc).find('timeSwitchList').eq(0).find('startMinute').eq(2).text());
                        $('#ircEndTimeTR3_preset').val($(xmlDoc).find('timeSwitchList').eq(0).find('endHour').eq(2).text() + ':' + $(xmlDoc).find('timeSwitchList').eq(0).find('endMinute').eq(2).text());

                        $("<option id='presetTypeTR4Opt1' value='0'>" + getNodeValue("laNonePreset") + "</option><option id='presetTypeTR4Opt2' value='1'>" + getNodeValue("laPresetOne") + "</option>").appendTo('#presetTypeTR4');
                        $('#presetTypeTR4').val($(xmlDoc).find('timeSwitchList').eq(0).find('PresetNo').eq(3).text());
                        $('#ircStartTimeTR4_preset').val($(xmlDoc).find('timeSwitchList').eq(0).find('startHour').eq(3).text() + ':' + $(xmlDoc).find('timeSwitchList').eq(0).find('startMinute').eq(3).text());
                        $('#ircEndTimeTR4_preset').val($(xmlDoc).find('timeSwitchList').eq(0).find('endHour').eq(3).text() + ':' + $(xmlDoc).find('timeSwitchList').eq(0).find('endMinute').eq(3).text());

                    }else if($(xmlDoc).find("ICRCtrl_Mode").length > 0){

                        $('#dayNightMode').val($(xmlDoc).find('PresetMode').eq(0).text());

                        $('#dayNightOptTR1').html("<option id='dayNightTR1Opt1' value='1'>" + getNodeValue('dayNightOpt1') + "</option><option id='dayNightTR1Opt2' value='2'>" + getNodeValue('dayNightOpt2') + "</option>");
                        $('#dayNightOptTR1').val($(xmlDoc).find('timeSwitchList').eq(0).find('timePresetMode').eq(0).text());
                        $('#ircStartTimeTR1').val($(xmlDoc).find('timeSwitchList').eq(0).find('startHour').eq(0).text() + ':' + $(xmlDoc).find('timeSwitchList').eq(0).find('startMinute').eq(0).text());
                        $('#ircEndTimeTR1').val($(xmlDoc).find('timeSwitchList').eq(0).find('endHour').eq(0).text() + ':' + $(xmlDoc).find('timeSwitchList').eq(0).find('endMinute').eq(0).text());

                        $('#dayNightOptTR2').html("<option id='dayNightTR2Opt1' value='1'>" + getNodeValue('dayNightOpt1') + "</option><option id='dayNightTR2Opt2' value='2'>" + getNodeValue('dayNightOpt2') + "</option>");
                        $('#dayNightOptTR2').val($(xmlDoc).find('timeSwitchList').eq(0).find('timePresetMode').eq(1).text());
                        $('#ircStartTimeTR2').val($(xmlDoc).find('timeSwitchList').eq(0).find('startHour').eq(1).text() + ':' + $(xmlDoc).find('timeSwitchList').eq(0).find('startMinute').eq(1).text());
                        $('#ircEndTimeTR2').val($(xmlDoc).find('timeSwitchList').eq(0).find('endHour').eq(1).text() + ':' + $(xmlDoc).find('timeSwitchList').eq(0).find('endMinute').eq(1).text());

                        $('#dayNightOptTR3').html("<option id='dayNightTR3Opt1' value='1'>" + getNodeValue('dayNightOpt1') + "</option><option id='dayNightTR3Opt2' value='2'>" + getNodeValue('dayNightOpt2') + "</option>");
                        $('#dayNightOptTR3').val($(xmlDoc).find('timeSwitchList').eq(0).find('timePresetMode').eq(2).text());
                        $('#ircStartTimeTR3').val($(xmlDoc).find('timeSwitchList').eq(0).find('startHour').eq(2).text() + ':' + $(xmlDoc).find('timeSwitchList').eq(0).find('startMinute').eq(2).text());
                        $('#ircEndTimeTR3').val($(xmlDoc).find('timeSwitchList').eq(0).find('endHour').eq(2).text() + ':' + $(xmlDoc).find('timeSwitchList').eq(0).find('endMinute').eq(2).text());

                        $('#dayNightOptTR4').html("<option id='dayNightTR4Opt1' value='1'>" + getNodeValue('dayNightOpt1') + "</option><option id='dayNightTR4Opt2' value='2'>" + getNodeValue('dayNightOpt2') + "</option>");
                        $('#dayNightOptTR4').val($(xmlDoc).find('timeSwitchList').eq(0).find('timePresetMode').eq(3).text());
                        $('#ircStartTimeTR4').val($(xmlDoc).find('timeSwitchList').eq(0).find('startHour').eq(3).text() + ':' + $(xmlDoc).find('timeSwitchList').eq(0).find('startMinute').eq(3).text());
                        $('#ircEndTimeTR4').val($(xmlDoc).find('timeSwitchList').eq(0).find('endHour').eq(3).text() + ':' + $(xmlDoc).find('timeSwitchList').eq(0).find('endMinute').eq(3).text());
                    }
                    ia(BaseVideoSettings).changeICRMode();

                }else{
                    $('#icrParamSettingDiv').hide();
                }

				ia(BaseVideoSettings).icrModeType = $('#icrModeOpts').val();
            }
        });
}

pr(BaseVideoSettings).cancelVideoSetting = function(){
    $('#imageLeft1').show();
    $.modal.impl.close();
	if (!g_bIsIE) {
		HWP.Stop(0);
		HWP.Play();
	}
}

/*************************************************
 Function:		saveVideoICRInfo
 Description:	设置图像参数ICR信息
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(BaseVideoSettings).saveVideoICRInfo = function(){

    $.ajax(
        {
            type: "GET",
            url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1",
            async: false,
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            success: function(xmlDoc, textStatus, xhr){
                if(ia(BaseVideoSettings).g_presetModeParam == 0){ //预置点 = 0 保存 ICRCtrl_Mode

                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('ICRMode').eq(0).text(ia(BaseVideoSettings).icrModeType);
                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('PresetMode').eq(0).text($('#dayNightMode').val());

                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('timePresetMode').eq(0).text($('#dayNightOptTR1').val());
                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('startHour').eq(0).text($('#ircStartTimeTR1').val().split(":")[0]);
                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('startMinute').eq(0).text($('#ircStartTimeTR1').val().split(":")[1]);
                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('endHour').eq(0).text($('#ircEndTimeTR1').val().split(":")[0]);
                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('endMinute').eq(0).text($('#ircEndTimeTR1').val().split(":")[1]);

                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('timePresetMode').eq(1).text($('#dayNightOptTR2').val());
                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('startHour').eq(1).text($('#ircStartTimeTR2').val().split(":")[0]);
                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('startMinute').eq(1).text($('#ircStartTimeTR2').val().split(":")[1]);
                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('endHour').eq(1).text($('#ircEndTimeTR2').val().split(":")[0]);
                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('endMinute').eq(1).text($('#ircEndTimeTR2').val().split(":")[1]);

                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('timePresetMode').eq(2).text($('#dayNightOptTR3').val());
                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('startHour').eq(2).text($('#ircStartTimeTR3').val().split(":")[0]);
                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('startMinute').eq(2).text($('#ircStartTimeTR3').val().split(":")[1]);
                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('endHour').eq(2).text($('#ircEndTimeTR3').val().split(":")[0]);
                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('endMinute').eq(2).text($('#ircEndTimeTR3').val().split(":")[1]);

                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('timePresetMode').eq(3).text($('#dayNightOptTR4').val());
                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('startHour').eq(3).text($('#ircStartTimeTR4').val().split(":")[0]);
                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('startMinute').eq(3).text($('#ircStartTimeTR4').val().split(":")[1]);
                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('endHour').eq(3).text($('#ircEndTimeTR4').val().split(":")[0]);
                    $(xmlDoc).find('ICRCtrl_Mode').eq(0).find('timeSwitchList').eq(0).find('endMinute').eq(3).text($('#ircEndTimeTR4').val().split(":")[1]);

                }else if(ia(BaseVideoSettings).g_presetModeParam == 1){ //预置点 > 0 保存 ICRCtrl_Preset

                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('ICRMode').eq(0).text($('#icrModeOpts').val());

                    if($('#icrModeOpts').val() == '1'){
                        $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('PresetList').eq(0).find('PresetVal').eq(0).text($('#presetInfo1').val());
                    }else if($('#icrModeOpts').val() == '2'){
                        $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('PresetList').eq(0).find('PresetVal').eq(0).text($('#presetInfoList1').val());
                    }else if($('#icrModeOpts').val() == '3'){
                        $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('PresetList').eq(0).find('PresetVal').eq(0).text($('#presetInfoOpt1').val());
                    }

                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('PresetNo').eq(0).text($('#presetTypeTR1').val());
                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('startHour').eq(0).text($('#ircStartTimeTR1_preset').val().split(':')[0]);
                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('startMinute').eq(0).text($('#ircStartTimeTR1_preset').val().split(':')[1]);
                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('endHour').eq(0).text($('#ircEndTimeTR1_preset').val().split(':')[0]);
                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('endMinute').eq(0).text($('#ircEndTimeTR1_preset').val().split(':')[1]);

                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('PresetNo').eq(1).text($('#presetTypeTR2').val());
                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('startHour').eq(1).text($('#ircStartTimeTR2_preset').val().split(':')[0]);
                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('startMinute').eq(1).text($('#ircStartTimeTR2_preset').val().split(':')[1]);
                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('endHour').eq(1).text($('#ircEndTimeTR2_preset').val().split(':')[0]);
                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('endMinute').eq(1).text($('#ircEndTimeTR2_preset').val().split(':')[1]);

                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('PresetNo').eq(2).text($('#presetTypeTR3').val());
                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('startHour').eq(2).text($('#ircStartTimeTR3_preset').val().split(':')[0]);
                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('startMinute').eq(2).text($('#ircStartTimeTR3_preset').val().split(':')[1]);
                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('endHour').eq(2).text($('#ircEndTimeTR3_preset').val().split(':')[0]);
                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('endMinute').eq(2).text($('#ircEndTimeTR3_preset').val().split(':')[1]);

                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('PresetNo').eq(3).text($('#presetTypeTR4').val());
                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('startHour').eq(3).text($('#ircStartTimeTR4_preset').val().split(':')[0]);
                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('startMinute').eq(3).text($('#ircStartTimeTR4_preset').val().split(':')[1]);
                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('endHour').eq(3).text($('#ircEndTimeTR4_preset').val().split(':')[0]);
                    $(xmlDoc).find('ICRCtrl_Preset').eq(0).find('timeSwitchList').eq(0).find('endMinute').eq(3).text($('#ircEndTimeTR4_preset').val().split(':')[1]);
                }
                var xmlObj = parseXmlFromStr(xmlToStr(xmlDoc));
                $.ajax({
                    type: "put",
                    url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1",
                    timeout: syncTime,
                    processData: false,
                    data: xmlObj,
                    beforeSend: function(xhr) {
                        xhr.setRequestHeader("If-Modified-Since", "0");
                        
                    },
                    complete:function(xhr, textStatus) {
						$('#imageLeft1').show();
					    $.modal.impl.close();
						SaveState(xhr);
						if (!g_bIsIE) {
							HWP.Stop(0);
							setTimeout(function() {
								HWP.Play();
							}, 10);	
						}
                    }
                });
            }
    });
}

pr(BaseVideoSettings).changeICRMode = function(){

    var modeStr = $('#icrModeOpts').val();
	ia(BaseVideoSettings).icrModeType = modeStr;
    if(modeStr == 0 || modeStr == 1){

        $('#dayNightModeDiv').hide();
        $('#presetInfoListDiv').hide();

        $('#timeSettingModeDiv').hide();
        $('#timeSettingPresetModeDiv').hide();

        if(modeStr == 1 && ia(BaseVideoSettings).g_presetModeParam == 1){
            $('#presetInfoContentDiv').show();
        }else{
            $('#presetInfoContentDiv').hide();
        }
    }else if(modeStr == 2){

        if(ia(BaseVideoSettings).g_presetModeParam == 0){

            $('#dayNightModeDiv').show();
            $('#presetInfoListDiv').hide();
        }else if(ia(BaseVideoSettings).g_presetModeParam == 1){

            $('#presetInfoListDiv').show();
            $('#dayNightModeDiv').hide();
        }

        $('#timeSettingModeDiv').hide();
        $('#timeSettingPresetModeDiv').hide();
        $('#presetInfoContentDiv').hide();
    }else if(modeStr == 3){

        $('#dayNightModeDiv').hide();
        $('#presetInfoListDiv').hide();

        $('#presetInfoContentDiv').hide();

        if(ia(BaseVideoSettings).g_presetModeParam == 0){
            $('#timeSettingModeDiv').show();
            $('#timeSettingPresetModeDiv').hide();
        }else if(ia(BaseVideoSettings).g_presetModeParam == 1){
            $('#timeSettingModeDiv').hide();
            $('#timeSettingPresetModeDiv').show();
        }else{
            $('#timeSettingModeDiv').hide();
            $('#timeSettingPresetModeDiv').hide();
        }
    }
}

/*************************************************
 机柜参数类
 *************************************************/
function CabinetParam() {
    this.m_szCabinetParamXml = null;
    this.m_iSelCabinetId = 0;
    SingletonInheritor.implement(this);
}
SingletonInheritor.declare(CabinetParam);

CabinetParam.changCabinetStatus = function(){
    if($('#isCabinetValid').prop("checked")){
        $("#cabinetParamContentDiv").css("display","block");
    }else{
        $("#cabinetParamContentDiv").css("display","none");
    }
}
/*************************************************
 Function:		update
 Description:	更新机柜配置信息
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(CabinetParam).update = function () {
    var that = this;
    this.m_iSelCabinetId = 0;
    $("#itemTypeSel").hide();
    if($.browser.msie && parseInt($.browser.version, 10) == 6){
        $("#taSnapOverlay").find("select").hide();
        $("#taSyncLight").find("select").hide();
        $("#taImageMerge").find("select").hide();
        $("#taSnapSetup").find("select").hide();
        $("#taTrafficParam").find("select").hide();
        $("#taIOSetting").find("select").hide();
        $("#taCabinetParam").find("select").show();
    }
    $('#SetResultTips').html('');
    $("#SaveConfigBtn").show();
    $("#AssociateIO").find('option').remove();
    HWP.Stop(0);
    g_transStack.clear();
    g_transStack.push(function () {
        that.setLxd(parent.translator.getLanguageXmlDoc(["SnapParam", "CabinetParam"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);
    $.ajax({
        type: "GET",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/cabinetParam",
        async: false,
        timeout: syncTime,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {
            that.m_szCabinetParamXml = xmlDoc;
            $("#isCabinetValid").prop("checked", $(xmlDoc).find("bCabinetEnable").eq(0).text() === "true");
            $("#cabinetId").empty();
            for(var i = 0; i < $(xmlDoc).find("cabinetId").length; i++) {   
                $("<option value='"+ $(xmlDoc).find("cabinetId").eq(i).text() + "'>" + $(xmlDoc).find("cabinetId").eq(i).text() +"</option>").appendTo("#cabinetId");
            }
            var ioOutputCount = ia(DeviceInfo).queryAlarmInNum();
            for(var i=0; i < ioOutputCount; i++){
                $("<option value='"+ (i+1) +"'>" + (i+1) + "</option>").appendTo("#AssociateIO");
            }
            $("<option value='255'>" + getNodeValue('laUnUsed') + "</option>").appendTo("#AssociateIO");
            $("#AssociateIO").val($(xmlDoc).find("AssociateIO").eq(0).text());
            $("#cabinetName").val($(xmlDoc).find("cabinetName").eq(0).text());
            $("#cabinetState").val($(xmlDoc).find("cabinetState").eq(0).text());
            $("#alarmIntervalTime").val($(xmlDoc).find("alarmIntervalTime").eq(0).text());

            CabinetParam.changCabinetStatus();
        }
    });
    autoResizeIframe();
}
/*************************************************
 Function:		GetcabinetIdParam
 Description:	获取单个机柜配置信息
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(CabinetParam).GetcabinetIdParam = function () {
    if($('#AssociateIO').val() != 255){
        if(!CheackStringLenthNull($("#cabinetName").val(),"cabinetNametips","lacabinetName",32)) {
            $("#cabinetName").focus();
            $.g.setField2('#cabinetId', ia(CabinetParam).m_iSelCabinetId+1);
            return;
        }
    }
    if(!CheackServerIDIntNum($("#alarmIntervalTime").val(),"alarmIntervalTimetips","laalarmIntervalTime",1,60)) {
        $("#alarmIntervalTime").focus();
        $.g.setField2('#cabinetId', ia(CabinetParam).m_iSelCabinetId+1);
        return;
    }

    //保存当前机柜参数
    $(ia(CabinetParam).m_szCabinetParamXml).find("AssociateIO").eq(ia(CabinetParam).m_iSelCabinetId).text($("#AssociateIO").val());
    $(ia(CabinetParam).m_szCabinetParamXml).find("cabinetName").eq(ia(CabinetParam).m_iSelCabinetId).text($("#cabinetName").val());
    $(ia(CabinetParam).m_szCabinetParamXml).find("cabinetState").eq(ia(CabinetParam).m_iSelCabinetId).text($("#cabinetState").val());
    $(ia(CabinetParam).m_szCabinetParamXml).find("alarmIntervalTime").eq(ia(CabinetParam).m_iSelCabinetId).text($("#alarmIntervalTime").val());

    //获取当前机柜参数
    var iIndex = parseInt($("#cabinetId").val())-1;
    ia(CabinetParam).m_iSelCabinetId = iIndex;
    $("#AssociateIO").val($(ia(CabinetParam).m_szCabinetParamXml).find("AssociateIO").eq(iIndex).text());
    $("#cabinetName").val($(ia(CabinetParam).m_szCabinetParamXml).find("cabinetName").eq(iIndex).text());
    $("#cabinetState").val($(ia(CabinetParam).m_szCabinetParamXml).find("cabinetState").eq(iIndex).text());
    $("#alarmIntervalTime").val($(ia(CabinetParam).m_szCabinetParamXml).find("alarmIntervalTime").eq(iIndex).text());
}
/*************************************************
 Function:		submit
 Description:	设置机柜参数信息
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(CabinetParam).submit = function () {

    if($('#AssociateIO').val() != 255){
        if(!CheackStringLenthNull($("#cabinetName").val(),"cabinetNametips","lacabinetName",32)) {
            $("#cabinetName").focus();
            return;
        }
        if(!CheackServerIDIntNum($("#alarmIntervalTime").val(),"alarmIntervalTimetips","laalarmIntervalTime",1,60)) {
            $("#alarmIntervalTime").focus();
            return;
        }
    }

    $(ia(CabinetParam).m_szCabinetParamXml).find("bCabinetEnable").eq(0).text($("#isCabinetValid").prop("checked").toString());
    //保存当前机柜参数
    var iIndex = parseInt($("#cabinetId").val())-1;
    $(ia(CabinetParam).m_szCabinetParamXml).find("AssociateIO").eq(iIndex).text($("#AssociateIO").val());
    $(ia(CabinetParam).m_szCabinetParamXml).find("cabinetName").eq(iIndex).text($("#cabinetName").val());
    $(ia(CabinetParam).m_szCabinetParamXml).find("cabinetState").eq(iIndex).text($("#cabinetState").val());
    $(ia(CabinetParam).m_szCabinetParamXml).find("alarmIntervalTime").eq(iIndex).text($("#alarmIntervalTime").val());

    var xmlObj = parseXmlFromStr(xmlToStr(ia(CabinetParam).m_szCabinetParamXml));
    $.ajax({
        type: "put",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/cabinetParam",
        timeout: 15000,
        processData: false,
        data: xmlObj,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        complete:function(xhr, textStatus) {
            SaveState(xhr);
        }
    });
}
// 其它参数页面
function OtherParam(){
    this.m_szOtherParamXml=null;
    SingletonInheritor.implement(this);
}
SingletonInheritor.declare(OtherParam);
pr(OtherParam).getOtherParamCap=function(){
    var that=this;
    $.ajax({
        url:m_lHttp+m_szHostName+":"+m_lHttpPort+"/PSIA/Custom/SelfExt/ITC/other/capabilities",
        type:"GET",
        async:false,
        timeout:syncTime,
        dataType: 'text',
        beforeSend:function(xhr){
            xhr.setRequestHeader("If-Modified-Since","0");
        },
        success:function(xmlDoc,textStatus,xhr){
            var $XmlDoc=$(parseXmlFromStr(xmlDoc));
            var closeUpSingleUploadEnable=$XmlDoc.find("closeUpSingleUploadEnable").eq(0).text();
            if("true"==closeUpSingleUploadEnable){
                $("#dvcloseUpSingleUpload").show();
            }else{
                $("#dvcloseUpSingleUpload").hide();
            }
            var nonMotoOSDModeEnable=$XmlDoc.find("nonMotoOSDModeEnable").eq(0).text();
            if("true"==nonMotoOSDModeEnable){
                $("#dvnonMotoOSDMode").show();
            }else{
                $("#dvnonMotoOSDMode").hide();
            }
            var nonPlateVehicleEnable=$XmlDoc.find("nonPlateVehicleEnable").eq(0).text();
            if("true"==nonPlateVehicleEnable){
                $("#dvnonPlateVehicle").show();
            }else{
                $("#dvnonPlateVehicle").hide();
            }
        }

    });
}

pr(OtherParam).update=function(){
    var that=this;

    g_transStack.clear();
    g_transStack.push(function () {
        that.setLxd(parent.translator.getLanguageXmlDoc(["SnapParam", "OtherParam"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);
    
    this.getOtherParamCap();
    $.ajax({
        url:m_lHttp+m_szHostName+":"+m_lHttpPort+"/PSIA/Custom/SelfExt/ITC/other",
        type:"GET",
        async:false,
        timeout:syncTime,
        dataType: 'text',
        beforeSend:function(xhr){
            xhr.setRequestHeader("If-Modified-Since","0");
        },
        success:function(xmlDoc,textStatus,xhr){
            that.m_szOtherParamXml=parseXmlFromStr(xmlDoc);
            var $xmlDoc=$(that.m_szOtherParamXml);
            $.each(["closeUpSingleUpload","nonMotoOSDMode","nonPlateVehicle"],function(i,n){
                $.g.setField2("#"+n,$xmlDoc.find(n).eq(0).text());
            });
        }

    });
    autoResizeIframe();
}
pr(OtherParam).submit=function(){
    var $xmlDoc=$(this.m_szOtherParamXml);
    $.each(["closeUpSingleUpload","nonMotoOSDMode","nonPlateVehicle"],function(i,n){
        $xmlDoc.find(n).eq(0).text($("#"+n).prop("checked").toString());
    });
    
    var xmlStr=xmlToStr(this.m_szOtherParamXml);
    $.ajax({
        url:m_lHttp+m_szHostName+":"+m_lHttpPort+"/PSIA/Custom/SelfExt/ITC/other",
        type:"put",
        timeout: 15000,
        processData: false,
        data:xmlStr,
        beforeSend:function(xhr){
            xhr.setRequestHeader("If-Modified-Since","0");
        },
        complete:function(xhr, textStatus){
            SaveState(xhr);
        }
    });
}

//车辆特征参数
function CarFeatureParam(){
    this.m_szCarFeatureParamXml=null;
    SingletonInheritor.implement(this);
}
SingletonInheritor.declare(CarFeatureParam);

pr(CarFeatureParam).isEnabledFaceDetect=function(){
    if($("#dvCarFeatureParam #isFaceDetect").prop("checked")){
        $('#dvCarFeatureParam #dvisFaceDetectParam').show();
    }else{
        $('#dvCarFeatureParam #dvisFaceDetectParam').hide();
    }
    autoResizeIframe();
}

pr(CarFeatureParam).isEnabledPhoneDetect=function(){
    if($("#dvCarFeatureParam #phoneCheckEnabled").prop("checked")){
        $('#dvCarFeatureParam #dvsensitiveness').show();
    }else{
        $('#dvCarFeatureParam #dvsensitiveness').hide();
    }
    autoResizeIframe();
}

pr(CarFeatureParam).update=function(){
    var that=this;

    g_transStack.clear();
    g_transStack.push(function () {
        that.setLxd(parent.translator.getLanguageXmlDoc(["SnapParam", "CarFeatureParam"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);

    $.ajax({
        url:m_lHttp+m_szHostName+":"+m_lHttpPort+"/PSIA/Custom/SelfExt/ITC/carFeatureParam",
        type:"GET",
        async:false,
        timeout:syncTime,
        dataType: 'text',
        beforeSend:function(xhr){
            xhr.setRequestHeader("If-Modified-Since","0");
        },
        success:function(xmlDoc,textStatus,xhr){
            that.m_szCarFeatureParamXml=parseXmlFromStr(xmlDoc);
            var $xmlDoc=$(that.m_szCarFeatureParamXml);
            $.each(["colorEnabled","carLogoEnabled","safetyBeltEnabled",
                /*"hostSunVisorEnabled","viceSunVisorEnabled",*/
                "SunVisorEnabled","highPollutVehicleEnabled",
                "dangerousVehicleEnabled","subBrandEnabled","isFaceDetect",
                "phoneCheckEnabled","sensitiveness","nonMotorFaceEnabled",
                "hostFaceEnabled","viceFaceEnabled","faceImgScale","faceImgRatio",
                "DrawFaceRectEnabled","faceImgBrightenEnhenceEnabled","faceImgBrightenEnhenceLevel",
                "coatColorEnabled","hangerEnabled"
                ],function(i,n){
                $.g.setField2("#"+n,$xmlDoc.find(n).eq(0).text());
            });
            $.g.setField2("#dvCarFeatureParam #faceImgOutputMode",$xmlDoc.find("outputCtrl").eq(0).find("faceImgOutputMode").eq(0).text());
            
            pr(CarFeatureParam).isEnabledFaceDetect();
            pr(CarFeatureParam).faceImgBrightenEnhenceEnabledClick();
            pr(CarFeatureParam).isEnabledPhoneDetect();
        }

    });
    autoResizeIframe();
}

//人脸提亮功能点击事件
pr(CarFeatureParam).faceImgBrightenEnhenceEnabledClick=function(){
    if($("#faceImgBrightenEnhenceEnabled").prop("checked")){
        $("#dvfaceImgBrightenEnhenceLevel").show();
    }else{
        $("#dvfaceImgBrightenEnhenceLevel").hide();
    }
}

pr(CarFeatureParam).submit=function(){
    var $xmlDoc=$(this.m_szCarFeatureParamXml);
    $.each(["colorEnabled","carLogoEnabled","safetyBeltEnabled",
                /*"hostSunVisorEnabled","viceSunVisorEnabled",*/
                "SunVisorEnabled","highPollutVehicleEnabled",
                "dangerousVehicleEnabled","subBrandEnabled","isFaceDetect",
                "phoneCheckEnabled","nonMotorFaceEnabled",
                "hostFaceEnabled","viceFaceEnabled","DrawFaceRectEnabled","faceImgBrightenEnhenceEnabled",
                "coatColorEnabled","hangerEnabled"
        ],function(i,n){
        $xmlDoc.find(n).eq(0).text($("#dvCarFeatureParam #"+n).prop("checked").toString());
    });
    $.each(["faceImgScale","faceImgRatio","faceImgBrightenEnhenceLevel","sensitiveness"],function(i,n){
        $xmlDoc.find(n).eq(0).text($.g.getEleVal("#dvCarFeatureParam #"+n));
    });
    $xmlDoc.find("outputCtrl").eq(0).find("faceImgOutputMode").eq(0).text($("#dvCarFeatureParam #faceImgOutputMode").val());
    var xmlStr=xmlToStr(this.m_szCarFeatureParamXml);
    $.ajax({
        url:m_lHttp+m_szHostName+":"+m_lHttpPort+"/PSIA/Custom/SelfExt/ITC/carFeatureParam",
        type:"put",
        timeout: 15000,
        processData: false,
        data:xmlStr,
        beforeSend:function(xhr){
            xhr.setRequestHeader("If-Modified-Since","0");
        },
        complete:function(xhr, textStatus){
            SaveState(xhr);
        }
    });
}

function GPSParam() {
    this.m_szGPSParamXml = null;
    SingletonInheritor.implement(this);
}
SingletonInheritor.declare(GPSParam);

pr(GPSParam).update = function(){
    $("#SaveConfigBtn").show();

    var that = this;
    HWP.Stop(0);
    g_transStack.clear();
    g_transStack.push(function () {
        that.setLxd(parent.translator.getLanguageXmlDoc(["SnapParam", "GPSParam"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);

    $.ajax({
        type: "GET",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/GPSParam",
        timeout: syncTime,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {
            that.m_szGPSParamXml = xmlDoc;
            var $xmlDoc = $(that.m_szGPSParamXml);

            // $.each(["emptyGPSInfo","GPSLocatingEnable","timingInterval","delGPSLoadInfoNo",
            //         "delStartPos","delEndPos","locateDisErr","GPSWorkMode","errRange",
            //          "entringInterval","locatingInterval"], function(i, n){
            //     $.g.setField2('#dvGPSParam #'+n, $xmlDoc.find(n).text());
            // });

            $.each(["GPSLocatingEnable","timingInterval",
                    "locateDisErr","GPSWorkMode","errRange",
                     "entringInterval","locatingInterval",
                     "bGpsLocatinfoFilter","criticalError","filteringError"], function(i, n){
                $.g.setField2('#dvGPSParam #'+n, $xmlDoc.find(n).text());
            });
            //$.g.setField2('#dvGPSParam #'+n,$xmlDoc.find(n).text()=="1"?true:false);
            that.GPSWorkModeChanged();
        }
    });


    $('#emptyGPSInfo').unbind().click(function(){
        var xml = '<?xml version="1.0" encoding="utf-8"?>';
        xml += '<clearGPS><clearGPSInfo>1</clearGPSInfo></clearGPS>';

        $.ajax({
            type: "put",
            url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/clearGPS",
            timeout: 15000,
            processData: false,
            data: xml,
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            complete:function(xhr, textStatus) {
                var resXml = xhr.responseText;
                var statusCode = $(parseXmlFromStr(resXml)).find('statusCode').text();
                if (statusCode == '1') {
                    alert("已清空GPS信息。");
                }else{
                    alert("清空GPS信息失败！");
                }
            }
        });
    });

    $('#deleteGPSInfo').unbind().click(function(){
        if (!that.validateForm('opt')) {
            return;
        };

        // var delRoadStartPos=parseInt($("#delRoadStartPos").val());
        // var delRoadEndPos=parseInt($("#delRoadEndPos").val());
        // if(delRoadStartPos>delRoadEndPos){
        //     $('#delRoadEndPostips').html("");
        // }

        var xml = '<?xml version="1.0" encoding="utf-8"?><DelRoadInfo>';
        $.each(['delRoadNum', 'delRoadStartPos', 'delRoadEndPos'], function(i, n){
            xml += '<'+n+'>'+$('#'+n).val()+'</'+n+'>';
        });
        xml += '</DelRoadInfo>';

        $.ajax({
            type: "put",
            url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/DelRoadInfo",
            timeout: 15000,
            processData: false,
            data: xml,
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            complete:function(xhr, textStatus) {
                var resXml = xhr.responseText;
                var statusCode = $(parseXmlFromStr(resXml)).find('statusCode').text();
                if (statusCode == '1') {
                    alert("删除成功！");
                }else{
                    alert("删除失败！");
                }
            }
        });
    })
    autoResizeIframe();
}

pr(GPSParam).validateForm = function(fieldType){
    var res = true;

    var warnTipsIcon = '<img src="../images/config/tips.png" class="verticalmiddle">&nbsp;';

    var sel = '#dvGPSParam *[range-field]';
    if (fieldType) {
        sel = '#dvGPSParam *[range-field='+fieldType+']';
    };

    $(sel).each(function(){
        var min = $(this).attr('min');
        var max = $(this).attr('max');

        var v = $(this).val();

        var id = $(this).attr('id');

        $('label#'+id+'tips').html('');

        if ($.trim(v) == '') {
            res = false;

            $('label#'+id+'tips').html(warnTipsIcon+"不能为空");
            return true;
        }

        if (min && max) {
            min = Number(min);
            max = Number(max);
            v = Number(v);

            if (v > max || v < min) {
                res = false;
                $('label#'+id+'tips').html(warnTipsIcon+"范围["+min+'-'+max+']');
            };
        }
    })

    return res;
}

pr(GPSParam).submit = function(){
    if (!this.validateForm('param')) {
        return;
    };

    var $xmlDoc = $(this.m_szGPSParamXml);

    $.each(["timingInterval","locateDisErr","GPSWorkMode","errRange",
             "entringInterval","locatingInterval",
             "criticalError","filteringError"], function(i, n){
        var v = $('#dvGPSParam #'+n).val();
        $xmlDoc.find(n).text(v);
    });
    $xmlDoc.find('bGpsLocatinfoFilter').text($('#dvGPSParam #bGpsLocatinfoFilter').prop('checked')?"1":"0");

    $xmlDoc.find('GPSLocatingEnable').text($('#dvGPSParam #GPSLocatingEnable').prop('checked') ? "1" : "0");

    var xml = xmlToStr(this.m_szGPSParamXml);
    $.ajax({
        type: "put",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/GPSParam",
        timeout: 15000,
        processData: false,
        data: xml,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        complete:function(xhr, textStatus) {
            SaveState(xhr);
        }
    });
}

pr(GPSParam).GPSWorkModeChanged = function(){
    var v = $('#GPSWorkMode').val();  // 2: 定位模式

    $('#entringIntervalWrapper').find('*').prop('disabled', v == 2);
    $('#locatingIntervalWrapper').find('*').prop('disabled', v != 2);    
}

