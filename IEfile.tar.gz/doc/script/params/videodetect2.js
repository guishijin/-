



/**
 * 信号灯
 * @return 
 */
(function(){
	Raphael.fn.SeLight = function (opts) {
		var paper = this;
		if (opts.isLight) {
			var light = opts;
			light.draw();
			return light;
		};

		if (!_.every(['type', 'region', 'text', 'bkImg'], function(ele){
				var t = typeof opts[ele];
				if (t != 'undefined' && opts[ele] != null) {
					return true;
				}
				return false;
			})
		) {
			log('SeLight parameter is not enough !');
			return;
		};

		if (!_.every(['directionCount', 'lightCount', 'isVertical'], function(ele){
				var t = typeof opts[ele];
				if (t != 'undefined' && opts[ele] != null) {
					return true;
				}
				return false;
			})
		) {
			log('SeLight parameter is not enough !');
			return;
		};

		var divId = 'paper';
		if (opts.divId) {
			divId = opts.divId;
		};

		var light = {
			uuid: Raphael.createUUID(),
			shapeType: opts.shapeType,
			isLight: true,

			type: opts.type.toLowerCase(),
			region: opts.region,
			text: opts.text,
			color: '#ff0000',

			bkImg: opts.bkImg,
			divId: divId,

			directionCount: opts.directionCount,
			lightCount: opts.lightCount,
			isVertical: opts.isVertical,

			draw: function () {
				var self = this;
				var color = this.color;
				
				if (self.bkImg.mode == 'full') {
					this._drawInFullMode();
				}else{
					this._drawInDragMode();
				}
			},

			_drawInFullMode: function () {
				var self = this;
				var bkImg = this.bkImg;

				if (bkImg.mode != 'full') {
					return;
				};

				var paperWidth = bkImg.paperWidth;
				var paperHeight = bkImg.paperHeight;

				var imgSrc = getLightPng(this.directionCount, 
					this.lightCount, this.isVertical);
				if (!imgSrc) {
					log("imgSrc is empty !");
					return;
				};

				var il = this.region.left * paperWidth;
				var it = this.region.top * paperHeight;
				var ir = this.region.right * paperWidth;
				var ib = this.region.bottom * paperHeight;

				var iw = ir - il;
				var ih = ib - it;

				self._drawText((il+ir)/2, it-10);

				self._drawInner(il, it, iw, ih);
			},
			_drawText: function(x, y){
				if (!this.txt) {
					this.txt = paper.text(0,0,this.text);
					this.txt.attr({
						//'fill': color,
						'fill': '#ffff00',
						'font-size': 12
					});
				}
				this.txt.attr({
					x: x,
					y: y
				})
			},
			_drawInDragMode: function () {
				var self = this;
				var bkImg = this.bkImg;

				if (bkImg.mode == 'full') {
					return;
				};

				var offsetX = bkImg.offsetX;
				var offsetY = bkImg.offsetY;

				var bkImageWidth = bkImg.imageWidth;
				var bkImageHeight = bkImg.imageHeight;

				var il = this.region.left * bkImageWidth - offsetX;
				var it = this.region.top * bkImageHeight - offsetY;
				var ir = this.region.right * bkImageWidth - offsetX;
				var ib = this.region.bottom * bkImageHeight - offsetY;

				var iw = ir - il;
				var ih = ib - it;

				self._drawText((il+ir)/2, it-10);

				self._drawInner(il, it, iw, ih);
			},

			_drawInner: function (x, y, w, h) {
				var imgSrc = getLightPng(this.directionCount, 
					this.lightCount, this.isVertical);
				if (!imgSrc) {
					log("imgSrc is empty !");
					return;
				};

				var self = this;

				if (!this.img) {
					this.img = paper.image(imgSrc, x, y, w, h);
					this.img.drag(function(dx, dy, mx, my) {
						if (!self.selected) {
							return;
						};

						if (self.bkImg.mode == 'full') {
							return;
						}

						var tx = dx - this.odx;
						var ty = dy - this.ody;
						
						this.ody = dy;
						this.odx = dx;

						var imageWidth = self.bkImg.imageWidth;
						var imageHeight = self.bkImg.imageHeight;

						var ftx = tx/imageWidth;
						var fty = ty/imageHeight;

						self.region.left += ftx;
						self.region.right += ftx;
						self.region.top += fty;
						self.region.bottom += fty;

						self.draw();
					},
					function(x, y) {
						this.ody = 0;
						this.odx = 0;
					},
					function() {

					}).hover(function(){
						if (self.selected 
							&& self.bkImg.mode == 'drag') {
							$('#'+self.divId).css('cursor', 'move');	
						};
					}, function(){
						$('#'+self.divId).css('cursor', 'default');
					});
				}else{
					this.img.attr({
						src: imgSrc,
						x: x,
						y: y,
						width: w,
						height: h
					});
				}

				this._drawCircles(x, y, w, h);
			},

			_drawCircles: function (x, y, w, h) {
				if (!this.selected 
					|| this.bkImg.mode == 'full') {
					if (this.circles) {
						_.each(this.circles, function(ele){
							ele.remove();
						});
						this.circles = false;
					};
					return;
				};

				var self = this;
				var bkImageWidth = self.bkImg.imageWidth;
				var bkImageHeight = self.bkImg.imageHeight;

				if (!this.circles) {
					this.circles = [];
					var leftTopCC = paper.circle(x, 
							y, 5).attr({
								'fill': self.color,
								'stroke-width': 0,
								'cursor': 'nw-resize'
							});
					leftTopCC.drag(function(dx, dy, mx, my){
						if (self.bkImg.mode == 'full') {
							return;
						};
						var tx = dx - this.odx;
						var ty = dy - this.ody;		

						var left = self.region.left	* bkImageWidth;
						var right = self.region.right * bkImageWidth;
						var top = self.region.top * bkImageHeight;
						var bottom = self.region.bottom * bkImageHeight;

						if (tx >= right-left) {
							tx = right-left-1;
						};		
						if (ty >= bottom-top) {
							ty = bottom-top-1;
						};		

						var rleft = left + tx;
						var rtop = top + ty;

						self.region.left = rleft/bkImageWidth;
						self.region.top = rtop/bkImageHeight;

						this.odx = tx+this.odx;
						this.ody = ty+this.ody;

						self.draw();
					}, function(x,y){
						this.odx = 0;
						this.ody = 0;
					}, function(evt){
					
					});

					this.circles[0] = leftTopCC;

					var color = self.color;
					var rightTopCC = paper.circle(x+w, 
							y, 5).attr({
								'fill': color,
								'stroke-width': 0,
								'cursor': 'ne-resize'
							});
					rightTopCC.drag(function(dx, dy, mx, my){
						var tx = dx - this.odx;
						var ty = dy - this.ody;			

						var left = self.region.left	* bkImageWidth;
						var right = self.region.right * bkImageWidth;
						var top = self.region.top * bkImageHeight;
						var bottom = self.region.bottom * bkImageHeight;

						if (-tx >= right-left) {
							tx = left-right+1;
						};		
						if (ty >= bottom-top) {
							ty = bottom-top-1;
						};		

						var rtop = top + ty;
						var rright = right + tx;
						
						self.region.right = rright/bkImageWidth;
						self.region.top = rtop/bkImageHeight;

						this.odx = tx+this.odx;
						this.ody = ty+this.ody;

						self.draw();
					}, function(x,y){
						this.odx = 0;
						this.ody = 0;
					}, function(evt){
					
					});
					this.circles[1] = rightTopCC;

					var rightBottomCC = paper.circle(x+w, 
							y+h, 5).attr({
								'fill': color,
								'stroke-width': 0,
								'cursor': 'nw-resize'
							});
					rightBottomCC.drag(function(dx, dy, mx, my){
						var tx = dx - this.odx;
						var ty = dy - this.ody;			

						var left = self.region.left	* bkImageWidth;
						var right = self.region.right * bkImageWidth;
						var top = self.region.top * bkImageHeight;
						var bottom = self.region.bottom * bkImageHeight;

						if (-tx >= right-left) {
							tx = left-right+1;
						};		
						if (-ty >= bottom-top) {
							ty = top-bottom+1;
						};		

						var rright = right + tx;
						var rbottom = bottom + ty;

						self.region.right = rright/bkImageWidth;
						self.region.bottom = rbottom/bkImageHeight;
						
						this.odx = tx+this.odx;
						this.ody = ty+this.ody;

						self.draw();
					}, function(x,y){
						this.odx = 0;
						this.ody = 0;
					}, function(evt){
					
					});
					this.circles[2] = rightBottomCC;

					var leftBottomCC = paper.circle(x, 
							y+h, 5).attr({
								'fill': color,
								'stroke-width': 0,
								'cursor': 'ne-resize'
							});
					leftBottomCC.drag(function(dx, dy, mx, my){
						var tx = dx - this.odx;
						var ty = dy - this.ody;			

						var left = self.region.left	* bkImageWidth;
						var right = self.region.right * bkImageWidth;
						var top = self.region.top * bkImageHeight;
						var bottom = self.region.bottom * bkImageHeight;

						if (tx >= right-left) {
							tx = right-left-1;
						};		
						if (-ty >= bottom-top) {
							ty = top-bottom+1;
						};		
						var rleft = left + tx;
						var rbottom = bottom + ty;

						self.region.left = rleft/bkImageWidth;
						self.region.bottom = rbottom/bkImageHeight;
						
						this.odx = tx+this.odx;
						this.ody = ty+this.ody;

						self.draw();
					}, function(x,y){
						this.odx = 0;
						this.ody = 0;
					}, function(evt){
					
					});

					this.circles[3] = leftBottomCC;
				}else{
					var left = x, right = x+w, top=y, bottom=y+h;
					this.circles[0].attr({
						cx: left,
						cy: top
					});
					this.circles[1].attr({
						cx: right,
						cy: top
					});
					this.circles[2].attr({
						cx: right,
						cy: bottom
					});
					this.circles[3].attr({
						cx: left,
						cy: bottom
					});
				}
			},
			remove: function () {
				if (this.circles) {
					_.each(this.circles, function(ele){
						ele.remove();
					});
					delete this.circles;	
				};

				if (this.txt) {
					this.txt.remove();
					this.txt = false;
				};
				
				if (this.img) {
					this.img.remove();
					this.img = false;
				};
				
			},
			select: function  () {
				this.selected = true;
				this.draw();
			}, 
			unselect: function () {
				this.selected = false;
				this.draw();
			}
		}

		return light;
	}


	/****************************************************************/
	
})();

/*
	绘图
 */
(function(){
	Raphael.fn.SeVD3 = function(opts){
		var paper = this;
		if (opts.isVD) {
			var light = opts;
			light.draw();
			return light;
		}

		var params = [
			'src'  		// 图片路径
			,'mode'			// 背景模式
		];
		if (!_.every(params, function(ele){
			var t = typeof opts[ele];
			if (t != 'undefined' && opts[ele] != null) {
				return true;
			}
			return false;
		})) {
			log('SeVD3 parameter is not enough !!!');
			return;
		};

		var divId = 'paper';
		if (opts.divId) {
			divId = opts.divId;
		};

		return {
			isVD: true,
			type: 'vd',

			divId: divId,

			Lights:{},
			img: null,
			mode: opts.mode,
			src: opts.src,

			offsetX: opts.offsetX ? opts.offsetX : 0,
			offsetY: opts.offsetY ? opts.offsetY : 0,
			loadComplete: opts.loadComplete ? opts.loadComplete : function(){},


			draw: function(){
				var paperWidth = paper.width;
				var paperHeight = paper.height;

				this.paperWidth = paperWidth;
				this.paperHeight = paperHeight;

				var self = this;

				this._loadImage(function(imgObj){					
					var fullWidth = imgObj.width;
					var fullHeight = imgObj.height;

					self.imageWidth = fullWidth;
					self.imageHeight = fullHeight;

					self._drawBkImage();
					self.drawLights();
				})

			},

			_initImgEvt: function(){
				var img = this.img;
				var self = this;

				var fullWidth = this.imageWidth;
				var fullHeight = this.imageHeight;

				var maxWidth = this.paperWidth;
				var maxHeight = this.paperHeight;

				img.toBack().drag(function(dx, dy, mx, my) {
					if (self.mode =='full') {
						return;
					};
					var tx = dx - this.odx;
					var ty = dy - this.ody;
					
					if (tx>self.offsetX) {
						tx = self.offsetX;
					}else if(fullWidth - self.offsetX - maxWidth + tx < 0){
						tx = maxWidth + self.offsetX - fullWidth;
					}
					if (ty > self.offsetY) {
						ty = self.offsetY;
					}else if(fullHeight - self.offsetY - maxHeight + ty < 0){
						ty = maxHeight + self.offsetY - fullHeight;
					}

					self.offsetX -= tx;
					self.offsetY -= ty;

					//log('tx='+tx+', ty='+ty+', offsetX='+
					//	self.offsetX+', offsetY='+self.offsetY);

					this.odx = tx + this.odx;
					this.ody = ty + this.ody;
					
					self._dragBkImage(tx, ty);

					self.draw();
				}, function(x, y) {
					if (self.mode == 'full') {
						return;
					};
					this.ody = 0;
					this.odx = 0;
				}, function() {

				}).mousemove(function(evt){
					if (!self.readyToDrag) {
						return;
					}

					var pos = getPos(evt, '#'+self.divId);

					var rw = self.paperWidth*self.paperWidth/self.imageWidth;
					var rh = self.paperHeight*self.paperHeight/self.imageHeight;

					var rx = pos.x - rw/2;
					var ry = pos.y - rh/2;


					if (!self.zoomRange) {
						self.zoomRange = paper.rect(rx, ry, rw, rh);
						self.zoomRange.attr({
							'stroke': '#ff0000',
							'stroke-width': 2,
							'stroke-dasharray': "."
						});
					}else{
						self.zoomRange.attr({
							x: rx,
							y: ry,
							width: rw,
							height: rh
						});
					}					
				}).click(function(evt){
					var pos = getPos(evt, '#'+self.divId);
					var rx = pos.x;
					var ry = pos.y;

					if (self.readyToDrag) {
						var rw = self.paperWidth*self.paperWidth/self.imageWidth;
						var rh = self.paperHeight*self.paperHeight/self.imageHeight;

						self.offsetX = (rx-rw/2)/self.paperWidth*self.imageWidth;
						self.offsetY = (ry-rh/2)/self.paperHeight*self.imageHeight;

						if (self.zoomRange) {
							self.zoomRange.remove();
							delete self.zoomRange;
						};

						self.mode = 'drag';
						self.readyToDrag = false;

						if (self.changeToDragModeCallback) {
							self.changeToDragModeCallback();
						};

						self.draw();
					}
					
				});
			},

			_loadImage: function(callback){
				var imgObj = this.imgObj;

				var self = this;

				if (!this.imgLoaded || !imgObj) {
					this.imgLoaded = false;
				};

				if (!this.imgLoaded) {
					imgObj = new Image();					

					if (imgObj.loadComplete) {
						//callback(imgObj);
						//self.loadComplete(true);	
					};

					imgObj.onload = function(){
						callback(imgObj);
						self.loadComplete(true);	
						self.imgLoaded = true;		
						self.imgObj = imgObj;	
					};

					imgObj.onerror = function(){
						self.loadComplete(false);
						self.imgLoaded = false;		
					}

					imgObj.src = this.src;
				}else{
					callback(imgObj);
				}
			},

			_drawBkImage: function(){
				var self = this;
				
				var fullWidth = this.imageWidth;
				var fullHeight = this.imageHeight;

				var maxWidth = this.paperWidth;
				var maxHeight = this.paperHeight;

				if (self.mode == 'full') {
					if (!self.img) {
						self.img = paper.image(self.src, 0, 0, self.paperWidth, self.paperHeight);
						self._initImgEvt();
					}else{
						self.img.attr({
							x:0,
							y:0,
							width: self.paperWidth,
							height: self.paperHeight
						});
					}

					self.imageScaleW = self.paperWidth/fullWidth;
					self.imageScaleH = self.paperHeight/fullHeight;		
				}else {
					var offsetX = self.offsetX;
					var offsetY = self.offsetY;

					//log("offsetY="+offsetY)

					if (!self.img) {
						self.img = paper.image(self.src, -offsetX, 
							-offsetY, fullWidth, fullHeight);
						// self.img.attr({
						// 	'cursor': 'pointer'
						// });
						self._initImgEvt();
					}else{
						self.img.attr({
							x: -offsetX,
							y: -offsetY,
							width: fullWidth,
							height: fullHeight
						});
					}
				};
			},

			_dragBkImage: function(dx, dy){

			},

			reset: function(){

			},

			changeMode: function(tMode, callback){
				if (this.mode == tMode) {
					return;
				}
				if (tMode == 'full') {
					this.mode = 'full';
					this.draw();
				}

				if (tMode == 'drag') {
					if (callback) {
						this.changeToDragModeCallback = callback;
					}else{
						this.changeToDragModeCallback = null;
					}
					this.readyToDrag = true;
				}
			},

			remove: function(){
				if (this.img) {
					this.img.remove();
					this.img = null;
				};
			},

			//新增信号灯
			//lightIdx:1,
				// region: {
				// 	left:,   // 0.xxx
				// 	right:
				// 	top:
				// 	bottom:
				// }，
				// isVertical: false,
				// lightCount: 3,
				// directionCount: 1
			addLights: function(arr){
				var self = this;
				_.each(arr, function (ele) {
					var lightIdx = ele.lightIdx;
					if (self.Lights[lightIdx]) {
						self.Lights[lightIdx].remove();
					}
					var light =  paper.SeLight({
						type: 'light',
						region: ele.region,
						text: '区域'+ele.lightIdx,
						isVertical: ele.isVertical,
						lightCount: ele.lightCount,
						directionCount: ele.directionCount,
						bkImg: self
					});
					self.Lights[lightIdx] = light;
				});
			},

			selectLight: function(idx){
				this.unselectLights();
				if (this.Lights[idx]) {
					this.Lights[idx].select();
				};
			},

			unselectLights: function(){
				_.each(this.Lights, function (v, k) {
					if (v && v.unselect) {
						v.unselect();
					};
				});
			},

			removeLight: function(idx){
				var l = this.Lights[idx];
				if (l && l.remove) {
					l.remove();
				};
				this.Lights[idx] = undefined;
			},

			changeLight:function (idx, info){
				
			},

			drawLight: function(idx){
				var light = this.Lights[idx];
				if (light) {
					light.draw();
				};
			},
			drawLights: function () {
				_.each(this.Lights, function (v, k) {
					if (v.draw) {
						v.draw();
					};
				});
			}
		}

	}
})();

var lastSelIdx = -1;
(function (window) {
	var VideoLight = {};
	var paper;
	var vd;

	VideoLight.isVerticalMap = {};

	function initPage(){
		var $xml = $(personRunRedLightTriggerMode.PersonObj);
		
		$('#lightIdx').find('option').remove();
		$xml.find('videoDetectLight').each(function (i, n) {
			var $light = $(n);
			var lightId = $light.find('videoDetectLightId').eq(0).text();
			
			$('#lightIdx').append('<option value="'+lightId+'">区域'+' '+lightId+'</option>');	
		});		

		$('#addLightBtn').prop('disabled', true).addClass('btnDisabled');
	}

	function initLights(){
		var $xml = $(personRunRedLightTriggerMode.PersonObj);

		VideoLight.isVerticalMap = {};

		var lightArr = [];
		$xml.find('videoDetectLight').each(function (i, n) {
			var $light = $(n);
			var lightId = $light.find('videoDetectLightId').eq(0).text();

			var left = parseInt($light.find('positionLeft').text(), 10);
			var right = parseInt($light.find('positionRight').text(), 10);
			var top = parseInt($light.find('positionTop').text(), 10);
			var bottom = parseInt($light.find('positionBottom').text(), 10);

			if (_.every([left, right, top, bottom], function(ele){
				return ele == 0;
			})) {

			}else{
				var directions = [];
				if ($light.find('leftLight').text() == "true") {
					directions.push('left');
				};
				if ($light.find('straightLight').text() == "true") {
					directions.push('straight');
				};
				if ($light.find('rightLight').text() == "true") {
					directions.push('right');
				};

				var lightCount = parseInt($light.find('lightNum').text());

				var vd = VideoLight.vd;
				var imgWidth = vd.imageWidth;
				var imgHeight = vd.imageHeight;

				var isVertical = false;
				var isv = VideoLight.isVerticalMap[lightId];
				if (!_.isUndefined(isv) && isv != null) {
					isVertical = isv;
				}else{
					if (lightCount == 3) {
						if ((bottom-top)*imgHeight >= (right-left)*imgWidth) {
							isVertical = true;
						}
					}
					VideoLight.isVerticalMap[lightId] = isVertical;
				}				

				var lt = {
					lightIdx:lightId,
					region: {
						left: left/imgWidth,
						right: right/imgWidth,
						top: top/imgHeight,
						bottom: bottom/imgHeight
					},
					isVertical: isVertical,
					lightCount: lightCount,
					directionCount: directions.length
				};

				lightArr.push(lt);
			}			
		});	

		VideoLight.vd.addLights(lightArr);	
	}

	
	function initEvt(){
		$('#lightIdx').unbind().change(function(){
			if (lastSelIdx>0) {
				storeLastLight(lastSelIdx);
			};
			var v = $(this).val();
			dispLight(v);
		});
	}

	/**
	 * 显示一个灯的信息
	 * @param  {[type]} idx [description]
	 * @return {[type]}     [description]
	 */
	function dispLight(idx){
		var $xml = $(personRunRedLightTriggerMode.PersonObj);
		$xml.find('videoDetectLight').each(function (i, n) {
			var $light = $(n);
			var lightId = $light.find('videoDetectLightId').eq(0).text();
			if (lightId == idx) {
				VideoLight.vd.selectLight(idx);

				var dleft = $light.find('leftLight').text() == "true";
				$('#direction_left').prop('checked', dleft);

				var dstraight = $light.find('straightLight').text() == "true";
				$('#direction_straight').prop('checked', dstraight);

				var dright = $light.find('rightLight').text() == "true";
				$('#direction_right').prop('checked', dright);

				var directionCount = 0;
				if (dleft) {
					directionCount++;
				};
				if (dstraight) {
					directionCount++;
				};
				if (dright) {
					directionCount++;
				};
				$("#yellowLightTime").val($light.find('yellowLightTime').eq(0).text());
				var cred = $light.find('redLight').text() == 'true';
				var cgreen = $light.find('greenLight').text() == 'true';
				var cyellow = $light.find('yellowLight').text() == 'true';
				$('#color_red').prop('checked', cred);
				$('#color_green').prop('checked', cgreen);
				$('#color_yellow').prop('checked', cyellow);	

				var lightCount = parseInt($light.find('lightNum').text());
				$('#light_count_'+lightCount).prop('checked', true);

				var isVertical = false;
				var isv = VideoLight.isVerticalMap[lightId];
				if (!_.isUndefined(isv) && isv != null) {
					isVertical = isv;
				}else{
					var left = parseInt($light.find('positionLeft').text(), 10);
					var right = parseInt($light.find('positionRight').text(), 10);
					var top = parseInt($light.find('positionTop').text(), 10);
					var bottom = parseInt($light.find('positionBottom').text(), 10);
					
					var vd = VideoLight.vd;
					var imgWidth = vd.imageWidth;
					var imgHeight = vd.imageHeight;
					if ((bottom-top)*imgHeight >= (right-left)*2*imgWidth) {
						isVertical = true;
					}
				}

				//log("in dispLight, isVertical="+isVertical);

				if (isVertical) {
					$('#lignt_v').prop('checked', true);
				}else{
					$('#lignt_h').prop('checked', true);
				}

				dispDemoPic(directionCount, lightCount, isVertical);
				
				lastSelIdx = lightId;
				return;
			}
		});		
	}

	function storeLastLight(lastIdx){
		var $xml = $(personRunRedLightTriggerMode.PersonObj);
		$xml.find('videoDetectLight').each(function (i, n) {
			var $light = $(n);
			var lightId = $light.find('videoDetectLightId').eq(0).text();
			if (lightId == lastIdx) {
				
				var dleft = $('#direction_left').prop('checked') ? "true" : "false";
				$light.find('leftLight').eq(0).text(dleft);

				var dstraight = $('#direction_straight').prop('checked') ? "true" : "false";
				$light.find('straightLight').eq(0).text(dstraight);
				
				var dright = $('#direction_right').prop('checked') ? "true" : "false";
				$light.find('rightLight').eq(0).text(dright);

				var cred = $('#color_red').prop('checked') ? "true" : "false";
				$light.find('redLight').eq(0).text(cred);

				var cgreen = $('#color_green').prop('checked') ? "true":"false";
				$light.find('greenLight').eq(0).text(cgreen); 

				var cyellow = $('#color_yellow').prop('checked') ? "true" : "false";
				$light.find('yellowLight').eq(0).text(cyellow);	
                
				$light.find('yellowLightTime').eq(0).text($("#yellowLightTime").val());
				
				var vd = VideoLight.vd;
				var light = vd.Lights[lightId];
				if (light) {
					var imgWidth = vd.imageWidth;
					var imgHeight = vd.imageHeight;

					var left = Math.round(parseFloat(light.region.left)*imgWidth);
					var right = Math.round(parseFloat(light.region.right)*imgWidth);
					var top = Math.round(parseFloat(light.region.top)*imgHeight);
					var bottom = Math.round(parseFloat(light.region.bottom)*imgHeight);

					$light.find('positionLeft').eq(0).text(left);
					$light.find('positionTop').eq(0).text(top);
					$light.find('positionRight').eq(0).text(right);
					$light.find('positionBottom').eq(0).text(bottom);
				}else{

				}

				var lightCount = 0;
				if (light) {
					if ($('#light_count_1').prop('checked')) {
						lightCount = 1;
					}else if ($('#light_count_3').prop('checked')) {
						lightCount = 3;
					};	
				};
				$light.find('lightNum').eq(0).text(lightCount);

				var isVertical = false;
				if ($('#lignt_v').prop('checked')) {
					isVertical = true;
				};
				VideoLight.isVerticalMap[lightId] = isVertical;
				return;
			};
		});
	}

	VideoLight.init = function () {
		$('#paper').find('*').remove();

		var width = $('#paper').width();
		var height = $('#paper').height();
		paper = Raphael('paper', width, height);

		personRunRedLightTriggerMode.InitPersonTmpSnapLines();
		initPage();

		vd = paper.SeVD3({
			type: 'vd',
			src: m_lHttp + m_szHostName + ":" + m_lHttpPort + '/PSIA/Streaming/channels/1/picture?authInfo='+m_szUserPwdValue+"&OSDType=0&_="+(new Date().getTime()),
			mode: 'full',
			offsetX: 0,
			offsetY: 0,
			loadComplete: function(res){
				if(!res){
					alert("加载图片失败，请刷新页面后重试！");
				}else{
					initLights();
					initEvt();
					dispLight(1);
				}
			}
		});
		vd.draw();

		VideoLight.vd = vd;
		VideoLight.paper = paper;
	}

	VideoLight.storeLast= function(){
		storeLastLight(lastSelIdx);
	}

	VideoLight.dispLight = dispLight;

	window.VD3 = VideoLight;
})(window);

function showVdRegion_PERSON() {
	var vd = window.VD3.vd;
	if (vd.mode == 'full') {
		vd.changeMode('drag', function () {
			$('#showVdRegionBtn').val(getNodeValue("cancelshowVdRegionBtn"));	
			$('#addLightBtn').prop('disabled', false).removeClass('btnDisabled');
		});
	}else{
		$('#showVdRegionBtn').val(getNodeValue("showVdRegionBtn"));
		vd.changeMode('full');

		$('#addLightBtn').prop('disabled', true).addClass('btnDisabled');
	}
}

function modifyLightInfo_PERSON(){
	var lightIdx = $('#lightIdx').val();

	var $light = window.VD3.vd.Lights[lightIdx];
	if (!$light) {
		return;
	};

	var directionCount=0;

	var dleft = $('#direction_left').prop('checked') ? 1 : 0;
	var dstraight = $('#direction_straight').prop('checked') ? 1 : 0;
	var dright = $('#direction_right').prop('checked') ? 1 : 0;
	var directionCount = dleft+dstraight+dright;


	var lightCount = 0;
	if ($('#light_count_1').prop('checked')) {
		lightCount = 1;
	}else if ($('#light_count_3').prop('checked')) {
		lightCount = 3;
	};

	var isVertical = false;
	if ($('#lignt_v').prop('checked')) {
		isVertical = true;
	};

	$light.directionCount = directionCount;
	$light.lightCount = lightCount;
	$light.isVertical = isVertical;

	$light.draw();

	dispDemoPic(directionCount, lightCount, isVertical);
}


function deleteCurLight_PERSON () {
	var lightIdx = $('#lightIdx').val(); 
	
	var vd = window.VD3.vd;
	vd.removeLight(lightIdx);

	var $xml = $(personRunRedLightTriggerMode.PersonObj);
	$xml.find('videoDetectLight').each(function (i, n) {
		var $light = $(n);
		var lightId = $light.find('videoDetectLightId').eq(0).text();
		if (lightId == lightIdx) {
			
			$light.find('leftLight, straightLight, rightLight, redLight, greenLight, yellowLight').text("false");
			$light.find('lightNum').text(0);

			$light.find('positionLeft, positionRight, positionTop, positionBottom').text(0);
			return;
		}
	});	

	clearDemoPic();

	window.VD3.dispLight(lightIdx);
}

function addLightToCanvas_PERSON(){
	if (window.VD3.vd.mode == 'full') {
		return;
	};

	var lightIdx = $('#lightIdx').val(); 

	var $light = window.VD3.vd.Lights[lightIdx];
	if ($light) {
		return;
	};

	var lightCount = 0;
	if ($('#light_count_1').prop('checked')) {
		lightCount = 1;
	}else if ($('#light_count_3').prop('checked')) {
		lightCount = 3;
	};

	var isVertical = false;
	if ($('#lignt_v').prop('checked')) {
		isVertical = true;
	};

	var directionCount=0;

	var dleft = $('#direction_left').prop('checked') ? 1 : 0;
	var dstraight = $('#direction_straight').prop('checked') ? 1 : 0;
	var dright = $('#direction_right').prop('checked') ? 1 : 0;
	var directionCount = dleft+dstraight+dright;

	if (directionCount == 0) {
		directionCount = 1;
	};

	var vd = window.VD3.vd;
	
	var centerX = (vd.offsetX*2+vd.paperWidth)/2;
	var centerY = (vd.offsetY*2+vd.paperHeight)/2;

	var v = getLightPngWH(directionCount, lightCount, isVertical);
	if (!v) {
		v = {
			w: 32,
			h: 32
		}
	};

	var left = centerX-v.w/2;
	var right = centerX+v.w/2;
	var top = centerY-v.h/2;
	var bottom = centerY+v.h/2;

	var iw = vd.imageWidth;
	var ih = vd.imageHeight;

	var light = {
		lightIdx: lightIdx,
		region: {
			left: left/iw,
			right: right/iw,
			top: top/ih,
			bottom: bottom/ih
		},
		directionCount: directionCount,
		isVertical: isVertical,
		lightCount: lightCount
	}

	vd.addLights([light]);
	vd.selectLight(lightIdx);

	dispDemoPic(directionCount, lightCount, isVertical);
}



function okVideDetect_PERSON(){
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }
    window.VD3.storeLast();
    
    var xml = x2js.parseXmlString(xmlToStr(personRunRedLightTriggerMode.PersonObj));
    personRunRedLightTriggerMode.setXml(xml);
    
    $.modal.impl.close();
    personRunRedLightTriggerMode.PlayView()
}

function cancelVideoDetect_PERSON(){
	$("#main_plugin").show();
    if (HWP.Play() !== 0) {
        alert(getNodeValue("previewfailed"));
    }
    $.modal.impl.close();

    personRunRedLightTriggerMode.PlayView();
}