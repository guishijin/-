

function VideoParamPlay () {
    $('#imageLeft1').show();
    HWP.Play();
}

function VideoParamStop () {
    $('#imageLeft1').hide();
    HWP.Stop(0);
}

function VideoParam() {
    SingletonInheritor.implement(this);
    
    this.icre = 'null'  //icr, e, null
}
SingletonInheritor.declare(VideoParam);

pr(VideoParam).setUninited = function(){
    //log("enter  setUninited ")

    ia(ITCImageGeneral).inited = false;
    ia(ITCImageIa).inited = false;
    ia(ITCImageRecord).inited = false;
    ia(ITCImageCap).inited = false;

    this.isVideoParamPage = false;

    //log("exit  setUninited ")
}

pr(VideoParam).init = function(){
    //log("enter  VideoParam init ")

    this.isVideoParamPage = true;

    var defTab = parseInt($.cookie("tabVideoParam_curTab"));
    if (!defTab) {
        defTab = 0;
    };

	this.tabs = $("#tabVideoParam").tabs(".pane", {
        remember : true, 
        defaultCur: defTab, 
        markCurrent: true,
        triggerClick: true
    });
    this.tabs.hideTabs([0,3,4,5]);
    isSupportLightCorrect();
    if(!g_bSupportLightCorrect){
        this.tabs.hideTab(6);
    }

    this.translate();

    var szInfo = parent.translator.translateNode(this.getLxd(), 'laPlugin');
    if(!checkPlugin('0', szInfo, 1, 'normal')){
        
    }

    setTimeout(function () {
            $("#PreviewActiveX").css('height','99.99%');    
    }, 100);

    InitSlider2();

    this.initCapability();
    DoubleShutEnableChanged();
    if ($("#aTwoShutter").is(".current")) {
        ia(MultiShut).update();    
    }
    if($("#aBasic").is(".current")){
        ia(ITCImageGeneral).update();
    }
    if($("#aVideoAlgIsp").is(".current")){
       ia(ITCImageIa).update();
    }
     if($("#aVideoIaIsp").is(".current")){
        ia(ITCImageRecord).update();
    }
     if($("#aCapIsp").is(".current")){
        ia(ITCImageCap).update();
    }
    if($("#aIcrE").is(".current")){
        ia(ITCImageIcrE).update();
    }
    // this.tabs.selectCurrentOrFirstTab({
    //     shouldNotTriggerClick: function (curTab) {
    //         return curTab == 6;
    //     }
    // });

    this.tabs.selectFirstTabWhenNoSelected();
    setTimeout(function () {
        if($('#imageLeft1').not(":hidden")){
            HWP.Play();
        }        
    }, 300);
        
}

pr(VideoParam).translate = function () {
	var that = this;
    g_transStack.clear();
    g_transStack.push(function() {
        that.setLxd(parent.translator.getLanguageXmlDoc(["VideoParam", "BaseVideoSettings"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
    }, true);
    g_transStack.push(function() { 
        parent.translator.translatePage(that.getLxd(), document); 
    }, true);
}

//根据能力集控制界面显示
pr(VideoParam).initCapability = function () {
    var self = this;
    var url = m_lHttp + m_szHostName + ":" + m_lHttpPort +
                     "/PSIA/Custom/SelfExt/ITCImage/channels/1/capabilities";

    //var url = "/doc/test/laneNo.xml"

    $.ajax({
        type: "GET",
        url : url,
        async: false,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        }      
    }).done(function(data, error, xhr) {
        ia(VideoParam).handleCapabilities(data);
    });

    
}

pr(VideoParam).handleCapabilities = function (data) {
    var self = this;

    var $xml = $(data);
    var maxNum = $xml.find('MuitiShutMaxNum').text();
    if (maxNum == '2') {
        self.tabs.showTabs([0]);
    }else{
        self.tabs.hideTabs([0]);
    }

    var $general = $('#ITCImageGeneralPane');

    //白平衡能力集
    if ($xml.find('ITCImageGeneral WhiteBlance').length) {
        $general.find('#WhiteBlanceStyle_tr, #WhiteBlanceRed_tr, #WhiteBlanceBlue_tr').show();
    }else{
        $general.find('#WhiteBlanceStyle_tr, #WhiteBlanceRed_tr, #WhiteBlanceBlue_tr').remove();
    }
    var WhiteBlanceOpt=$xml.find('WhiteBlance WhiteBlanceStyle').attr('opt');
    var WhiteBlance=WhiteBlanceOpt?WhiteBlanceOpt.split(','):[];
    var WhiteBlanceOption=null;
    for(i=0;i<WhiteBlance.length;i++){
        var optionName=getNodeValue("WhiteBlanceStyle_"+WhiteBlance[i])
        WhiteBlanceOption+="<option value='"+WhiteBlance[i]+"'>"+optionName+"</option>";
    }
    $general.find("#WhiteBlanceStyle").html(WhiteBlanceOption);

    var opt = $xml.find('Flip enabled').attr('opt');
    var flip = opt ? opt.split(',') : [];
    if (flip.length == 2) {
        $general.find('#Flip_tr, #FlipStyle_tr').show();
    }else{
        $general.find('#Flip_tr, #FlipStyle_tr').remove();
    }

    //获取局部对比度增强的能力集
    var partContrastEnhanceOpt=$xml.find("partContrastEnhance").eq(0).find("enabled ").attr("opt");
    var CeOpts=partContrastEnhanceOpt?partContrastEnhanceOpt.split(','):[];
    if(CeOpts.length==1 && CeOpts[0]=="false"){
        $general.find('#dvEnablePartContrastEnhance, #dvPartContrastEnhance').hide();
    }else{
        $general.find('#dvEnablePartContrastEnhance, #dvPartContrastEnhance').show();
    }


    //判断镜头类型的能力集
    var ExposureOpt=$xml.find("ExposureType").attr("opt");
    var opts=ExposureOpt?ExposureOpt.split(','):[];
    if(opts.length!=2){
        $general.find("#ExposureType").prop("disabled",true);
    }else{
        $general.find("#ExposureType").prop("disabled",false);
    }

    //获取宽动态模式能力集
    var hdr=$xml.find("HdrMode").attr("opt");
    var hdropts=hdr?hdr.split(','):[];
    var opthtml="";
    $("#HdrMode").html("");
    for(var i=0;i<hdropts.length;i++){
        var optname=getNodeValue("opt"+hdropts[i]);
        opthtml+="<option value='"+hdropts[i]+"'>"+optname+"</option>";
    }
    opthtml+="<option value='close'>"+getNodeValue("optclose")+"</option>";
    $("#HdrMode").html(opthtml);
    if(hdropts.length==1 && hdropts[0]=="notSupport"){
        $general.find("#dvHdrMode,#dvHdrSwitchMode,#dvHdrLevel").hide();
    }else{
        $general.find("#dvHdrMode,#dvHdrSwitchMode,#dvHdrLevel").show();
    }

    //获取日夜切换亮度阈值能力集
    if($xml.find("brightnessThreld").text()=="true"){
        $("#dvLightSwitch").show();
    }else{
        $("#dvLightSwitch").hide();
    }

    //晚间亮度能力集
    if($xml.find("BrightCompensateCap").text()=="true"){
        $("#dvbrightEnhance").show();
    }else{
        $("#dvbrightEnhance").hide();
    }

    //补光灯纠正
    if($xml.find("correctFactor ").eq(0).find("enable").eq(0).text()=="true"){
        $general.find("#dvIsUseCorrectFactor").show();
    }else{
        $general.find("#dvIsUseCorrectFactor").remove();
    }

    //JPEG能力集
    if ($xml.find("JPEGParam").eq(0).find("enable").eq(0).text()=="true") {
        $general.find('#dvJPEGSize').show();
        var sel = '#ITCImageGeneralPane #JPEGSize';

        var min = $xml.find('JPEGSize').attr('min');
        var max = $xml.find('JPEGSize').attr('max');
        $(sel).attr('min', min).attr('max', max);
    }else{
        $general.find('#dvJPEGSize').remove();
    }

    opt = $xml.find('darkEnhanceEnabled').attr('opt');
    var tmp = opt ? opt.split(',') : [];
    if (tmp.length == 2) {
        $general.find('#dvdarkEnhanceEnabled').show();
    }else{
        $general.find('#dvdarkEnhanceEnabled').remove();
    }

    opt = $xml.find('Dehaze enabled').attr('opt');
    tmp = opt ? opt.split(',') : [];
    if (tmp.length == 2) {
        $general.find('#dvDehaze').show();
    }else{
        $general.find('#dvDehaze').remove();
    }

    // opt = $xml.find("Wdr");
    // if (opt.length) {
    //     $general.find('#dvWdr').show();
    // }else{
    //     $general.find('#dvWdr').remove();
    // }

    var $ia = $('#ITCImageIaPane');
    var $iaXml = $xml.find('ITCImageIa');
    if ($iaXml.find('ShutterLevel').length) {
        $ia.find('#ShutterLevel_tr').show();

        var sel = '#ITCImageIaPane #ShutterLevel';

        var min = $iaXml.find('ShutterLevel').attr('min');
        var max = $iaXml.find('ShutterLevel').attr('max');
        $(sel).attr('min', min).attr('max', max);
    }else{
        $ia.find('#ShutterLevel_tr').remove();
    }

    if ($iaXml.find('NoiseReduceExtIa').text() == 'true') {
        $ia.find('#NoiseReduceMode_tr').show();
    }else{
        $ia.find('#NoiseReduceMode_tr').remove();
    }

    if ($iaXml.find('NoiseReduce2DIa').text() == 'true') {
        $ia.find('#dvNoiseReduce2DEnable').show();
    }else{
        $ia.find('#dvNoiseReduce2DEnable').remove();
    }

    //车牌亮度补偿能力集
    if($xml.find("plateBright").eq(0).find("enabled").eq(0).text()=="true"){
        $general.find("#dvSnapBright").show();
    }else{
        $general.find("#dvSnapBright").remove();
    }

    if($xml.find("lseCap").eq(0).text()=="true"){
        $general.find("#dvLseCap").show();
        $general.find("#dvEnableLseCap").show();
    }else{
        $general.find("#dvLseCap").remove();
        $general.find("#dvEnableLseCap").remove();
    }

    var $record = $('#ITCImageRecordPane');
    var $recordXml = $xml.find('ITCImageRecord');
    if ($recordXml.find('ShutterLevel').length) {
        $record.find('#ShutterLevel_tr').show();

        var sel = '#ITCImageRecordPane #Rec_ShutterLevel';

        var min = $recordXml.find('ShutterLevel').attr('min');
        var max = $recordXml.find('ShutterLevel').attr('max');
        $(sel).attr('min', min).attr('max', max);
    }else{
        $record.find('#ShutterLevel_tr').remove();
    }

    if ($recordXml.find('NoiseReduceExtRecord').text() == 'true') {
        $record.find('#NoiseReduceMode_tr').show();
    }else{
        $record.find('#NoiseReduceMode_tr').remove();
    }

    if ($recordXml.find('NoiseReduce2DRecord').text() == 'true') {
        $record.find('#dvNoiseReduce2DEnable').show();
    }else{
        $record.find('#dvNoiseReduce2DEnable').remove();
    }

    var $cap = $("#ITCImageCapPane");
    var $capXml = $xml.find('ITCImageCap');
    if ($capXml.find('ImageCapSupport').text() == 'true') {
        self.tabs.showTab(4);
    }else{
        self.tabs.hideTab(4);
    }

    if ($capXml.find('snapShutterLevel').length) {
        $record.find('#ShutterLevel_tr').show();

        var sel = '#ITCImageCapPane #Cap_snapShutterLevel';

        var min = $capXml.find('snapShutterLevel').attr('min');
        var max = $capXml.find('snapShutterLevel').attr('max');
        $(sel).attr('min', min).attr('max', max);
    }else{
        $record.find('#ShutterLevel_tr').remove();
    }

    if ($capXml.find('NoiseReduce2DCap').text() == 'true') {
        $cap.find('#dvNoiseReduce2DEnable').show();
    }else{
        $cap.find('#dvNoiseReduce2DEnable').remove();
    }


    var $icre = $('#ITCImageIcrEPane');
    var $icreXml = $xml.find('ITCImageIcrE');
    var icreText = $icreXml.find('ImageIcrESupport').text();

    this.icre = icreText;

    if (icreText == 'icr'
        || icreText == 'e') {
        self.tabs.showTab(5);
    }else{
        self.tabs.hideTab(5);
    }
    self.initIcrePage();
    autoResizeIframe(); 
}

pr(VideoParam).initIcrePage = function () {
    if(this.icre == 'icr'){
        $('#ITCImageIcrEPane div[dev-type=e]').remove();
    }else if (this.icre == 'e') {
        $('#ITCImageIcrEPane div[dev-type=icr]').remove();
    };

    var $sels;
    var opts = [];

    if (this.icre == 'e') {
        $sels = $('#presetTypeTR1, #presetTypeTR2, #presetTypeTR3, #presetTypeTR4');
        opts = ['<option value="0" >', getNodeValue('laPreset1'), '</option>',
                '<option value="1" >', getNodeValue('laPreset2'), '</option>'];
    }else if (this.icre == 'icr') {
        $sels = $('#dayNightOptTR1, #dayNightOptTR2, #dayNightOptTR3, #dayNightOptTR4');

        opts = ['<option value="day" >', getNodeValue('dayNightOpt1'), '</option>',
                '<option value="night" >', getNodeValue('dayNightOpt2'), '</option>'];
    }

    if ($sels && $sels.length) {
        $sels.html(opts.join(''));    
    };
}



// 双快门参数
function MultiShut() {
     SingletonInheritor.implement(this);

}
SingletonInheritor.declare(MultiShut);

pr(MultiShut).update = function () {
    $("#SaveConfigBtn").show();
    VideoParamPlay();

    var self = this;
    var url = m_lHttp + m_szHostName + ":" + m_lHttpPort +
                     "/PSIA/Custom/SelfExt/ITCImage/channels/1/multiShut";

    // var url = "/doc/testXml/multiShut.xml"

    $.ajax({
        type: "GET",
        url : url,
        async: false,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        }      
    }).done(function(data, error, xhr) {
        var $xml = $(data);
        self.$xml = $xml;

        $.each(['DoubleShutEnable', 'CodecType'], function (i, n) {
           $.g.setField2('#'+n, $xml.find(n).eq(0).text(), true); 
        });
    });
}

pr(MultiShut).restore = function () {
    if (!this.$xml) {
        return false;
    };
    var de = $('#DoubleShutEnable').prop('checked') ? "true" : "false";
    this.$xml.find('DoubleShutEnable').eq(0).text(de);
    this.$xml.find('CodecType').eq(0).text($('#CodecType').val());

    return true;
}

function DoubleShutEnableChanged () {
    var v = $('#DoubleShutEnable').prop('checked');
    if (v) {
        ia(VideoParam).tabs.showTab(3);
        $('#dvCodecType').show();
    }else{
        ia(VideoParam).tabs.hideTab(3);
        $('#dvCodecType').hide();
    }
}

pr(MultiShut).submit = function () {
    var url = m_lHttp + m_szHostName + ":" + m_lHttpPort +
                     "/PSIA/Custom/SelfExt/ITCImage/channels/1/multiShut";

    if(!this.restore()){
        return;
    }

    var self = this;
    $.ajax({
        type: "PUT",
        url : url,
        data: xmlToStr(self.$xml[0]),
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        }      
    }).done(function(data, error, xhr) {
        SaveState(xhr);
    }).fail(function (xhr) {
        SaveState(xhr);
    });
}

function plateBrightEnabledChanged () {
    var v = $('#ITCImageGeneralPane #plateBrightEnabled').prop('checked');
    if (v) {
        $.g.setField2('#ITCImageGeneralPane #correctFactorEnabled', "false");
        // $('#ITCImageGeneralPane #dvCorrectFactor').hide();
    };
}

function correctFactorEnabledChanged () {
    var v = $('#ITCImageGeneralPane #correctFactorEnabled').prop('checked');
    if (v) {
        $.g.setField2('#ITCImageGeneralPane #plateBrightEnabled', "false");
        $('#ITCImageGeneralPane #dvplateBrightSensitivity').hide();
        $('#ITCImageGeneralPane #dvCorrectFactor').show();
    }else{
        $('#ITCImageGeneralPane #dvCorrectFactor').hide();
    };

    ia(ITCImageGeneral).submit();
}

// 通用参数
function ITCImageGeneral() {
    SingletonInheritor.implement(this);

    this.paramArr = [/*'saturationLevel', */'plateBrightEnabled',
        'plateBrightSensitivity', 'correctFactorEnabled', 'correctFactor',
        'JPEGSize', 'flipStyle', /*'SharpnessLevel', *//*'dynamicContrastLevel', */
        'WhiteBlanceStyle', 'WhiteBlanceRed', 'WhiteBlanceBlue',
        'gammaCorrectionEnabled', 'gammaCorrectionLevel',
        'partContrastEnhanceEnabled','partContrastEnhanceLevel', /*'Wdrlevel',*/
        'HdrMode','HdrSwitchMode','HdrLevel',"ExposureType",
        'brightEnhanceLevel', 'darkEnhanceEnabled', 'darkEnhanceLevel',
        'brightnessThreld','lseEnable','lseLevel'];
    this.paramArr2 = [    {inXml: 'Dehaze enabled', inDoc: '#dehazeEnabled'}
                        , {inXml: 'Flip enabled', inDoc: '#flipEnabled'}
                        //, {inXml: 'DynamicContrast enabled', inDoc: '#DynamicContrastEnabled'}
                    ];

    this.pdivSel = 'div[relatePara=ITCImageGeneral]';
}
SingletonInheritor.declare(ITCImageGeneral);

// pr(ITCImageGeneral).HdrSwitchModeSubmit=function(){
//     pr(ITCImageGeneral).HdrSwitchModeChange();
//     this.submit();
// }

//宽动态切换模式触发事件
pr(ITCImageGeneral).HdrSwitchModeChange=function(){
    if($("#HdrSwitchMode").val()=='timeCtrl'){
        $("#dvTimeSwitch").show();
    }else{
        $("#dvTimeSwitch").hide();
    }
    this.submit();
    autoResizeIframe();
}

//宽动态切换触发事件
pr(ITCImageGeneral).HdrModeChange=function(){
    if($("#HdrMode").val()=='close'){
        $("#dvHdrSwitchMode").hide();
        $("#dvHdrLevel").hide();
        $("#dvTimeSwitch").hide();
    }else{
        $("#dvHdrSwitchMode").show();
        $("#dvHdrLevel").show();
        
        if($("#HdrMode").val()=='realHdr'){
            $("#partContrastEnhanceEnabled").prop("checked",false);
            $("#dvPartContrastEnhance").hide();
            $("#partContrastEnhanceEnabled").prop("disabled",true);
        }else{
            $("#partContrastEnhanceEnabled").prop("disabled",false);
        }
        this.HdrSwitchModeChange();
    }
    this.submit();
    autoResizeIframe();
}

//自动检测亮度控制补光灯触发事件
pr(ITCImageGeneral).changeDetectBrightnessAutomatic = function (){

    if($('#lightSwitchEnabled').prop("checked")){

        $('#notDetectBrightness').prop("checked",false);
        $('#timeSwitchEnabled').prop("checked",false);
        $("#brightnessDateContent").css("display","none");
        $("#brightnessThreldContent").css("display","block");
    }else{
        $('#brightnessThreldContent').css("display","none");
    }

    autoResizeIframe();
}

//按时间启用补光灯触发事件
pr(ITCImageGeneral).changeDetectBrightnessByTime = function (){
    if($('#timeSwitchEnabled').prop("checked")){

        $('#notDetectBrightness').prop("checked",false);
        $('#lightSwitchEnabled').prop("checked",false);
        $("#brightnessDateContent").css("display","block");
        $("#brightnessThreldContent").css("display","none");
    }else{
        $("#brightnessDateContent").css("display","none");
    }
    autoResizeIframe();
}

pr(ITCImageGeneral).ExposureTypeChange=function(){
    this.submit();
    autoResizeIframe();
}

pr(ITCImageGeneral).update = function () {
    $("#SaveConfigBtn").hide();
    VideoParamPlay();
    this.url =  m_lHttp + m_szHostName + ":" + m_lHttpPort +
                     "/PSIA/Custom/SelfExt/ITCImage/channels/1/general";

    //this.url = "/doc/testXml/general.xml"

    UpdateCall.call(this);
}

pr(ITCImageGeneral).SaveJPEGSize = function (evt) {
    if(evt.keyCode === 13) {
        var $ele = $(this.pdivSel).find('#JPEGSize');
        var v = $ele.val();
        v = $.trim(v);

        if (v != '' && v != '0') {
            v = parseInt(v);    
        }

        var min = parseInt($ele.attr('min'));
        var max = parseInt($ele.attr('max'));

        if(!CheackServerIDIntNum(v,"SetResultTips","laJPEGSize",min,max))
        {
            return;
        }
        
        if (!v && v != 0) {
            return;
        }
        this.submit();        
    }
}

function submitITCImageGeneral () {
    ia(ITCImageGeneral).submit();    
}

var ParamTabMap = {
    'ITCImageGeneral': ITCImageGeneral,
    'ITCImageIa': ITCImageIa,
    'ITCImageCap': ITCImageCap,
    'ITCImageRecord': ITCImageRecord,
    'ITCImageIcrE': ITCImageIcrE
};

function simpleCheckDivBind(srcSel, destSel) {
    var v = $(srcSel).prop('checked');
    if (v) {
        $(destSel).show();
    }else{
        $(destSel).hide();
    }

    var p = $(srcSel).parents('div[relatePara]:eq(0)').attr('relatePara');
    if (p && ParamTabMap[p]) {
        ia(ParamTabMap[p]).submit(); 
    };
    autoResizeIframe();
}

function showAdvanceConfig (parDivId) {
    var $pdiv = $('div[relatePara='+parDivId+']:eq(0)');
    
    var $content = $pdiv.find('#picParamMainContentDiv');

    if ($content.is(":hidden")) {
        $content.show();
    }else{
        $content.hide();
    }
    autoResizeIframe();
}

pr(ITCImageGeneral).WhiteBlanceStyleChanged = function () {
    // var v = $('#WhiteBlanceStyle').prop('checked');
    // if (v) {
    //     $('#WhiteBlanceRed_tr, #WhiteBlanceBlue_tr').show();
    // }else{
    //     $('#WhiteBlanceRed_tr, #WhiteBlanceBlue_tr').show();
    // }

    this.submit();
}

pr(ITCImageGeneral).correctFactorEnabledChanged = function () {
    var v = $('#correctFactorEnabled').prop('checked');
    // if (v) {
    //     $('#dvCorrectFactor').show();
    // }else{
    //     $('#dvCorrectFactor').hide();
    // }
    this.submit();
}

pr(ITCImageGeneral).flipEnabledChanged = function () {
    var v = $('#flipEnabled').prop('checked');
    if (v) {
        $('#FlipStyle_tr').show();
    }else{
        $('#FlipStyle_tr').hide();
    }

    this.submit();
}

pr(ITCImageGeneral).WdrChanged = function(){
    this.submit();
}


pr(ITCImageGeneral).submit = function () {
    SubmitCall.call(this, this.update);
}


function SubmitCall (cb) {
    if (!this.inited || !ia(VideoParam).isVideoParamPage) {
        return;
    };

    //log("enter  SubmitCall ")
    
    var self = this;
    var $xml = self.$xml;

    var preStr = this.preStr || '';

    var pSel = self.pdivSel;

    $.each(self.paramArr, function (i, n) {
        if ($(pSel + ' #'+preStr+n).length) {
            var v = $.g.getEleVal(pSel + ' #'+preStr+n);
            $xml.find(n).eq(0).text(v);
        };
    });

    $.each(self.paramArr2, function (i, n) {
        if ($(pSel + ' '+n.inDoc).length) {
            var v = $.g.getEleVal(pSel + ' '+n.inDoc);
            $xml.find(n.inXml).eq(0).text(v);
        };
    });

    $xml.find("startHour").text($("#StartTime").val().split(":")[0]);
    $xml.find("startMinute").text($("#StartTime").val().split(":")[1]);
    $xml.find("endHour").text($("#EndTime").val().split(":")[0]);
    $xml.find("endMinute").text($("#EndTime").val().split(":")[1]);

    $.ajax({
        type: "PUT",
        url : self.url,
        data: xmlToStr(self.$xml[0]),
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        }      
    }).done(function(data, error, xhr) {
        if (cb) {
            cb.call(self);
        };
        SaveState(xhr);
    }).fail(function (xhr) {
        if (cb) {
            cb.call(self);
        };
        SaveState(xhr);
    });
}



function UpdateCall (extCallback) {
    if (!ia(VideoParam).isVideoParamPage) {
        return;
    };

    //log("enter  UpdateCall ")

    this.inited = false;

    this.$pdiv = $(this.pdivSel);

    var preStr = this.preStr || '';

    var self = this;

    var url = this.url;

    var updateReq = this.updateReq;
    if (updateReq) {
        try{
            updateReq.abort();
        }catch(e){}
    };

    this.updateReq = $.ajax({
        type: "GET",
        url : url,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        }      
    }).done(function(data, error, xhr) {
        //log("get xml success ")

        self.updateReq = undefined;

        var $xml = $(data);
        self.$xml = $xml;

        var pdivSel  = self.pdivSel;

        $.each(self.paramArr, function (i, n) {
            // var isHide = $(pdivSel + ' #'+ preStr + n).is(":hidden");
            $.g.setField2(pdivSel + ' #'+ preStr + n, $xml.find(n).eq(0).text(), true); 
        });

        $.each(self.paramArr2, function (i, n) {
            // var isHide = $(pdivSel + ' '+n.inDoc).is(":hidden");
           $.g.setField2(pdivSel + ' '+n.inDoc, $xml.find(n.inXml).eq(0).text(), true); 
        });
        if($xml.find("startHour").eq(0).text()=="" && $xml.find("startMinute").eq(0).text()==""){
            $("#StartTime").val("");
        }else{
            $("#StartTime").val($xml.find("startHour").eq(0).text() + ":" + $xml.find("startMinute").eq(0).text());
        }
        if($xml.find("endHour").eq(0).text()=="" && $xml.find("endMinute").eq(0).text()==""){
            $("#EndTime").val("");
        }else{
            $("#EndTime").val($xml.find("endHour").eq(0).text() + ":" + $xml.find("endMinute").eq(0).text());
        }

        if (extCallback) {
            extCallback();
        };

        // setTimeout(function () {
            if (ia(VideoParam).isVideoParamPage) {
                self.inited = true;  

                //log("set inited=true")  
            };
        // }, 10);

        

        if($("#HdrMode").val()=='close' || $("#HdrMode").val()=='notSupport'){
            $("#dvHdrSwitchMode").hide();
            $("#dvHdrLevel").hide();
            $("#dvTimeSwitch").hide();
        }else{
            $("#dvHdrSwitchMode").show();
            $("#dvHdrLevel").show();
            
            if($("#HdrMode").val()=='realHdr'){
                $("#partContrastEnhanceEnabled").prop("checked",false);
                $("#dvPartContrastEnhance").hide();
                $("#partContrastEnhanceEnabled").prop("disabled",true);
            }else{
                $("#partContrastEnhanceEnabled").prop("disabled",false);
            }
            pr(ITCImageGeneral).HdrSwitchModeChange();
        }

        autoResizeIframe();

        //log("exit  UpdateCall callback ")
    });
}

// 算法流参数
function ITCImageIa() {
     SingletonInheritor.implement(this);

    this.paramArr = ['brightnessLevel', 'contrastLevel', 'saturationLevel', 'SharpnessLevel',
                        'ShutterLevel', 'GainLevel', 
                        'generalLevel', 'SpatialLevel', 'TemporalLevel',
                        'NoiseReduce2DEnable', 'NoiseReduce2DLevel', 'sectionCtrlEnabled'];
    this.paramArr2 = [{inXml: 'NoiseReduceExt mode', inDoc: '#NoiseReduceMode'}];

    this.pdivSel = 'div[relatePara=ITCImageIa]';

}
SingletonInheritor.declare(ITCImageIa);

pr(ITCImageIa).update = function () {
    $("#SaveConfigBtn").hide();
    VideoParamPlay();

    this.url =  m_lHttp + m_szHostName + ":" + m_lHttpPort +
                     "/PSIA/Custom/SelfExt/ITCImage/channels/1/ia";

    //this.url = "/doc/testXml/ia.xml"

    var self = this;

    UpdateCall.call(this, function () {
        self.NoiseReduceModeChanged();    
    });
}

pr(ITCImageIa).NoiseReduceModeChanged = function () {
    var v = $('div[relatePara=ITCImageIa] #NoiseReduceMode').val();
    if (v == 'close') {
        this.$pdiv.find('#generalLevel_tr, #SpatialLevel_tr, #TemporalLevel_tr').hide();
    }else if(v == 'general'){
        this.$pdiv.find('#SpatialLevel_tr, #TemporalLevel_tr').hide();
        this.$pdiv.find('#generalLevel_tr').show();
    }else if (v == 'advanced') {
        this.$pdiv.find('#generalLevel_tr').hide();
        this.$pdiv.find('#SpatialLevel_tr, #TemporalLevel_tr').show();
    };

    this.submit();
}

pr(ITCImageIa).SaveShutter = function (evt) {
    //evt = evt ? evt || window.event;
    
    if(evt.keyCode === 13) {
        var $ele = this.$pdiv.find('#ShutterLevel');
        var v = $ele.val();
        v = $.trim(v);

        if (v != '' && v != '0') {
            v = parseInt(v);    
        }

        var min = parseInt($ele.attr('min'));
        var max = parseInt($ele.attr('max'));

        if(!CheackServerIDIntNum(v,"SetResultTips","laShutterLevel",min,max))
        {
            return;
        }

        v = parseInt(v);
        if (!v && v != 0) {
            return;
        }
        this.submit();        
    }
}

function submitITCImageIa () {
    ia(ITCImageIa).submit();
}

pr(ITCImageIa).submit = function () {
    SubmitCall.call(this, this.update);
}


// 录像流
function ITCImageRecord() {
    SingletonInheritor.implement(this);

    this.paramArr = ['brightnessLevel', 'contrastLevel', 'saturationLevel', 'SharpnessLevel',
                        'ShutterLevel', 'GainLevel', 
                        'generalLevel', 'SpatialLevel', 'TemporalLevel',
                        'NoiseReduce2DEnable', 'NoiseReduce2DLevel', 'sectionCtrlEnabled'];
    this.paramArr2 = [{inXml: 'NoiseReduceExt mode', inDoc: '#Rec_NoiseReduceMode'}];

    this.pdivSel = 'div[relatePara=ITCImageRecord]';

    this.preStr = 'Rec_';

}
SingletonInheritor.declare(ITCImageRecord);

pr(ITCImageRecord).update = function () {
    $("#SaveConfigBtn").hide();
    VideoParamPlay();


    this.url =  m_lHttp + m_szHostName + ":" + m_lHttpPort +
                     "/PSIA/Custom/SelfExt/ITCImage/channels/1/record";

    //this.url = "/doc/testXml/record.xml"

    var self = this;

    UpdateCall.call(this, function () {
        self.NoiseReduceModeChanged();    
    });
}

pr(ITCImageRecord).NoiseReduceModeChanged = function () {
    var v = $('div[relatePara=ITCImageRecord] #Rec_NoiseReduceMode').val();
    if (v == 'close') {
        this.$pdiv.find('#generalLevel_tr, #SpatialLevel_tr, #TemporalLevel_tr').hide();
    }else if(v == 'general'){
        this.$pdiv.find('#SpatialLevel_tr, #TemporalLevel_tr').hide();
        this.$pdiv.find('#generalLevel_tr').show();
    }else if (v == 'advanced') {
        this.$pdiv.find('#generalLevel_tr').hide();
        this.$pdiv.find('#SpatialLevel_tr, #TemporalLevel_tr').show();
    };

    this.submit();
}

pr(ITCImageRecord).SaveShutter = function (evt) {
    if(evt.keyCode === 13) {
        var $ele = this.$pdiv.find('#Rec_ShutterLevel');
        var v = $ele.val();
        v = $.trim(v);

        if (v != '' && v != '0') {
            v = parseInt(v);    
        }

        var min = parseInt($ele.attr('min'));
        var max = parseInt($ele.attr('max'));

        if(!CheackServerIDIntNum(v,"SetResultTips","laShutterLevel",min,max))
        {
            return;
        }

        if (!v && v != 0) {
            return;
        }
        this.submit();        
    }
}

function submitITCImageRecord () {
    ia(ITCImageRecord).submit();
}

pr(ITCImageRecord).submit = function () {
    if (!this.inited) {
        return;
    };
    SubmitCall.call(this, this.update);
}

// 抓拍图像参数
function ITCImageCap() {
     SingletonInheritor.implement(this);

     this.paramArr = ['brightnessLevel', 'contrastLevel', 'saturationLevel', 'SharpnessLevel',
                        'snapShutterLevel', 'snapGainLevel',
                        'NoiseReduce2DEnable', 'NoiseReduce2DLevel'];
    this.paramArr2 = [];

    this.pdivSel = 'div[relatePara=ITCImageCap]';

    this.preStr = 'Cap_';

}
SingletonInheritor.declare(ITCImageCap);

pr(ITCImageCap).update = function () {
    $("#SaveConfigBtn").hide();
    VideoParamPlay();

    this.url =  m_lHttp + m_szHostName + ":" + m_lHttpPort +
                     "/PSIA/Custom/SelfExt/ITCImage/channels/1/cap";

    //this.url = "/doc/testXml/cap.xml"

    var self = this;

    UpdateCall.call(this);
}

pr(ITCImageCap).SaveShutter = function (evt) {
    //evt = evt ? evt || window.event;
    
    if(evt.keyCode === 13) {
        var $ele = this.$pdiv.find('#Cap_snapShutterLevel');
        var v = $ele.val();
        v = $.trim(v);

        if (v != '' && v != '0') {
            v = parseInt(v);    
        }

        var min = parseInt($ele.attr('min'));
        var max = parseInt($ele.attr('max'));

        if(!CheackServerIDIntNum(v,"SetResultTips","laShutterLevel",min,max))
        {
            return;
        }

        if (!v && v != 0) {
            return;
        }
        this.submit();        
    }
}

function submitITCImageCap () {
    ia(ITCImageCap).submit();
}

pr(ITCImageCap).submit = function () {
    if (!this.inited) {
        return;
    };
    SubmitCall.call(this, this.update);
}

// ICR
function ITCImageIcrE() {
     SingletonInheritor.implement(this);

     this.pdivSel = '#ITCImageIcrEPane';


}
SingletonInheritor.declare(ITCImageIcrE);

pr(ITCImageIcrE).update = function () {
    $("#SaveConfigBtn").show();
    VideoParamStop();
    this.inited = false;

    var self = this;
    var url = m_lHttp + m_szHostName + ":" + m_lHttpPort +
                     "/PSIA/Custom/SelfExt/ITCImage/channels/1/icr_e";

    this.url = url;
    // var url = "/doc/testXml/icr_e.xml"

    $.ajax({
        type: "GET",
        url : url,
        async: false,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        }      
    }).done(function(data, error, xhr) {
        self.oriData = data;
        self.$xml = $(data);

        var icre = ia(VideoParam).icre;
        if (icre == 'e') {
            self.updateE();
        }else if (icre == 'icr') {
            self.updateIcr();
        };
    });

    autoResizeIframe();
}

pr(ITCImageIcrE).updateE = function () {
    var pSel = '#ITCImageIcrEPane div[dev-type=e]';
    var $p = $(pSel);

    var $xml = this.$xml;

    $.g.setField2(pSel+' #icrModeOpts', $xml.find('ECtrlMode').text());
    $.g.setField2(pSel + ' #E_ManualPresetVal', $xml.find('ManualPresetVal').text());
    $.g.setField2(pSel + ' #E_DayNightFilterTh', $xml.find('DayNightFilterTh').text());
    $.g.setField2(pSel + ' #E_ExceptionCatchTh', $xml.find('ExceptionCatchTh').text());

    var $presets = $xml.find('Preset');
    for (var i = 0; i < $presets.length; i++) {
        var $p = $presets.eq(i);
        var id = $p.find('PresetId').text();
        $.g.setField2(pSel+' #E_Preset_'+id, $p.find('PresetVal').text());
    };

    var $ss = $xml.find('timeSwitch');
    for (var i = 0; i < $ss.length; i++) {
        var $s = $ss.eq(i);

        var pid = $s.find('PresetId').text();
        $.g.setField2(pSel+' #presetTypeTR'+(i+1), pid);

        var startHour = $s.find('startHour').text();
        var startMinute = $s.find('startMinute').text();
        var endHour = $s.find('endHour').text();
        var endMinute = $s.find('endMinute').text();

        var start = startHour.padLeft(2, '0') + ":"+startMinute.padLeft(2, '0');
        var end = endHour.padLeft(2, '0') + ":"+endMinute.padLeft(2, '0');

        $.g.setField2(pSel+' #ircStartTimeTR'+(i+1)+'_preset', start);
        $.g.setField2(pSel+' #ircEndTimeTR'+(i+1)+'_preset', end);
    };

    this.changeICRMode();
}

pr(ITCImageIcrE).updateIcr = function () {
    
    var $xml = this.$xml;

    var pSel = '#ITCImageIcrEPane div[dev-type=icr]';
    var $p = $(pSel);

    $.g.setField2(pSel+' #icrModeOpts', $xml.find('ICRCtrlMode').text());

    var mp =$xml.find('ManualPresetVal').text();
    $.g.setField2(pSel + ' #ICR_ManualPresetVal', mp);

    var dn = parseInt($xml.find('DayNightFilterTh').text());
    $.g.setField2(pSel + ' #ICR_DayNightFilterTh', dn);

    var $ss = $xml.find('timeSwitch');
    for (var i = 0; i < $ss.length; i++) {
        var $s = $ss.eq(i);

        var psVal = $s.find('PresetVal').text();
        $.g.setField2(pSel+' #dayNightOptTR'+(i+1), psVal);


        var startHour = $s.find('startHour').text();
        var startMinute = $s.find('startMinute').text();
        var endHour = $s.find('endHour').text();
        var endMinute = $s.find('endMinute').text();

        var start = startHour.padLeft(2, '0') + ":"+startMinute.padLeft(2, '0');
        var end = endHour.padLeft(2, '0') + ":"+endMinute.padLeft(2, '0');

        $.g.setField2(pSel+' #ircStartTimeTR'+(i+1), start);
        $.g.setField2(pSel+' #ircEndTimeTR'+(i+1), end);
    };

    this.changeICRMode();

}

pr(ITCImageIcrE).changeICRMode = function () {
    var icre = ia(VideoParam).icre;
    if (!icre || icre == 'null') {
        return;
    };

    var $p = $('#ITCImageIcrEPane div[dev-type='+icre+']');

    var mode = $p.find('#icrModeOpts').val();

    $p.find('div[icre-mode]').hide();
    $p.find('div[icre-mode='+mode+']').show();
}

pr(ITCImageIcrE).submit = function () {
   
    var xml = '';
    var icre = ia(VideoParam).icre;
    if (icre == 'e') {
        xml = this.submitE();
    }else if (icre == 'icr') {
        xml = this.submitIcr();
    };

    var self = this;
    $.ajax({
        type: "PUT",
        url : self.url,
        data: xml,
        processData: false,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        }      
    }).done(function(data, error, xhr) {
        SaveState(xhr);
    }).fail(function (xhr) {
        SaveState(xhr);
    });

}

pr(ITCImageIcrE).submitIcr = function () {
    var pSel = '#ITCImageIcrEPane div[dev-type=icr]';
    var $p = $(pSel);

    var mode = $(pSel+' #icrModeOpts').val();

    var obj = {
        ITCImageIcrE: {
            ICRCtrl: {
                ICRCtrlMode: mode
            }
        }
    };

    if (mode == 'time') {
        var tsList = [];
        for (var i = 0; i < 2; i++) {
            var start = $('#ircStartTimeTR'+(i+1)).val();
            var end =$('#ircEndTimeTR'+(i+1)).val();

            var ss = start.split(':');
            var es = end.split(":");

            tsList.push({
                timeId: i,
                PresetVal: $(pSel+' #dayNightOptTR'+(i+1)).val(),
                startHour: parseInt(ss[0], 10),
                startMinute: parseInt(ss[1], 10),
                endHour: parseInt(es[0], 10),
                endMinute: parseInt(es[1], 10)
            });
        };

        obj.ITCImageIcrE.ICRCtrl.TimeMode = {
            SwitchList: {
                timeSwitch: tsList
            }
        };
    }else if (mode == 'auto') {
        if ($(pSel+' #ICR_DayNightFilterTh').length) {
            obj.ITCImageIcrE.ICRCtrl.AutoMode = {
                DayNightFilterTh: $.g.getEleVal(pSel+' #ICR_DayNightFilterTh')
            }
        };
    }else if (mode == 'manual') {
        obj.ITCImageIcrE.ICRCtrl.ManualMode = {
            ManualPresetVal: $.g.getEleVal(pSel+' #ICR_ManualPresetVal')
        };
    };

    var xml = x2js.json2xml_str(obj, true);
    return xml;
}

pr(ITCImageIcrE).submitE = function () {
     var pSel = '#ITCImageIcrEPane div[dev-type=e]';
    var $p = $(pSel);

    var mode = $(pSel+' #icrModeOpts').val();

    var obj = {
        ITCImageIcrE: {
            ECtrl: {
                ECtrlMode: mode
            }
        }
    };

    if (mode == 'time') {
        var tsList = [];
        for (var i = 0; i < 2; i++) {
            var start = $('#ircStartTimeTR'+(i+1)+'_preset').val();
            var end =$('#ircEndTimeTR'+(i+1)+'_preset').val();

            var ss = start.split(':');
            var es = end.split(":");

            tsList.push({
                timeId: i,
                PresetId: $(pSel+' #presetTypeTR'+(i+1)).val(),
                startHour: parseInt(ss[0], 10),
                startMinute: parseInt(ss[1], 10),
                endHour: parseInt(es[0], 10),
                endMinute: parseInt(es[1], 10)
            });
        };

        var pList = [];
        for (var i = 0; i < 2; i++) {
            pList.push({
                PresetId: i,
                PresetVal: $.g.getEleVal(pSel+' #E_Preset_'+i)
            });
        };

        obj.ITCImageIcrE.ECtrl.TimeMode = {
            PresetList:{
                Preset: pList
            },
            SwitchList: {
                timeSwitch: tsList
            }
        };
    }else if (mode == 'auto') {
        obj.ITCImageIcrE.ECtrl.AutoMode = {
            DayNightFilterTh: $.g.getEleVal(pSel+' #E_DayNightFilterTh'),
            ExceptionCatchTh: $.g.getEleVal(pSel+' #E_ExceptionCatchTh')
        }
    }else if (mode == 'manual') {
        obj.ITCImageIcrE.ECtrl.ManualMode = {
            ManualPresetVal: $.g.getEleVal(pSel+' #E_ManualPresetVal')
        };
    };

    var xml = x2js.json2xml_str(obj, true);
    return xml;
}

// 描红
function LightCorParam() {
    this.lightCorrentVersion="1";
    SingletonInheritor.implement(this);

}
SingletonInheritor.declare(LightCorParam);

pr(LightCorParam).update = function () {
    $("#SaveConfigBtn").show();
    VideoParamStop();

    var self = this;

    var url = m_lHttp + m_szHostName + ":" + m_lHttpPort + 
                '/PSIA/Custom/SelfExt/ITC/lightCorrect';

    self.url = url;
    // var url = '/doc/testXml/miaohong.xml';

    $('#showVd2RegionBtn').val("区域放大");

     $.ajax({
        type: "GET",
        url : url,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        }      
    }).done(function(data, error, xhr) {
        self.oriData = data;

        self.$xml = $(data);

        var $xml = self.$xml;
        if($xml.find("lightCorrentVersion").text()){
            self.lightCorrentVersion=$xml.find("lightCorrentVersion").text();
        }

        var jsonData = x2js.xml_str2json(xmlToStr(data));
        var arr = jsonData.lightCorParam.lightCorrentAreaList.lightCorrentArea;
        if (!arr) {
            arr = [];
        }else if (!$.isArray(arr)) {
            arr = [arr];
        };
        $.g.setField2('#bCorrent', $xml.find('bCorrent').eq(0).text(), true);

        $.g.setField2('#sensitivity', $xml.find('sensitivity').eq(0).text());
        $.g.setField2('#saturation', $xml.find('saturation').eq(0).text());
        $.g.setField2('#controlLevel', $xml.find('controlLevel').eq(0).text());
        $.g.setField2('#overExposureLenvel', $xml.find('overExposureLenvel').eq(0).text());
        $.g.setField2('#lightCorrentLevel', $xml.find('lightCorrentLevel').eq(0).text());

        VD2.init(arr,self.lightCorrentVersion);

        autoResizeIframe();
    }).fail(function () {
        alert("加载信号灯校正参数失败！")
    })

    
    autoResizeIframe();
}

pr(LightCorParam).submit = function () {
   //  var ele = $('#lightCorrentLevel')[0];
   // if (!CheackTriggerIntNum(ele, ele.value,'lalightCorrentLevel',0,100)) {
   //      return;
   // };

   var self  = this;

   var tmpJsonData = x2js.xml_str2json(xmlToStr(self.oriData));

   var isCorrect = $('#bCorrent').prop('checked') ? "true" : "false";
    
   tmpJsonData.lightCorParam.bCorrent = isCorrect;
   tmpJsonData.lightCorParam.sensitivity = $.g.getEleVal("#sensitivity");
   tmpJsonData.lightCorParam.saturation = $.g.getEleVal("#saturation");
   tmpJsonData.lightCorParam.controlLevel = $.g.getEleVal("#controlLevel");
   tmpJsonData.lightCorParam.overExposureLenvel = $.g.getEleVal("#overExposureLenvel");
   tmpJsonData.lightCorParam.lightCorrentLevel = $.g.getEleVal("#lightCorrentLevel");

   var tmpArr = window.VD2.getResultArray();

   var arr = [];

   for (var i = 0; i < tmpArr.length; i++) {
       var lt = tmpArr[i];

       var left = null;
       var top = null;
       var right = null;
       var bottom = null;
       if("2"==self.lightCorrentVersion){
            left = Math.round(lt.left * 10000);
            top = Math.round(lt.top * 10000);
            right = Math.round(lt.right * 10000);
            bottom = Math.round(lt.bottom * 10000);
       }else{
            left = Math.round(lt.left * 1000);
            top = Math.round(lt.top * 1000);
            right = Math.round(lt.right * 1000);
            bottom = Math.round(lt.bottom * 1000);
       };

       if (left > right) {
            var t = right;
            right = left;
            left = t;
       };

       if (bottom < top) {
            var t = bottom;
            bottom = top;
            top =t;
       };

        var bDigLight=null;
        if(lt.bDigLight){
            bDigLight=lt.bDigLight;
        }
        var yellowDelLight=null;
        if(lt.yellowDelLight){
            yellowDelLight=lt.yellowDelLight;
        }

       arr.push({
            lightCorrentAreaXStart: left,
            lightCorrentAreaYStart: top,
            lightCorrentAreaWidth: right - left,
            lightCorrentAreaHeight: bottom - top,
            bDigLight:bDigLight,
            yellowDelLight:yellowDelLight
       });
   };


   tmpJsonData.lightCorParam.lightCorrentNum  =arr.length;
   tmpJsonData.lightCorParam.lightCorrentAreaList = {
        lightCorrentArea: arr
   };

   var xmlDoc = x2js.json2xml_str(tmpJsonData, true);

    $.ajax({
        type: "PUT",
        url : self.url,
        data: xmlDoc,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success:function(data, error, xhr) {
            //yqw begin 保存成功后自动刷新实时场景图数据
            $('#showVd2RegionBtn').val("区域放大");
            pr(LightCorParam).update();
            $("#LightCorParamContent #lightIdx").val("1");
            //yqw end
            SaveState(xhr);
        },
        error:function (xhr) {
            SaveState(xhr);
        }
    });      
    
}