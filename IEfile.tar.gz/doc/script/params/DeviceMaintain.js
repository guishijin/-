// JavaScript Document
// 
var DeviceMaintain = {
	tabs: null	// 保存DeviceMaintain配置页面的tabs对象引用
};
var ImportMode=0;
/*************************************************
Function:		Maintain
Description:	构造函数，Singleton派生类
Input:			无			
Output:			无
return:			无				
*************************************************/
function Maintain() {
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(Maintain);

(function() { // Maintain implementation

	/*************************************************
	Function:		initCSS 类方法
	Description:	初始化CSS
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	Maintain.prototype.initCSS = function()
	{
		$("#diMaintain :button").addClass("button");
		$("#diMaintain :text").addClass("maintaintext");
	};
	
	/*************************************************
	Function:		update
	Description:	更新
	Input:			无	
	Output:			无
	return:			无				
	*************************************************/
	Maintain.prototype.update = function()
	{
		$("#SaveConfigBtn").hide();
		$("#SetResultTips").html("");
		g_transStack.clear();
		var that = this;
		g_transStack.push(function() {
			that.setLxd(parent.translator.getLanguageXmlDoc(["DeviceMaintain", "Maintain"]));
			parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
			parent.translator.translatePage(that.getLxd(), document);
		}, true);
	
		var szInfo = parent.translator.translateNode(this.getLxd(), 'laPlugin');
		if(!checkPlugin('0', szInfo, 1, 'normal')){
			return;
		}
		
		m_PreviewOCX = document.getElementById("PreviewActiveX");
		// <!--$("#PreviewActiveX")[0]. = document.getElementById("PreviewActiveX");-->
		$("#PreviewActiveX").css('width','1'); 
		if(!CompareFileVersion())
		{
			UpdateTips();
		}

        ia(Maintain).changeImportType();
        if($('#importType').val() == 1 && !$('#isUseOSD').prop("checked")&& !$('#isUseMODE').prop("checked")&& !$('#isUseIMAGE').prop("checked")&& !$('#isUseIOOUT').prop("checked")){
            $('#btnImport').prop("disabled", true);
        }
		autoResizeIframe();
	}
	
	/*************************************************
	Function:		restoreDefault 类方法
	Description:	恢复默认值
	Input:			szMode: "basic"-简单重启, "full"-完全重启
	Output:			无
	return:			无				
	*************************************************/
	Maintain.prototype.restoreDefault = function(szMode)
	{
		if("full"==szMode){
			if(!window.confirm("恢复出厂设置完成后设备将自动重启，确定恢复？")){
				return;
			}
		}
		var that = this;
		$.ajax({
			type: "put",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/factoryReset?mode=" + szMode,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");  
				
			},
			success: function(xmlDoc, textStatus, xhr) 
			{
				var szStatus = $(xmlDoc).find('statusString').eq(0).text();
				if ("OK" == szStatus)
				{
					var szRetInfo = m_szSuccessState + parent.translator.translateNode(that.getLxd(), 'tipsRestoreSucc');
					$("#SetResultTips").html(szRetInfo);
					setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
				}
				else if ("Reboot Required" == szStatus)
				{
					var szRetInfo = m_szSuccessState + parent.translator.translateNode(that.getLxd(), 'tipsRestoreReboot');
					$("#SetResultTips").html(szRetInfo); 
					setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
					pr(Maintain).confirmAndRestart();
				}
				else
				{
					var szRetInfo = m_szErrorState + parent.translator.translateNode(that.getLxd(), 'tipsRestoreFailed');
					$("#SetResultTips").html(szRetInfo); 
					setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
				}
			},
			error: function(xhr, textStatus, errorThrown) 
			{
				if (xhr.status === 403) 
				{
					var szRetInfo = m_szErrorState + m_szError8;
					$("#SetResultTips").html(szRetInfo);
					setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
				};
			}
		});
	}
	
	/*************************************************
	Function:		confirmAndRestart 类方法
	Description:	弹出提示并重启
	Input:			无		
	Output:			无
	return:			无				
	*************************************************/
	Maintain.prototype.confirmAndRestart = function()
	{
		if (window.confirm(m_szRestartAsk))
		{
			pr(Maintain).restart();
			return true;
		}
		else 
		{
			return false;
		}
	}
	
	/*************************************************
	Function:		restart 类方法
	Description:	重启设备
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	Maintain.prototype.restart = function()
	{
		$.ajax({
			type: "PUT",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/reboot",
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0"); 
			},
			success: function(xmlDoc, textStatus, xhr) 
			{
				if ("OK" == xmlDoc.documentElement.getElementsByTagName('statusString')[0].childNodes[0].nodeValue)
				{
					var szRetInfo = m_szWaitState + m_szRestartSuccess;
					window.parent.$("#ConfigDivUpdateBlock").show().html("<div style='position:relative; top:50%; margin:0 auto; height:30px; width:100%; text-align:center;'>"+szRetInfo+"</div>");
					setTimeout("Maintain.prototype.reconnect()",20000);
				}
				else
				{
					var szRetInfo = m_szErrorState + m_szRestartFailed;
					$("#SetResultTips").html(szRetInfo);
					setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
				}
			},
			error: function(xhr, textStatus, errorThrown) 
			{
				if (xhr.status === 403) {
					var szRetInfo = m_szErrorState + m_szError8;
					$("#SetResultTips").html(szRetInfo);
					setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
				};
			}
		});
	}
	/*************************************************
	Function:		reconnect 类方法
	Description:	重连设备
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	Maintain.prototype.reconnect = function()
	{
		$.ajax(
		{
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/userCheck",
			async: true,
			timeout: 60000,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) 
			{
				window.parent.$("#ConfigDivUpdateBlock").hide();
				window.parent.$("#ConfigDivUpdateBlock").empty();
			},
			error: function(xhr, textStatus, errorThrown)
			{
				setTimeout(function()
				{
					Maintain.prototype.reconnect();
				},5000);
			}
		});
	}
	
	Maintain.prototype.StartImportVio = function  () {
		 var szFileName = $("#teVioTypeFile").val();
        if (szFileName == "")
        {
            szAreaNameInfo = m_szErrorState + parent.translator.translateNode(this.getLxd(), 'ImportVioFailedTips');
            $("#laVioImporting").html(szAreaNameInfo);
            return;
        }
        var szImportURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/illegalCodeData";

        var iRet = m_PreviewOCX.HWP_ImportDeviceConfig(szImportURL, m_szUserPwdValue, szFileName, 0);
        if (iRet == -1)
        {
            szAreaNameInfo = m_szErrorState + parent.translator.translateNode(this.getLxd(), 'ImportVioFailedTips');
            $("#laVioImporting").html(szAreaNameInfo);
            setTimeout(function(){$("#laVioImporting").html("");},5000);  //5秒后自动清除
            return;
        }
        else
        {
            szAreaNameInfo = m_szSuccessState + parent.translator.translateNode(this.getLxd(), 'ImportVioSuccessTips');
            $("#laVioImporting").html(szAreaNameInfo);
            setTimeout(function(){$("#laVioImporting").html("");},5000);  //5秒后自动清除
            pr(Maintain).confirmAndRestart();
            return;
        }
	}

	/*************************************************
	Function:		StartUp
	Description:	开始远程升级
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	Maintain.prototype.StartUp = function()
	{
		var szAreaNameInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
		var szFileName = $("#teUpgradeFile").val();
		
		if(szFileName == "")
		{
			szAreaNameInfo += parent.translator.translateNode(this.getLxd(), 'tipsUpgradeFailed');
			$("#laServerUping").html(szAreaNameInfo);
			return;
		}
		
		var szUpgradeURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/updateFirmware";
		var szStatusURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/upgradeStatus";
		
		var iRet = m_PreviewOCX.HWP_StartUpgrade(szUpgradeURL, szStatusURL, m_szUserPwdValue, szFileName);
		if(iRet == -1)
		{
			szAreaNameInfo += parent.translator.translateNode(this.getLxd(), 'tipsUpgradeFailed');
			$("#laServerUping").html(szAreaNameInfo);
			return;
		}
		window.parent.$("#ConfigDivUpdateBlock").show();
		m_iUpdateTimerID = setInterval("Maintain.prototype.GetUpgradeStatus()",1000);
		$("#laServerUping").html("");
	}
	
	/*************************************************
	Function:		GetUpgradeStatus
	Description:	获取设备升级状态
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/	
	Maintain.prototype.GetUpgradeStatus = function()
	{
		var szAreaNameInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
		var iStatus = m_PreviewOCX.HWP_UpgradeStatus();
		if (iStatus == 0)
		{
			var iProcess = m_PreviewOCX.HWP_UpgradeProgress();
			if (iProcess < 0)
			{
				clearInterval(m_iUpdateTimerID);
				window.parent.$("#ConfigDivUpdateBlock").hide();
				alert(parent.translator.translateNode(this.getLxd(), 'tipsGetProgress'));
				return;
			}
			else if (iProcess < 100)
			{
				$("#laServerUping").html(m_szWaitState + parent.translator.translateNode(this.getLxd(), 'tipsUpdating') + parent.translator.translateNode(this.getLxd(), 'laProcess') + iProcess + "%");
			}
			else
			{
				$("#laServerUping").html(parent.translator.translateNode(this.getLxd(), 'tipsUpdateSucc'));
				m_PreviewOCX.HWP_StopUpgrade();
				clearInterval(m_iUpdateTimerID);		
				window.parent.$("#ConfigDivUpdateBlock").hide();
				//抓拍机升级后提示自动重启
				if(!pr(Maintain).confirmAndRestart()){
					$("#laServerUping").html(parent.translator.translateNode(this.getLxd(), 'tipsUpdateSucc'));
					setTimeout(function(){$("#laServerUping").html("");},5000);  //5秒后自动清除
				}
			}
		}
		else if (iStatus == 1)
		{
			m_PreviewOCX.HWP_StopUpgrade();
			$("#laServerUping").html(szAreaNameInfo + parent.translator.translateNode(this.getLxd(), 'tipsUpgradeFailed'));
			setTimeout(function(){$("#laServerUping").html("");},5000);  //5秒后自动清除
			clearInterval(m_iUpdateTimerID);
			window.parent.$("#ConfigDivUpdateBlock").hide();
			return;
		}
		else if (iStatus == 2)
		{
			m_PreviewOCX.HWP_StopUpgrade();
			$("#laServerUping").html(szAreaNameInfo + parent.translator.translateNode(this.getLxd(), 'tipsLanguageMismatch'));
			setTimeout(function(){$("#laServerUping").html("");},5000);  //5秒后自动清除
			clearInterval(m_iUpdateTimerID);
			window.parent.$("#ConfigDivUpdateBlock").hide();
			return;
		}
		else
		{
			clearInterval(m_iUpdateTimerID);
			window.parent.$("#ConfigDivUpdateBlock").hide();
			alert(parent.translator.translateNode(this.getLxd(), 'tipsGetStatus'));
			return;
		}
	}


    /*************************************************
     Function:		changeImportMode
     Description:	改变导入模式参数; OSD MODE IMAGE IOOUT
     Input:			无
     Output:			无
     return:			无
     *************************************************/
    Maintain.prototype.changeImportMode = function(){

        if(!$('#isUseOSD').prop("checked")&& !$('#isUseMODE').prop("checked")&& !$('#isUseIMAGE').prop("checked")&& !$('#isUseIOOUT').prop("checked")){
            $('#btnImport').prop("disabled", true);
        }else{
            $('#btnImport').prop("disabled", false);
        }
    }

    /*************************************************
     Function:		changeImportType
     Description:	改变导入方式 0：全部导入；1：部分导入
     Input:			无
     Output:			无
     return:			无
     *************************************************/
    Maintain.prototype.changeImportType = function(){

        if($('#importType').val() == 0) {
            $('#partImportInfoContent').css("display","none");
            $('#btnImport').prop("disabled", false);
            ImportMode = 0;
        }else if($('#importType').val() == 1) {
            $('#partImportInfoContent').css("display","block");
            if(!$('#isUseOSD').prop("checked")&& !$('#isUseMODE').prop("checked")&& !$('#isUseIMAGE').prop("checked")&& !$('#isUseIOOUT').prop("checked")){
                $('#btnImport').prop("disabled", true);
            }
            ImportMode = 1;
        }
        else{
            $('#partImportInfoContent').css("display","none");
            $('#btnImport').prop("disabled", false);
            ImportMode = 2;
        }
        autoResizeIframe();
    }
    /*************************************************
     Function:		ImportParam
     Description:	导入配置参数方法
     Input:			无
     Output:			无
     return:			无
     *************************************************/
    Maintain.prototype.ImportParam = function(){
        var iRet = 1;
        var obj = this;
        if((ImportMode == 0) || (ImportMode == 1))
        {

            var szFileName = $("#inImportFile").val();
            if (szFileName == "") {
                szAreaNameInfo = m_szErrorState + parent.translator.translateNode(this.getLxd(), 'ImportFailedTips');
                $("#laImportUping").html(szAreaNameInfo);
                return;
            }
            var szImportURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/configurationData";
            if ($('#importType').val() == 1) {

                if ($('#isUseOSD').prop("checked") || $('#isUseMODE').prop("checked") || $('#isUseIMAGE').prop("checked") || $('#isUseIOOUT').prop("checked")) {

                    szImportURL += "?type=";
                    var paramArr = new Array();
                    if ($('#isUseOSD').prop("checked")) {
                        paramArr.push("OSD");
                    }
                    if ($('#isUseMODE').prop("checked")) {
                        paramArr.push("MODE");
                    }
                    if ($('#isUseIMAGE').prop("checked")) {
                        paramArr.push("IMAGE");
                    }
                    if ($('#isUseIOOUT').prop("checked")) {
                        paramArr.push("IOOUT");
                    }
                    szImportURL += paramArr.join("&");
                }
            }
            iRet = m_PreviewOCX.HWP_ImportDeviceConfig(szImportURL, m_szUserPwdValue, szFileName, 0);
            if (iRet == -1) {
                szAreaNameInfo = m_szErrorState + parent.translator.translateNode(this.getLxd(), 'ImportFailedTips');
                $("#laImportUping").html(szAreaNameInfo);
                setTimeout(function () {
                    $("#laImportUping").html("");
                }, 5000);  //5秒后自动清除
                return;
            }
            if (iRet == 0) {
                szAreaNameInfo = m_szSuccessState + parent.translator.translateNode(this.getLxd(), 'ImportSuccessTips');
                $("#laImportUping").html(szAreaNameInfo);
                setTimeout(function () {
                    $("#laImportUping").html("");
                }, 5000);  //5秒后自动清除
                window.parent.$("#ConfigDivUpdateBlock").hide();
                pr(Maintain).confirmAndRestart();
                return;
            }
        }
        else {
            window.parent.$("#ConfigDivUpdateBlock").show();
            szAreaNameInfo = m_szSuccessState + parent.translator.translateNode(obj.getLxd(), 'ImportDuartionTips');
            $("#laImportUping").html(szAreaNameInfo);
            setTimeout(function () {
                var szFileName = $("#inImportFile").val();
                if (szFileName == "") {
                    szAreaNameInfo = m_szErrorState + parent.translator.translateNode(this.getLxd(), 'ImportFailedTips');
                    $("#laImportUping").html(szAreaNameInfo);
                    return;
                }
                var szImportURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/configurationData";
                if ($('#importType').val() == 1) {

                    if ($('#isUseOSD').prop("checked") || $('#isUseMODE').prop("checked") || $('#isUseIMAGE').prop("checked") || $('#isUseIOOUT').prop("checked")) {

                        szImportURL += "?type=";
                        var paramArr = new Array();
                        if ($('#isUseOSD').prop("checked")) {
                            paramArr.push("OSD");
                        }
                        if ($('#isUseMODE').prop("checked")) {
                            paramArr.push("MODE");
                        }
                        if ($('#isUseIMAGE').prop("checked")) {
                            paramArr.push("IMAGE");
                        }
                        if ($('#isUseIOOUT').prop("checked")) {
                            paramArr.push("IOOUT");
                        }
                        szImportURL += paramArr.join("&");
                    }
                }
                iRet = m_PreviewOCX.HWP_ImportDeviceConfig(szImportURL, m_szUserPwdValue, szFileName, 0);
                if (iRet == -1) {
                    szAreaNameInfo = m_szErrorState + parent.translator.translateNode(obj.getLxd(), 'ImportFailedTips');
                    $("#laImportUping").html(szAreaNameInfo);
                    setTimeout(function () {
                        $("#laImportUping").html("");
                    }, 5000);  //5秒后自动清除
                    return;
                }
                if (iRet == 0) {
                    szAreaNameInfo = m_szSuccessState + parent.translator.translateNode(obj.getLxd(), 'ImportSuccessTips');
                    $("#laImportUping").html(szAreaNameInfo);
                    setTimeout(function () {
                        $("#laImportUping").html("");
                    }, 5000);  //5秒后自动清除
                    window.parent.$("#ConfigDivUpdateBlock").hide();
                    pr(Maintain).confirmAndRestart();
                    return;
                }
            }, 1000);
        }
    }


    Maintain.prototype.ExportVioType = function () {
    	var szExportURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/illegalCodeData";
		var iRet = m_PreviewOCX.HWP_ExportDeviceConfig(szExportURL, m_szUserPwdValue, '', 0);
		if (iRet < 0)
		{
			szAreaNameInfo = m_szErrorState + parent.translator.translateNode(this.getLxd(), 'ExportVioFailedTips');
			$("#laVioTypeExporting").html(szAreaNameInfo);
			setTimeout(function(){$("#laVioTypeExporting").html("");},5000);  //5秒后自动清除
			return;
		}
		else if(iRet == 0)
		{
			 var a = parent.translator.translateNode(this.getLxd(), 'ExportVioSuccessTips');
			 szAreaNameInfo = m_szSuccessState + parent.translator.translateNode(this.getLxd(), 'ExportVioSuccessTips');
			 $("#laVioTypeExporting").html(szAreaNameInfo);
			 setTimeout(function(){$("#laVioTypeExporting").html("");},5000);  //5秒后自动清除
			 return;
		}
    }
	/*************************************************
	Function:		ExportParam
	Description:	导出配置参数
	Input:			无			
	Output:			无
	return:			无
	*************************************************/	
	Maintain.prototype.ExportParam = function()	
	{
		var szExportURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/configurationData";
		var iRet = m_PreviewOCX.HWP_ExportDeviceConfig(szExportURL, m_szUserPwdValue, '', 0);
		if (iRet < 0)
		{
			szAreaNameInfo = m_szErrorState + parent.translator.translateNode(this.getLxd(), 'ExportFailedTips');
			$("#laExportUping").html(szAreaNameInfo);
			setTimeout(function(){$("#laExportUping").html("");},5000);  //5秒后自动清除
			return;
		}
		else if(iRet == 0)
		{
			 var a = parent.translator.translateNode(this.getLxd(), 'ExportSuccessTips');
			 szAreaNameInfo = m_szSuccessState + parent.translator.translateNode(this.getLxd(), 'ExportSuccessTips');
			 $("#laExportUping").html(szAreaNameInfo);
			 setTimeout(function(){$("#laExportUping").html("");},5000);  //5秒后自动清除
			 return;
		}
	}

})(); // Maintain implementation