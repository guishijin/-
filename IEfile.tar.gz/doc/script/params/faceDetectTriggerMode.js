function faceDetectTriggerModeS () {
	SingletonInheritor.implement(this);	
}

SingletonInheritor.declare(faceDetectTriggerModeS);

faceDetectTriggerModeS.prototype.updateLang = function () {
	$('#CommendParamBtn, #SaveConfigBtn').hide();

	g_transStack.clear();
	var that = ia(faceDetectTriggerModeS);
	g_transStack.push(function() {
		var prsDoc = parent.translator.getLanguageXmlDoc("faceDetectTriggerMode");
		that.setLxd(prsDoc);
		
		var tModeDoc = parent.translator.getLanguageXmlDoc("TriggerMode");
		parent.translator.appendLanguageXmlDoc(that.getLxd(), tModeDoc);
		
		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	}, true);
};

(function() {
	var faceDetectTriggerMode = window.faceDetectTriggerMode || {};

	var $xml = null;
	var sTriggerTypeCurNum=null;
	var triggerIONum=0;

	var paramJsonObject = null;

	faceDetectTriggerMode.update = function () {
		if ($("#main_plugin").html() == "") {
			if (checkPlugin('2', getNodeValue('laPlugin'), 1, 'snapdraw', 0)) {
				if (!CompareFileVersion()) {
					UpdateTips();
				}
			}
		}
		InitSlider2();
		GetParam();
		
		setTimeout(function(){
			HWP.Stop();
			HWP.Play();
			if (HWP.Play() !== 0) {
				alert(getNodeValue("previewfailed"));
			}
		}, 300);

		autoResizeIframe();
	}

	faceDetectTriggerMode.updateLang = function () {
		ia(faceDetectTriggerModeS).updateLang();
	}

	//cmd代表是否获得推荐值
	function GetParam(cmd){
		var tail = '';
		if (cmd) {
			tail = '/recommendation';
		};
		var capaRes = GetCapa();

		$.ajax({
	        type: "GET",
	        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/faceDetect"+tail,
	        timeout: 15000,
	        dataType: 'text', 
	        beforeSend: function(xhr) {
	            xhr.setRequestHeader("If-Modified-Since", "0");
	        },
	        success: function(xmlDoc, textStatus, xhr) {
	            var originalXml = parseXmlFromStr(xmlDoc);
	            $xml = $(originalXml);

	            paramJsonObject = x2js.xml_str2json(xmlDoc);

	            var rlist = paramJsonObject.faceDetect.ruleList;
	            if (!rlist || !rlist.ruleParam) {
	            	paramJsonObject.faceDetect.ruleList = {
	            		ruleParam : []
	            	}
	            }else if (!$.isArray(rlist.ruleParam)) {
	            	rlist.ruleParam = [rlist.ruleParam];
	            };

	            var laneCount = $xml.find('curRuleNum').eq(0).text();
	            fillLaneCountOptions(capaRes.ruleCount.min, capaRes.ruleCount.max, laneCount);
                var shieldCount = $xml.find('curShieldNum').eq(0).text();
                fillShieldCountOptions(capaRes.shieldCount.min, capaRes.shieldCount.max, shieldCount);

	            $.each(['enableAttrDetect','onlyFacePic','streamWithVCA','algVersion','generateRate',
	            	'snapTime','sensitive','snapInterval','snapThreshold','exposureEnabled','brightRef',
	            	'expDurationTime','ROIEnable','dspPicAddTarget'],function(i,n){
            		if($("#"+n).length){
            			var valParam=$xml.find(n).eq(0).text();
	            		$.g.setField2("#"+n,valParam,true);
            		}
	            });

	            faceDetectTriggerMode.lastLaneIndex = false;
	            faceDetectTriggerMode.changefacedetectCount(laneCount);
	            faceDetectTriggerMode.changeShieldCount(shieldCount);
	        },
	        error: function(xhr, textStatus, errorThrown) {
	            alert("获取参数失败！");
	        }
	    });
	}

	function GetCapa () {
		var url = m_lHttp + m_szHostName + ":"+m_lHttpPort 
					+ '/PSIA/Custom/SelfExt/ITC/facedetect/capabilities';
		var res = {
			ruleCount: {
                min: 1,
                max: 1
            },
            shieldCount: {
                min: 1,
                max: 1
            }
		};
		$.ajax({
			type: "GET",
			url: url,
			timeout: 15000,
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				var $nd = $(xmlDoc).find('ruleNum').eq(0);
				if ($nd.length) {
					var min = parseInt($nd.attr('min'));
					var max = parseInt($nd.attr('max'));

					if (min >=0 && max >= 1) {
						res.ruleCount.min = min;
						res.ruleCount.max = max;
					};
				};

                var $nd = $(xmlDoc).find('shieldNum').eq(0);
                if($nd.length){
                    var min = parseInt($nd.attr('min'));
                    var max = parseInt($nd.attr('max'));

                    if (min >=0 && max >= 1) {
                        res.shieldCount.min = min;
                        res.shieldCount.max = max;
                    };
                }
			}
		});

		return res;
	}

	function fillLaneCountOptions(min, max, curVal){
		if (min < 0) {
			min = 0;
		}
        var $s = $('#RelatedLaneCount_facedetect');
        $s.find('option').remove();

        for (var i=min; i <= max; i++) {
            var opt = "<option value='"+i+"' ";
            if (curVal != null && i == curVal) {
                opt += " selected='selected' ";
            }
            opt += ">"+i+"</option>";
            $s.append(opt);
        }
        autoResizeIframe();
    }

    function fillShieldCountOptions(min, max, curVal){
        if (min < 0) {
            min = 0;
        }
        var $s = $('#shieldCount_facedetect');
        $s.find('option').remove();

        for (var i=min; i <= max; i++) {
            var opt = "<option value='"+i+"' ";
            if (curVal != null && i == curVal) {
                opt += " selected='selected' ";
            }
            opt += ">"+i+"</option>";
            $s.append(opt);
        }
        autoResizeIframe();
    }

    faceDetectTriggerMode.changeShieldCount = function (shieldCount) {
    	if (!shieldCount) {
    		shieldCount = 1;
    	};

    	var sList = paramJsonObject.faceDetect.shieldList;
        if (!sList || !sList.shieldParam) {
        	paramJsonObject.faceDetect.shieldList = {
        		shieldParam : []
        	}
        }else if (!$.isArray(sList.shieldParam)) {
        	sList.shieldParam = [sList.shieldParam];
        };

		var sList = paramJsonObject.faceDetect.shieldList.shieldParam;
		if (sList.length > shieldCount) {
			// sList.length = shieldCount;
		}else if(sList.length < shieldCount){
			for (var i = sList.length; i < shieldCount; i++) {
				sList[i] = {
					shieldNo: i+1,
					enable: true
				}
			};
		}

		displayRegions();
    }

	faceDetectTriggerMode.changefacedetectCount = function (laneCount) {
		if (!laneCount) {
			laneCount = 1;
		};

		paramJsonObject.faceDetect.ruleList.ruleParam = paramJsonObject.faceDetect.ruleList.ruleParam_asArray;
		var ruleParams = paramJsonObject.faceDetect.ruleList.ruleParam;
		if (ruleParams.length > laneCount) {
			// ruleParams.length = laneCount;
		}else if(ruleParams.length < laneCount){
			for (var i = ruleParams.length; i < laneCount; i++) {
				ruleParams[i] = {
					ruleNo: i+1,
					enable: false,
					// ruleRegion: {
					// 	regionCoordinatesList:{
					// 		regionCoordinates: []
					// 	}
					// },
					sizeFilterParam: {
						enable: false
						// sizeFilteMinRect: {},
						// sizeFilteMaxRect: {}
					}
				}
			};
		}

		displayRegions();
	}



	faceDetectTriggerMode.selectLane = function (laneIndex) {
		var $a = $('#tabfacedetect a').eq(laneIndex);
		if (!$a.length) {
			return;
		};

		$('#tabfacedetect a').removeClass('current');
		$a.addClass('current');

		this.restoreLaneParam();
		this.displayLaneParam(laneIndex);

		this.lastLaneIndex = laneIndex;
		this.showAllShapes();
	}



	faceDetectTriggerMode.SetParam=function(){
		ia(TriggerMode).m_bRebootRequired = false;

		var laneCount = $('#RelatedLaneCount_facedetect').val();
		var shieldCount = $('#shieldCount_facedetect').val();

		paramJsonObject.faceDetect.ruleList.ruleParam.length = laneCount;
		paramJsonObject.faceDetect.shieldList.shieldParam.length = shieldCount;

		var xml = x2js.json2xml_str(paramJsonObject);
		var xmlDoc = parseXmlFromStr(xml);

		var $xml=$(xmlDoc);

		$.each(['enableAttrDetect','onlyFacePic','streamWithVCA','algVersion','generateRate',
        	'snapTime','sensitive','snapInterval','snapThreshold','exposureEnabled','brightRef',
        	'expDurationTime','ROIEnable','dspPicAddTarget'],function(i,n){
    		if($("#"+n).length){
    			var valParam=$.g.getEleVal("#"+n);
    			$xml.find(n).eq(0).text(valParam);
    		}
        });
		
		if ($xml.find('ruleParam').length != laneCount) {
			alert("请为每个规则绘制规则区域！");
			return;
		};

		$xml.find('ruleParam').each(function () {
			var ruleNo = $(this).find('ruleNo').text();
			if ($(this).find('ruleRegion').find('regionCoordinates').length < 3) {
				alert("请为规则"+ruleNo+"绘制规则区域！");
				return;
			};
		});

		$xml.find("curRuleNum").eq(0).text(laneCount);

		var sc = $xml.find('shieldRegion').length;
		$xml.find('curShieldNum').eq(0).text(sc);
		
		$.ajax({
	        type: "PUT",
	        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/facedetect",
	        timeout: 15000,
	        dataType:"text",
	        data: xmlToStr(xmlDoc),
			processData: false,
	        beforeSend: function(xhr) {
	            xhr.setRequestHeader("If-Modified-Since", "0");
	            
	        },
			complete:function(xhr, textStatus) {
				if(xhr.status != 200) {
					if(xhr.status == 403) {
						var szErrorInfo = m_szError8;
						szRetInfo = m_szErrorState + szErrorInfo;
					} else {
						var xmlDoc =xhr.responseXML;
						if($(xmlDoc).find("detailedStatusCode").eq(0).text() != "") {
							var szErrorInfo = getNodeValue("Error" + $(xmlDoc).find("detailedStatusCode").eq(0).text());
						} else {
							var szErrorInfo = m_szError13;
						}
						szRetInfo = m_szErrorState + szErrorInfo;
					}
		            $("#SetResultTips").html(szRetInfo); 
			        setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			        return;	
				} else {
					if($(xhr.responseXML).find("statusCode").eq(0).text() == "7") {
						ia(TriggerMode).m_bRebootRequired = true;
					}

					SaveState(xhr);
				}
			}
	    });
	}

	faceDetectTriggerMode.GetCommendParam = function(){
		GetParam(true);
	}

	faceDetectTriggerMode.showAllShapes = function(){
		var ruleIdxArr = [];

		// var v = $('#drawAllPicCheck').prop('checked');
		var v = true;
		if (v) {
			var laneCount = $('#RelatedLaneCount_facedetect').val();
	    	laneCount = parseInt(laneCount, 10);
	    	for (var i = 1; i <= laneCount; i++) {
				ruleIdxArr.push(i);
			}
		}else{
			if (this.lastLaneIndex === false) {
				ruleIdxArr = [1];
			}else{
				ruleIdxArr.push(this.lastLaneIndex+1);
			}
		}

		DisplayfacedetectShapes(ruleIdxArr);
	}

	function DisplayfacedetectShapes (ruleIdxArr, ocxSel, sheildIdxArr, useTmpXmlEle, dispOpt) {
	    if (!ocxSel) {
		    ocxSel = '#PreviewActiveX';
	    }
	    var ocx = $(ocxSel)[0];
	    try{
	    	ocx.HWP_ClearSnapInfo(4	);
	    }catch(e){}

	    var selMode = false;
	    if (useTmpXmlEle) {
	    	selMode = true;
	    };

	    var shieldIdxArr = [];
		for (var i = 0; i < $("#shieldCount_facedetect").val(); i++) {
			shieldIdxArr.push(i+1);
		};

		var rlist = paramJsonObject.faceDetect.ruleList;
        if (!rlist || !rlist.ruleParam) {
        	paramJsonObject.faceDetect.ruleList = {
        		ruleParam : []
        	}
        }else if (!$.isArray(rlist.ruleParam)) {
        	rlist.ruleParam = [rlist.ruleParam];
        };

        var regionInfos = {
        	SnapPolygonList:{
				SnapPolygon: []
			}
        };

        var rlen = $('#RelatedLaneCount_facedetect').val();
        // _.each(rlist.ruleParam, function (r) {
        for(var ridx = 0; ridx < rlen; ridx++){
        	var r = rlist.ruleParam[ridx];

        	var ruleNo = parseInt(r.ruleNo, 10);
        	if (_.contains(ruleIdxArr, ruleNo) 
        			&& r.ruleRegion 
        			&& r.ruleRegion.regionCoordinatesList 
        			&& r.ruleRegion.regionCoordinatesList.regionCoordinates) {
        		var ptArr = [];
        		_.each(r.ruleRegion.regionCoordinatesList.regionCoordinates, function (rc) {
        			var x=parseInt(rc.positionX, 10);
					var y=parseInt(rc.positionY, 10);
					if(!(x == 0 && y == 0 )){
						ptArr.push({
							x:(x/1000).toFixed(3),
							y:(y/1000).toFixed(3)
						})
					}
        		});
        		if (ptArr.length > 1) {
        			regionInfos.SnapPolygonList.SnapPolygon.push({
        				id: 100+ruleNo,
						polygonType: 1,
						color: {r: 0, g: 255, b: 0},
						tips: '规则'+ruleNo,
						isClosed: "true",
						PointNumMax:11,
						MinClosed:5,
						pointList: {
							point: ptArr
						}
        			});	
        		};

        		if (r.sizeFilterParam) {
        			var minRect = r.sizeFilterParam.sizeFilteMinRect;
        			if (minRect) {
        				var x = parseInt(minRect.positionX, 10);
        				var y = parseInt(minRect.positionY, 10);
        				var w = parseInt(minRect.width, 10);
        				var h = parseInt(minRect.height, 10);
        				
        				if (w > 0 && h > 0) {
        					regionInfos.SnapPolygonList.SnapPolygon.push({
		        				id: 200+ruleNo,
								polygonType: 0,
								color: {r: 255, g: 255, b: 0},
								tips: '最小瞳距'+ruleNo,
								isClosed: "true",
								PointNumMax:5,
								MinClosed:5,
								pointList: {
									point: [{
										x: (x/1000).toFixed(3),
										y: (y/1000).toFixed(3)
									},{
										x: ((x+w)/1000).toFixed(3),
										y: (y/1000).toFixed(3)
									},{
										x: ((x+w)/1000).toFixed(3),
										y: ((y+h)/1000).toFixed(3)
									},{
										x: (x/1000).toFixed(3),
										y: ((y+h)/1000).toFixed(3)
									}]
								}
		        			});	
        				}
        			};

        			var maxRect = r.sizeFilterParam.sizeFilteMaxRect;
        			if (maxRect) {
        				var x = parseInt(maxRect.positionX, 10);
        				var y = parseInt(maxRect.positionY, 10);
        				var w = parseInt(maxRect.width, 10);
        				var h = parseInt(maxRect.height, 10);
        				
        				if (w > 0 && h > 0) {
        					regionInfos.SnapPolygonList.SnapPolygon.push({
		        				id: 300+ruleNo,
								polygonType: 0,
								color: {r: 255, g: 255, b: 0},
								tips: '最大瞳距'+ruleNo,
								isClosed: "true",
								PointNumMax:5,
								MinClosed:5,
								pointList: {
									point: [{
										x: (x/1000).toFixed(3),
										y: (y/1000).toFixed(3)
									},{
										x: ((x+w)/1000).toFixed(3),
										y: (y/1000).toFixed(3)
									},{
										x: ((x+w)/1000).toFixed(3),
										y: ((y+h)/1000).toFixed(3)
									},{
										x: (x/1000).toFixed(3),
										y: ((y+h)/1000).toFixed(3)
									}]
								}
		        			});	
        				}
        			};
        		}
        	}

        }; // end rlist

		var sList = paramJsonObject.faceDetect.shieldList;
        if (!sList || !sList.shieldParam) {
        	paramJsonObject.faceDetect.shieldList = {
        		shieldParam : []
        	}
        }else if (!$.isArray(sList.shieldParam)) {
        	sList.shieldParam = [sList.shieldParam];
        };

        var slen = $('#shieldCount_facedetect').val();
        // _.each(sList.shieldParam, function (s, idx) {
        for(var sidx = 0; sidx<slen; sidx++){
        	var s = sList.shieldParam[sidx];
        	var idx = sidx;

        	// var shieldNo = parseInt(s.shieldNo, 10);
        	var shieldNo = idx+1;
        	if (s && s.shieldRegion 
        			&& s.shieldRegion.regionCoordinatesList 
        			&& s.shieldRegion.regionCoordinatesList.regionCoordinates) {
        		var ptArr = [];
        		_.each(s.shieldRegion.regionCoordinatesList.regionCoordinates, function (rc) {
        			var x=parseInt(rc.positionX, 10);
					var y=parseInt(rc.positionY, 10);
					if(!(x == 0 && y == 0 )){
						ptArr.push({
							x:(x/1000).toFixed(3),
							y:(y/1000).toFixed(3)
						})
					}
        		});
        		if (ptArr.length > 1) {
        			regionInfos.SnapPolygonList.SnapPolygon.push({
        				id: 400+shieldNo,
						polygonType: 1,
						color: {r: 255, g: 0, b: 0},
						tips: '屏蔽'+shieldNo,
						isClosed: "true",
						PointNumMax:11,
						MinClosed:5,
						pointList: {
							point: ptArr
						}
        			});	
        		};
        	}
        };

	   	try{	
			var xml = x2js.json2xml_str(regionInfos, true);
			ocx.HWP_SetSnapPolygonInfo(xml);
			
			if (selMode) {
				try{
		    		ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
		    	}catch(e){}
			}
		}catch(e){}
	}

    //存储临时变量
	function RestorefacedetectToTmpObj () {
		var ocx = $("#facedetectDrawPlugin")[0];
		if(!ocx){
			return;
		}
		var polygonXml=parseXmlFromStr(ocx.HWP_GetSnapPolygonInfo());
		
		var rlist = paramJsonObject.faceDetect.ruleList;
        if (!rlist || !rlist.ruleParam) {
        	paramJsonObject.faceDetect.ruleList = {
        		ruleParam : []
        	}
        }else if (!$.isArray(rlist.ruleParam)) {
        	rlist.ruleParam = [rlist.ruleParam];
        };

        var sList = paramJsonObject.faceDetect.shieldList;
        if (!sList || !sList.shieldParam) {
        	paramJsonObject.faceDetect.shieldList = {
        		shieldParam : []
        	}
        }else if (!$.isArray(sList.shieldParam)) {
        	sList.shieldParam = [sList.shieldParam];
        };

		$(polygonXml).find("SnapPolygon").each(function(i,n){
			var $this=$(this);
			var id=parseInt($this.find("id").eq(0).text(),10);
			if(id >= 100 && id < 200){
				// 规则区域
				var ruleNo=id%100;

				var rpts = [];
				$this.find('point').each(function () {
					var x = $(this).find('x').text();
					var y = $(this).find('y').text();
					x = Math.round(parseFloat(x) * 1000);
					y = Math.round(parseFloat(y) * 1000);
					rpts.push({
						positionX: x,
						positionY: y
					});
				});

				var p = _.find(rlist.ruleParam, function (v) {
					return v.ruleNo == ruleNo;
				});
				if (p) {
					p["ruleRegion"]= {
						regionCoordinatesList: {
							regionCoordinates: rpts
						}
					}
				};

				
			}else if(id >= 200 && id < 300){
				// 尺寸过滤最小矩阵
				var ruleNo=id%100;
				
				var minX=10000, maxX=0, minY=10000, maxY=0;
				$this.find('point').each(function () {
					var x = $(this).find('x').text();
					var y = $(this).find('y').text();
					x = Math.round(parseFloat(x) * 1000);
					y = Math.round(parseFloat(y) * 1000);
					minX = Math.min(minX, x);
					maxX = Math.max(maxX, x);
					minY = Math.min(minY, y);
					maxY = Math.max(maxY, y);
				});

				var w = maxX - minX;
				var h = maxY - minY;

				var p = _.find(rlist.ruleParam, function (v) {
					return v.ruleNo == ruleNo;
				});

				if (p) {
					p["sizeFilterParam"]["sizeFilteMinRect"]= {
						positionX: minX,
						positionY: minY,
						width: w,
						height: h
					}

					p.sizeFilterParam.enable = true;	
				};
				
			}else if(id >= 300 && id < 400){
				// 尺寸过滤最大矩阵
				var ruleNo=id%100;

				var minX=10000, maxX=0, minY=10000, maxY=0;
				$this.find('point').each(function () {
					var x = $(this).find('x').text();
					var y = $(this).find('y').text();
					x = Math.round(parseFloat(x) * 1000);
					y = Math.round(parseFloat(y) * 1000);
					minX = Math.min(minX, x);
					maxX = Math.max(maxX, x);
					minY = Math.min(minY, y);
					maxY = Math.max(maxY, y);
				});

				var w = maxX - minX;
				var h = maxY - minY;

				var p = _.find(rlist.ruleParam, function (v) {
					return v.ruleNo == ruleNo;
				});

				if (p) {
					p["sizeFilterParam"]["sizeFilteMaxRect"]= {
						positionX: minX,
						positionY: minY,
						width: w,
						height: h
					}	
				};
				
			}else if(id >= 400 && id < 500){
				// 屏蔽区域
				var ruleNo=id%100;

				var rpts = [];
				$this.find('point').each(function () {
					var x = $(this).find('x').text();
					var y = $(this).find('y').text();
					x = Math.round(parseFloat(x) * 1000);
					y = Math.round(parseFloat(y) * 1000);
					rpts.push({
						positionX: x,
						positionY: y
					});
				});
				if (!sList.shieldParam[ruleNo-1]) {
					sList.shieldParam[ruleNo-1] = {};
				}
				sList.shieldParam[ruleNo-1]["shieldRegion"]= {
					regionCoordinatesList: {
						regionCoordinates: rpts
					}
				}
			}
		});
	}

	faceDetectTriggerMode.ShowDrawPolygonModal = function() {
		if (!g_bIsIE) {
	        $("#facedetect_Draw_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='facedetectDrawPlugin' width='100%' height='100%' name='facedetectDrawPlugin' align='center' wndtype='1' playmode='snapdraw'>");
	    } else {
	        $("#facedetect_Draw_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='facedetectDrawPlugin' width='100%' height='100%' name='facedetectDrawPlugin' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
	    }
	    var ruleIdxArr = [];

	    var laneCount = $('#RelatedLaneCount_facedetect').val();
	    laneCount = parseInt(laneCount, 10);

	    if (laneCount == 0) {
	    	$('#ruleWrapper1').hide();
	    }else{
	    	$('#ruleWrapper1').show();
	    	var ruleStr = [];
		    for (var i = 0; i < laneCount; i++) {
		    	ruleStr.push('<option value="'+(i+1)+'">'+''+(i+1)+'</option>');
		    	ruleIdxArr.push(i+1);
		    };
		    $('#ruleSelect').html(ruleStr.join(''));	
	    }
	    
	    var shieldCount=$("#shieldCount_facedetect").val();
	    shieldCount=parseInt(shieldCount, 10);

	    if (shieldCount == 0) {
	    	$('#ruleWrapper2').hide();
	    }else{	
	    	$('#ruleWrapper2').show();
	    	var shieldStr = [];
		    for (var i = 0; i < shieldCount; i++) {
		    	shieldStr.push('<option value="'+(i+1)+'">'+''+(i+1)+'</option>');
		    };
		    $('#shieldSelect').html(shieldStr.join(''));
	    }
	    

        HWP.Stop();
        $("#main_plugin").hide();

        $('#facedetectModalDiv').modal();

        setTimeout(function () {
        	DisplayfacedetectShapes(ruleIdxArr, '#facedetectDrawPlugin', null, true);

	        var ocx = $('#facedetectDrawPlugin')[0];		
			try{
				//设置为选择模式
				ocx.HWP_SetSnapDrawMode(0, 3);  
			}catch(e){}
        }, 500);

        var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
        var iRet = $("#facedetectDrawPlugin")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
        if (iRet !== 0) {
            alert(getNodeValue("previewfailed"));
        }
	}


	function displayRegions(){
		faceDetectTriggerMode.showAllShapes();
	}


	faceDetectTriggerMode.OkModel = function(){
		$("#main_plugin").show();

		setTimeout(function () {
			if (HWP.Play() !== 0) {
		        alert(getNodeValue("previewfailed"));
		    }	
		}, 300);
	    
	    
	   	RestorefacedetectToTmpObj();

	   	var ocx = $("#facedetectDrawPlugin")[0];
		try{
			var iRet = ocx.HWP_Stop(0);
		}catch(e){}
	    $.modal.impl.close();
	    displayRegions();
	}

	faceDetectTriggerMode.CancelModel = function () {
		$("#main_plugin").show();
	    setTimeout(function () {
			if (HWP.Play() !== 0) {
		        alert(getNodeValue("previewfailed"));
		    }	
		}, 300);

	    var ocx = $("#facedetectDrawPlugin")[0];
		try{
			var iRet = ocx.HWP_Stop(0);
		}catch(e){}
	    $.modal.impl.close();
	    displayRegions();
	}

	function redrawRect (regionId, ocxSel, color, polygonName) {
		if (!color) {
			color = {r: 255, g: 255, b: 0};
		};
		var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>"
					+ regionId
					+ "</id><polygonType>0</polygonType><tips>" + polygonName
					+ "</tips><isClosed>false</isClosed>"
					+ "<color><r>"+color.r+"</r><g>"+color.g+"</g><b>"+color.b+"</b></color><pointList/></SnapPolygon></SnapPolygonList>";
		var ocx = $(ocxSel)[0];
		try{
			var iRet = ocx.HWP_SetSnapPolygonInfo(szInfo3);
		}catch(e){}
		try{
			ocx.HWP_SetSnapDrawMode(0, 1);  //设置为选择模式
		}catch(e){}
	}

	function reDrawPolygonFace (regionId, ocxSel, color, polygonName) {
		if (!color) {
			color = {r: 255, g: 255, b: 0};
		};

		var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>"
					+ regionId
					+ "</id><polygonType>1</polygonType><tips>" + polygonName
					+ "</tips><isClosed>false</isClosed><PointNumMax>11</PointNumMax><MinClosed>5</MinClosed>"
					+ "<color><r>"+color.r+"</r><g>"+color.g+"</g><b>"+color.b+"</b></color><pointList/></SnapPolygon></SnapPolygonList>";
		var ocx = $(ocxSel)[0];
		try{
			var iRet = ocx.HWP_SetSnapPolygonInfo(szInfo3);
		}catch(e){}
		try{
			ocx.HWP_SetSnapDrawMode(0, 2);  //设置为选择模式
		}catch(e){}
	}


    faceDetectTriggerMode.drawRuleRegion = function(){
        var ruleNo = $('#facedetectModalDiv #ruleSelect').val();
        var polygonId = 100+parseInt(ruleNo, 10);

        reDrawPolygonFace(polygonId, 
        		'#facedetectDrawPlugin', 
        		{r: 0, g:255, b:0}, "规则"+ruleNo);	
    }
    faceDetectTriggerMode.drawRuleMin = function(){
    	var ruleNo = $('#facedetectModalDiv #ruleSelect').val();
        var polygonId = 200+parseInt(ruleNo, 10);

        redrawRect(polygonId, 
        		'#facedetectDrawPlugin', 
        		{r: 255, g:255, b:0}, "最小"+ruleNo);	
    }
    faceDetectTriggerMode.drawRuleMax = function(){
    	var ruleNo = $('#facedetectModalDiv #ruleSelect').val();
        var polygonId = 300+parseInt(ruleNo, 10);

        redrawRect(polygonId, 
        		'#facedetectDrawPlugin', 
        		{r: 255, g:255, b:0}, "最大"+ruleNo);	
    }
    faceDetectTriggerMode.reDrawShieldRegion = function(){
    	var ruleNo = $('#facedetectModalDiv #shieldSelect').val();
        var polygonId = 400+parseInt(ruleNo, 10);

        reDrawPolygonFace(polygonId, 
        		'#facedetectDrawPlugin', 
        		{r: 255, g:0, b:0}, "屏蔽"+ruleNo);	
    }


    faceDetectTriggerMode.showAdvParam = function () {
    	if ($('#generateRate').is(":hidden")) {
    		$('#divAdvancedParam_facedetect > div').not("#advWrapper").show();
    		$("#advancedButton").addClass("show");
    	}else{
    		$('#divAdvancedParam_facedetect > div').not("#advWrapper").hide();
    		$("#advancedButton").removeClass("show");
    	}
    }



	window.faceDetectTriggerMode = faceDetectTriggerMode;
})();

