function Audio() {
    SingletonInheritor.implement(this);
}
SingletonInheritor.declare(Audio);
pr(Audio).update = function() {
    $('#SetResultTips').html('');
    $("#SaveConfigBtn").show();
    g_transStack.clear();
    var that = this;
    g_transStack.push(function() {
        that.setLxd(parent.translator.getLanguageXmlDoc(["VideoAudio", "Audio"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);
    initAudio();
}
/*************************************************
Function:		initAudio
Description:	初始化音频配置页面
Input:			无			
Output:			无
return:			无				
*************************************************/
function initAudio()
{
	GetAudioAbility();
	/*GetAudioInfo();*/
	autoResizeIframe();
}
/*************************************************
Function:		GetAudioAbility
Description:	获取音频能力集
Input:			无			
Output:			无
return:			无				
*************************************************/
function GetAudioAbility()
{
	$.ajax(
	{
		type: "GET",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/TwoWayAudio/channels/1/capabilities",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) 
		{
			if($(xmlDoc).find('audioCompressionType').length > 0)
			{
				$("#divAudioCompressionType").show();
				$("#selectAudioCompressionType").empty();
				var oAudioCompressionType = $(xmlDoc).find('audioCompressionType').eq(0).attr("opt").split(",");
				for(i = 0;i < oAudioCompressionType.length; i++)
				{
					$("<option value='"+ oAudioCompressionType[i] +"'>"+ oAudioCompressionType[i] +"</option>").appendTo("#selectAudioCompressionType");
				}
			}
			else
			{
				$("#divAudioCompressionType").hide();
			}
			if($(xmlDoc).find('audioInputType').length > 0)
			{
				$("#divAudioInputType").show();	
				$("#selectAudioInputType").empty();
				var oAudioInputType = $(xmlDoc).find('audioInputType').eq(0).attr("opt").split(",");
				for(i = 0;i < oAudioInputType.length; i++)
				{
					$("<option value='"+ oAudioInputType[i] +"'>"+ oAudioInputType[i] +"</option>").appendTo("#selectAudioInputType");
				}
			}
			else
			{
				$("#divAudioInputType").hide();
			}
			GetAudioInfo();
		}
	});
}
/*************************************************
Function:		GetAudioAbility
Description:	获取音频信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function GetAudioInfo()
{
	$.ajax(
	{
		type: "GET",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/TwoWayAudio/channels/1",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) 
		{
			if($(xmlDoc).find('audioCompressionType').length > 0)
			{ 
				$("#selectAudioCompressionType").val($(xmlDoc).find('audioCompressionType').eq(0).text());
			}
			if($(xmlDoc).find('audioInputType').length > 0)
			{
				$("#selectAudioInputType").val($(xmlDoc).find('audioInputType').eq(0).text());
			}
		}
	});
}
/*************************************************
Function:		setAudioInfo
Description:	音频设置
Input:			无			
Output:			无
return:			无				
*************************************************/
function setAudioInfo()
{
	var xmlDoc = null;
	var szXml = "";
	szXml = "<?xml version='1.0' encoding='UTF-8'?>";
	szXml += "<TwoWayAudioChannel version='1.0' xmlns='http://www.hikvision.com/ver10/XMLSchema'>";
	szXml += "<id>1</id>";
	szXml +="<enabled>true</enabled>";
	if($("#divAudioCompressionType").css("display") != "none")
	{
		szXml += "<audioCompressionType>" + $("#selectAudioCompressionType").val() + "</audioCompressionType>";
	}
	if($("#divAudioInputType").css("display") != "none")
	{
		szXml += "<audioInputType>" + $("#selectAudioInputType").val() + "</audioInputType>";
	}
	szXml += "</TwoWayAudioChannel>";
	xmlDoc = parseXmlFromStr(szXml);
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/TwoWayAudio/channels/1",
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}