function dodgePedestrianTriggerModeS () {
	SingletonInheritor.implement(this);	
}

SingletonInheritor.declare(dodgePedestrianTriggerModeS);

dodgePedestrianTriggerModeS.prototype.updateLang = function () {
	$('#CommendParamBtn, #SaveConfigBtn').hide();

	g_transStack.clear();
	var that = ia(dodgePedestrianTriggerModeS);
	g_transStack.push(function() {
		var prsDoc = parent.translator.getLanguageXmlDoc("dodgePedestrianTriggerMode");
		that.setLxd(prsDoc);
		
		var tModeDoc = parent.translator.getLanguageXmlDoc("TriggerMode");
		parent.translator.appendLanguageXmlDoc(that.getLxd(), tModeDoc);
		
		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	}, true);
};

(function() {
	var dodgePedestrianTriggerMode = window.dodgePedestrianTriggerMode || {};

	var ParamLoaded = false;
	
	var originalXml = null;
	var $xml = null;
	var sTriggerTypeCurNum=null;
	var triggerIONum=0;

	dodgePedestrianTriggerMode.update = function () {
		if ($("#main_plugin").html() == "") {
			if (checkPlugin('2', getNodeValue('laPlugin'), 1, 'snapdraw', 0)) {
				if (!CompareFileVersion()) {
					UpdateTips();
				}
			}
		}

		GetParam();
		
		setTimeout(function(){
			HWP.Stop();
			HWP.Play();
			if (HWP.Play() !== 0) {
				alert(getNodeValue("previewfailed"));
			}
		}, 300);

		autoResizeIframe();
	}

	//cmd代表是否获得推荐值
	function GetParam(cmd){
		ParamLoaded = false;

		var tail = '';
		if (cmd) {
			tail = '/recommendation';
		};
        
		var laneCountRes = GetLaneCount();  

		$.ajax({
	        type: "GET",
	        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/dodgePedestrian"+tail,
	        timeout: 15000,
	        dataType: 'text', 
	        beforeSend: function(xhr) {
	            xhr.setRequestHeader("If-Modified-Since", "0");
	
	        },
	        success: function(xmlDoc, textStatus, xhr) {
	            originalXml = parseXmlFromStr(xmlDoc);
	            $xml = $(originalXml);

	            var laneCount = $xml.find('relateLaneCount').eq(0).text();
	            ParamLoaded = true;
	            fillLaneCountOptions(laneCountRes.min, laneCountRes.max, laneCount);

	            dodgePedestrianTriggerMode.lastLaneIndex = false;
	            dodgePedestrianTriggerMode.changedodgePedestrianCount(laneCount);

	            GetPlateRegionParam(cmd);
	        },
	        error: function(xhr, textStatus, errorThrown) {
	            alert("获取参数失败！");
	        }
	    });
	}

	function GetPlateRegionParam(cmd){
		var url = m_lHttp + m_szHostName + ":"+m_lHttpPort + 
				"/PSIA/Custom/SelfExt/ITC/PlateRecognition/dodgePedestrian";//dodgePedestrian
		if (cmd) {
			url += "/recommendation";
		}

		PlateRegion.GetPlateRecognition(url, function(){
			displayRegions();
		});
	}

	dodgePedestrianTriggerMode.changedodgePedestrianCount = function (laneCount) {
		if (!laneCount) {
			laneCount = 1;
		};

		$('#tabdodgePedestrian li').each(function (i, n) {
			if (i < laneCount) {
				$(this).show();
			}else{
				$(this).hide();
			}
		});
		var current = $('#tabdodgePedestrian a.current').not(":hidden");

		// 行人检测区域
		$("#sCheckRuleList div").each(function(i, n) {
			if (i < laneCount) {
				$(this).show();
			}else{
				$(this).hide();
			}
		});

		if (current.length == 0) {
			this.selectLane(0);
		} else {
			var idx = current.eq(0).parent().attr('id').replace("adodgePedestrianLane", "");
			idx = parseInt(idx, 10) - 1;
			this.selectLane(idx);
		}

		displayRegions();
	}

	dodgePedestrianTriggerMode.selectLane = function (laneIndex) {
		var $a = $('#tabdodgePedestrian a').eq(laneIndex);
		if (!$a.length) {
			return;
		};

		$('#tabdodgePedestrian a').removeClass('current');
		$a.addClass('current');

		this.restoreLaneParam();
		this.displayLaneParam(laneIndex);

		this.lastLaneIndex = laneIndex;
		this.showAllShapes();
	}

	function GetLaneCount () {
		var url = m_lHttp + m_szHostName + ":"+m_lHttpPort 
					+ '/PSIA/Custom/SelfExt/ITC/dodgePedestrian/capabilities';
		var res = {
			min: 1, 
			max: 1
		};
		$.ajax({
			type: "GET",
			url: url,
			timeout: 15000,
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				var $nd = $(xmlDoc).find('relateLaneCount').eq(0);
				if ($nd.length) {
					min = parseInt($nd.attr('min'));
					max = parseInt($nd.attr('max'));

					if (min >=0 && max >= 1) {
						res.min = min;
						res.max = max;
					};
				};
			}
		});

		return res;
	}

	function fillLaneCountOptions(min, max, curVal){
		if (min <= 0) {
			min = 1;
		}
        var $s = $('#RelatedLaneCount_dodgePedestrian');
        $s.find('option').remove();

        for (var i=min; i <= max; i++) {
            var opt = "<option value='"+i+"' ";
            if (curVal != null && i == curVal) {
                opt += " selected='selected' ";
            }
            opt += ">"+i+"</option>";
            $s.append(opt);
        }
        autoResizeIframe();
    }

	function SetParam(callback){
		ia(TriggerMode).m_bRebootRequired = false;
		dodgePedestrianTriggerMode.restoreLaneParam();

		var laneCount = $('#RelatedLaneCount_dodgePedestrian').val();
		$(originalXml).find("relateLaneCount").eq(0).text(laneCount);
		
		$.ajax({
	        type: "PUT",
	        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/dodgePedestrian",
	        timeout: 15000,
	        dataType:"text",
	        data: xmlToStr(originalXml),
			//processData: false,
	        beforeSend: function(xhr) {
	            xhr.setRequestHeader("If-Modified-Since", "0");
	            
	        },
			complete:function(xhr, textStatus) {
				if(xhr.status != 200) {
					if(xhr.status == 403) {
						var szErrorInfo = m_szError8;
						szRetInfo = m_szErrorState + szErrorInfo;
					} else {
						var xmlDoc =xhr.responseXML;
						if($(xmlDoc).find("detailedStatusCode").eq(0).text() != "") {
							var szErrorInfo = getNodeValue("Error" + $(xmlDoc).find("detailedStatusCode").eq(0).text());
						} else {
							var szErrorInfo = m_szError13;
						}
						szRetInfo = m_szErrorState + szErrorInfo;
					}
		            $("#SetResultTips").html(szRetInfo); 
			        setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			        return;	
				} else {
					if($(xhr.responseXML).find("statusCode").eq(0).text() == "7") {
						ia(TriggerMode).m_bRebootRequired = true;
					}

					if (callback) {
						callback();
					}
				}
			}
	    });
	}

	dodgePedestrianTriggerMode.updateLang = function () {
		ia(dodgePedestrianTriggerModeS).updateLang();
	}
    
    //存储每个车道下的数据，非识牌区
	dodgePedestrianTriggerMode.restoreLaneParam = function (laneIndex) {
		if (typeof laneIndex == 'undefined') {
			laneIndex = this.lastLaneIndex;
		};
		if (this.lastLaneIndex === false) {
			return;
		};

		var $laneparam=$xml.find("LaneList").eq(0).find("Lane").eq(laneIndex);
        $.each(['relateDriveWay', 'passerNumThreshold', 
        	'carSpeedThreshold','carDistanceThreshold'], function (i, n) {
        	var v = $.g.getEleVal('#dvdodgePedestrian #'+n);
			if (v !== '') {
				$laneparam.find(n).eq(0).text(v);
			}		
        });
        $.each($laneparam.find("CheckRule"),function(i,n){
        	var $n=$(n);
        	var id=$n.find("id").text();
        	var left = $.g.getEleVal('#dvdodgePedestrian #ruleLeft'+id);
			if (left !== '') {
				$n.find("ruleLeft").eq(0).text(left);
			}	
			var right = $.g.getEleVal('#dvdodgePedestrian #ruleRight'+id);
			if (right !== '') {
				$n.find("ruleRight").eq(0).text(right);
			}
        });
	}
    
    //显示此车道之前存储的数据，非识牌区
	dodgePedestrianTriggerMode.displayLaneParam = function (laneIndex) {
		if (typeof laneIndex == 'undefined') {
			return;
		};
       
        var $laneparam=$xml.find("LaneList").eq(0).find("Lane").eq(laneIndex);
        $.each(['relateDriveWay','passerNumThreshold', 
        	'carSpeedThreshold','carDistanceThreshold'], function (i, n) {
        	$.g.setField2('#dvdodgePedestrian #'+n, $laneparam.find(n).eq(0).text());		
        });
        $.each($laneparam.find("CheckRule"),function(i,n){
        	var $n=$(n);
        	var id=$n.find("id").text();
        	$.g.setField2('#dvdodgePedestrian #ruleLeft'+id,$n.find("ruleLeft").eq(0).text());
        	$.g.setField2('#dvdodgePedestrian #ruleRight'+id,$n.find("ruleRight").eq(0).text());
        });
	}

	dodgePedestrianTriggerMode.GetCommendParam = function(){
		GetParam(true);
	}

	dodgePedestrianTriggerMode.SetParam = function(){
		SetParam(function(){
			var url = m_lHttp + m_szHostName + ":"+m_lHttpPort + 
				"/PSIA/Custom/SelfExt/ITC/PlateRecognition/dodgePedestrian";
			PlateRegion.SetPlateRecognition(url);
		});
	}

	dodgePedestrianTriggerMode.showAllShapes = function(){
		var idxArr = [];

		var v = $('#drawPicCheck').prop('checked');
		if (v) {
			var laneCount = $('#RelatedLaneCount_dodgePedestrian').val();
	    	laneCount = parseInt(laneCount, 10);
	    	for (var i = 1; i <= laneCount; i++) {
				idxArr.push(i);
			}
		}else{
			if (this.lastLaneIndex === false) {
				idxArr = [1];
			}else{
				idxArr.push(this.lastLaneIndex+1);
			}
		}

		DisplaydodgePedestrianShapes(idxArr);
	}

    //线数据存储临时变量
	var dodgePedestrianTmp;
	function RestoredodgePedestrianToTmpObj () {
		//将线数据存到临时变量中
		RestorePRSLines('#dodgePedestrianDrawPlugin');
		// 将不礼让行人区域存到临时变量中
		RestorePasserRegion('#dodgePedestrianDrawPlugin');
		//将区域数据存到临时变量中
		PlateRegion.RestorePlateRegion('#dodgePedestrianDrawPlugin', true);
	}
	function RestorePasserRegion(ocxSel){
		var ocx = $(ocxSel)[0];
		if (!ocx) {
			return;
		};

		var PasserRegion = $(dodgePedestrianTmp).find("PasserRegion");
		var regionXml=ocx.HWP_GetSnapPolygonInfo();
		$(parseXmlFromStr(regionXml)).find("SnapPolygon").each(function(){
			var $s=$(this);
			var id=$s.find("id").eq(0).text();
			if("700"==id){
				$s.find('point').each(function (i,n) {
					var x = Math.floor(parseFloat($(n).find('x').text())*1000);
					var y = Math.floor(parseFloat($(n).find('y').text())*1000);
					$(PasserRegion).find("RegionCoordinates").eq(i).find("positionX").text(x);
					$(PasserRegion).find("RegionCoordinates").eq(i).find("positionY").text(y);
				});
			}
		});
	}
    
	function RestorePRSLines (ocxSel) {
		var ocx = $(ocxSel)[0];
		if (!ocx) {
			return;
		};

		var $xmlDoc = $(dodgePedestrianTmp);

		var lineXml = ocx.HWP_GetSnapLineInfo();
		$(parseXmlFromStr(lineXml)).find('SnapLine').each(function () {
			var lineId = $(this).find('id').eq(0).text();

			var $st = $(this).find("StartPos");
			var $et = $(this).find("EndPos");

			var sx = parseFloat($st.find('x').text());
			var sy = parseFloat($st.find('y').text());
			var ex = parseFloat($et.find('x').text());
			var ey = parseFloat($et.find('y').text());

			lineId = parseInt(lineId,10);

			sx = Math.floor(sx*1000);
			sy = Math.floor(sy*1000);
			ex = Math.floor(ex*1000);
			ey = Math.floor(ey*1000);

			var $line;

			if (lineId > 300 && lineId < 400) { //停止线
				var lineNum = lineId % 100 - 1;
				$line = $xmlDoc.find('Lane').eq(lineNum).find("ViolationDetectLine").eq(0);
			}else if (lineId > 200 && lineId < 300){   // 车道线
				var lineNum = lineId % 100 - 1;
				$line = $xmlDoc.find('Lane').eq(lineNum).find("ViolationDetectLine").eq(1);
			}else if(lineId==400){//右边界线
				$line=$xmlDoc.find("VirtualLane").eq(0);
			}else if(lineId==500){//不礼让行人触发线
				$line=$xmlDoc.find("VirtualLane").eq(1);
			}

			$line.find('positionX').eq(0).text(sx);
			$line.find('positionX').eq(1).text(ex);
			$line.find('positionY').eq(0).text(sy);
			$line.find('positionY').eq(1).text(ey);
		});
	}

	function DisplaydodgePedestrianShapes (regionIdArray, ocxSel, color, useTmpXmlEle, dispOpt) {
        // 画线
		DisplaydodgePedestrianLines(regionIdArray, ocxSel,color, useTmpXmlEle, dispOpt);
		// 画礼让行人区域
		DisplayPasserRegion(regionIdArray,ocxSel, color, useTmpXmlEle);
        // 画区域
		PlateRegion.DisplayPlateRegionEx(regionIdArray,ocxSel, color, useTmpXmlEle);
	}

	function DisplayPasserRegion(regionIdArray,ocxSel, color, useTmpXmlEle){
		var domEle;
	    if (useTmpXmlEle && dodgePedestrianTmp) {
	    	domEle = dodgePedestrianTmp;
	    }else{
		    domEle = originalXml;	
	    }
	    if (!color) {
		    color = {r: 255, g:255, b:0};
	    }
	    if (!ocxSel) {
		    ocxSel = '#PreviewActiveX';
	    }
	    var ocx = $(ocxSel)[0];

	    // 画不礼让行人区域
	    var obj = {
			SnapPolygonList:{
				SnapPolygon: []
			}
		};
		var pts = [];
		var $r = $(domEle).find('PasserRegion');

		var $_pts = $r.find('RegionCoordinates');
		$_pts.each(function (i, n) {
			var tx = parseInt($(n).find('positionX').text());
			var ty = parseInt($(n).find('positionY').text());
			pts.push({
				x:(tx/1000).toFixed(3),
				y:(ty/1000).toFixed(3)
			});
		});

        var objDetColor = {r: 255, g:0, b:0};
		obj['SnapPolygonList']['SnapPolygon'].push({
			id: 700,
			polygonType: 0,
			color: objDetColor,
			tips: getNodeValue("PasserRegion"),
			isClosed: "true",
			PointNumMax:5,
			MinClosed:5,
			pointList: {
				point:pts
			}
		});
		var xml = x2js.json2xml_str(obj, true);
		try{	
			ocx.HWP_SetSnapPolygonInfo(xml);
			// ocx.HWP_SetSnapDrawMode(0, 3);
		}catch(e){}
	}

    function DisplaydodgePedestrianLines (regionIdArray, ocxSel, color, useTmpXmlEle, dispOpt) {
	    var domEle;
	    if (useTmpXmlEle && dodgePedestrianTmp) {
	    	domEle = dodgePedestrianTmp;
	    }else{
		    domEle = originalXml;	
	    }

	    if (!color) {
		    color = {r: 255, g:255, b:0};
	    }

	    if (!ocxSel) {
		    ocxSel = '#PreviewActiveX';
	    }
	    var ocx = $(ocxSel)[0];

	    var opts = {
		    laneLine: true,
		    stopLine:true,
		    laneRightBoundaryLine: true,
		    pedestrianTriggerLine:true,
		    PasserRegion:true
	    };

	    try{
	    	HWP.Play();
	    	ocx.HWP_ClearSnapInfo(2);
	    }catch(e){}

	    opts = $.extend({}, opts, dispOpt);

	    if (!opts.laneLine && !opts.laneRightBoundaryLine && opts.stopLine && opts.pedestrianTriggerLine) {
			return;
	    }
	    var snapLines = {
		    SnapLineList: {
		    	SnapLine:[]
		    }
	    };
	    if (opts.laneLine || opts.stopLine) {
	    	$(domEle).find('Lane').each(function () {
			    var laneId = parseInt($(this).find('laneId').text());
			    if (_.contains(regionIdArray, laneId)) {
			    	var $linelist = $(this).find('ViolationDetectLine');
			    	$linelist.each(function(){
			    		var $line=$(this);
			    		var lineName = $line.find('lineName').eq(0).text();
			    		// 画车道线
					    if (lineName == 'laneLine' && opts.laneLine) {
					    	var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
						    var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
						    var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
						    var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

						    var LineType = ia(TriggerMode).TransLineType(lineName);

						    var color = colorMap[LineType];
						    if (!color) {
						    	color = {r: 255, g: 255, b: 0};
						    }

						    var _line = {
						    	id: 200+laneId,
							    LineType: LineType,
							    Tips:  getNodeValue(szTips[LineType])+laneId,
							    StartPos: {
							    	x: startX,
								    y: startY
							    },
							    EndPos: {
								    x: endX,
								    y: endY
							    },
							    color: color
						    };

						    snapLines.SnapLineList.SnapLine.push(_line);
					    }
					    // 画停止线
					    if (lineName == 'stopLine' && opts.stopLine) {
					    	var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
						    var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
						    var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
						    var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

						    var LineType = ia(TriggerMode).TransLineType(lineName);

						    var color = colorMap[LineType];
						    if (!color) {
						    	color = {r: 255, g: 255, b: 0};
						    }

						    var _line = {
						    	id: 300+laneId,
							    LineType: LineType,
							    Tips:  getNodeValue(szTips[LineType])+laneId,
							    StartPos: {
							    	x: startX,
								    y: startY
							    },
							    EndPos: {
								    x: endX,
								    y: endY
							    },
							    color: color
						    };

						    snapLines.SnapLineList.SnapLine.push(_line);
					    }
			    	})
			    	
			    }
		    });
	    }
	    if (opts.laneRightBoundaryLine || opts.pedestrianTriggerLine) {
	    	var $virtualList = $(domEle).find('VirtualLane');
	    	$virtualList.each(function(){
	    		var $line=$(this);
	    		var lineName = $line.find('lineName').eq(0).text();
	    		// 画右边界线
			    if (lineName == 'laneRightBoundaryLine' && opts.laneRightBoundaryLine) {
			    	var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
				    var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
				    var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
				    var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

				    var LineType = ia(TriggerMode).TransLineType(lineName);

				    var color = colorMap[LineType];
				    if (!color) {
				    	color = {r: 255, g: 255, b: 0};
				    }

				    var _line = {
				    	id: 400,
					    LineType: LineType,
					    Tips:  getNodeValue(szTips[LineType]),
					    StartPos: {
					    	x: startX,
						    y: startY
					    },
					    EndPos: {
					    	x: endX,
						    y: endY
					    },
					    color: color
				    };

				    snapLines.SnapLineList.SnapLine.push(_line);
			    }
			    // 画不礼让行人触发线
			    if (lineName == 'pedestrianTriggerLine' && opts.pedestrianTriggerLine) {
			    	var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
				    var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
				    var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
				    var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

				    var LineType = ia(TriggerMode).TransLineType(lineName);

				    var color = colorMap[LineType];
				    if (!color) {
				    	color = {r: 255, g: 255, b: 0};
				    }

				    var _line = {
				    	id: 500,
					    LineType: LineType,
					    Tips:  getNodeValue("DrawPedestrianTriggerLinebtn"),
					    StartPos: {
					    	x: startX,
						    y: startY
					    },
					    EndPos: {
					    	x: endX,
						    y: endY
					    },
					    color: color
				    };

				    snapLines.SnapLineList.SnapLine.push(_line);
			    }
	    	})
	    }
	    
	    if (snapLines.SnapLineList.SnapLine.length) {
		    var szLineInfo = x2js.json2xml_str(snapLines);
		    ocx.HWP_SetSnapLineInfo(szLineInfo);
	    }
    }

	dodgePedestrianTriggerMode.SelectdodgePedestrianModal = function(laneIndex){
		$("#tabdodgePedestrianModal").find("li a").removeClass('current');
		$("#tabdodgePedestrianModal li").eq(laneIndex).find("a").addClass("current");
	}

	function drawLines() {
		RestoredodgePedestrianToTmpObj();

		var selIdx = -1;
	    var idxArr = [];
	    $("#tabdodgePedestrian").find("li").not(":hidden").each(function() {
	    	var idx = $(this).attr('id').replace("adodgePedestrianLane", "");
            idx = parseInt(idx);
            idxArr.push(idx);

            if($(this).children().hasClass("current")) {
            	selIdx = idx;
            }
        });
    
	    var opt = {
	    	laneLine: $('#laneLine_dodgePedestrian').prop('checked'),
    	    laneRightBoundaryLine: $('#laneRightLine_dodgePedestrian').prop('checked'),
		    stopLine:$('#laneStopLine_dodgePedestrian').prop('checked'),
		    pedestrianTriggerLine:$('#pedestrianTriggerLine_dodgePedestrian').prop('checked')
        };
	    DisplaydodgePedestrianShapes(idxArr, '#dodgePedestrianDrawPlugin', null, true, opt);

	    var ocx = $('#dodgePedestrianDrawPlugin')[0];		
		try{
			ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
		}catch(e){}
    }

	dodgePedestrianTriggerMode.initEvt=function(){
		$('#laneLine_dodgePedestrian, #laneRightLine_dodgePedestrian,#laneStopLine_dodgePedestrian,#pedestrianTriggerLine_dodgePedestrian').prop('checked', true).unbind().click(drawLines);
	}

	dodgePedestrianTriggerMode.reDrawdodgePedestrianPlateRegion=function() {
	    var selIdx = -1;
	    $("#tabdodgePedestrianModal").find("li").each(function() {
	    	if($(this).children().hasClass("current")) {
	    		var idx = $(this).attr('id').replace("lidodgePedestrian", "");
        	    selIdx = parseInt(idx);
            }
        });
	    if (selIdx >= 0) {
	    	PlateRegion.reDrawPlateRegion(selIdx, '#dodgePedestrianDrawPlugin');
	    }
    }

    dodgePedestrianTriggerMode.reDrawPasserRegion=function(){
    	var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>"
					+ "700"
					+ "</id><polygonType>1</polygonType><tips>" + getNodeValue('PasserRegion')
					+ "</tips><isClosed>false</isClosed><PointNumMax>5</PointNumMax><MinClosed>5</MinClosed><color><r>255</r><g>0</g><b>0</b></color><pointList/></SnapPolygon></SnapPolygonList>";
		var ocx = $("#dodgePedestrianDrawPlugin")[0];
		try{
			var xml="<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>700</id><polygonType>0</polygonType><color><r>255</r><g>0</g><b>0</b></color><tips>"+getNodeValue("PasserRegion")+"</tips><isClosed>true</isClosed><PointNumMax>5</PointNumMax><MinClosed>5</MinClosed><pointList></pointList></SnapPolygon></SnapPolygonList>"
			ocx.HWP_SetSnapPolygonInfo(xml)
			var iRet = ocx.HWP_SetSnapPolygonInfo(szInfo3);
		}catch(e){}
		try{
			ocx.HWP_SetSnapDrawMode(0, 2);  //设置为选择模式
		}catch(e){}
    }

    dodgePedestrianTriggerMode.initdodgePedestrianTemp = function () {
    	var x = xmlToStr(originalXml);
		dodgePedestrianTmp = x2js.parseXmlString(x);
    }

	dodgePedestrianTriggerMode.ShowDrawPolygonModal = function() {
		if (!g_bIsIE) {
	        $("#dodgePedestrian_Draw_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='dodgePedestrianDrawPlugin' width='100%' height='100%' name='dodgePedestrianDrawPlugin' align='center' wndtype='1' playmode='snapdraw'>");
	    } else {
	        $("#dodgePedestrian_Draw_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='dodgePedestrianDrawPlugin' width='100%' height='100%' name='dodgePedestrianDrawPlugin' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
	    }
        //初始化线的临时变量
		this.initdodgePedestrianTemp();
		//初始化区域的临时变量
		PlateRegion.GenTmpXmlEle();

	    var idxArr = [];

	    var laneCount = $('#RelatedLaneCount_dodgePedestrian').val();
	    laneCount = parseInt(laneCount, 10);
	    
	    for (var i = 0; i < 6; i++) {
	    	if (i < laneCount) {
	    		idxArr.push(i+1);
	    		var j = i+1;
	    		$('#lidodgePedestrian'+(i+1)).show();
	    	}else{
	    		$('#lidodgePedestrian'+(i+1)).hide();
	    	}
	    };
        
        $('#dodgePedestrianModalDiv').modal();

        dodgePedestrianTriggerMode.initEvt();

        setTimeout(function () {
        	DisplaydodgePedestrianShapes(idxArr, '#dodgePedestrianDrawPlugin', null, true);

	        var ocx = $('#dodgePedestrianDrawPlugin')[0];		
			try{
				//设置为选择模式
				ocx.HWP_SetSnapDrawMode(0, 3);  
			}catch(e){}
        }, 500);

        HWP.Stop();
        $("#main_plugin").hide();

        var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
        var iRet = $("#dodgePedestrianDrawPlugin")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
        if (iRet !== 0) {
            alert(getNodeValue("previewfailed"));
        }
	}


	function displayRegions(){
		dodgePedestrianTriggerMode.showAllShapes();
	}


	dodgePedestrianTriggerMode.OkModel = function(){
		$("#main_plugin").show();
	    if (HWP.Play() !== 0) {
	        alert(getNodeValue("previewfailed"));
	    }
	    
	   	RestoredodgePedestrianToTmpObj();
        originalXml=parseXmlFromStr(xmlToStr(dodgePedestrianTmp));
        PlateRegion.ConvertTmpToOri();

	    $.modal.impl.close();
	    displayRegions();
	}

	dodgePedestrianTriggerMode.CancelModel = function () {
		$("#main_plugin").show();
	    if (HWP.Play() !== 0) {
	        alert(getNodeValue("previewfailed"));
	    }
	    $.modal.impl.close();

	    displayRegions();
	}

	window.dodgePedestrianTriggerMode = dodgePedestrianTriggerMode;
})();

