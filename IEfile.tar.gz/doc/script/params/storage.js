var g_szMainVideoInfoXml = "";
var g_szSubMainVideoInfoXml = "";
var g_IsSupportCodecCom = false; //是否支持编码复杂度
var g_IsSupportMainStream = false; //是否支持主码流
var g_IsSupportSubMainStream = false;//是否支持子码流
var AudioAndVideo = {
    tabs: null   // 保存音视频配置页面的tabs对象引用
};
/*************************************************
 继承，未完成，wuyang
 *************************************************/
function VideoCode() {
    this.m_szMainStreamVideoCodecType = "H.264"; // 码流类型
    this.m_oXmlFisheye = null;
    this.m_oXmlLocalConfig = null;
    SingletonInheritor.implement(this);
}
SingletonInheritor.declare(VideoCode);
pr(VideoCode).update = function() {
    var szInfo = parent.translator.translateNode(this.getLxd(), 'laPlugin');
    /*if (!checkPlugin('0', szInfo)) {
        return;
    }
    m_PreviewOCX = document.getElementById("PreviewActiveX");
    if (!CompareFileVersion()) {
        UpdateTips();
    }*/
    $('#SetResultTips').html('');
    $("#SaveConfigBtn").show();
    g_transStack.clear();
    var that = this;
    g_transStack.push(function() {
        that.setLxd(parent.translator.getLanguageXmlDoc(["Storage", "Video"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);

    initVideoSetting();
}
/*************************************************
 继承，未完成，wuyang
 *************************************************/
function CloudComputing() {
    this.m_szMainStreamVideoCodecType = "H.264"; // 码流类型
    this.m_oXmlFisheye = null;
    this.m_oXmlLocalConfig = null;
    SingletonInheritor.implement(this);
}
SingletonInheritor.declare(CloudComputing);
pr(CloudComputing).update = function() {
    var szInfo = parent.translator.translateNode(this.getLxd(), 'laPlugin');
    /*if (!checkPlugin('0', szInfo)) {
        return;
    }
    m_PreviewOCX = document.getElementById("PreviewActiveX");
    if (!CompareFileVersion()) {
        UpdateTips();
    }*/
    $('#SetResultTips').html('');
    $("#SaveConfigBtn").show();
    g_transStack.clear();
    var that = this;
    g_transStack.push(function() {
        that.setLxd(parent.translator.getLanguageXmlDoc(["Storage", "CloudComputing"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);

    initCloudComputing();
}
function Roi() {
	this.m_iNorScreenWidth = 1000;
	this.m_iNorScreenHeight = 1000;
	this.m_oXml = null;
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(Roi);
pr(Roi).update = function () {
	var szInfo = parent.translator.translateNode(this.getLxd(), 'laPlugin');
	if (checkPlugin('1', szInfo, 1, 'tamperdetect')) {
		if (!CompareFileVersion()) {
			UpdateTips();
		}

		if (!g_bIsIE) {
			HWP.Stop(0);
		}
		//开预览
		if (!HWP.wnds[0].isPlaying) {
			setTimeout(function () {
				if (HWP.Play() !== 0) {
					alert(getNodeValue("previewfailed"));
				}
			}, 100);
		}
	}
	$('#SetResultTips').html('');
	$("#SaveConfigBtn").show();
	g_transStack.clear();
	var that = this;
	g_transStack.push(function () {
		that.setLxd(parent.translator.getLanguageXmlDoc(["Storage", "ROI"]));
		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	}, true);
	this.initROI();
}
/*************************************************
 Function:		initCSS
 Description:	初始化页面样式
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(VideoCode).initCSS = function()
{

}

VideoCode.MainStreamAdvanceInfo = function(){
    if($('#videoMainContentDiv').css("display") == "none"){
        $('#videoMainContentDiv').css("display","block");
    }else{
        $('#videoMainContentDiv').css("display","none");
    }
    autoResizeIframe();
}
VideoCode.SubMainStreamAdvanceInfo = function(){
    if($('#videoSubMainContentDiv').css("display") == "none"){
        $('#videoSubMainContentDiv').css("display","block");
    }else{
        $('#videoSubMainContentDiv').css("display","none");
    }
    autoResizeIframe();
}
/*************************************************
 Function:		VideoCode.EnableMainStreamCustom
 Description:	设置主码流自定义
 Input:			无
 Output:			无
 return:			无
 *************************************************/
VideoCode.EnableMainStreamCustom = function()
{
    if($("#constantBitRate").val() == 'Customize')
    {
        $("#customBitRate, #customBitRateUnit").show();
    }else
    {
        $("#customBitRate, #customBitRateUnit").hide();
        $("#MaxBitRatetips").html("");
    }
}

/*************************************************
 Function:		VideoCode.EnableSubMainCustom
 Description:	设置子码流自定义
 Input:			无
 Output:			无
 return:			无
 *************************************************/
VideoCode.EnableSubMainCustom = function()
{
    if($("#subConstantBitRate").val() == 'Customize')
    {
        $("#subCustomBitRate, #subCustomBitRateUnit").show();
    }else
    {
        $("#subCustomBitRate, #subCustomBitRateUnit").hide();
        $("#SubMaxBitRatetips").html("");
    }
}
/*************************************************
 Function:		initVideoSetting
 Description:	初始化视频配置页面
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function initVideoSetting()
{
    if(!window.parent.g_bIsSupportSubStream) {
        $("#StreamTypeIn").find("option").eq(1).remove();
    }
    GetMainOrSubMainAbility();
    GetVideoInfo();
    autoResizeIframe();
}
/*************************************************
 Function:		initCloudComputing
 Description:	初始化云存储页面
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function initCloudComputing()
{
    if(!window.parent.g_bIsSupportSubStream) {
        $("#StreamTypeIn").find("option").eq(1).remove();
    }
    GetMainOrSubMainAbility();
    GetCloudComputingInfo();
    autoResizeIframe();
}
/*************************************************
 Function:		changeVideoCodeType
 Description:	改变编码方式
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(VideoCode).changeVideoCodeType = function()
{
    ia(VideoCode).m_szMainStreamVideoCodecType = $("#videoCodecType").val();
    if($('#videoCodecType').val() == 'H.264')
    {
        if(g_IsSupportCodecCom)
        {
            $('#CodecComplexity_tr').show();
        }
    }
    else
    {
        $('#CodecComplexity_tr').hide();
    }
    this.initCSS();
}

var iMinRate = 0;
var iMaxRate = 0;
var iSubMinRate = 0;
var iSubMaxRate = 0;
var m_iResolution = "704*576";
var m_szChanStreamNum = 0;
var g_iMinIntervalFrameI = 0;
var g_iMaxIntervalFrameI = 0;

var g_iMinSubIntervalFrameI = 0;
var g_iMaxSubIntervalFrameI = 0;
var m_iSubResolution = "704*576";

/*************************************************
 Function:		GetMainOrSubMainAbility
 Description:	获取视频信息能力集
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function GetMainOrSubMainAbility(){
    $.ajax({
        type: "GET",
        url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Streaming/channels",
        async: false,
        timeout: 15000,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr){

            if($(xmlDoc).find('StreamingChannelList').length > 0){

                var StreamNum = $(xmlDoc).find('id').length;
                if(StreamNum > 0){

                    var ids = new Array();
                    for(var i=0; i < StreamNum; i++){
                        ids[i] = $(xmlDoc).find('id').eq(i).text();
                    }

                    for(var j=0; j< ids.length; j++){

                        switch(ids[j]){
                            case '1':
                                g_IsSupportMainStream = true;
                                GetVideoAbility(101);
                            case '2':
                                g_IsSupportSubMainStream = true;
                                GetVideoAbility(102);
                            default: break;
                        }
                    }
                    /*var VId = $(xmlDoc).find('id').eq(0).text();
                    if(VId == 1){
                        GetVideoAbility(101);
                    }
                    if(StreamNum == 2){
                        var SubId = $(xmlDoc).find('id').eq(1).text();
                        if(SubId == 2){
                            GetVideoAbility(102);
                        }
                    }*/
                }
            }
        }
    });
}

/*************************************************
 Function:		GetVideoAbility
 Description:	获取视频信息能力集
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function GetVideoAbility(StreamId)
{
    $("#SetResultTips").html("");
    $.ajax(
        {
            type: "GET",
            url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Streaming/channels/" + StreamId + "/capabilities",
            async: false,
            timeout: 15000,
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            success: function(xmlDoc, textStatus, xhr)
            {
                if(StreamId == 101){

                    //逐行和隔行
                    if($(xmlDoc).find('videoScanType').length > 0)
                     {
                        videoScanType = $(xmlDoc).find('videoScanType').eq(0).attr("opt").split(",");
                     }
                     else
                     {
                        videoScanType = "";
                     }
                    //分辨率
                    document.getElementById("videoResolution").options.length = 0;
                    var videoResolutionW = $(xmlDoc).find('videoResolutionWidth').eq(0).attr("opt").split(",");
                    var videoResolutionY = $(xmlDoc).find('videoResolutionHeight').eq(0).attr("opt").split(",");
                    var szOptionInfo = "";
                    for(i = 0;i < videoResolutionW.length; i++)
                    {
                        if((videoResolutionW[i] == "1920" &&  videoResolutionY[i] == "1080") || (videoResolutionW[i] == "1280" && videoResolutionY[i] == "720"))
                        {
                            if(videoScanType != "")
                            {
                                for(var j = 0; j < videoScanType.length; j++)
                                {
                                    if(videoScanType[j] == "progressive")
                                    {
                                        szOptionInfo = "<option value ='"+videoResolutionW[i] +"*"+videoResolutionY[i]+"P'>"+videoResolutionW[i] +"*"+videoResolutionY[i]+"P</option>";
                                    }
                                    else if(videoScanType[j] == "interlaced")
                                    {
                                        szOptionInfo = "<option value ='"+videoResolutionW[i] +"*"+videoResolutionY[i]+"I'>"+videoResolutionW[i] +"*"+videoResolutionY[i]+"I</option>";
                                    }
                                }
                            }
                            else
                            {
                                szOptionInfo = "<option value ='"+videoResolutionW[i] +"*"+videoResolutionY[i]+"'>"+videoResolutionW[i] +"*"+videoResolutionY[i]+"</option>";
                            }
                        }
                        else
                        {
                            szOptionInfo = "<option value ='"+videoResolutionW[i] +"*"+videoResolutionY[i]+"'>"+videoResolutionW[i] +"*"+videoResolutionY[i]+"</option>";
                        }
                        $(szOptionInfo).appendTo("#videoResolution");
                    }

                    //图像质量
                    var fixedQuality = "";
                     if($(xmlDoc).find('fixedQuality').eq(0).attr("opt"))
                     {
                        fixedQuality = $(xmlDoc).find('fixedQuality').eq(0).attr("opt").split(",");
                     }
                     if(fixedQuality.length > 0)
                     {
                         document.getElementById("fixedQuality").options.length = 0;
                         var ifixedQuality = 0;
                         szOptionInfo = '';
                         for(i = 0;i < fixedQuality.length; i++)
                         {
                            szOptionInfo += "<option value ='"+fixedQuality[i]+"' name='fixedQualityOpt"+(fixedQuality.length - i)+"'>"+getNodeValue('fixedQualityOpt'+(fixedQuality.length - i))+"</option>";
                         }
                        $(szOptionInfo).appendTo("#fixedQuality");
                     }
                    //视频帧率
                    document.getElementById("maxFrameRate").options.length = 0;
                    var maxFrameRate = $(xmlDoc).find('maxFrameRate').eq(0).attr("opt").split(",");
                    var imaxFrameRate = 0;
                    for(i = 0;i < maxFrameRate.length; i++)
                    {
                        imaxFrameRate = parseInt(maxFrameRate[i]);
                        if(imaxFrameRate >= 100)
                        {
                            imaxFrameRate /= 100;
                            $("<option value='"+ maxFrameRate[i] +"'>"+ imaxFrameRate +"</option>").appendTo("#maxFrameRate");
                        }
                        else
                        {
                            if(imaxFrameRate == 0){
                                $("<option value='0'>"+ getNodeValue('maxFrameRateOpt1') +"</option>").appendTo("#maxFrameRate");
                                continue;
                            }
                            imaxFrameRate = Math.floor(100/imaxFrameRate);
                            $("<option value='"+ maxFrameRate[i] +"'>1/"+ imaxFrameRate +"</option>").appendTo("#maxFrameRate");
                        }
                    }
                    iMinRate = parseInt($(xmlDoc).find('constantBitRate').eq(0).attr("min"), 10);
                    iMaxRate = parseInt($(xmlDoc).find('constantBitRate').eq(0).attr("max"), 10);

                    if(iMinRate == iMaxRate)
                    {
                        $("#constantBitRate").prop('disabled', true);
                        $("#RangeTips").html();
                    }
                    else
                    {
                        $("#constantBitRate").prop('disabled', false);
                        $("#RangeTips").html("(" + getNodeValue('RangeTips') + ":" + iMinRate + "-" + iMaxRate + ")");
                    }
                    //码流类型
                    /*var StreamTypeLength = document.getElementById('StreamType').length;
                    if($(xmlDoc).find('Audio').length > 0)
                    {
                        if(StreamTypeLength == 1)
                        {
                            $("<option value='1'>" + getNodeValue('StreamTypeOpt2') +"</option>").appendTo("#StreamType");
                        }
                    }
                    else
                    {
                        if(StreamTypeLength == 2)
                        {
                            document.getElementById('StreamType').remove(1);
                        }
                    }*/

                    //编码类型
                    document.getElementById("videoCodecType").options.length = 0;
                    var CodecType = $(xmlDoc).find('videoCodecType').eq(0).attr("opt").split(",");
                    if(window.parent.g_bIsIPDome)
                    {
                        $.each(CodecType, function(i, CodecTypeValue) {
                            $("<option value='"+ CodecTypeValue +"'>"+ CodecTypeValue +"</option>").appendTo("#videoCodecType");
                        });
                    }
                    else
                    {
                        $.each(CodecType, function(i, CodecTypeValue) {
                            if($("#StreamTypeIn").val() !== "01" && ia(VideoCode).m_szMainStreamVideoCodecType == "MPEG4" && CodecTypeValue == "H.264")
                            {
                                return;
                            }
                            $("<option value='"+ CodecTypeValue +"'>"+ CodecTypeValue +"</option>").appendTo("#videoCodecType");
                        });
                    }


                    $("#customBitRate").blur(function () {CheackServerIDIntNum($('#customBitRate').val(),'MaxBitRatetips','jsCustonBitRate',iMinRate,iMaxRate);});
                    //I帧间隔
                    if($(xmlDoc).find('Video').eq(0).find('GovLength').length != 0)
                    {
                        try
                        {
                            g_iMinIntervalFrameI = parseInt($(xmlDoc).find('Video').eq(0).find('GovLength').eq(0).attr("min"), 10);
                        }
                        catch(e)
                        {
                            g_iMinIntervalFrameI = 1;
                        }
                        try
                        {
                            g_iMaxIntervalFrameI = parseInt($(xmlDoc).find('Video').eq(0).find('GovLength').eq(0).attr("max"), 10);
                        }
                        catch(e)
                        {
                            g_iMaxIntervalFrameI = 400;
                        }
                    }

                    //编码复杂度
                    /*if($(xmlDoc).find('Video').eq(0).find('H264Profile').length > 0)
                     {
                     g_IsSupportCodecCom = true;
                     var H264Profile = $(xmlDoc).find('Video').eq(0).find('H264Profile').eq(0).attr("opt").split(",");
                     $('#selectCodecComplexity').empty();
                     for(i = 0;i < H264Profile.length; i++)
                     {
                     $("<option name='optionQuality" + (i + 1) + "' value='"+ H264Profile[i] +"'>"+ getNodeValue('optionQuality'+(i + 1)) +"</option>").appendTo("#selectCodecComplexity");
                     }
                     }
                     else
                     {
                     g_IsSupportCodecCom = false;
                     }*/
                }else if(StreamId == 102){
                    //分辨率
                    document.getElementById("subVideoResolution").options.length = 0;
                    var videoResolutionW = $(xmlDoc).find('videoResolutionWidth').eq(0).attr("opt").split(",");
                    var videoResolutionY = $(xmlDoc).find('videoResolutionHeight').eq(0).attr("opt").split(",");
                    var szOptionInfo = "";
                    for(i = 0;i < videoResolutionW.length; i++)
                    {
                        if((videoResolutionW[i] == "1920" &&  videoResolutionY[i] == "1080") || (videoResolutionW[i] == "1280" && videoResolutionY[i] == "720"))
                        {
                            if(videoScanType != "")
                            {
                                for(var j = 0; j < videoScanType.length; j++)
                                {
                                    if(videoScanType[j] == "progressive")
                                    {
                                        szOptionInfo = "<option value ='"+videoResolutionW[i] +"*"+videoResolutionY[i]+"P'>"+videoResolutionW[i] +"*"+videoResolutionY[i]+"P</option>";
                                    }
                                    else if(videoScanType[j] == "interlaced")
                                    {
                                        szOptionInfo = "<option value ='"+videoResolutionW[i] +"*"+videoResolutionY[i]+"I'>"+videoResolutionW[i] +"*"+videoResolutionY[i]+"I</option>";
                                    }
                                }
                            }
                            else
                            {
                                szOptionInfo = "<option value ='"+videoResolutionW[i] +"*"+videoResolutionY[i]+"'>"+videoResolutionW[i] +"*"+videoResolutionY[i]+"</option>";
                            }
                        }
                        else
                        {
                            szOptionInfo = "<option value ='"+videoResolutionW[i] +"*"+videoResolutionY[i]+"'>"+videoResolutionW[i] +"*"+videoResolutionY[i]+"</option>";
                        }
                        $(szOptionInfo).appendTo("#subVideoResolution");
                    }

                    //图像质量
                    var subFixedQuality = "";
                    if($(xmlDoc).find('fixedQuality').eq(0).attr("opt"))
                    {
                        subFixedQuality = $(xmlDoc).find('fixedQuality').eq(0).attr("opt").split(",");
                    }
                    if(subFixedQuality.length > 0)
                    {
                        document.getElementById("subFixedQuality").options.length = 0;
                        var ifixedQuality = 0;
                        szOptionInfo = '';
                        for(i = 0;i < subFixedQuality.length; i++)
                        {
                            szOptionInfo += "<option value ='"+subFixedQuality[i]+"' name='fixedQualityOpt"+(subFixedQuality.length - i)+"'>"+getNodeValue('fixedQualityOpt'+(subFixedQuality.length - i))+"</option>";
                        }
                        $(szOptionInfo).appendTo("#subFixedQuality");
                    }

                    //视频帧率 subMaxFrameRate
                    document.getElementById("subMaxFrameRate").options.length = 0;
                    var maxFrameRate = $(xmlDoc).find('maxFrameRate').eq(0).attr("opt").split(",");
                    var imaxFrameRate = 0;
                    for(i = 0;i < maxFrameRate.length; i++)
                    {
                        imaxFrameRate = parseInt(maxFrameRate[i]);
                        if(imaxFrameRate >= 100)
                        {
                            imaxFrameRate /= 100;
                            $("<option value='"+ maxFrameRate[i] +"'>"+ imaxFrameRate +"</option>").appendTo("#subMaxFrameRate");
                        }
                        else
                        {
                            if(imaxFrameRate == 0){
                                $("<option value='0'>"+ getNodeValue('maxFrameRateOpt1') +"</option>").appendTo("#subMaxFrameRate");
                                continue;
                            }
                            imaxFrameRate = Math.floor(100/imaxFrameRate);
                            $("<option value='"+ maxFrameRate[i] +"'>1/"+ imaxFrameRate +"</option>").appendTo("#subMaxFrameRate");
                        }
                    }
                    iSubMinRate = parseInt($(xmlDoc).find('constantBitRate').eq(0).attr("min"), 10);
                    iSubMaxRate = parseInt($(xmlDoc).find('constantBitRate').eq(0).attr("max"), 10);

                    if(iSubMinRate == iSubMaxRate)
                    {
                        $("#subConstantBitRate").prop('disabled', true);
                        $("#RangeTips").html();
                    }
                    else
                    {
                        $("#subConstantBitRate").prop('disabled', false);
                        $("#RangeTips").html("(" + getNodeValue('RangeTips') + ":" + iSubMinRate + "-" + iSubMaxRate + ")");
                    }

                    //编码类型 <!-- 视频编码 -->
                    document.getElementById("subVideoCodecType").options.length = 0;
                    var CodecType = $(xmlDoc).find('videoCodecType').eq(0).attr("opt").split(",");
                    if(window.parent.g_bIsIPDome)
                    {
                        $.each(CodecType, function(i, CodecTypeValue) {
                            $("<option value='"+ CodecTypeValue +"'>"+ CodecTypeValue +"</option>").appendTo("#subVideoCodecType");
                        });
                    }
                    else
                    {
                        $.each(CodecType, function(i, CodecTypeValue) {
                            if(ia(VideoCode).m_szMainStreamVideoCodecType == "MPEG4" && CodecTypeValue == "H.264")
                            {
                                return;
                            }
                            $("<option value='"+ CodecTypeValue +"'>"+ CodecTypeValue +"</option>").appendTo("#subVideoCodecType");
                        });
                    }

                    $("#subCustomBitRate").blur(function () {CheackServerIDIntNum($('#subCustomBitRate').val(),'SubMaxBitRatetips','jsCustonBitRate',iSubMinRate,iSubMaxRate);});
                    //I帧间隔
                    if($(xmlDoc).find('Video').eq(0).find('GovLength').length != 0)
                    {
                        try
                        {
                            g_iMinSubIntervalFrameI = parseInt($(xmlDoc).find('Video').eq(0).find('GovLength').eq(0).attr("min"), 10);
                        }
                        catch(e)
                        {
                            g_iMinSubIntervalFrameI = 1;
                        }
                        try
                        {
                            g_iMaxSubIntervalFrameI = parseInt($(xmlDoc).find('Video').eq(0).find('GovLength').eq(0).attr("max"), 10);
                        }
                        catch(e)
                        {
                            g_iMaxSubIntervalFrameI = 400;
                        }
                    }
                }
            },
            error: function(xhr, textStatus, errorThrown){

            }
        });
}
/*************************************************
 Function:		GetVideoInfo
 Description:	获取视频信息
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function GetVideoInfo()
{
    if(g_IsSupportMainStream){

        g_szMainVideoInfoXml = "";

        $.ajax({
            type: "GET",
            url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Streaming/channels/101",
            async: false,
            timeout: 15000,
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            success: function(xmlDoc, textStatus, xhr)
            {
                g_szMainVideoInfoXml = xhr.responseText;

                //视频类型
                var audioEnabled = 1;
                if($(xmlDoc).find('Audio').length > 0)
                {
                    audioEnabled = 0;
                    var AudioEnabled = $(xmlDoc).find('Audio').eq(0).find('enabled').eq(0).text();
                    if(AudioEnabled == 'true')
                    {
                        $("#StreamType").val('1');
                    }
                    else
                    {
                        $("#StreamType").val('0');
                    }
                }
                else
                {
                    $("#StreamType").val('0');
                }

                if(audioEnabled == 1){
                    $('#StreamType').find("option").each(function(i, codeType){

                        if(audioEnabled == $(this).attr('value')){
                            $(this).remove();
                        }
                    });
                }

                videoBitRate = $(xmlDoc).find('videoQualityControlType').eq(0).text();
                var ivideoResolutionWidth = $(xmlDoc).find('videoResolutionWidth').eq(0).text();
                var ivideoResolutionHeight = $(xmlDoc).find('videoResolutionHeight').eq(0).text();
                if((ivideoResolutionWidth == "1920" &&  ivideoResolutionHeight == "1080") || (ivideoResolutionWidth == "1280" && ivideoResolutionHeight == "720"))
                {
                    if($(xmlDoc).find('videoScanType').length > 0)
                    {
                        if($(xmlDoc).find('videoScanType').eq(0).text() == 'progressive')
                        {
                            m_iResolution = ivideoResolutionWidth +"*"+ivideoResolutionHeight + "P";
                        }
                        else
                        {
                            m_iResolution = ivideoResolutionWidth +"*"+ivideoResolutionHeight + "I";
                        }
                    }
                    else
                    {
                        m_iResolution = ivideoResolutionWidth +"*"+ivideoResolutionHeight;
                    }
                }
                else
                {
                    m_iResolution = ivideoResolutionWidth +"*"+ivideoResolutionHeight;
                }
                $("#videoCodecType").val($(xmlDoc).find('videoCodecType').eq(0).text());
                $("#mainsvcEnabled").val($(xmlDoc).find('svcMode').eq(0).text());

                var bCustom = true;
                var BitRate = 0;
                if(videoBitRate.toLowerCase() == "cbr")
                {
                    $("#fixedQuality").val($(xmlDoc).find('fixedQuality').eq(0).text());//图像质量
                    BitRate = parseInt($(xmlDoc).find('constantBitRate').eq(0).text(), 10);
                    for(i = 0;i < document.getElementById('constantBitRate').options.length;i++)
                    {
                        if(document.getElementById('constantBitRate').options[i].value == BitRate){
                            bCustom = false;
                            break;
                        }
                    }
                } else {
                    $("#fixedQuality").val($(xmlDoc).find('fixedQuality').eq(0).text());//图像质量
                    BitRate = parseInt($(xmlDoc).find('vbrUpperCap').eq(0).text(), 10);
                    for(i = 0;i < document.getElementById('constantBitRate').options.length;i++)
                    {
                        if(document.getElementById('constantBitRate').options[i].value == BitRate){
                            bCustom = false;
                            break;
                        }
                    }
                }
                if(bCustom){
                    $("#constantBitRate").attr("value",'Customize');
                    $("#customBitRate").attr("value",BitRate);
                }else{
                    $("#constantBitRate").attr("value",BitRate);
                }
                //EnableCustom();
                VideoCode.EnableMainStreamCustom();

                setTimeout(function()
                {
                    $("#videoResolution").val(m_iResolution);//分辨率
                    $("#maxFrameRate").val($(xmlDoc).find('maxFrameRate').eq(0).text());
                    $("#videoQualityControlType").val($(xmlDoc).find('videoQualityControlType').eq(0).text().toLowerCase()); //位率类型
                    ChangeBirateType();
                }, 1);

                //I帧间隔
                if($(xmlDoc).find('Video').eq(0).find('GovLength').length > 0)
                {
                    $("#IntervalFrameI_tr").show();
                    $("#IntervalFrameI").val($(xmlDoc).find('Video').eq(0).find('GovLength').eq(0).text());
                }
                //编码复杂度
                if($(xmlDoc).find('Video').eq(0).find('videoEncComplexity').length>0){
                    $("#videoEncComplexity").val($(xmlDoc).find('Video').eq(0).find('videoEncComplexity').eq(0).text());
                }
                /*if($(xmlDoc).find('Video').eq(0).find('H264Profile').length > 0)
                {
                    if($('#videoCodecType').val() == 'H.264' )
                    {
                        $("#CodecComplexity_tr").show();
                        $("#selectCodecComplexity").val($(xmlDoc).find('Video').eq(0).find('H264Profile').eq(0).text());
                    }
                }*/
                pr(VideoCode).initCSS();

            },
            error: function(xhr, textStatus, errorThrown)
            {
                alert(m_szError400);
            }
        });
    }
    if(g_IsSupportSubMainStream){

        g_szSubMainVideoInfoXml = "";

        $.ajax({
            type: "GET",
            url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Streaming/channels/102",
            async: false,
            timeout: 15000,
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            success: function(xmlDoc, textStatus, xhr)
            {
                g_szSubMainVideoInfoXml = xhr.responseText;

                var audioEnabled = 1;
                if($(xmlDoc).find('Audio').length > 0)
                {
                    audioEnabled = 0;
                    var AudioEnabled = $(xmlDoc).find('Audio').eq(0).find('enabled').eq(0).text();
                    if(AudioEnabled == 'true')
                    {
                        $("#subStreamType").val('1');
                    }
                    else
                    {
                        $("#subStreamType").val('0');
                    }
                }
                else
                {
                    $("#subStreamType").val('0');
                }
                if(audioEnabled == 1){
                    $('#subStreamType').find("option").each(function(i, optType){
                        if(audioEnabled == $(this).attr('value')){
                            $(this).remove();
                        }
                    });
                }
                videoBitRate = $(xmlDoc).find('videoQualityControlType').eq(0).text();
                var ivideoResolutionWidth = $(xmlDoc).find('videoResolutionWidth').eq(0).text();
                var ivideoResolutionHeight = $(xmlDoc).find('videoResolutionHeight').eq(0).text();
                if((ivideoResolutionWidth == "1920" &&  ivideoResolutionHeight == "1080") || (ivideoResolutionWidth == "1280" && ivideoResolutionHeight == "720"))
                {
                    if($(xmlDoc).find('videoScanType').length > 0)
                    {
                        if($(xmlDoc).find('videoScanType').eq(0).text() == 'progressive')
                        {
                            m_iSubResolution = ivideoResolutionWidth +"*"+ivideoResolutionHeight + "P";
                        }
                        else
                        {
                            m_iSubResolution = ivideoResolutionWidth +"*"+ivideoResolutionHeight + "I";
                        }
                    }
                    else
                    {
                        m_iSubResolution = ivideoResolutionWidth +"*"+ivideoResolutionHeight;
                    }
                }
                else
                {
                    m_iSubResolution = ivideoResolutionWidth +"*"+ivideoResolutionHeight;
                }
                $("#subVideoCodecType").val($(xmlDoc).find('videoCodecType').eq(0).text());
                $("#subsvcEnabled").val($(xmlDoc).find('svcMode').eq(0).text());

                var bCustom = true;
                var BitRate = 0;
                if(videoBitRate.toLowerCase() == "cbr")
                {
                    $("#subFixedQuality").val($(xmlDoc).find('fixedQuality').eq(0).text());//图像质量
                    BitRate = parseInt($(xmlDoc).find('constantBitRate').eq(0).text(), 10);
                    for(i = 0;i < document.getElementById('constantBitRate').options.length;i++)
                    {
                        if(document.getElementById('constantBitRate').options[i].value == BitRate){
                            bCustom = false;
                            break;
                        }
                    }
                } else {
                    $("#subFixedQuality").val($(xmlDoc).find('fixedQuality').eq(0).text());//图像质量
                    BitRate = parseInt($(xmlDoc).find('vbrUpperCap').eq(0).text(), 10);
                    for(i = 0;i < document.getElementById('subConstantBitRate').options.length;i++)
                    {
                        if(document.getElementById('subConstantBitRate').options[i].value == BitRate){
                            bCustom = false;
                            break;
                        }
                    }
                }
                if(bCustom){
                    $("#subConstantBitRate").attr("value",'Customize');
                    $("#subCustomBitRate").attr("value",BitRate);
                }else{
                    $("#subConstantBitRate").attr("value",BitRate);
                }
                VideoCode.EnableSubMainCustom();

                setTimeout(function()
                {
                    $("#subVideoResolution").val(m_iSubResolution);//分辨率
                    $("#subMaxFrameRate").val($(xmlDoc).find('maxFrameRate').eq(0).text());
                    $("#subVideoQualityControlType").val($(xmlDoc).find('videoQualityControlType').eq(0).text().toLowerCase()); //位率类型
                    ChangeSubBirateType();
                }, 1);

                //编码复杂度
                if($(xmlDoc).find('Video').eq(0).find('videoEncComplexity').length>0){
                    $("#subVideoEncComplexity").val($(xmlDoc).find('Video').eq(0).find('videoEncComplexity').eq(0).text());
                }

                //I帧间隔
                if($(xmlDoc).find('Video').eq(0).find('GovLength').length > 0)
                {
                    $("#SubIntervalFrameI_tr").show();
                    $("#SubIntervalFrameI").val($(xmlDoc).find('Video').eq(0).find('GovLength').eq(0).text());
                }

                pr(VideoCode).initCSS();
            },
            error: function(xhr, textStatus, errorThrown)
            {
                alert(m_szError400);
            }
        });
    }
}
function GetCloudComputingInfo()
{
    if(g_IsSupportMainStream){

        g_szMainVideoInfoXml = "";

        $.ajax({
            type: "GET",
            url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/CloudStorageInfo",
            async: false,
            timeout: 15000,
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            success: function(xmlDoc, textStatus, xhr)
            {
			  if($(xmlDoc).find('enable').eq(0).text() == 'true') {
	              $("#enable").prop("checked", true);
				  $("#ipAddress").prop("disabled", false);
				  $("#portNo").prop("disabled", false);
				  $("#userName").prop("disabled", false);
				  $("#password").prop("disabled", false);
				  $("#postPoolID").prop("disabled", false);
				  $("#illegalPoolID").prop("disabled", false);
              } else {
	              $("#enable").prop("checked", false);
				   $("#ipAddress").prop("disabled", true);
				  $("#portNo").prop("disabled", true);
				  $("#userName").prop("disabled", true);
				  $("#password").prop("disabled", true);
				  $("#postPoolID").prop("disabled", true);
				  $("#illegalPoolID").prop("disabled", true);
              }
			  $("#ipAddress").val($(xmlDoc).find("ipAddress").eq(0).text());
              $("#portNo").val($(xmlDoc).find("portNo").eq(0).text());
			  $("#userName").val($(xmlDoc).find("userName").eq(0).text());
              var defPasswd = oCheckPassword.m_szDefaultPassword;
			  $("#password").val(defPasswd);
              $("#postPoolID").val($(xmlDoc).find("postPoolID").eq(0).text());
			  $("#illegalPoolID").val($(xmlDoc).find("illegalPoolID").eq(0).text());


            },
            error: function(xhr, textStatus, errorThrown)
            {
                alert(m_szError400);
            }
        });
    }
}
/*************************************************
 Function:		CreateMainVideoInfoDoc
 Description:	创建主码流视频信息xml
 Input:			iNo:通道号
 Output:			无
 return:			无
 *************************************************/
function CreateMainVideoInfoDoc()
{
    if(g_szMainVideoInfoXml == "")
    {
        return null;
    }
    var xmlDoc = parseXmlFromStr(g_szMainVideoInfoXml);

    var oMulticast = $(xmlDoc).find("Multicast");
    if(oMulticast.length > 0)
    {
        oMulticast.eq(0).remove();
    }

    var oVideo = $(xmlDoc).find("Video").eq(0);
    oVideo.find("videoCodecType").eq(0).text($('#videoCodecType').val()); 
    oVideo.find("svcMode").eq(0).text($('#mainsvcEnabled').val()); 
    //编码复杂度  
   oVideo.find("videoEncComplexity").eq(0).text($("#videoEncComplexity").val());

     //---------------------以前没用的编码复杂度代码 begin---------------------------------
    // if($('#CodecComplexity_tr').css('display') != 'none')
    // {
    //     var H264Profile = oVideo.find("H264Profile");
    //     if(H264Profile.length > 0)
    //     {
    //         H264Profile.eq(0).text($('#selectCodecComplexity').val());
    //     }
    //     else
    //     {
    //         oVideo.find("selfExt").eq(0).append($(parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><StreamingChannel version="1.0" xmlns="urn:psialliance-org"><H264Profile>'+$('#selectCodecComplexity').val()+'</H264Profile></StreamingChannel>')).find("StreamingChannel").eq(0).clone().children());
    //     }
    // }
    // else
    // {
    //     oVideo.find("H264Profile").remove();
    // }
     //---------------------以前没用的编码复杂度代码 end---------------------------------

    var oVideoScanType = oVideo.find("videoScanType");
    var videoResolution = ($('#videoResolution').val()).split("*");
    if($('#videoResolution').val() == '1920*1080P' || $('#videoResolution').val() == '1920*1080I' || $('#videoResolution').val() == '1280*720P' || $('#videoResolution').val() == '1280*720I')
    {
        if($('#videoResolution').val().substring($('#videoResolution').val().length - 1) == 'P')
        {
            if(oVideoScanType.length > 0)
            {
                oVideoScanType.eq(0).text("progressive");
            }
            else
            {
                oVideo.append($(parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><StreamingChannel version="1.0" xmlns="urn:psialliance-org"><videoScanType>progressive</videoScanType></StreamingChannel>')).find("StreamingChannel").eq(0).clone().children());
            }
        }
        else if($('#videoResolution').val().substring($('#videoResolution').val().length - 1) == 'I')
        {
            if(oVideoScanType.length > 0)
            {
                oVideoScanType.eq(0).text("interlaced");
            }
            else
            {
                oVideo.append($(parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><StreamingChannel version="1.0" xmlns="urn:psialliance-org"><videoScanType>interlaced</videoScanType></StreamingChannel>')).find("StreamingChannel").eq(0).clone().children());
            }
        }
        else
        {
            oVideo.find("videoScanType").eq(0).remove();
        }
    }
    else
    {
        oVideo.find("videoScanType").eq(0).remove();
    }
    oVideo.find("videoResolutionWidth").eq(0).text(videoResolution[0]);

    var szVideoResolutionHeight;
    if($('#videoResolution').val() == '1920*1080P' || $('#videoResolution').val() == '1920*1080I' || $('#videoResolution').val() == '1280*720P' || $('#videoResolution').val() == '1280*720I')
    {
        if($('#videoResolution').val().substring($('#videoResolution').val().length - 1) == 'P' || $('#videoResolution').val().substring($('#videoResolution').val().length - 1) == 'I')
        {
            szVideoResolutionHeight = videoResolution[1].substring(0,videoResolution[1].length - 1);
        }
        else
        {
            szVideoResolutionHeight = videoResolution[1];
        }
    }
    else
    {
        szVideoResolutionHeight = videoResolution[1];
    }
    oVideo.find("videoResolutionHeight").eq(0).text(szVideoResolutionHeight);

    oVideo.find("videoQualityControlType").eq(0).text($('#videoQualityControlType').val());

    var BitRate = 0;
    if('Customize' == $("#constantBitRate").val())
    {
        BitRate = $('#customBitRate').val();
    }
    else
    {
        BitRate = $('#constantBitRate').val();
    }

    if($('#videoQualityControlType').val() == 'cbr')
    {
        var oConstantBitRate = oVideo.find("constantBitRate");
        if(oConstantBitRate.length > 0)
        {
            oConstantBitRate.eq(0).text(BitRate);
        }
        else
        {
            oVideo.append($(parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><StreamingChannel version="1.0" xmlns="urn:psialliance-org"><constantBitRate>'+BitRate+'</constantBitRate></StreamingChannel>')).find("StreamingChannel").eq(0).clone().children());
        }
    }
    else
    {
        oVideo.find("constantBitRate").eq(0).remove();
        //图片质量xml
        var oFixedQuality = oVideo.find("fixedQuality");
        if(oFixedQuality.length > 0)
        {
            oFixedQuality.eq(0).text($('#fixedQuality').val());
        }
        else
        {
            oVideo.append($(parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><StreamingChannel version="1.0" xmlns="urn:psialliance-org"><fixedQuality>'+$('#fixedQuality').val()+'</fixedQuality></StreamingChannel>')).find("StreamingChannel").eq(0).clone().children());
        }

        var oVbrUpperCap = oVideo.find("vbrUpperCap");
        if(oVbrUpperCap.length > 0)
        {
            oVbrUpperCap.eq(0).text(BitRate);
        }
        else
        {
            oVideo.append($(parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><StreamingChannel version="1.0" xmlns="urn:psialliance-org"><vbrUpperCap>'+BitRate+'</vbrUpperCap></StreamingChannel>')).find("StreamingChannel").eq(0).clone().children());
        }

        var oVbrLowerCap = oVideo.find("vbrLowerCap");
        if(oVbrLowerCap.length > 0)
        {
            oVbrLowerCap.eq(0).text('32');
        }
        else
        {
            oVideo.append($(parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><StreamingChannel version="1.0" xmlns="urn:psialliance-org"><vbrLowerCap>32</vbrLowerCap></StreamingChannel>')).find("StreamingChannel").eq(0).clone().children());
        }
    }

    oVideo.find("maxFrameRate").eq(0).text($('#maxFrameRate').val());
    if($('#IntervalFrameI_tr').css("display") != 'none')
    {
        var oKeyFrameInterval = oVideo.find("keyFrameInterval");
        if(oKeyFrameInterval.length > 0)
        {
            oKeyFrameInterval.eq(0).remove();
        }
        var oGovLength = oVideo.find("GovLength");
        if(oGovLength.length > 0)
        {
            oGovLength.eq(0).text($('#IntervalFrameI').val());
        }
        else
        {
            oVideo.find("selfExt").eq(0).append($(parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><StreamingChannel version="1.0" xmlns="urn:psialliance-org"><GovLength>'+$('#IntervalFrameI').val()+'</GovLength></StreamingChannel>')).find("StreamingChannel").eq(0).clone().children());
        }
    }
    if(document.getElementById('StreamType').options.length == 2)
    {
        if($("#StreamType").val() == '1')
        {
            $(xmlDoc).find("Audio").eq(0).find("enabled").eq(0).text("true");
        }
        else
        {
            $(xmlDoc).find("Audio").eq(0).find("enabled").eq(0).text("false");
        }
    }
    return xmlDoc;
}

/*************************************************
 Function:		CreateSubMainVideoInfoDoc
 Description:	创建子码流视频信息xml
 Input:			iNo:通道号
 Output:			无
 return:			无
 *************************************************/
function CreateSubMainVideoInfoDoc()
{
    if(g_szSubMainVideoInfoXml == "")
    {
        return null;
    }
    var xmlDoc = parseXmlFromStr(g_szSubMainVideoInfoXml);

    var oMulticast = $(xmlDoc).find("Multicast");
    if(oMulticast.length > 0)
    {
        oMulticast.eq(0).remove();
    }

    var oVideo = $(xmlDoc).find("Video").eq(0);
    oVideo.find("videoCodecType").eq(0).text($('#subVideoCodecType').val());
    oVideo.find("svcMode").eq(0).text($('#subsvcEnabled').val());
    
    //编码复杂度  yqw
     oVideo.find("videoEncComplexity").eq(0).text($("#subVideoEncComplexity").val());
    
    //---------------------以前没用的编码复杂度代码 begin---------------------------------
    // if($('#CodecComplexity_tr').css('display') != 'none')  //编码复杂度
    // {
    //     var H264Profile = oVideo.find("H264Profile");
    //     if(H264Profile.length > 0)
    //     {
    //         H264Profile.eq(0).text($('#selectCodecComplexity').val());
    //     }
    //     else
    //     {
    //         oVideo.find("selfExt").eq(0).append($(parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><StreamingChannel version="1.0" xmlns="urn:psialliance-org"><H264Profile>'+$('#selectCodecComplexity').val()+'</H264Profile></StreamingChannel>')).find("StreamingChannel").eq(0).clone().children());
    //     }
    // }
    // else
    // {
    //     oVideo.find("H264Profile").remove();
    // }
    //-------------------------------------end-----------------

    var oVideoScanType = oVideo.find("videoScanType");
    var videoResolution = ($('#subVideoResolution').val()).split("*");
    if($('#subVideoResolution').val() == '1920*1080P' || $('#subVideoResolution').val() == '1920*1080I' || $('#subVideoResolution').val() == '1280*720P' || $('#subVideoResolution').val() == '1280*720I')
    {
        if($('#subVideoResolution').val().substring($('#subVideoResolution').val().length - 1) == 'P')
        {
            if(oVideoScanType.length > 0)
            {
                oVideoScanType.eq(0).text("progressive");
            }
            else
            {
                oVideo.append($(parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><StreamingChannel version="1.0" xmlns="urn:psialliance-org"><videoScanType>progressive</videoScanType></StreamingChannel>')).find("StreamingChannel").eq(0).clone().children());
            }
        }
        else if($('#videoResolution').val().substring($('#videoResolution').val().length - 1) == 'I')
        {
            if(oVideoScanType.length > 0)
            {
                oVideoScanType.eq(0).text("interlaced");
            }
            else
            {
                oVideo.append($(parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><StreamingChannel version="1.0" xmlns="urn:psialliance-org"><videoScanType>interlaced</videoScanType></StreamingChannel>')).find("StreamingChannel").eq(0).clone().children());
            }
        }
        else
        {
            oVideo.find("videoScanType").eq(0).remove();
        }
    }
    else
    {
        oVideo.find("videoScanType").eq(0).remove();
    }
    oVideo.find("videoResolutionWidth").eq(0).text(videoResolution[0]);

    var szVideoResolutionHeight;
    if($('#subVideoResolution').val() == '1920*1080P' || $('#subVideoResolution').val() == '1920*1080I' || $('#subVideoResolution').val() == '1280*720P' || $('#subVideoResolution').val() == '1280*720I')
    {
        if($('#subVideoResolution').val().substring($('#subVideoResolution').val().length - 1) == 'P' || $('#subVideoResolution').val().substring($('#subVideoResolution').val().length - 1) == 'I')
        {
            szVideoResolutionHeight = videoResolution[1].substring(0,videoResolution[1].length - 1);
        }
        else
        {
            szVideoResolutionHeight = videoResolution[1];
        }
    }
    else
    {
        szVideoResolutionHeight = videoResolution[1];
    }
    oVideo.find("videoResolutionHeight").eq(0).text(szVideoResolutionHeight);

    oVideo.find("videoQualityControlType").eq(0).text($('#subVideoQualityControlType').val());

    var BitRate = 0;
    if('Customize' == $("#subConstantBitRate").val())
    {
        BitRate = $('#subCustomBitRate').val();
    }
    else
    {
        BitRate = $('#subConstantBitRate').val();
    }

    if($('#subVideoQualityControlType').val() == 'cbr')
    {
        var oConstantBitRate = oVideo.find("constantBitRate");
        if(oConstantBitRate.length > 0)
        {
            oConstantBitRate.eq(0).text(BitRate);
        }
        else
        {
            oVideo.append($(parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><StreamingChannel version="1.0" xmlns="urn:psialliance-org"><constantBitRate>'+BitRate+'</constantBitRate></StreamingChannel>')).find("StreamingChannel").eq(0).clone().children());
        }
    }
    else
    {
        oVideo.find("constantBitRate").eq(0).remove();

        //图片质量xml
        var oFixedQuality = oVideo.find("fixedQuality");
        if(oFixedQuality.length > 0)
        {
            oFixedQuality.eq(0).text($('#subFixedQuality').val());
        }
        else
        {
            oVideo.append($(parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><StreamingChannel version="1.0" xmlns="urn:psialliance-org"><fixedQuality>'+$('#subFixedQuality').val()+'</fixedQuality></StreamingChannel>')).find("StreamingChannel").eq(0).clone().children());
        }

        var oVbrUpperCap = oVideo.find("vbrUpperCap");
        if(oVbrUpperCap.length > 0)
        {
            oVbrUpperCap.eq(0).text(BitRate);
        }
        else
        {
            oVideo.append($(parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><StreamingChannel version="1.0" xmlns="urn:psialliance-org"><vbrUpperCap>'+BitRate+'</vbrUpperCap></StreamingChannel>')).find("StreamingChannel").eq(0).clone().children());
        }

        var oVbrLowerCap = oVideo.find("vbrLowerCap");
        if(oVbrLowerCap.length > 0)
        {
            oVbrLowerCap.eq(0).text('32');
        }
        else
        {
            oVideo.append($(parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><StreamingChannel version="1.0" xmlns="urn:psialliance-org"><vbrLowerCap>32</vbrLowerCap></StreamingChannel>')).find("StreamingChannel").eq(0).clone().children());
        }
    }

    oVideo.find("maxFrameRate").eq(0).text($('#subMaxFrameRate').val());
    if($('#SubIntervalFrameI_tr').css("display") != 'none')
    {
        var oKeyFrameInterval = oVideo.find("keyFrameInterval");
        if(oKeyFrameInterval.length > 0)
        {
            oKeyFrameInterval.eq(0).remove();
        }
        var oGovLength = oVideo.find("GovLength");
        if(oGovLength.length > 0)
        {
            oGovLength.eq(0).text($('#SubIntervalFrameI').val());
        }
        else
        {
            oVideo.find("selfExt").eq(0).append($(parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><StreamingChannel version="1.0" xmlns="urn:psialliance-org"><GovLength>'+$('#SubIntervalFrameI').val()+'</GovLength></StreamingChannel>')).find("StreamingChannel").eq(0).clone().children());
        }
    }
    if(document.getElementById('subStreamType').options.length == 2)
     {
         if($("#subStreamType").val() == '1')
         {
            $(xmlDoc).find("Audio").eq(0).find("enabled").eq(0).text("true");
         }
         else
         {
            $(xmlDoc).find("Audio").eq(0).find("enabled").eq(0).text("false");
         }
     }
    return xmlDoc;
}
/*************************************************
 Function:		SetVideoInfo
 Description:	设置视频信息
 Input:			iNo:通道号
 Output:			无
 return:			无
 *************************************************/
function SetVideoInfo()
{
    if($('#IntervalFrameI_tr').css("display") != 'none') {
        if(!CheackServerIDIntNum($("#IntervalFrameI").val(),'IntervalFrameItips','laIntervalFrameI',g_iMinIntervalFrameI, g_iMaxIntervalFrameI)) {
            return;
        }
    }
    if($("#constantBitRate").val() == 'Customize')
    {
        if(!CheackServerIDIntNum($('#customBitRate').val(),'MaxBitRatetips','jsCustonBitRate',iMinRate,iMaxRate))
        {
            return;
        }
    }
    if($('#SubIntervalFrameI_tr').css("display") != 'none') {
        if(!CheackServerIDIntNum($("#SubIntervalFrameI").val(),'SubIntervalFrameItips','laIntervalFrameI',g_iMinSubIntervalFrameI, g_iMaxSubIntervalFrameI)) {
            return;
        }
    }
    if($("#subConstantBitRate").val() == 'Customize')
    {
        if(!CheackServerIDIntNum($('#subCustomBitRate').val(),'SubMaxBitRatetips','jsCustonBitRate',iSubMinRate,iSubMaxRate))
        {
            return;
        }
    }

    var xmlDoc = null;
    var saveUrl =  "";
    if(g_IsSupportMainStream){
        xmlDoc = CreateMainVideoInfoDoc();
        saveUrl = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Streaming/channels/101";
        $.ajax({
            type: "PUT",
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            async: false,
            timeout: 15000,
            url : saveUrl,
            processData: false,
            data: xmlDoc,
            complete: function(xhr, textStatus) {
                SaveState(xhr);
            }
        });

    }
    if(g_IsSupportSubMainStream){
        xmlDoc = null;
        saveUrl = "";
        xmlDoc = CreateSubMainVideoInfoDoc();
        saveUrl = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Streaming/channels/102";
        $.ajax({
            type: "PUT",
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            async: false,
            timeout: 15000,
            url : saveUrl,
            processData: false,
            data: xmlDoc,
            complete: function(xhr, textStatus) {
                SaveState(xhr);
            }
        });
    }

}

/*************************************************
 Function:		SetCloudComputingInfo
 Description:	设置云储存信息
 Output:			无
 return:			无
 *************************************************/
function SetCloudComputingInfo()
{  
	if(!CheckIPAddress($("#ipAddress").val(), 'ipAddressTips', 'laipAddress')){
		return;
	}
	
	if(!CheackServerIDIntNum($("#portNo").val(), 'portNoTips', 'laPortNo', 2000,65535)){
		return;
	}
	
	if(!CheackStringLenthNull($("#userName").val(), "userNameTips", "laUserName",48)) {
		return;
	}
	if(!CheackStringLenthNull($("#password").val(), "passwordTips", "laPassword",48)) {
		return;
	}

	if(!CheackServerIDIntNum($("#postPoolID").val(), 'postPoolIDTips', 'laPostPoolID', 1,4294967295)){
		return;
	}
	if(!CheackServerIDIntNum($("#illegalPoolID").val(), 'illegalPoolIDTips', 'laIllegalPoolID', 1,4294967295)){
		return;
	}
	var szXml = "<?xml version='1.0' encoding='UTF-8'?>" + 
                "<CloudStorageInfo>" + 
                    "<enable>" + 
                        $("#enable").prop("checked").toString() + 
                    "</enable>"+
                    "<addressingFormatType>"+"ipaddress"+"</addressingFormatType>"+
                    "<ipAddress>"+$("#ipAddress").val()+"</ipAddress>"+
                    "<portNo>"+$("#portNo").val()+"</portNo>"+
                    "<userName>"+$("#userName").val()+"</userName>";
    var pwd = $('#password').val();
    if (pwd != '' && pwd != oCheckPassword.m_szDefaultPassword) {
        szXml +=    "<password>"+ pwd +"</password>";
    };
    szXml +=        "<postPoolID>"+$("#postPoolID").val()+"</postPoolID>"+
                    "<illegalPoolID>"+$("#illegalPoolID").val()+"</illegalPoolID>"+
                "</CloudStorageInfo>";
	var xmlDoc = parseXmlFromStr(szXml);
    var saveUrl = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/CloudStorageInfo";
    $.ajax({
        type: "PUT",
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        async: false,
        timeout: 15000,
        url : saveUrl,
        processData: false,
        data: xmlDoc,
		error: function(xhr, textStatus, errorThrown)
        {
			//alert(textStatus);
        },
        complete: function(xhr, textStatus) {
            SaveState(xhr);
        }		
    });
}
/*************************************************
 Function:		ChangeBirateType
 Description:	切换位率类型
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function ChangeBirateType()
{
    if($("#videoQualityControlType").val() == "cbr")  //定码率
    {
        $("#fixedQuality").prop("disabled", true);    //图像质量选项无效
    }
    else
    {
        $("#fixedQuality").prop("disabled", false);
    }
}

function ChangeSubBirateType()
{
    if($("#subVideoQualityControlType").val() == "cbr")  //定码率
    {
        $("#subFixedQuality").prop("disabled", true);    //图像质量选项无效
    }
    else
    {
        $("#subFixedQuality").prop("disabled", false);
    }
}

/*************************************************
 Function:		jump_VideoStream
 Description:	根据码流类型获取当前通道相关显示信息
 Input:			iSet: select项的通道号
 Output:			无
 return:			无
 *************************************************/
function jump_VideoStream(iSet)
{
    document.getElementById("videoResolution").disabled = 0;
    document.getElementById("fixedQuality").disabled = 0;
    document.getElementById("videoQualityControlType").disabled = 0;
    document.getElementById("constantBitRate").disabled = 0;
    document.getElementById("maxFrameRate").disabled = 0;

    //GetVideoAbility();              //更新能力集
    GetVideoInfo();  				//获取相关信息
}

/***************** VideoCode end ***********************************/
var m_iTimeNum = 0;
var g_szCurFormatId = "";
var g_bRequiredReboot = false;
var g_strFtpXmlDoc = null;

/*************************************************
继承，未完成，wuyang
*************************************************/
function RecordPlan() {
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(RecordPlan);
pr(RecordPlan).update = function() {
	$('#SetResultTips').html('');
	$("#SaveConfigBtn").show();
	g_transStack.clear();
	var that = this;
	g_transStack.push(function() {
		that.setLxd(parent.translator.getLanguageXmlDoc(["Storage", "RecordPlan"]));
		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	}, true);
	initRecordPlan();
	//录像计划
	if($("#scheduleplan").html() == "")
	{
		$.ajax(
		{ 
			url: "params/recordplanschedule.asp",
			type: "GET",
			dataType:"html",
			async: true,
			success:function(szMsg)
			{
				$("#scheduleplan").html(szMsg);
				if(g_bSupportWLS && g_bSupportPIR)
				{
					if(g_bSupportCH)
					{
						$("#scheduleplan").find("select").append("<option value='pir' name='laPIRAlarm'>"+getNodeValue("laPIRAlarm")+"</option><option value='wlsensor' name='laWirelessAlarm'>"+getNodeValue("laWirelessAlarm")+"</option><option value='callhelp' name='OptCallHelp'>"+getNodeValue("OptCallHelp")+"</option><option value='AllEvent' name='OptAllEvent'>"+getNodeValue("OptAllEvent")+"</option>");
						g_transStack.push(function() {
							$("#scheduleplan").find("select").find("option[name='OptAllEvent']").attr("title", getNodeValue("OptAllEvent"));
						}, true);
					}
					else
					{
						$("#scheduleplan").find("select").append("<option value='pir' name='laPIRAlarm'>"+getNodeValue("laPIRAlarm")+"</option><option value='wlsensor' name='laWirelessAlarm'>"+getNodeValue("laWirelessAlarm")+"</option><option value='callhelp' name='OptCallHelp'>"+getNodeValue("OptCallHelp")+"</option><option value='pirORwlsensorORcallhelp' name='OptPirORWlsensorORCallhelp'>"+getNodeValue("OptPirORWlsensorORCallhelp")+"</option>");
					}
				}
				m_iCurWeekDay = 0;
				parent.translator.translatePage(that.getLxd(), $("#scheduleplan")[0]);
			}
		});
	}
}

function DiskInfo() {
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(DiskInfo);
pr(DiskInfo).update = function() {
	$('#SetResultTips').html('');
    $("#SaveConfigBtn").show();
	g_transStack.clear();
	var that = this;
	g_transStack.push(function() {
		that.setLxd(parent.translator.getLanguageXmlDoc(["Storage", "DiskInfo"]));
		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
		initDiskInfo();
	}, true);
}

/*************************************************
Function:		initStorage
Description:	初始化存储页面信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function initStorage()
{
	//硬盘管理
	$("#selAllDisk").bind("click",function()
	{
		if(this.checked)
		{
			$(".seldiskcheck").each(function()
			{
				if(!$(this).prop("disabled"))
				{
					$(this).prop("checked", true);
				}
			});
		}
		else
		{
			$(".seldiskcheck").each(function()
			{
				if(!$(this).prop("disabled"))
				{
					$(this).prop("checked", false);
				}
			});
		}
	});
	//nas
	/*$("#nas").find("span").each(
	function(i)
	{
		var iRow = parseInt(i/4,10);
		var j = i%4;
		switch(j)
		{
			case 0:
				$(this).addClass("nasrowfirst");
				break;
			case 1:
				$(this).addClass("nasrowsecond");
				break;
			case 2:
				$(this).addClass("nasrowthird");
				if(iRow > 0)
				{
					if(window.parent.g_bIsIPDome)
					{
						if(iRow > 1)
						{
							return;
						}
					}
					$(this).bind(
					{
						click:function()
						{
							$("#editText").show();
							$("#editText").css({"left":$(this).offset().left+"px", "top":$(this).offset().top+"px",width:$(this).width()+"px",height:$(this).height()+"px"});
							$("#inputText").css({width:$(this).width()-4+"px",height:$(this).height()+"px","padding-left":"5px"});
							$("#inputText").focus();
							$("#inputText").val($(this).html());
							var self = this;
							$("#inputText").unbind().bind(
							{
								blur:function()
								{
									$(self).html(this.value);
									$("#editText").hide();
								},
								keydown:function(event)
								{
									if(13 == event.keyCode)
									{
										$(this).blur();
									}
								}
							})
						}
					});
				}
				break;
			case 3:
				$(this).addClass("nasrowfouth");
				if(iRow > 0)
				{
					if(window.parent.g_bIsIPDome)
					{
						if(iRow > 1)
						{
							return;
						}
					}
					$(this).bind(
					{
						click:function()
						{
							$("#editText").show();
							$("#editText").css({"left":$(this).offset().left+"px", "top":$(this).offset().top+"px",width:$(this).width()+"px",height:$(this).height()+"px"});
							$("#inputText").css({width:$(this).width()-4+"px",height:$(this).height()+"px","padding-left":"5px"});
							$("#inputText").focus();
							$("#inputText").val($(this).html().replace(/&amp;/g, '&'));
							var self = this;
							$("#inputText").unbind().bind(
							{
								blur:function()
								{
									$(self).html(this.value.replace(/\&/g, '&amp;')).attr("title", this.value);
									$("#editText").hide();
								},
								keydown:function(event)
								{
									if(13 == event.keyCode)
									{
										$(this).blur();
									}
								}
							})
						}
					});
				}
				break;
			default:
				break;
		}
	});*/
}
/*************************************************
Function:		initDiskInfo
Description:	初始化硬盘信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function initDiskInfo()
{
	GetDiskInfo();
	GetSDCardInfo();
	autoResizeIframe();
}
/*************************************************
Function:		GetSDCardInfo
Description:	获取设备上SD卡格式化信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function GetSDCardInfo()
{
	$.ajax({
		type: "GET",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/AutoFormat",
		timeout: 15000,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) 
		{
			$("#AutoFormatCard").prop("checked", $(xmlDoc).find("enabled").eq(0).text() == "true"?true:false);
			$.ajax({
				type: "GET",
				url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/Event/notification/ftp/1",
				timeout: 15000,
				beforeSend: function(xhr) {
					xhr.setRequestHeader("If-Modified-Since", "0");
					
				},
				success: function(xmlDoc, textStatus, xhr) 
				{
					g_strFtpXmlDoc = xmlDoc;
					$("#UploadSDInfo").prop("checked", $(xmlDoc).find("uploadSDInfomation").eq(0).text() == "true"?true:false);
					$('#UploadAppendInfo').prop("checked", $(xmlDoc).find("uploadAttachedInfomation").eq(0).text() == "true"?true:false);
				},
				error: function()
				{
					//alert(getNodeValue('NetworkErrorTips'));
				}
			});
		},
		error: function()
		{
			//alert(getNodeValue('NetworkErrorTips'));
		}
	});
}
/*************************************************
Function:		SetSDCardInfo
Description:	设置设备上SD卡格式化信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function SetSDCardInfo()
{
	var szXml = '<?xml version="1.0" encoding="utf-8"?>';
	szXml += "<AutoFormat><enabled>" + $("#AutoFormatCard")[0].checked.toString() + "</enabled></AutoFormat>";
	var xmlDoc = parseXmlFromStr(szXml);
	
	$.ajax({
		type: "put",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/AutoFormat",
		timeout: 15000,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		processData: false,
		data: xmlDoc,
		success: function(xmlDoc, textStatus, xhr) 
		{
			$(g_strFtpXmlDoc).find("uploadSDInfomation").eq(0).text($("#UploadSDInfo")[0].checked.toString());
            $(g_strFtpXmlDoc).find("uploadAttachedInfomation").eq(0).text($("#UploadAppendInfo")[0].checked.toString());
			var xmlObj = parseXmlFromStr(xmlToStr(g_strFtpXmlDoc));
			$.ajax({
				type: "put",
				url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/Event/notification/ftp/1",
				timeout: 15000,
				processData: false,
		        data: xmlObj,
				beforeSend: function(xhr) {
					xhr.setRequestHeader("If-Modified-Since", "0");
					
				},
				complete: function(xhr, textStatus) 
				{
					SaveState(xhr);
				}
			});
		},
		error: function()
		{
			//alert(getNodeValue('NetworkErrorTips'));
		}
	});
}
/*************************************************
Function:		GetDiskInfo
Description:	获取设备上SD卡信息
Input:			无			
Output:			无
return:			无				
*************************************************/
function GetDiskInfo()
{
	$("#storageDecList").empty();
	$.ajax({
		type: "GET",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ContentMgmt/Storage",
		timeout: 15000,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) 
		{
			var xmlRoot = $(xmlDoc);
			var iHddLen = xmlRoot.find("hdd").length;
			for(var i = 0; i < iHddLen; i++)
			{
				var szDiskId = xmlRoot.find('id').eq(i).text();
				var szDiskType = TurnDiskType(xmlRoot.find('hddType').eq(i).text());//硬盘类型
				
				var szDiskCapacity = (parseInt(xmlRoot.find('capacity').eq(i).text(), 10)/1024).toFixed(2) + "GB"; 
				var szDiskFreeSpace = (parseInt(xmlRoot.find('freeSpace').eq(i).text(), 10)/1024).toFixed(2) + "GB";
				var szDiskProperty = TurnHardDiskProperty(xmlRoot.find('property').eq(i).text());
				var szDiskStatus =  TurnDiskStatus(xmlRoot.find('status').eq(i).text());//硬盘状态
				var szvideoCapacity = (parseInt(xmlRoot.find('videoCapacity').eq(i).text(), 10)/1024).toFixed(2) + "GB";
				var szvideoFreeSpace = (parseInt(xmlRoot.find('videoFreeSpace').eq(i).text(), 10)/1024).toFixed(2) + "GB";
				var szpictureCapacity = (parseInt(xmlRoot.find('pictureCapacity').eq(i).text(), 10)/1024).toFixed(2) + "GB";
				var szpictureFreeSpace = (parseInt(xmlRoot.find('pictureFreeSpace').eq(i).text(), 10)/1024).toFixed(2) + "GB";
				
				insertOneDisk(szDiskId, "hdd", szDiskCapacity, szDiskFreeSpace, szDiskStatus, szDiskType, szDiskProperty, szvideoCapacity, szvideoFreeSpace, szpictureCapacity, szpictureFreeSpace);
			}
			var iNasLen = xmlRoot.find("nas").length;
			for(var i = 0; i < iNasLen; i++)
			{
				var szDiskStatus =  xmlRoot.find("nas").eq(i).find('status').eq(0).text();//硬盘状态
				
				var szDiskId = xmlRoot.find("nas").eq(i).find('id').eq(0).text();
				var szDiskType = TurnDiskType(xmlRoot.find("nas").eq(i).find('nasType').eq(0).text());//硬盘类型
				
				var szDiskCapacity = (parseInt(xmlRoot.find("nas").eq(i).find('capacity').eq(0).text(), 10)/1024).toFixed(2) + "GB"; 
				var szDiskFreeSpace = (parseInt(xmlRoot.find("nas").eq(i).find('freeSpace').eq(0).text(), 10)/1024).toFixed(2) + "GB";
				var szDiskProperty = TurnHardDiskProperty(xmlRoot.find("nas").eq(i).find('property').eq(0).text());
				var szvideoCapacity = (parseInt(xmlRoot.find("nas").eq(i).find('videoCapacity').eq(0).text(), 10)/1024).toFixed(2) + "GB";
				var szvideoFreeSpace = (parseInt(xmlRoot.find("nas").eq(i).find('videoFreeSpace').eq(0).text(), 10)/1024).toFixed(2) + "GB";
				var szpictureCapacity = (parseInt(xmlRoot.find("nas").eq(i).find('pictureCapacity').eq(0).text(), 10)/1024).toFixed(2) + "GB";
				var szpictureFreeSpace = (parseInt(xmlRoot.find("nas").eq(i).find('pictureFreeSpace').eq(0).text(), 10)/1024).toFixed(2) + "GB";
				
				insertOneDisk(szDiskId, "nas", szDiskCapacity, szDiskFreeSpace, TurnDiskStatus(szDiskStatus), szDiskType, szDiskProperty, szvideoCapacity, szvideoFreeSpace, szpictureCapacity, szpictureFreeSpace);
				if(szDiskStatus == 'offline')
				{
					$("#nas_"+szDiskId).find(":checkbox").eq(0).prop("disabled", true);
				}
			}
		},
		error: function()
		{
			//alert(getNodeValue('NetworkErrorTips'));
		}
	});
}

/*************************************************
Function:		TurnDiskStatus
Description:	将硬盘状态转换成文字
Input:			szDiskStatus:硬盘状态		
Output:			无
return:			无				
*************************************************/
function TurnDiskStatus(szDiskStatus)
{
	if("ok" == szDiskStatus)
	{
		return getNodeValue('tipsNormal');
	}
	else if("unformatted" == szDiskStatus)
	{
		return getNodeValue('tipsUnformatted');
	}
	else if("error" == szDiskStatus)
	{
		return getNodeValue('tipsError');
	}
	else if("idle" == szDiskStatus)
	{
		return getNodeValue('tipsIdle');
	}
	else if("mismatch" == szDiskStatus)
	{
		return getNodeValue('tipsMismatch');
	}
	else if("offline" == szDiskStatus)
	{
		return getNodeValue('OffLineTips');
	}
	else if("formating" == szDiskStatus)
	{
		return getNodeValue('tipsFormatting');
	}
	return "";
}

/*************************************************
Function:		TurnHardDiskProperty
Description:	将硬盘类型转换成文字
Input:			strDiskType:硬盘类型			
Output:			无
return:			无				
*************************************************/
function TurnDiskType(strDiskType)
{
	var szDiskType = '';
	switch(strDiskType)
	{
		case 'SATA':
			szDiskType = getNodeValue('LocalTips');
			break;
		case 'NFS':
		    szDiskType = 'NAS';
			break;
		case 'iSCSI':
		    szDiskType = 'IP SAN';
			break;
		case 'Virtual Disk':
		    szDiskType = getNodeValue('tipsArray');
		default:
		    szDiskType = strDiskType;
			break;
	}
	return szDiskType;
}

/*************************************************
Function:		TurnHardDiskProperty
Description:	将硬盘属性转换成文字
Input:			iDiskProperty: 硬盘属性			
Output:			无
return:			无				
*************************************************/
function TurnHardDiskProperty(iDiskProperty)
{
	var szDiskProperty = '';
	if('RW' == iDiskProperty)
	{
		szDiskProperty = getNodeValue('tipsRW');
	}
	else if('Redund' == iDiskProperty)
	{
		szDiskProperty = getNodeValue('tipsRedund');
	}
	else if('RO' == iDiskProperty)
	{
		szDiskProperty = getNodeValue('tipsRO');
	}
	return szDiskProperty;
}
/*************************************************
Function:		insertOneDisk
Description:	向存储设备列表插入一条设备信息
Input:			iNo       磁盘号
				szName    名称
				iCap      总容量
				iFreeSpc  剩余容量
				szStatus  状态
				szType    类型
				szProp    属性
				szvideoCapacity 录像容量
				szvideoFreeSpace 录像剩余空间
				szpictureCapacity   图片容量
				szpictureFreeSpace  图片剩余空间
Output:			无
return:			无				
*************************************************/
function insertOneDisk(iNo, szName, iCap, iFreeSpc, szStatus, szType, szProp, szvideoCapacity, szvideoFreeSpace, szpictureCapacity, szpictureFreeSpace)
{
	var oDiv = $("<div class='storagelist' id="+(szName+"_"+iNo)+"><span class='storagerowfirst'><input type='checkbox' class='seldiskcheck'>"+iNo+"</span><span class='storagerowother'>"+iCap+"</span><span class='storagerowother'>"+iFreeSpc+"</span><span class='storagerowother'>"+szStatus+"</span><span class='storagerowother'>"+szType+"</span><span class='storagerowother'>"+szProp+"</span><span class='storagerowlast'></span></div>").appendTo("#storageDecList").bind(
	{
		click:function()
		{
			
		},
		mouseover:function()
		{

		},
		mouseout:function()
		{

		}
	}).find(":checkbox").eq(0).bind("click", function()
	{
		var iCheckAble = $(".seldiskcheck").filter(function(index)
		{
			return !this.disabled;
		});
		iCheckAble.each(function(i)
		{
			if(!this.checked)
			{
				$("#selAllDisk").prop("checked", false);
				return false;
			}
			if((i+1) >= iCheckAble.length)
			{
				$("#selAllDisk").prop("checked", true);
			}
		});
	});
}
/*************************************************
Function:		FormatSelDisk
Description:	格式化选中硬盘
Input:			无
Output:			无
return:			无				
*************************************************/
function FormatSelDisk()
{
	g_bRequiredReboot = false;  //初始化为false
	szTips1 = getNodeValue('tipsSelectDisk');
	var iCheckLen = $(".seldiskcheck").length;
	var iSel = -1;
	$(".seldiskcheck").each(function(i)
	{
		if(this.checked && !this.disabled)
		{
			iSel = i;
			return false;
		}
	});
	if(-1 != iSel)
	{
		szTips2 = getNodeValue('tipsFormatSelect');
		var bWarning = confirm(szTips2);
		if(bWarning)
		{
			var oSel = $("#storageDecList").children("div").eq(iSel);
			FormatOneDisk(oSel[0].id.split("_")[0], oSel[0].id.split("_")[1]);   //格式化第一个选中的硬盘
		}
	}
	else
	{
		alert(szTips1);
	}
}
/*************************************************
Function:		FormatOneDisk
Description:	格式化硬盘
Input:			szType 硬盘类型
				iId    ID号
Output:			无
return:			无				
*************************************************/
function FormatOneDisk(szType, iId)
{
	$("#SetResultTips").html(''); 
	var szTips3 = getNodeValue('jsComplete');
	var szTips4 = getNodeValue('tipsFormatFailed');
	g_szCurFormatId = szType+"_"+iId;
	window.parent.$("#ConfigDivUpdateBlock").show();
	var szURL = m_lHttp + m_strIp + ":" + m_lHttpPort +  "/PSIA/Custom/SelfExt/ContentMgmt/Storage/"+szType+"/" + iId + "/format";
	$.ajax({
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		timeout: 0,
		complete:function(xhr, textStatus)
		{
			var xmlDoc = xhr.responseXML;
			var state = $(xmlDoc).find('statusCode').eq(0).text();
			
			if("7" == state)	//Reboot Required
			{
				g_bRequiredReboot = true;
			}
			if(xhr.status == 403)
			{
				var szRetInfo = m_szErrorState + m_szError8;
				window.parent.$("#ConfigDivUpdateBlock").hide();
				$("#"+g_szCurFormatId).find(".storagerowlast").eq(0).html(szRetInfo); 
				clearTimeout(m_hFormatClockTime);
				return;
			}
			else if(xhr.status == 200)
			{
				//选中的磁盘格式化完毕
				m_iTimeNum = 0;
				clearTimeout(m_hFormatClockTime);
				/*if("7" == state)	//Reboot Required
				{
					var szRetInfo = m_szSuccessState + m_szSuccess5;
					$("#"+g_szCurFormatId).find(".storagerowlast").eq(0).html(szRetInfo); 
				}
				else*/
				{
					$("#"+g_szCurFormatId).find(".storagerowlast").eq(0).html(szTips3);
				}
			}
			else
			{
				m_iTimeNum = 0;
				clearTimeout(m_hFormatClockTime);
				$("#"+g_szCurFormatId).find(".storagerowlast").eq(0).html(szTips4);
			}
			var iListLen = $("#storageDecList").children("div").length;
			if($("#"+g_szCurFormatId).index() >= (iListLen-1))//所有选中的磁盘均格式化完毕
			{
				setTimeout(function(){
						GetDiskInfo();
						if(g_bRequiredReboot)
						{
							pr(Maintain).confirmAndRestart();
						}
					}, 2000);             //刷新硬盘信息列表（因为硬盘格式化后，状态会发生变化）
				window.parent.$("#ConfigDivUpdateBlock").hide();
				$("#selAllDisk").prop("checked", false);
				return;
			}
			$("#"+g_szCurFormatId).nextAll().each(function()
			{
				if($(this).find(".seldiskcheck").eq(0).prop("checked"))
				{
					var szTypeName = this.id.split("_")[0];
					var iID = this.id.split("_")[1];
					FormatOneDisk(szTypeName, iID);
					return false;
				}
				else if(($(this).index()+1) >= iListLen)//所有选中的磁盘均格式化完毕
				{
					setTimeout(function(){
						GetDiskInfo();
						if(g_bRequiredReboot)
						{
							pr(Maintain).confirmAndRestart();
						}
					}, 2000);             //刷新硬盘信息列表（因为硬盘格式化后，状态会发生变化）
					window.parent.$("#ConfigDivUpdateBlock").hide();
					$("#selAllDisk").prop("checked", false);
				}
			})
			
		}
	});
	m_hFormatClockTime = setTimeout("FormatProgress('"+szType+"', "+iId+")", 500);
}

/*************************************************
Function:		FormatProgress
Description:	定时获取硬盘格式化进度
Input:			无
Output:			无
return:			无				
*************************************************/
function FormatProgress(szType, iId)
{
	var szTips3 = getNodeValue('jsComplete');
	var szTips4 = getNodeValue('tipsFormatFailed');
	
	var szURL = m_lHttp + m_strIp + ":" + m_lHttpPort +  "/PSIA/Custom/SelfExt/ContentMgmt/Storage/"+szType+"/" + iId + "/formatStatus";
	$.ajax(
	{
		type: "GET",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		async: true,
		timeout: 30000,
		url: szURL,
		success: function(xmlDoc, textStatus, xhr)
		{
			var szTips1 = getNodeValue('tipsFormattingWait');  
			
			var szFormatProgress = parseInt(xmlDoc.documentElement.getElementsByTagName('percent')[0].childNodes[0].nodeValue);
			var IsFormating = xmlDoc.documentElement.getElementsByTagName('formating')[0].childNodes[0].nodeValue;
			
			if(IsFormating == 'false' && szFormatProgress == 0)
			{
				m_iTimeNum++;
				if(m_iTimeNum >= 10)
				{
					$("#"+g_szCurFormatId).find(".storagerowlast").eq(0).html(getNodeValue('jsNetworkAbnormal'));
				} else {
					m_hFormatClockTime = setTimeout("FormatProgress('"+szType+"', "+iId+")", 3000);
				}
			}
			else if(szFormatProgress < 100 && IsFormating == 'true')  //格式化未完成，不断地获取硬盘格式化进度
			{
				$("#"+g_szCurFormatId).find(".storagerowlast").eq(0).html(szFormatProgress + '%');
				m_iTimeNum = 0;
				m_hFormatClockTime = setTimeout("FormatProgress('"+szType+"', "+iId+")", 3000);
			}
			else if(szFormatProgress == 100 && IsFormating == 'false')//格式化完一个硬盘的话
			{
				m_iTimeNum = 0;
				$("#"+g_szCurFormatId).find(".storagerowlast").eq(0).html(szTips3);
			}  
			
		},
		error:function(xhr, textStatus, errorThrown)
		{
			if("timeout" == textStatus)
			{
				$("#"+g_szCurFormatId).find(".storagerowlast").eq(0).html(getNodeValue('jsNetworkAbnormal'));
			}
			else
			{  
				$("#"+g_szCurFormatId).find(".storagerowlast").eq(0).html(szTips4);
			}
		}
	});
}

function FTP(){
    SingletonInheritor.implement(this);
    this.m_iCurSelFTPNum = -1;
    this.sz_ftpXML = null;
    this.m_pwdConfirm = null;
}
SingletonInheritor.declare(FTP);

pr(FTP).update = function() {
    $('#SetResultTips').html('');
    $("#SaveConfigBtn").show();
    g_transStack.clear();
    var that = this;
    g_transStack.push(function() {
        that.setLxd(parent.translator.getLanguageXmlDoc(["Storage", "FTP"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);
    initFTP();
}

/*************************************************
 Function:		initFTP
 Description:	初始化FTP页面
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function initFTP()
{
    GetFTPInfo();
    autoResizeIframe();
}

/*************************************************
 Function:		GetFTPInfo
 Description:	获取FTP信息
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function GetFTPInfo()
{
    m_iSelectItem = -1;

    ia(FTP).m_iCurSelFTPNum = 0;
    $.ajax({
        type: "GET",
        url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ftp",
        timeout: 15000,
        async: false,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr)
        {
            ia(FTP).sz_ftpXML = xmlDoc;

            var xmlRoot = $(xmlDoc);
            var enableLength = xmlRoot.find('enble').length;
            var ftpCount = 0;
            for(var a=0; a <enableLength; a++){
                if(xmlRoot.find('enble').eq(a).text() == 'true'){
                    ftpCount++;
                }
            }
            $('#ftpEnableOpt').val(ftpCount);

            if(ftpCount > 0){
                $("#tabUploadFTP").find("li").each(function() {
                    if($(this).children().hasClass("current")) {
                        $(this).children().removeClass();
                    }
                });
                $("#tabUploadFTP").find("li").eq(0).find("a").eq(0).addClass("current");
            }

            $('#ftpUploadData1').val(xmlRoot.find("upDataType").eq(0).text());
            $('#ftpUploadData2').val(xmlRoot.find("upDataType").eq(1).text());

			

            //FTP.checkUploadFTP();
			if($('#ftpEnableOpt').val() == 0){

				$('#ftpEnableContent').css("display","none");

			}else if($('#ftpEnableOpt').val() == 1){

				$('#ftpEnableContent').css("display","block");
				$('#ftpUploadDiv').css("display","none");
				$('#osdInfoDiv').css("display","block");
				$('#liFTP2').css("display","none");
			}else{
				$('#ftpEnableContent').css("display","block");
				$('#ftpUploadDiv').css("display","block");
				$('#osdInfoDiv').css("display","block");
				$('#liFTP2').css("display","block");
				FTP.changeUploadFTP1();
			}

            if("hostname" == xmlRoot.find("addressingFormatType").eq(0).text())
            {
                $("#FtpAddress").val(xmlRoot.find("hostName").eq(0).text());
            }
            else
            {
                if(0 != xmlRoot.find("ipAddress").length)
                {
                    $("#FtpAddress").val(xmlRoot.find("ipAddress").eq(0).text());
                }
                else
                {
                    $("#FtpAddress").val(xmlRoot.find("ipv6Address").eq(0).text());
                }
            }
			if ($(xmlRoot).find('uploadPlateEnable').eq(0).text() == 'true') {
	            $("#uploadPlateEnable").prop("checked", true);
            } else {
	            $("#uploadPlateEnable").prop("checked", false);
            }
            $("#FtpPort").val(xmlRoot.find("portNo").eq(0).text());
            $("#FtpUserName").val(xmlRoot.find("userName").eq(0).text());
            //$('#FtpPassword').val(xmlRoot.find("password").eq(0).text());
            oCheckPassword.checkUserName(xmlRoot.find("userName").eq(0).text(), $('#FtpPassword'), $('#FtpPasswordConfirm'));

            $("#selPathDepth").val(xmlRoot.find("pathDepth").eq(0).text());
            $("#selTopPath").val(xmlRoot.find("FTPParam").eq(0).find('topDirNameRule').eq(0).text());
            $("#selSubPath").val(xmlRoot.find("FTPParam").eq(0).find('subDirNameRule').eq(0).text());
            $("#selThirdPath").val(xmlRoot.find("FTPParam").eq(0).find('threeDirNameRule').eq(0).text());
            $("#selFourthPath").val(xmlRoot.find("FTPParam").eq(0).find('fourDirNameRule').eq(0).text());
            FTP.changePathDepthInfo($("#selPathDepth").val());

            if($("#selTopPath").val() == 'custom'){
                $('#selTopPathText').css('display','inline-block');
                $('#selTopPathText').val(xmlRoot.find("FTPParam").eq(0).find('topCustomStr').eq(0).text());
            }
            if($("#selSubPath").val() == 'custom'){
                $('#selSubPathText').css('display','inline-block');
                $('#selSubPathText').val(xmlRoot.find("FTPParam").eq(0).find('subCustomStr').eq(0).text());
            }
            if($("#selThirdPath").val() == 'custom'){
                $('#selThirdPathText').css('display','inline-block');
                $('#selThirdPathText').val(xmlRoot.find("FTPParam").eq(0).find('threeCustomStr').eq(0).text());
            }
            if($("#selFourthPath").val() == 'custom'){
                $('#selFourthPathText').css('display','inline-block');
                $('#selFourthPathText').val(xmlRoot.find("FTPParam").eq(0).find('fourCustomStr').eq(0).text());
            }

            //JPEG图片信息
            $("#delimiter").val(xmlRoot.find("delimiter").eq(0).text());
            try
            {
                var num = document.getElementById("PictureNameList").rows.length;
            }
            catch(e)
            {
                var num = 0;
            }
            for(var i = 1; i < num; i++)
            {
                document.getElementById("PictureNameList").deleteRow(1);
            }
            for(var i = 0; i < xmlRoot.find("pictureNameRuleList").eq(0).find("pictureNameRule").length; i++)
            {
                m_strItem[i] = xmlRoot.find("pictureNameRuleList").eq(0).find("item").eq(i).text();
				if(m_strItem[i]=="custom"){
				    m_strCustomStr[i] = xmlRoot.find("customStr").eq(0).text();
				}
                InsertItemList(i+1, (getNodeValue("ItemName") + (parseInt(i)+1)), getNodeValue(xmlRoot.find("pictureNameRuleList").eq(0).find("item").eq(i).text()+"Item"),(xmlRoot.find("pictureNameRuleList").eq(0).find("item").eq(i).text()), m_strCustomStr[i]);
				
            }
            for(var i = xmlRoot.find("pictureNameRuleList").eq(0).find("pictureNameRule").length; i < 15; i++) {
                InsertItemList(i, (getNodeValue("ItemName") + i), getNodeValue("NullItem"),"none", "");
            }

            // 新增osd相关信息。
            $('#osdAddress').val(xmlRoot.find('site').eq(0).text());
            $('#osdDirection').val(xmlRoot.find('direction').eq(0).text());
            $('#osdDirectionDesc').val(xmlRoot.find('directionDesc').eq(0).text());
            $('#osdRoadNum').val(xmlRoot.find('roadNum').eq(0).text());
            $('#osdMonitoringSite').val(xmlRoot.find('monitoringInfo1').eq(0).text());
            $('#osdDeviceNum').val(xmlRoot.find('instrumentNum').eq(0).text());  //设备编号

        },
        error: function()
        {
        }
    });
	autoResizeIframe();
}

/*************************************************
 Function:		selectFTPTab
 Description:	切换FTP触发事件
 Input:			    无
 Output:			无
 return:			无
 *************************************************/
FTP.selectFTPTab = function(tabId){
	m_iSelectItem = -1;
    var iLastIndex = parseInt(ia(FTP).m_iCurSelFTPNum);
    if(tabId == iLastIndex) {
        return;
    }
    $("#tabUploadFTP").find("li").each(function() {
        if($(this).children().hasClass("current")) {
            $(this).children().removeClass();
        }
    });
    $("#tabUploadFTP").find("li").eq(tabId).find("a").eq(0).addClass("current");

    //保存之前tab信息
    if($("#uploadPlateEnable").prop("checked")) {
	     $(ia(FTP).sz_ftpXML).find('uploadPlateEnable').eq(iLastIndex).text('true');
    } else {
         $(ia(FTP).sz_ftpXML).find('uploadPlateEnable').eq(iLastIndex).text('false');
    }
    $(ia(FTP).sz_ftpXML).find('ipAddress').eq(iLastIndex).text($('#FtpAddress').val());
    $(ia(FTP).sz_ftpXML).find('portNo').eq(iLastIndex).text($('#FtpPort').val());
    $(ia(FTP).sz_ftpXML).find('userName').eq(iLastIndex).text($('#FtpUserName').val());
	if($('#FtpPassword').val() != "" && $('#FtpPassword').val() != oCheckPassword.m_szDefaultPassword)
	{
		//$(ia(FTP).sz_ftpXML).find('password').eq(iLastIndex).text($('#FtpPassword').val());
        var pwd = $('#FtpPassword').val();

        var obj = x2js.xml_str2json(xmlToStr(ia(FTP).sz_ftpXML));
        if(obj){
            var ftpParamsArray = obj['DoubleFTPNotification']['FTPParamList'].FTPParam_asArray;
            if (ftpParamsArray && ftpParamsArray.length) {
                for (var i = 0; i < ftpParamsArray.length; i++) {
                    if (i == iLastIndex) {
                        var ftpParam = ftpParamsArray[i];
                        ftpParam['password'] = pwd;    
                        break;
                    };
                };
            };
        }

        ia(FTP).sz_ftpXML = x2js.json2xml(obj);
	}

    $(ia(FTP).sz_ftpXML).find("pathDepth").eq(iLastIndex).text($("#selPathDepth").val());
    $(ia(FTP).sz_ftpXML).find("FTPParam").eq(iLastIndex).find('topDirNameRule').eq(0).text($("#selTopPath").val());
    $(ia(FTP).sz_ftpXML).find("FTPParam").eq(iLastIndex).find('subDirNameRule').eq(0).text($("#selSubPath").val());
    $(ia(FTP).sz_ftpXML).find("FTPParam").eq(iLastIndex).find('threeDirNameRule').eq(0).text($("#selThirdPath").val());
    $(ia(FTP).sz_ftpXML).find("FTPParam").eq(iLastIndex).find('fourDirNameRule').eq(0).text($("#selFourthPath").val());

    $(ia(FTP).sz_ftpXML).find("FTPParam").eq(iLastIndex).find('topCustomStr').eq(0).text($("#selTopPathText").val());
    $(ia(FTP).sz_ftpXML).find("FTPParam").eq(iLastIndex).find('subCustomStr').eq(0).text($("#selSubPathText").val());
    $(ia(FTP).sz_ftpXML).find("FTPParam").eq(iLastIndex).find('threeCustomStr').eq(0).text($("#selThirdPathText").val());
    $(ia(FTP).sz_ftpXML).find("FTPParam").eq(iLastIndex).find('fourCustomStr').eq(0).text($("#selFourthPathText").val());

//    $(ia(FTP).sz_ftpXML).find('FTPParam').eq(iLastIndex).find('dirPathDepth').eq(0).text();
   /* for(var i=0;i<=14;i++){
		if($('#itemtdC'+(i+1)).attr("name")=="custom"){
		  $(ia(FTP).sz_ftpXML).find('customStr').eq(iLastIndex).text(m_strCustomStr[i]);
		}
	}*/
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(iLastIndex).find('delimiter').eq(0).text($('#delimiter').val());
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(iLastIndex).find('pictureNameRule').eq(0).find('item').eq(0).text($('#ItemElement1').length>0?$('#ItemElement1').val():$('#itemtdC1').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(iLastIndex).find('pictureNameRule').eq(1).find('item').eq(0).text($('#ItemElement2').length>0?$('#ItemElement2').val():$('#itemtdC2').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(iLastIndex).find('pictureNameRule').eq(2).find('item').eq(0).text($('#ItemElement3').length>0?$('#ItemElement3').val():$('#itemtdC3').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(iLastIndex).find('pictureNameRule').eq(3).find('item').eq(0).text($('#ItemElement4').length>0?$('#ItemElement4').val():$('#itemtdC4').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(iLastIndex).find('pictureNameRule').eq(4).find('item').eq(0).text($('#ItemElement5').length>0?$('#ItemElement5').val():$('#itemtdC5').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(iLastIndex).find('pictureNameRule').eq(5).find('item').eq(0).text($('#ItemElement6').length>0?$('#ItemElement6').val():$('#itemtdC6').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(iLastIndex).find('pictureNameRule').eq(6).find('item').eq(0).text($('#ItemElement7').length>0?$('#ItemElement7').val():$('#itemtdC7').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(iLastIndex).find('pictureNameRule').eq(7).find('item').eq(0).text($('#ItemElement8').length>0?$('#ItemElement8').val():$('#itemtdC8').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(iLastIndex).find('pictureNameRule').eq(8).find('item').eq(0).text($('#ItemElement9').length>0?$('#ItemElement9').val():$('#itemtdC9').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(iLastIndex).find('pictureNameRule').eq(9).find('item').eq(0).text($('#ItemElement10').length>0?$('#ItemElement10').val():$('#itemtdC10').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(iLastIndex).find('pictureNameRule').eq(10).find('item').eq(0).text($('#ItemElement11').length>0?$('#ItemElement11').val():$('#itemtdC11').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(iLastIndex).find('pictureNameRule').eq(11).find('item').eq(0).text($('#ItemElement12').length>0?$('#ItemElement12').val():$('#itemtdC12').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(iLastIndex).find('pictureNameRule').eq(12).find('item').eq(0).text($('#ItemElement13').length>0?$('#ItemElement13').val():$('#itemtdC13').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(iLastIndex).find('pictureNameRule').eq(13).find('item').eq(0).text($('#ItemElement14').length>0?$('#ItemElement14').val():$('#itemtdC14').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(iLastIndex).find('pictureNameRule').eq(14).find('item').eq(0).text($('#ItemElement15').length>0?$('#ItemElement15').val():$('#itemtdC15').attr("name"));
	
    //获取当前tab信息.
	
	if ($(ia(FTP).sz_ftpXML).find('uploadPlateEnable').eq(tabId).text() == 'true') {
	    $("#uploadPlateEnable").prop("checked", true);
    } else {
	    $("#uploadPlateEnable").prop("checked", false);
    }
    $('#FtpAddress').val($(ia(FTP).sz_ftpXML).find('ipAddress').eq(tabId).text());
    $('#FtpPort').val($(ia(FTP).sz_ftpXML).find('portNo').eq(tabId).text());
    $('#FtpUserName').val($(ia(FTP).sz_ftpXML).find('userName').eq(tabId).text());
	
    //$('#FtpPassword').val($(ia(FTP).sz_ftpXML).find('password').eq(tabId).text());
    oCheckPassword.checkUserName($(ia(FTP).sz_ftpXML).find('userName').eq(tabId).text(), $('#FtpPassword'), $('#FtpPasswordConfirm'));

    $("#selPathDepth").val($(ia(FTP).sz_ftpXML).find("pathDepth").eq(tabId).text());

    FTP.changePathDepthInfo($("#selPathDepth").val());

    $("#selTopPath").val($(ia(FTP).sz_ftpXML).find("FTPParam").eq(tabId).find('topDirNameRule').eq(0).text());
    $("#selSubPath").val($(ia(FTP).sz_ftpXML).find("FTPParam").eq(tabId).find('subDirNameRule').eq(0).text());
    $("#selThirdPath").val($(ia(FTP).sz_ftpXML).find("FTPParam").eq(tabId).find('threeDirNameRule').eq(0).text());
    $("#selFourthPath").val($(ia(FTP).sz_ftpXML).find("FTPParam").eq(tabId).find('fourDirNameRule').eq(0).text());

    if($("#selTopPath").val() == 'custom'){
        $('#selTopPathText').css('display','inline-block');
        $('#selTopPathText').val($(ia(FTP).sz_ftpXML).find("FTPParam").eq(tabId).find('topCustomStr').eq(0).text());
    }else{
        $('#selTopPathText').css('display','none');
        $('#selTopPathText').val('');
    }
    if($("#selSubPath").val() == 'custom'){
        $('#selSubPathText').css('display','inline-block');
        $('#selSubPathText').val($(ia(FTP).sz_ftpXML).find("FTPParam").eq(tabId).find('subCustomStr').eq(0).text());
    }else{
        $('#selSubPathText').css('display','none');
        $('#selSubPathText').val('');
    }
    if($("#selThirdPath").val() == 'custom'){
        $('#selThirdPathText').css('display','inline-block');
        $('#selThirdPathText').val($(ia(FTP).sz_ftpXML).find("FTPParam").eq(tabId).find('threeCustomStr').eq(0).text());
    }else{
        $('#selThirdPathText').css('display','none');
        $('#selThirdPathText').val('');
    }
    if($("#selFourthPath").val() == 'custom'){
        $('#selFourthPathText').css('display','inline-block');
        $('#selFourthPathText').val($(ia(FTP).sz_ftpXML).find("FTPParam").eq(tabId).find('fourCustomStr').eq(0).text());
    }else{
        $('#selFourthPathText').css('display','none');
        $('#selFourthPathText').val('');
    }
    $('#delimiter').val($(ia(FTP).sz_ftpXML).find("pictureName").eq(tabId).find('delimiter').eq(0).text());
    //FTP.checkUploadFTP();
	
	if($('#ftpEnableOpt').val() == 0){

        $('#ftpEnableContent').css("display","none");

    }else if($('#ftpEnableOpt').val() == 1){

        $('#ftpEnableContent').css("display","block");
        $('#ftpUploadDiv').css("display","none");
        $('#osdInfoDiv').css("display","block");
        $('#liFTP2').css("display","none");
    }else{
        $('#ftpEnableContent').css("display","block");
        $('#ftpUploadDiv').css("display","block");
        $('#osdInfoDiv').css("display","block");
        $('#liFTP2').css("display","block");
        FTP.changeUploadFTP1();
    }
    
    try
    {
        var num = document.getElementById("PictureNameList").rows.length;
    }
    catch(e)
    {
        var num = 0;
    }
    for(var i = 1; i < num; i++)
    {
        document.getElementById("PictureNameList").deleteRow(1);
    }

    for(var i = 0; i < $(ia(FTP).sz_ftpXML).find("pictureNameRuleList").eq(tabId).find("pictureNameRule").length; i++)
    {
        m_strItem[i] = $(ia(FTP).sz_ftpXML).find("pictureNameRuleList").eq(tabId).find("item").eq(i).text();
		if(m_strItem[i]=="custom"){
		    m_strCustomStr[i] = $(ia(FTP).sz_ftpXML).find('customStr').eq(tabId).text(); 
		}
        InsertItemList(i+1, (getNodeValue("ItemName") + (parseInt(i)+1)), getNodeValue($(ia(FTP).sz_ftpXML).find("pictureNameRuleList").eq(tabId).find('pictureNameRule').eq(i).find("item").eq(0).text()+"Item"),($(ia(FTP).sz_ftpXML).find("pictureNameRuleList").eq(tabId).find("item").eq(i).text()), m_strCustomStr[i]);
    }
    for(var i = $(ia(FTP).sz_ftpXML).find("pictureNameRuleList").eq(tabId).find("pictureNameRule").length; i < 15; i++) {
        InsertItemList(i, (getNodeValue("ItemName") + i), getNodeValue("NullItem"),"none", "");
    }

    ia(FTP).m_iCurSelFTPNum = tabId;
	autoResizeIframe();
}

FTP.changePathDepthInfo = function(depthId){
    if(depthId == 0){
        $('#selTopPath').prop('disabled',true);
        $('#selSubPath').prop('disabled',true);
        $('#selThirdPath').prop('disabled',true);
        $('#selFourthPath').prop('disabled',true);

        $('#selTopPath').val('none');
        $('#selSubPath').val('none');
        $('#selThirdPath').val('none');
        $('#selFourthPath').val('none');
    }else if(depthId == 1){
        $('#selTopPath').prop('disabled',false);
        $('#selSubPath').prop('disabled',true);
        $('#selThirdPath').prop('disabled',true);
        $('#selFourthPath').prop('disabled',true);

        $('#selSubPath').val('none');
        $('#selThirdPath').val('none');
        $('#selFourthPath').val('none');
    }else if(depthId == 2){
        $('#selTopPath').prop('disabled',false);
        $('#selSubPath').prop('disabled',false);
        $('#selThirdPath').prop('disabled',true);
        $('#selFourthPath').prop('disabled',true);

        $('#selThirdPath').val('none');
        $('#selFourthPath').val('none');
    }else if(depthId == 3){
        $('#selTopPath').prop('disabled',false);
        $('#selSubPath').prop('disabled',false);
        $('#selThirdPath').prop('disabled',false);
        $('#selFourthPath').prop('disabled',true);

        $('#selFourthPath').val('none');
    }else if(depthId == 4){
        $('#selTopPath').prop('disabled',false);
        $('#selSubPath').prop('disabled',false);
        $('#selThirdPath').prop('disabled',false);
        $('#selFourthPath').prop('disabled',false);
    }
}

FTP.changeDirPath = function(type){

    if($('#' + type).val() == 'custom'){
        $('#'+ type + 'Text').css('display','inline-block');
    }else{
        $('#'+ type + 'Text').css('display','none');
        $('#'+ type + 'Text').val('');
    }
}


FTP.checkUploadFTP = function(){

    if($('#ftpEnableOpt').val() == 0){

        $('#ftpEnableContent').css("display","none");

    }else if($('#ftpEnableOpt').val() == 1){

        $('#ftpEnableContent').css("display","block");
        $('#ftpUploadDiv').css("display","none");
        $('#osdInfoDiv').css("display","block");
        $('#liFTP2').css("display","none");
		
		var ftpType;
		$('#tabUploadFTP li').each(function(){
			if($(this).children().hasClass("current")){
				ftpType = $(this).text();
			}
		});
		if(ftpType == 'FTP2'){
			FTP.selectFTPTab(0);
		}
		
    }else{
        $('#ftpEnableContent').css("display","block");
        $('#ftpUploadDiv').css("display","block");
        $('#osdInfoDiv').css("display","block");
        $('#liFTP2').css("display","block");
        FTP.changeUploadFTP1();
    }
    autoResizeIframe();
}

FTP.changeUploadFTP1 = function(){

    if($('#ftpUploadData1').val() == '1'){

        $('#ftpUploadData2').val('2');
    }else if($('#ftpUploadData1').val() == '2'){
        $('#ftpUploadData2').val('1');
    }else{
        $('#ftpUploadData1').val('1');
        $('#ftpUploadData2').val('2');
    }
}

FTP.changeUploadFTP2 = function(){

    if( $('#ftpUploadData2').val() == '1'){

        $('#ftpUploadData1').val('2');
    }else if($('#ftpUploadData2').val() == '2'){
        $('#ftpUploadData1').val('1');
    }else{
        $('#ftpUploadData1').val('2');
        $('#ftpUploadData2').val('1');
    }
}
/*************************************************
 Function:		SetFTPInfo
 Description:	设置FTP信息
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function SetFTPInfo()
{

    if($("#ftpEnableOpt").val() > 0) {
        if(!CheckIPAddress($("#FtpAddress").val(),"SetResultTips","laServerAdd"))
        {
            return;
        }
        if(!CheackServerIDIntNum($("#FtpPort").val(),"SetResultTips","gePort",1,65535))
        {
            return;
        }

        /*if(!CheackStringLenthNull($("#FtpUserName").val(),"SetResultTips","geUserName",32))
        {
            return;
        }*/
        if($("#FtpPassword").val() != $("#FtpPasswordConfirm").val() )
        {
            var szAreaNameInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
            szAreaNameInfo += getNodeValue('jsPwdCheckMismatch');
            $("#SetResultTips").html(szAreaNameInfo);
            return -1;
        }
        /*if($('#FtpPassword').val().length == 0)
        {
            var szPasswordInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
            szPasswordInfo += getNodeValue("gePassword") + getNodeValue("NullTips");
            $("#SetResultTips").html(szPasswordInfo);
            return -1;
        }*/
    }

    if($('#ftpEnableOpt').val() == '0'){
        $(ia(FTP).sz_ftpXML).find('enble').eq(0).text("false");
        $(ia(FTP).sz_ftpXML).find('enble').eq(1).text("false");
    }else if($('#ftpEnableOpt').val() == '1'){
        $(ia(FTP).sz_ftpXML).find('enble').eq(0).text("true");
        $(ia(FTP).sz_ftpXML).find('enble').eq(1).text("false");
    }else if($('#ftpEnableOpt').val() == '2'){
        $(ia(FTP).sz_ftpXML).find('enble').eq(0).text("true");
        $(ia(FTP).sz_ftpXML).find('enble').eq(1).text("true");
    }
    if ($("#uploadPlateEnable").prop("checked")) {
	     $(ia(FTP).sz_ftpXML).find('uploadPlateEnable').eq(ia(FTP).m_iCurSelFTPNum).text('true');
    } else {
         $(ia(FTP).sz_ftpXML).find('uploadPlateEnable').eq(ia(FTP).m_iCurSelFTPNum).text('false');
    }
    $(ia(FTP).sz_ftpXML).find('ipAddress').eq(ia(FTP).m_iCurSelFTPNum).text($('#FtpAddress').val());
    $(ia(FTP).sz_ftpXML).find('portNo').eq(ia(FTP).m_iCurSelFTPNum).text($('#FtpPort').val());
    $(ia(FTP).sz_ftpXML).find('userName').eq(ia(FTP).m_iCurSelFTPNum).text($('#FtpUserName').val());
	if($('#FtpPassword').val() != "" && $('#FtpPassword').val() != oCheckPassword.m_szDefaultPassword)
	{
        var pwd = $('#FtpPassword').val();

        var obj = x2js.xml_str2json(xmlToStr(ia(FTP).sz_ftpXML));
        if(obj){
            var ftpParamsArray = obj['DoubleFTPNotification']['FTPParamList'].FTPParam_asArray;
            if (ftpParamsArray && ftpParamsArray.length) {
                for (var i = 0; i < ftpParamsArray.length; i++) {
                    if (i == ia(FTP).m_iCurSelFTPNum) {
                        var ftpParam = ftpParamsArray[i];
                        ftpParam['password'] = pwd;    
                        break;
                    };
                };
            };
        }

        ia(FTP).sz_ftpXML = x2js.json2xml(obj);
        
        // var curFtpParam = $(ia(FTP).sz_ftpXML).find('FTPParam').eq(ia(FTP).m_iCurSelFTPNum);

        // var tempXml = parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><root><password>'+pwd+'</password></root>');
        // var nd = $(tempXml).find('password').eq(0).clone();
        // curFtpParam.append(nd);
	}

    $(ia(FTP).sz_ftpXML).find("pathDepth").eq(ia(FTP).m_iCurSelFTPNum).text($("#selPathDepth").val());
    $(ia(FTP).sz_ftpXML).find("FTPParam").eq(ia(FTP).m_iCurSelFTPNum).find('topDirNameRule').eq(0).text($("#selTopPath").val());
    $(ia(FTP).sz_ftpXML).find("FTPParam").eq(ia(FTP).m_iCurSelFTPNum).find('subDirNameRule').eq(0).text($("#selSubPath").val());
    $(ia(FTP).sz_ftpXML).find("FTPParam").eq(ia(FTP).m_iCurSelFTPNum).find('threeDirNameRule').eq(0).text($("#selThirdPath").val());
    $(ia(FTP).sz_ftpXML).find("FTPParam").eq(ia(FTP).m_iCurSelFTPNum).find('fourDirNameRule').eq(0).text($("#selFourthPath").val());

    $(ia(FTP).sz_ftpXML).find("FTPParam").eq(ia(FTP).m_iCurSelFTPNum).find('topCustomStr').eq(0).text($("#selTopPathText").val());
    $(ia(FTP).sz_ftpXML).find("FTPParam").eq(ia(FTP).m_iCurSelFTPNum).find('subCustomStr').eq(0).text($("#selSubPathText").val());
    $(ia(FTP).sz_ftpXML).find("FTPParam").eq(ia(FTP).m_iCurSelFTPNum).find('threeCustomStr').eq(0).text($("#selThirdPathText").val());
    $(ia(FTP).sz_ftpXML).find("FTPParam").eq(ia(FTP).m_iCurSelFTPNum).find('fourCustomStr').eq(0).text($("#selFourthPathText").val());
	

    $(ia(FTP).sz_ftpXML).find('pictureName').eq(ia(FTP).m_iCurSelFTPNum).find('delimiter').eq(0).text($('#delimiter').val());
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(ia(FTP).m_iCurSelFTPNum).find('pictureNameRule').eq(0).find('item').eq(0).text($('#ItemElement1').length>0?$('#ItemElement1').val():$('#itemtdC1').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(ia(FTP).m_iCurSelFTPNum).find('pictureNameRule').eq(1).find('item').eq(0).text($('#ItemElement2').length>0?$('#ItemElement2').val():$('#itemtdC2').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(ia(FTP).m_iCurSelFTPNum).find('pictureNameRule').eq(2).find('item').eq(0).text($('#ItemElement3').length>0?$('#ItemElement3').val():$('#itemtdC3').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(ia(FTP).m_iCurSelFTPNum).find('pictureNameRule').eq(3).find('item').eq(0).text($('#ItemElement4').length>0?$('#ItemElement4').val():$('#itemtdC4').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(ia(FTP).m_iCurSelFTPNum).find('pictureNameRule').eq(4).find('item').eq(0).text($('#ItemElement5').length>0?$('#ItemElement5').val():$('#itemtdC5').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(ia(FTP).m_iCurSelFTPNum).find('pictureNameRule').eq(5).find('item').eq(0).text($('#ItemElement6').length>0?$('#ItemElement6').val():$('#itemtdC6').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(ia(FTP).m_iCurSelFTPNum).find('pictureNameRule').eq(6).find('item').eq(0).text($('#ItemElement7').length>0?$('#ItemElement7').val():$('#itemtdC7').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(ia(FTP).m_iCurSelFTPNum).find('pictureNameRule').eq(7).find('item').eq(0).text($('#ItemElement8').length>0?$('#ItemElement8').val():$('#itemtdC8').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(ia(FTP).m_iCurSelFTPNum).find('pictureNameRule').eq(8).find('item').eq(0).text($('#ItemElement9').length>0?$('#ItemElement9').val():$('#itemtdC9').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(ia(FTP).m_iCurSelFTPNum).find('pictureNameRule').eq(9).find('item').eq(0).text($('#ItemElement10').length>0?$('#ItemElement10').val():$('#itemtdC10').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(ia(FTP).m_iCurSelFTPNum).find('pictureNameRule').eq(10).find('item').eq(0).text($('#ItemElement11').length>0?$('#ItemElement11').val():$('#itemtdC11').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(ia(FTP).m_iCurSelFTPNum).find('pictureNameRule').eq(11).find('item').eq(0).text($('#ItemElement12').length>0?$('#ItemElement12').val():$('#itemtdC12').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(ia(FTP).m_iCurSelFTPNum).find('pictureNameRule').eq(12).find('item').eq(0).text($('#ItemElement13').length>0?$('#ItemElement13').val():$('#itemtdC13').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(ia(FTP).m_iCurSelFTPNum).find('pictureNameRule').eq(13).find('item').eq(0).text($('#ItemElement14').length>0?$('#ItemElement14').val():$('#itemtdC14').attr("name"));
    $(ia(FTP).sz_ftpXML).find('pictureName').eq(ia(FTP).m_iCurSelFTPNum).find('pictureNameRule').eq(14).find('item').eq(0).text($('#ItemElement15').length>0?$('#ItemElement15').val():$('#itemtdC15').attr("name"));
	
	// 判断只能有一个自定义类型
	var customStrNum = 0;
	for(var i=0;i<=14;i++){
		if($(ia(FTP).sz_ftpXML).find('pictureName').eq(ia(FTP).m_iCurSelFTPNum).find('pictureNameRule').eq(i).find('item').eq(0).text()=="custom"){
			customStrNum++;
		}
	}
	if(customStrNum>=2){
		alert("只能有一个自定义");
		return;
	}
	for(var i=0;i<=14;i++){
		if($(ia(FTP).sz_ftpXML).find('pictureName').eq(ia(FTP).m_iCurSelFTPNum).find('pictureNameRule').eq(i).find('item').eq(0).text()=="custom"){
	        $(ia(FTP).sz_ftpXML).find('pictureName').eq(ia(FTP).m_iCurSelFTPNum).find('customStr').eq(0).text($('#customStr'+(i+1)).val());
		}
	}
	
    $(ia(FTP).sz_ftpXML).find('site').eq(0).text($('#osdAddress').val());
    $(ia(FTP).sz_ftpXML).find('direction').eq(0).text($('#osdDirection').val());
    $(ia(FTP).sz_ftpXML).find('directionDesc').eq(0).text($('#osdDirectionDesc').val());

    $(ia(FTP).sz_ftpXML).find('roadNum').eq(0).text($('#osdRoadNum').val());
    $(ia(FTP).sz_ftpXML).find('monitoringInfo1').eq(0).text($('#osdMonitoringSite').val());
    $(ia(FTP).sz_ftpXML).find('instrumentNum').eq(0).text($('#osdDeviceNum').val());

    if($('#ftpEnableOpt').val() == '0'|| $('#ftpEnableOpt').val() == '1'){
        $(ia(FTP).sz_ftpXML).find('upDataType').eq(0).text(0);
        $(ia(FTP).sz_ftpXML).find('upDataType').eq(1).text(0);
    }else{
        $(ia(FTP).sz_ftpXML).find('upDataType').eq(0).text($('#ftpUploadData1').val());
        $(ia(FTP).sz_ftpXML).find('upDataType').eq(1).text($('#ftpUploadData2').val());
    }

    var xmlDoc = parseXmlFromStr(xmlToStr(ia(FTP).sz_ftpXML));
    $.ajax({
        type: "PUT",
        url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ftp",
        timeout: 15000,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        processData: false,
        data: xmlDoc,
        complete:function(xhr, textStatus){
            SaveState(xhr);
        }
    });
}

/*************************************************
 Function:		InsertItemList
 Description:	插入文件条目信息到List中
 Input:			a : 序号
 b : 命名项
 c : 命名元素
 d:  命名元素value
 e:
 Output:			无
 return:			无
 *************************************************/
function InsertItemList(a,b,c,d,e)
{
    var ObjTr;
    var ObjTd;
    ObjTr = document.getElementById("PictureNameList").insertRow(document.getElementById("PictureNameList").rows.length);
    ObjTr.style.height = 22 + 'px';
    ObjTr.style.cursor = "pointer";
    for(j = 0;j < document.getElementById("PictureNameList").rows[0].cells.length;j++)
    {
        ObjTd = ObjTr.insertCell(j);
        $(ObjTd).css({border:"1px solid #d7d7d7",background:"#ffffff",padding:"0 0 0 5px"});
        switch(j)
        {
            case 0:
                ObjTd.innerHTML = a;
                ObjTd.id = "itemtdA"+ a;
                ObjTd.style.color = "#39414A";
                break;
            case 1:
                ObjTd.innerHTML = b;
                ObjTd.id = "itemtdB"+ a;
                ObjTd.style.color = "#39414A";
                break;
            case 2:
               	if ("custom" === d) {
					ObjTd.innerHTML = c + "<input class='width75' id='customStr"+ a +"' value='"+ e + "' maxlength='32'/>";
				} else {
					ObjTd.innerHTML = c;
				}
				
                ObjTd.id = "itemtdC"+ a;
                ObjTd.name = d;
                ObjTd.style.color = "#39414A";
                break;
			case 3:
			     ObjTd.innerHTML = d;
                ObjTd.id = "itemtdD"+ a;
                ObjTd.style.color = "#39414A";
                break;
            default:
                break;
        }
    }
}
/*************************************************
 Function:        initROI
 Description:    初始化ROI配置页面
 Input:            无
 Output:            无
 return:            无
 *************************************************/
Roi.prototype.initROI = function () {
	if (window.parent.g_szDeviceType == "IPDome") {
		$("#ptzControl").show();
		sliderPtzSpd.wsetValue(4);
	} else {
		$("#ptzControl").hide();
	}
	HWP.SetDrawStatus(false);
	this.getROICap();
	autoResizeIframe();
}
/*************************************************
 Function:        getROICap
 Description:    获取ROI能力集
 Input:            无
 Output:            无
 return:            无
 *************************************************/
Roi.prototype.getROICap = function () {
	if (!$("#selStreamType").val()) {
		$("#selStreamType").val("01");
	}
	var that = this;
	$.ajax({
		type:"GET",
		url:m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ROI/channels/1" + $("#selStreamType").val() + "/capabilities",
		async: false,
        timeout: 15000,
		beforeSend:function (xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success:function (xmlDoc, textStatus, xhr) {
			that.m_iNorScreenWidth = parseInt($(xmlDoc).find("normalizedScreenWidth").eq(0).text(), 10);
			that.m_iNorScreenHeight = parseInt($(xmlDoc).find("normalizedScreenHeight").eq(0).text(), 10);
			//固定区域提升等级范围
			var iMinFixedImageLevel = parseInt($(xmlDoc).find("ROIRegionList").eq(0).find("qualityLevelOfROI").attr("min"), 10);
			var iMaxFixedImageLevel = parseInt($(xmlDoc).find("ROIRegionList").eq(0).find("qualityLevelOfROI").attr("max"), 10);
			$("#selFixedImageQuaLevel").empty();
			$("#selDynImageQuaLevel").empty();
			for (var i = iMinFixedImageLevel; i <= iMaxFixedImageLevel; i++) {
				$("<option value='" + i + "'>" + i + "</option>").appendTo("#selFixedImageQuaLevel");
				$("<option value='" + i + "'>" + i + "</option>").appendTo("#selDynImageQuaLevel");
			}
			that.getROIInfo();
		}
	});
}
/*************************************************
 Function:        getROIInfo
 Description:    获取ROI配置信息
 Input:            无
 Output:            无
 return:            无
 *************************************************/
Roi.prototype.getROIInfo = function () {
	var that = this;
	$.ajax({
		type:"GET",
		url:m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ROI/channels",
		async:false,
		beforeSend:function (xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success:function (xmlDoc, textStatus, xhr) {
			that.m_oXml = xmlDoc;
			$("#selStreamType").find("option").prop("disabled", true);
			var oROIList = $(xmlDoc).find("ROI");
			for (var i = 0; i < oROIList.length; i++) {
				var iId = parseInt(oROIList.eq(i).find("id").eq(0).text(), 10);
				switch (iId) {
					case 101:
						$("#selStreamType").find("option").eq(0).prop("disabled", false);
						break;
					case 102:
						$("#selStreamType").find("option").eq(1).prop("disabled", false);
						break;
					case 103:
						$("#selStreamType").find("option").eq(2).prop("disabled", false);
						break;
				}
			}
			if ($("#selStreamType").find("option:disabled").length === $("#selStreamType").find("option").length) {
				$("#SaveConfigBtn").hide();
				$("#selStreamType").get(0).selectedIndex = -1;
			} else {
				that.changeStreamType();
			}
		}
	});
}
/*************************************************
 Function:        changeStreamType
 Description:    改变码流类型
 Input:            无
 Output:            无
 return:            无
 *************************************************/
Roi.prototype.changeStreamType = function () {
	var that = this;
	$.ajax({
		type:"GET",
		url:m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ROI/channels/1" + $("#selStreamType").val(),
		async:false,
		beforeSend:function (xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success:function (xmlDoc, textStatus, xhr) {
			//ROI个数根据能力获取
			var iSize = parseInt($(xmlDoc).find("ROIRegionList").eq(0).attr("size"), 10);
			if (!isNaN(iSize)) {
				$("#selFixedROINum").empty();
				for (var i = 0; i < iSize; i++) {
					$("<option value='" + (i + 1) + "'>" + (i + 1) + "</option>").appendTo("#selFixedROINum");
				}
			}
			$("#divDynamicROI").removeData("dynamicType");
			//人脸跟踪
			if ($(xmlDoc).find("FaceTrace").length > 0) {
				$("#divDynamicROI").show().data("dynamicType", "FaceTrace");
				$("#chEnableDynTrackROI").prop("checked", $(xmlDoc).find("FaceTrace").eq(0).find("enabled").eq(0).text() == "true" ? true : false);
				$("#selDynImageQuaLevel").val($(xmlDoc).find("FaceTrace").eq(0).find("qualityLevelOfROI").eq(0).text());
			} else {
				//物体跟踪
				if ($(xmlDoc).find("ObjectTrace").length > 0) {
					$("#divDynamicROI").show().data("dynamicType", "ObjectTrace");
					$("#chEnableDynTrackROI").prop("checked", $(xmlDoc).find("ObjectTrace").eq(0).find("enabled").eq(0).text() == "true" ? true : false);
					$("#selDynImageQuaLevel").val($(xmlDoc).find("ObjectTrace").eq(0).find("qualityLevelOfROI").eq(0).text());
				} else {
					$("#divDynamicROI").hide();
				}
			}

			that.changeFixedROINum();
		},
		error:function () {
			$("#divDynamicROI").hide();
		}
	});
}
/*************************************************
 Function:        changeFixedROINum
 Description:    改变固定区域编号
 Input:            无
 Output:            无
 return:            无
 *************************************************/
Roi.prototype.changeFixedROINum = function () {
	var that = this;
	$.ajax({
		type:"GET",
		url:m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ROI/channels/1" + $("#selStreamType").val() + "/regions/" + $("#selFixedROINum").val(),
		async:false,
		beforeSend:function (xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success:function (xmlDoc, textStatus, xhr) {
			//固定区域
			$("#chEnableFixedROI").prop("checked", $(xmlDoc).find("enabled").eq(0).text() == "true" ? true : false);
			$("#selFixedImageQuaLevel").val($(xmlDoc).find("qualityLevelOfROI").eq(0).text());
			$("#txtRoiName").val($(xmlDoc).find("name").eq(0).text());
			var oRegion = $(xmlDoc).find("RegionCoordinatesList").eq(0).find("RegionCoordinates");
			if (oRegion.length > 0) {
				var szXml = "<?xml version='1.0' encoding='utf-8' ?><DetectionRegionInfo><videoFormat>" + m_iVideoOutNP + "</videoFormat><RegionType>roi</RegionType><ROI><HorizontalResolution>" + that.m_iNorScreenWidth + "</HorizontalResolution><VerticalResolution>" + that.m_iNorScreenHeight + "</VerticalResolution></ROI><DisplayMode>transparent</DisplayMode><MaxRegionNum>1</MaxRegionNum><DetectionRegionList><DetectionRegion><RegionCoordinatesList>";
				szXml += "<RegionCoordinates><positionX>" + oRegion.find("positionX").eq(0).text() + "</positionX><positionY>" + (oRegion.find("positionY").eq(0).text()) + "</positionY></RegionCoordinates>";
				szXml += "<RegionCoordinates><positionX>" + oRegion.find("positionX").eq(1).text() + "</positionX><positionY>" + (oRegion.find("positionY").eq(1).text()) + "</positionY></RegionCoordinates>";
				szXml += "<RegionCoordinates><positionX>" + oRegion.find("positionX").eq(2).text() + "</positionX><positionY>" + (oRegion.find("positionY").eq(2).text()) + "</positionY></RegionCoordinates>";
				szXml += "<RegionCoordinates><positionX>" + oRegion.find("positionX").eq(3).text() + "</positionX><positionY>" + (oRegion.find("positionY").eq(3).text()) + "</positionY></RegionCoordinates>";
				szXml += "</RegionCoordinatesList></DetectionRegion></DetectionRegionList></DetectionRegionInfo>";
			} else {
				var szXml = "<?xml version='1.0' encoding='utf-8' ?><DetectionRegionInfo><videoFormat>" + m_iVideoOutNP + "</videoFormat><RegionType>roi</RegionType><ROI><HorizontalResolution>" + that.m_iNorScreenWidth + "</HorizontalResolution><VerticalResolution>" + that.m_iNorScreenHeight + "</VerticalResolution></ROI><DisplayMode>transparent</DisplayMode><MaxRegionNum>1</MaxRegionNum></DetectionRegionInfo>";
			}
			HWP.SetRegionInfo(szXml);
			//HWP.SetDrawStatus(true);
		},
		error:function () {

		}
	});
}
/*************************************************
 Function:        setROIInfo
 Description:    设置ROI配置信息
 Input:            无
 Output:            无
 return:            无
 *************************************************/
Roi.prototype.setROIInfo = function () {
	if (!CheackStringLenth($("#txtRoiName").val(), "spRoiNameTips", "laROIName", 32)) {
		return;
	}
	var that = this;
	var szXml = "<?xml version='1.0' encoding='utf-8' ?><ROI><id>1" + $("#selStreamType").val() + "</id><enabled>true</enabled>";
	szXml += "<ROIRegionList><ROIRegion><id>" + $("#selFixedROINum").val() + "</id><enabled>" + $("#chEnableFixedROI").prop("checked").toString() + "</enabled><name>" + $("#txtRoiName").val() + "</name><qualityLevelOfROI>" + $("#selFixedImageQuaLevel").val() + "</qualityLevelOfROI><RegionCoordinatesList>";
	var szAreaXml = HWP.GetRegionInfo();
	var oAreaXml = parseXmlFromStr(szAreaXml);
	if ($(oAreaXml).find("RegionCoordinatesList").length > 0) {
		szXml += "<RegionCoordinates><positionX>" + $(oAreaXml).find("positionX").eq(0).text() + "</positionX><positionY>" + $(oAreaXml).find("positionY").eq(0).text() + "</positionY></RegionCoordinates>";
		szXml += "<RegionCoordinates><positionX>" + $(oAreaXml).find("positionX").eq(3).text() + "</positionX><positionY>" + $(oAreaXml).find("positionY").eq(3).text() + "</positionY></RegionCoordinates>";
		szXml += "<RegionCoordinates><positionX>" + $(oAreaXml).find("positionX").eq(2).text() + "</positionX><positionY>" + $(oAreaXml).find("positionY").eq(2).text() + "</positionY></RegionCoordinates>";
		szXml += "<RegionCoordinates><positionX>" + $(oAreaXml).find("positionX").eq(1).text() + "</positionX><positionY>" + $(oAreaXml).find("positionY").eq(1).text() + "</positionY></RegionCoordinates>";
	}
	szXml += "</RegionCoordinatesList></ROIRegion></ROIRegionList>";
	if ($("#divDynamicROI").css("display") != "none" && $("#divDynamicROI").data("dynamicType") != undefined) {
		szXml += "<" + $("#divDynamicROI").data("dynamicType") + "><enabled>" + $("#chEnableDynTrackROI").prop("checked").toString() + "</enabled><qualityLevelOfROI>" + $("#selDynImageQuaLevel").val() + "</qualityLevelOfROI></" + $("#divDynamicROI").data("dynamicType") + ">";
	}
	szXml += "</ROI>";
	var xmlDoc = parseXmlFromStr(szXml);
	$.ajax({
		type:"PUT",
		url:m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ROI/channels/1" + $("#selStreamType").val(),
		beforeSend:function (xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		processData:false,
		data:xmlDoc,
		complete:function (xhr, textStatus) {
			SaveState(xhr);
		}
	});
}
//CloudComputing.prototype.changeCloudComputing = function(){
function changeCloudComputing(){
	if($("#enable").prop("checked")){
		$("#ipAddress").prop("disabled",false);
		$("#portNo").prop("disabled",false);
		$("#userName").prop("disabled",false);
		$("#password").prop("disabled",false);
		$("#postPoolID").prop("disabled",false);
		$("#illegalPoolID").prop("disabled",false);
	}
	else{
		$("#ipAddress").prop("disabled",true);
		$("#portNo").prop("disabled",true);
		$("#userName").prop("disabled",true);
		$("#password").prop("disabled",true);
		$("#postPoolID").prop("disabled",true);
		$("#illegalPoolID").prop("disabled",true);
	}
}