// JavaScript Document
// 
var System = {
	tabs: null	// 保存System配置页面的tabs对象引用
};
function XmlUtils(xmlDoc) {
	this.doc = xmlDoc;
}
XmlUtils.prototype = {
	constructor: XmlUtils,
	elems: function(name) {
		return this.doc.documentElement.getElementsByTagName(name);
	},
	elem: function(name) {
		return this.elems(name)[0];
	},
	val: function(name, value) {
		if (arguments.length === 1){
			try {
				return this.elem(name).childNodes[0].nodeValue;
			} catch (e) {
				return "";
			}
		}else{
			this.elem(name).childNodes[0].nodeValue = value;
		}
	}
};

/*************************************************
Function:		DeviceInfo
Description:	构造函数，Singleton派生类
Input:			无			
Output:			无
return:			无				
*************************************************/

function DeviceInfo() {
	SingletonInheritor.implement(this);
	this.m_xmlDoc = null;		// "/PSIA/System/deviceInfo"返回
	this.m_iChannelNum = -1;	// 通道个数，缓存（原m_iAnalogChannelNum）
	this.m_szVideoFormat = null;// 通道视频制式（原m_iVideoOutNP）
	this.m_iDiskNum = -1;		// 硬盘个数
	this.m_iAlarmInNum = -1;	// 报警输入数，缓存（原m_iAnalogAlarmNum）
	this.m_iAlarmOutNum = -1;	// 报警输出数，缓存（原m_iAlarmOutputAnalogNum）
}
SingletonInheritor.declare(DeviceInfo);

(function() { // DeviceInfo implementation

	/*************************************************
	Function:		update
	Description:	更新设备基本信息
	Input:			无
	Output:			无
	return:			无
	*************************************************/
    DeviceInfo.prototype.update = function()
	{
		if($.browser.msie && parseInt($.browser.version, 10) == 6)
		{
            $(".timehidden").hide();
			$(".232hidden").hide();
			$(".485hidden").hide();
			$("#dvTelecontrol").find("select").hide();
		}
		$("#SaveConfigBtn").show();
		$("#SetResultTips").html("");
		
		g_transStack.clear();
		var that = this;
		g_transStack.push(function() {
			that.setLxd(parent.translator.getLanguageXmlDoc(["System", "DeviceInfo"]));
			parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
			parent.translator.translatePage(that.getLxd(), document);
		}, true);

		$.ajax({
			type: "get",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/deviceInfo",
			beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
                xhr.setRequestHeader("Content-Type", "text/xml");
            },
			success: function(xmlDoc, textStatus, xhr) {
				that.m_xmlDoc = xmlDoc;
				var xmlU = new XmlUtils(that.m_xmlDoc);
				if (xmlU.elem("deviceName").hasChildNodes())
				{
					$("#teDeviceName").val(xmlU.val("deviceName"));
				}
				else
				{
					$("#teDeviceName").val("");
				}
				if (xmlU.elems("telecontrolID").length > 0)
				{
					$("#dvDeviceID").show();
					try
					{
						$("#teDeviceID").val(xmlU.val("telecontrolID"));
					}
					catch (oError)
					{
						$("#teDeviceID").val("");
						$("#teDeviceID").prop("disabled", true);
					}
				}
				else
				{
					$("#dvDeviceID").hide();
				}
				try
				{
					$("#tdDeviceTypeValue").html(xmlU.val("model"));
				}
				catch (e)
				{
					$("#tdDeviceTypeValue").html("");
				}
				$("#tdDeviceSnValue").html(xmlU.val("serialNumber"));
				$("#tdFirmwareVersionValue").html(xmlU.val("firmwareVersion") + "  " + xmlU.val("firmwareReleasedDate"));
				$("#tdHardwareVersionValue").html(xmlU.val("hardwareVersion"));
				if (xmlU.elems("logicVersion").length > 0)
				{
					$("#tdLogicVersionValue").html(xmlU.val("logicVersion") + "  " + xmlU.val("logicReleasedDate"));
				}
				
				try
				{
					var oChannelInfo = pr(DeviceInfo).queryChannelInfo();
					that.m_iChannelNum = oChannelInfo.iChannelNum;
					that.m_szVideoFormat = oChannelInfo.szVideoFormat;
					$("#tdChannelNumValue").html(that.m_iChannelNum);
					that.m_iDiskNum = pr(DeviceInfo).queryDiskNum();
					$("#tdDiskNumValue").html(that.m_iDiskNum);
					// 下面这2个方法和2个属性，之后要封装到AlarmIn和AlarmOut对象中，wuyang
					if (that.m_iAlarmInNum === -1)
					{
						that.m_iAlarmInNum = pr(DeviceInfo).queryAlarmInNum();
					}
					$("#tdAlarmInNumValue").html(that.m_iAlarmInNum);
					if (that.m_iAlarmOutNum === -1)
					{
						that.m_iAlarmOutNum = pr(DeviceInfo).queryAlarmOutNum();
					}
					$("#tdAlarmOutNumValue").html(that.m_iAlarmOutNum);
				}
				catch (error)
				{
					alert(error);
				}
				autoResizeIframe();
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				alert(m_szError400);
				return;
			}
		});
	}
	
	/*************************************************
	Function:		submit
	Description:	提交设备基本信息
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	DeviceInfo.prototype.submit = function()
	{
		if (this.m_xmlDoc === null)
		{
			return;
		}
		var xmlDoc = this.m_xmlDoc;
		if (!pr(DeviceInfo).checkDeviceNameValidity($("#teDeviceName").val(), "devicenametips", 1))
		{
			return;
		}
		if ($("#dvDeviceID").css("display")!="none" && !$("#teDeviceID").prop("disabled"))
		{
			if (!pr(DeviceInfo).checkDeviceIDValidity($("#teDeviceID").val(), "Equipmenttips", "laDeviceID", 1, 99999999))
			{
				return;
			}
		}
		$(xmlDoc).find("deviceName").eq(0).text($("#teDeviceName").val());
		
		if ($("#dvDeviceID").css("display")!="none")
		{
			if ($(xmlDoc).find("Extensions").length > 0)
			{
				$(xmlDoc).find("telecontrolID").eq(0).text($("#teDeviceID").val()); 
			}
			else
			{
				var extensions = xmlU.doc.createElement("Extensions");
				var element = xmlU.doc.createElement("telecontrolID");
				var text = xmlU.doc.createTextNode($("#teDeviceID").val());
				element.appendChild(text);
				extensions.appendChild(element);
				xmlDoc.documentElement.appendChild(extensions);
			}
		}
        var xmlObj = parseXmlFromStr(xmlToStr(xmlDoc));
		$.ajax({
			type: "PUT",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/deviceInfo",
			data: xmlObj,
			processData: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
				xhr.setRequestHeader("Content-Type", "text/xml");
			},
			complete: function(xhr, textStatus) {
				SaveState(xhr);
			}
		});
	}
	
	/*************************************************
	  Function:    	checkDeviceNameValidity 类方法
	  Description:	检查设备名称是否合法
	  Input:        szInfo:			传入的参数
					szTipsId:		提示信息ID
					bAllowEmpty:	是否可以为空
	  Output:      	无
	  Return:		bool:true false
	*************************************************/
	DeviceInfo.prototype.checkDeviceNameValidity = function(szInfo, szTipsId, bAllowEmpty)
	{
		var szAreaNameInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
		if (!bAllowEmpty && $.isEmpty(szInfo))
		{ // 为空时提示
			szAreaNameInfo += parent.translator.translateNode(this.getLxd(), "DevNameNullTips");
			$("#" + tipsId).html(szAreaNameInfo);
			return false;
		}
		if (/[':\*\?<>\|\/%\\\"]/.test(szInfo))
		{ // 包含特殊字符时提示
			szAreaNameInfo += parent.translator.translateNode(this.getLxd(), "DevNameWrongCharTips") + " / \\ : * ? ' \" < > | % ";
			$("#" + szTipsId).html(szAreaNameInfo);
			return false;
		}
		if ($.lengthw(szInfo) > 32)
		{
			szAreaNameInfo += parent.translator.translateNode(this.getLxd(), "DevNameLengthTips");
			$("#" + szTipsId).html(szAreaNameInfo);
			return false;
		}
		$("#" + szTipsId).html("");
		return true;
	}
	
	/*************************************************
	  Function:    	checkDeviceIDValidity 类方法
	  Description:	检查设备号是否合法
	  Input:        szInfo:		传入的参数
					szTipsId:	提示信息
					szName:		标题
					iMin:		最小数
					iMax:		最大数
	  Output:      	无
	  Return:		bool:true false
	*************************************************/
	DeviceInfo.prototype.checkDeviceIDValidity = function(szInfo, szTipsId, szName, iMin, iMax)
	{
		var szTipsInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
		if ($.isEmpty(szInfo))
		{
			szTipsInfo += parent.translator.translateNode(this.getLxd(), "InputTips") + parent.translator.translateNode(this.getLxd(), szName);
			$("#" + szTipsId).html(szTipsInfo); 
			return false;
		}
		if (!$.isCosinaIntNum(szInfo, iMin, iMax))
		{
			szTipsInfo += parent.translator.translateNode(this.getLxd(), szName) + parent.translator.translateNode(this.getLxd(), "RangeTips") + iMin + "-" + iMax;
			$("#" + szTipsId).html(szTipsInfo); 
			return false;
		}
		$("#" + szTipsId).html(""); 
		return true;
	}
	
	/*************************************************
	Function:		queryChannelInfo 类方法
	Description:	查询获取通道信息，同步
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	DeviceInfo.prototype.queryChannelInfo = function()
	{
		var ret = {
			iChannelNum: -1,
			szVideoFormat: ""
		};
		var that = this;
		$.ajax({
			type: "get",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/Video/inputs",
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");  
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				var xmlU = new XmlUtils(xmlDoc);
				ret.iChannelNum = xmlU.elems("VideoInputChannel").length;
				m_iAChannelNum = ret.iChannelNum;
			    m_iAllChannelNum = m_iAChannelNum;
				try
				{
					ret.szVideoFormat = xmlU.val("videoFormat");
					m_iVideoOutNP = ret.szVideoFormat;
				}
				catch (oError)
				{
				}
			},
			error: function() {
				throw m_szError400;
			}
		});
		return ret;
	}
		
	/*************************************************
	Function:		getDiskNum 类方法
	Description:	获取设备已接硬盘数，同步
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	DeviceInfo.prototype.queryDiskNum = function()
	{
		var iDiskNum = -1;
		$.ajax({
			type: "get",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ContentMgmt/Storage",
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");  
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				var xmlU = new XmlUtils(xmlDoc);
				iDiskNum = xmlU.elems("hdd").length;
				for (var i = 0; i < xmlU.elems("nas").length; i++)
				{
					if (xmlU.elems("nas")[i].getElementsByTagName('status')[0].childNodes[0].nodeValue != 'offline')
					{
						++iDiskNum;
					}
				}
			},
			error: function() {
				throw m_szError400;
			}
		});
		return iDiskNum;
	}
	
	//////////////////////////////////////////////////
	// 下面这几个方法之后要放到AlarmIn和AlarmOut类中
	
	/*************************************************
	Function:		queryAlarmInNum
	Description:	获取报警输入数，同步
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	DeviceInfo.prototype.queryAlarmInNum = function()
	{
		var iAlarmInNum = -1;
		$.ajax({
			type: "get",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/ITCStatus",
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");  
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				iAlarmInNum = $(xmlDoc).find("relatedTriggerInputs").eq(0).text();
			},
			error: function(xhr, textStatus, errorThrown) {
				throw m_szError400;
			}
		});
		return iAlarmInNum;
	}
	
	/*************************************************
	Function:		queryAlarmOutNum 类方法
	Description:	获取报警输出数，同步
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	DeviceInfo.prototype.queryAlarmOutNum = function()
	{
		var iAlarmOutNum = -1;
		$.ajax({
			type: "get",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/ITCStatus",
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");  
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				iAlarmOutNum =  $(xmlDoc).find("relatedSyncOutputs").eq(0).text();
			},
			error: function(xhr, textStatus, errorThrown) {
				throw m_szError400;
			}
		});
		return iAlarmOutNum;
	}
	
	//////////////////////////////////////////////////

})(); // DeviceInfo implementation

/*************************************************
Function:		TransparentChannel
Description:	构造函数，Singleton派生类 专用接口类
Input:			无			
Output:			无
return:			无				
*************************************************/
function TransparentChannel() {
	this.m_szXmlDoc = null;
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(TransparentChannel);
(function() { // TimeSettings implementation
    TransparentChannel.prototype.update = function() {

		$("#SaveConfigBtn").show();
		$("#SetResultTips").html("");
		$("#dvTransSerial").html("");
		g_transStack.clear();
		var that = this;
		g_transStack.push(function() {
			that.setLxd(parent.translator.getLanguageXmlDoc(["System", "TransparentChannel"]));
			parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
			parent.translator.translatePage(that.getLxd(), document);
		}, true);
		$.ajax({
			type: "get",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/TransparentData",
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");  
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				that.m_szXmlDoc = xmlDoc;
				for(var i = 1; i <= $(xmlDoc).find("intTransDataNum").eq(0).text(); i++) {
					$("<div class='subparamswhite'><span class='firstspan' id='IntTransSerialSpan" + i + "'></span><span><input id='IntTransData" + i + "' type='text' class='inputwidth' maxlength='5'/></span><span><label id='laIntTransDataTips" + i + "' class='tips'/></span></div>").appendTo("#dvTransSerial");
					$("#IntTransSerialSpan" + i).html($(xmlDoc).find("intTransDataName").eq(i-1).text());
					$("#IntTransData" + i).val($(xmlDoc).find("intTransDataVal").eq(i-1).text());
				}
				
				for(var i = 1; i <= $(xmlDoc).find("stringTransDataNum").eq(0).text(); i++) {
					$("<div class='subparamswhite'><span class='firstspan' id='StrTransSerialSpan" + i + "'></span><span><input id='StrTransData" + i + "' type='text' class='inputwidth' maxlength='44'/></span><span><label id='laStrTransDataTips" + i + "' class='tips'/></span></div>").appendTo("#dvTransSerial");
					$("#StrTransSerialSpan" + i).html($(xmlDoc).find("stringTransDataName").eq(i-1).text());
					$("#StrTransData" + i).val($(xmlDoc).find("stringTransDataVal").eq(i-1).text());
				}
				$("#dvTransSerial").find(":input").each(function(i) {
					if(i < $(xmlDoc).find("intTransDataNum").eq(0).text()) {
						$(this).blur(function () {CheackTransparentIntNum(this.value,'laIntTransDataTips' + (i+1),$('#IntTransSerialSpan' + (i+1)).html(),0,65535);});
					} else {
						var iStrIndex= i+1-$(xmlDoc).find("intTransDataNum").eq(0).text();
						$(this).blur(function () {CheackTransparentStringLenth(this.value,'laStrTransDataTips' + iStrIndex,$('#StrTransSerialSpan' + iStrIndex).html(),44);});
					}
			    });
			}
		});
		autoResizeIframe();
	}
	TransparentChannel.prototype.submit = function() {
		for(var i = 1; i <= $(this.m_szXmlDoc).find("intTransDataNum").eq(0).text(); i++) {
			$(this.m_szXmlDoc).find("intTransDataVal").eq(i-1).text($("#IntTransData" + i).val());
		}
		for(var i = 1; i <= $(this.m_szXmlDoc).find("stringTransDataNum").eq(0).text(); i++) {
			$(this.m_szXmlDoc).find("stringTransDataVal").eq(i-1).text($("#StrTransData" + i).val());
		}
		var that = this;
        var xmlObj = parseXmlFromStr(xmlToStr(that.m_szXmlDoc));
		$.ajax({
			type: "put",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/TransparentData",
			async: false,
			data: xmlObj,
			processData: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			complete: function(xhr, textStatus) {
				SaveState(xhr);
			}
		});
	}
})();

/*************************************************
TCP/IP   类
 *************************************************/
function IpConfig() {
    this.m_AlarmInfoXML = null;
    SingletonInheritor.implement(this);
}
SingletonInheritor.declare(IpConfig);
pr(IpConfig).update = function() {
    $('#SetResultTips').html('');
    $("#SaveConfigBtn").show();
    g_transStack.clear();
    var that = this;
    g_transStack.push(function() {
        that.setLxd(parent.translator.getLanguageXmlDoc(["System", "IpConfig"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);
    initIpConfig();
}

/*************************************************
 Function:		initIpconfig
 Description:	初始化IpConfig页面
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function initIpConfig()
{
    if(g_bSupportWIFI)
    {
        $("#dvSelectNetCard").show()
    }
    else
    {
        $("#dvSelectNetCard").hide()
    }
    $("#divIpConfig").children("div").first().children("div:visible[class!='mainparams']").each(function(i)
    {
        if($(this).hasClass("subparamswhite") || $(this).hasClass("subparamsgray"))
        {
            return false;
        }

         $(this).attr("class", "subparamswhite");
    });
    $("#Multicast").unbind("blur").blur(function(){
        if(this.value != "")
        {
            CheckMulticastIP(this.value,'Multicasttips','laMulticast');
        }
    });
    GetNetBasicInfo();
    GetAlarmManangeInfo();
    //获取多播
    getMulticast();
    autoResizeIframe();
}


function GetAlarmManangeInfo(){

    $.ajax({
        type: "GET",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/Event/notification/httpHost/1",
        async: false,
        timeout: syncTime,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {
            ia(IpConfig).m_AlarmInfoXML = xmlDoc;
            $('#alarmHostAddress_singleNet').val($(xmlDoc).find('ipAddress').eq(0).text());
            $('#alarmHostPort_singleNet').val($(xmlDoc).find('portNo').eq(0).text());
        }
    });
}

/*************************************************
 Function:		GetNetBasicInfo
 Description:	获取网络基本信息
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function GetNetBasicInfo(szIndex)
{
	if(szIndex === undefined)
    {
        szIndex = "1";
    }
    $("#NetworkNo").val(szIndex);
    $.ajax(
        {
            type: "GET",
            url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces/"+szIndex,
            async: false,
            timeout: 15000,
            beforeSend: function(xhr)
            {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            success: function(xmlDoc, textStatus, xhr)
            {
                //获取网卡类型
                if($(xmlDoc).find('autoNegotiation').length > 0)
                {
                    $("#dvNetworkType").show();
                    if($(xmlDoc).find('autoNegotiation').eq(0).text() == 'true')
                    {
                        $("#NetworkType").val('5');
                    }
                    else if($(xmlDoc).find('speed').eq(0).text() == '10')
                    {
                        if($(xmlDoc).find('duplex').eq(0).text() == 'half')
                        {
                            $("#NetworkType").val('1');
                        }
                        else if($(xmlDoc).find('duplex').eq(0).text() == 'full')
                        {
                            $("#NetworkType").val('2');
                        }
                    }
                    else if($(xmlDoc).find('speed').eq(0).text() == '100')
                    {
                        if($(xmlDoc).find('duplex').eq(0).text() == 'half')
                        {
                            $("#NetworkType").val('3');
                        }
                        else if($(xmlDoc).find('duplex').eq(0).text() == 'full')
                        {
                            $("#NetworkType").val('4');
                        }
                    }
                    else if($(xmlDoc).find('speed').eq(0).text() == '1000')
                    {
                        $("#NetworkType").val('6');
                    }
                    else
                    {
                        document.getElementById('NetworkType').selectedIndex = -1;
                    }
                }
                else
                {
                    $("#dvNetworkType").hide();
                }
                //获取是否自动获取ip
                if($(xmlDoc).find('addressingType').eq(0).text() == 'dynamic')
                {
                    $("#IsUseDHCP").prop('checked',true);
                }
                else
                {
                    $("#IsUseDHCP").prop('checked',false);
                }
                $("#IsUseDHCP").prop('disabled',true);
                //获取ip4地址
                $("#ipAddress").val($(xmlDoc).find('IPAddress').eq(0).find('ipAddress').eq(0).text());

                //获取ip4子网掩码
                $("#subnetMask").val($(xmlDoc).find('IPAddress').eq(0).find('subnetMask').eq(0).text());
                //获取ip4网关
                $("#DefaultGateway").val($(xmlDoc).find('DefaultGateway').eq(0).find('ipAddress').eq(0).text());

                if($("#DefaultGateway").val() == '0.0.0.0')
                {
                    $("#DefaultGateway").val("");
                }
                //获取Mac地址
                if($(xmlDoc).find('MACAddress').length > 0)
                {
                    $("#dvMacAddress").show();
                    $("#MacAddress").val($(xmlDoc).find('MACAddress').eq(0).text());
                }
                else
                {
                    $("#dvMacAddress").hide();
                }

                //获取首选DNS服务器
                $("#PrimaryDNS").val($(xmlDoc).find('PrimaryDNS').eq(0).find('ipAddress').eq(0).text());

                //获取备用DNS服务器
                if($(xmlDoc).find('SecondaryDNS').length > 0)
                {
                    $("#dvDNSServer2").show();
                    $("#DNSServer2IP").val($(xmlDoc).find('SecondaryDNS').eq(0).find('ipAddress').eq(0).text());
                }
                else
                {
                    $("#dvDNSServer2").hide();
                }

                if($("#PrimaryDNS").val() == '0.0.0.0')
                {
                    $("#PrimaryDNS").val("");
                }
                if($("#DNSServer2IP").val() == '0.0.0.0')
                {
                    $("#DNSServer2IP").val("");
                }
                //获取MTU值
                if($(xmlDoc).find('MTU').length > 0)
                {
                    $("#MTU").val($(xmlDoc).find('MTU').eq(0).text());
                    $("#9000MTU").show();
                }
                else
                {
                    $("#9000MTU").hide();
                }
                //响应西东获取勾选框
                CheckIsDhcp();

                GetPPPOEEnable();
            },
            error: function(xhr, textStatus, errorThrown)
            {
                alert(m_szError400);
            }
        });
}

/*************************************************
 Function:		getMulticast
 Description:	获取多播地址
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function getMulticast()
{
    g_szMulticastXml = "";
    $.ajax(
        {
            type: "GET",
            url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Streaming/channels/101",
            async: true,
            timeout: 15000,
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            success: function(xmlDoc, textStatus, xhr)
            {
                g_szMulticastXml = xhr.responseText;
                //多播地址
                if($(xmlDoc).find('Transport').eq(0).find('Multicast').length > 0)
                {
                    $("#dvMulticast").show();
                    var iIndex = $("#divIpConfig").children("div").first().children("div:visible[class!='mainparams']").index($("#dvMulticast"));
                    if(iIndex%2 == 0)
                    {
                        $("#dvMulticast").attr("class", "subparamswhite");
                    }
                    else
                    {
                        $("#dvMulticast").attr("class", "subparamswhite");
                    }
                    if(m_strIpVersion == 'v4')
                    {
                        var szMulticast = $(xmlDoc).find('Transport').eq(0).find('Multicast').eq(0).find('destIPAddress').eq(0).text();
                        if(szMulticast == "0.0.0.0")
                        {
                            $("#Multicast").val('');
                        }
                        else
                        {
                            $("#Multicast").val(szMulticast);
                        }
                    }
                    else
                    {
                        var szMulticast = $(xmlDoc).find('Transport').eq(0).find('Multicast').eq(0).find('destIPv6Address').eq(0).text();
                        if(szMulticast == "::")
                        {
                            $("#Multicast").val('');
                        }
                        else
                        {
                            $("#Multicast").val(szMulticast);
                        }
                    }
                }
                else
                {
                    $("#dvMulticast").hide();
                }
            },
            error: function(xhr, textStatus, errorThrown)
            {
                $("#dvMulticast").hide();
            }
        });
}

/*************************************************
 Function:		CheckIsDhcp
 Description:	检查是否启用DHCP
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function CheckIsDhcp()
{
    if($("#IsUseDHCP").prop("checked"))
    {
        $('#ipAddress').prop('disabled', true);
        $('#subnetMask').prop('disabled', true);
        $('#DefaultGateway').prop('disabled', true);
    }
    else
    {
        $('#ipAddress').prop('disabled', false);
        $('#subnetMask').prop('disabled', false);
        $('#DefaultGateway').prop('disabled', false);
    }
}

/*************************************************
 Function:    	CheckMulticastIP
 Description:	检查是否多播地址
 Input:        strInfo:传入的参数
 tipsId:提示信息
 szName:标题
 Output:      	无
 Return:		bool:true false
 *************************************************/
function CheckMulticastIP(strInfo,tipsId,szName)
{
    var szTipsInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
    setTimeout(function(){$("#" + tipsId).html("");},5000);  //5秒后自动清除
    if(strInfo == "")
    {
        szTipsInfo += getNodeValue("InputTips") + getNodeValue(szName);
        $("#" + tipsId).html(szTipsInfo);
        return false;
    }
    if($.isIpAddress(strInfo) == false)
    {
        szTipsInfo += getNodeValue("WrongTips") + getNodeValue(szName);
        $("#" + tipsId).html(szTipsInfo);
        return false;
    }
    if($.isMulticastIP(strInfo) == false)
    {
        szTipsInfo += getNodeValue("jsMulticastRange");
        $("#" + tipsId).html(szTipsInfo);
        return false;
    }
    $("#" + tipsId).html("");
    return true;
}

/*************************************************
 Function:		GetPPPOEEnable
 Description:	获取是否启用ppoe
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function GetPPPOEEnable()
{
    $.ajax(
        {
            type: "GET",
            url:  m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/PPPoE",
            timeout: 15000,
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            success: function(xmlDoc, textStatus, xhr)
            {
                if("true" == $(xmlDoc).find('enabled').eq(0).text())
                {
                    $('#PrimaryDNS').prop('disabled', true);
                    $('#DNSServer2IP').prop('disabled', true);
                }
                else
                {
                    $('#PrimaryDNS').prop('disabled', false);
                    $('#DNSServer2IP').prop('disabled', false);
                }
            }
        });
}

/*************************************************
 Function:		SetNetBasicInfo
 Description:	设置网络基本信息
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function SetNetBasicInfo()
{
    var szTipsInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
    if($('#alarmHostAddress_singleNet').val()!=''){
        if(!CheckIPAddress($('#alarmHostAddress_singleNet').val(),'alarmHostAddressTips_singleNet','laAlarmHostAddress')){
            return;
        }
    }
    if($('#alarmHostPort_singleNet').val()!=''){
        if(!CheackServerIDIntNum($('#alarmHostPort_singleNet').val(),'HostPortTips_singleNet','laAlarmHostPort',1,65535)){
            return;
        }
    }
    if($("#PrimaryDNS").val() != "")
    {
        if(!CheckDIPadd($("#PrimaryDNS").val(),'DNSServerIPtips','jsFirstDNS'))
        {
            return;
        }
    }
    if($("#DNSServer2IP").val() != "")
    {
        if(!CheckDIPadd($("#DNSServer2IP").val(),'DNSServer2IPtips','jsSecondDNS'))
        {
            return;
        }
    }
    if($("#9000MTU").css("display") != "none")
    {
        if(!CheackServerIDIntNum($("#MTU").val(),'MTUtips','jsMtuParam',500,9676))
        {
            return;
        }
    }
    if(!$("#IsUseDHCP").prop("checked"))
    {
        if($("#ipAddress").val() == '0.0.0.0')
        {
            $("#ServerIPtips").html(szTipsInfo + getNodeValue('DIPAddInvalidTips'));
            return;
        }
        if($("#subnetMask").val() == '0.0.0.0')
        {
            $("#ServerMaskIPtips").html(szTipsInfo + getNodeValue('MaskAddInvalidTips'));
            return;
        }

        if(!CheckDIPadd($("#ipAddress").val(),'ServerIPtips','laIpAddress'))
        {
            return;
        }

        if(!CheckMaskIP($("#subnetMask").val(),'ServerMaskIPtips','jsMaskAdd'))
        {
            return;
        }

        if($("#DefaultGateway").val() != '')
        {
            if(!CheckDIPadd($("#DefaultGateway").val(),'ServerGateWayIPtips','jsGateAdd'))
            {
                return;
            }
        }
    }
    if($("#dvMulticast").css("display") != "none")
    {
        var szMulticast = $("#Multicast").val();
        if(szMulticast != "")
        {
            if(!CheckMulticastIP(szMulticast,'Multicasttips','laMulticast'))
            {
                return;
            }
        }
    }

    var xmlDoc = new createxmlDoc();
    var Instruction = xmlDoc.createProcessingInstruction("xml","version='1.0' encoding='utf-8'");
    xmlDoc.appendChild(Instruction);

    Root = xmlDoc.createElement('NetworkInterface');

    Element = xmlDoc.createElement("id");
    text = xmlDoc.createTextNode("1");
    Element.appendChild(text);
    Root.appendChild(Element);

    IPAddress = xmlDoc.createElement('IPAddress');
    ipVersion = xmlDoc.createElement("ipVersion");
    text = xmlDoc.createTextNode('v4');
    ipVersion.appendChild(text);
    IPAddress.appendChild(ipVersion);

    addressingType = xmlDoc.createElement("addressingType");
    if($("#IsUseDHCP").prop("checked"))
    {
        text = xmlDoc.createTextNode('dynamic');
    }
    else
    {
        text = xmlDoc.createTextNode('static');
    }
    addressingType.appendChild(text);
    IPAddress.appendChild(addressingType);

    Element = xmlDoc.createElement("ipAddress");
    text = xmlDoc.createTextNode($("#ipAddress").val());
    Element.appendChild(text);
    IPAddress.appendChild(Element);

    Element = xmlDoc.createElement("subnetMask");
    text = xmlDoc.createTextNode($("#subnetMask").val());
    Element.appendChild(text);
    IPAddress.appendChild(Element);

    Gateway = xmlDoc.createElement('DefaultGateway');

    Element = xmlDoc.createElement("ipAddress");
    if($("#DefaultGateway").val() == '')
    {
        text = xmlDoc.createTextNode('0.0.0.0');
    }
    else
    {
        text = xmlDoc.createTextNode($("#DefaultGateway").val());
    }
    Element.appendChild(text);
    Gateway.appendChild(Element);
    IPAddress.appendChild(Gateway);

    FirstDNS = xmlDoc.createElement('PrimaryDNS');
    Element = xmlDoc.createElement("ipAddress");
    if($("#PrimaryDNS").val() == '')
    {
        text = xmlDoc.createTextNode('0.0.0.0');
    }
    else
    {
        text = xmlDoc.createTextNode($("#PrimaryDNS").val());
    }
    Element.appendChild(text);
    FirstDNS.appendChild(Element);
    IPAddress.appendChild(FirstDNS);

    SecondaryDNS = xmlDoc.createElement('SecondaryDNS');
    Element = xmlDoc.createElement("ipAddress");
    if($("#DNSServer2IP").val() == '')
    {
        text = xmlDoc.createTextNode('0.0.0.0');
    }
    else
    {
        text = xmlDoc.createTextNode($("#DNSServer2IP").val());
    }
    Element.appendChild(text);
    SecondaryDNS.appendChild(Element);
    IPAddress.appendChild(SecondaryDNS);

    Root.appendChild(IPAddress);

    Extensions = xmlDoc.createElement("Extensions");

    Link = xmlDoc.createElement("Link");
    MACAddress = xmlDoc.createElement("MACAddress");
    text = xmlDoc.createTextNode($("#MacAddress").val());
    MACAddress.appendChild(text);
    Link.appendChild(MACAddress);

    autoNegotiation = xmlDoc.createElement("autoNegotiation");
    text = xmlDoc.createTextNode('false');
    autoNegotiation.appendChild(text);
    Link.appendChild(autoNegotiation);

    speed = xmlDoc.createElement("speed");
    text = xmlDoc.createTextNode('');
    speed.appendChild(text);
    Link.appendChild(speed);

    duplex = xmlDoc.createElement("duplex");
    text = xmlDoc.createTextNode('');
    duplex.appendChild(text);
    Link.appendChild(duplex);

    Element = xmlDoc.createElement("MTU");
    text = xmlDoc.createTextNode($("#MTU").val());
    Element.appendChild(text);
    Link.appendChild(Element);

    Extensions.appendChild(Link);
    Root.appendChild(Extensions);
    xmlDoc.appendChild(Root);

    if($("#NetworkType").val() == '1')
    {
        xmlDoc.getElementsByTagName('speed')[0].childNodes[0].nodeValue = '10';
        xmlDoc.getElementsByTagName('duplex')[0].childNodes[0].nodeValue = 'half';
    }
    else if($("#NetworkType").val() == '2')
    {
        xmlDoc.getElementsByTagName('speed')[0].childNodes[0].nodeValue = '10';
        xmlDoc.getElementsByTagName('duplex')[0].childNodes[0].nodeValue = 'full';
    }
    else if($("#NetworkType").val() == '3')
    {
        xmlDoc.getElementsByTagName('speed')[0].childNodes[0].nodeValue = '100';
        xmlDoc.getElementsByTagName('duplex')[0].childNodes[0].nodeValue = 'half';
    }
    else if($("#NetworkType").val() == '4')
    {
        xmlDoc.getElementsByTagName('speed')[0].childNodes[0].nodeValue = '100';
        xmlDoc.getElementsByTagName('duplex')[0].childNodes[0].nodeValue = 'full';
    }
    else if($("#NetworkType").val() == '6')
    {
        xmlDoc.getElementsByTagName('speed')[0].childNodes[0].nodeValue = '1000';
        xmlDoc.getElementsByTagName('duplex')[0].childNodes[0].nodeValue = 'full';
    }
    else
    {
        xmlDoc.getElementsByTagName('speed')[0].childNodes[0].nodeValue = '0';
        xmlDoc.getElementsByTagName('duplex')[0].childNodes[0].nodeValue = 'full';
        if($("#NetworkType").val() == '5')
        {
            xmlDoc.getElementsByTagName('autoNegotiation')[0].childNodes[0].nodeValue = 'true';
        }
    }
    g_bIsRestart = true;
    var szURL = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces/"+$("#NetworkNo").val();
	//var szURL = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces";
    $.ajax(
        {
            type: "PUT",
            url: szURL,
            processData: false,
            data: xmlDoc,
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            complete:function(xhr, textStatus)
            {
                var xmlDoc = xhr.responseXML;
                if(xhr.status == 200)
                {
                    setMulticast();
                }
                var state = $(xmlDoc).find('statusCode').eq(0).text();
                if("7" == state)	//Reboot Required
                {
                    g_bIsRestart = false;
                    SaveState(xhr);
                }
                else
                {
                    SaveState(xhr);
                }
                setAlarmManageInfo();
            }
        });
}

function setAlarmManageInfo(){

    $(ia(IpConfig).m_AlarmInfoXML).find('ipAddress').eq(0).text($('#alarmHostAddress_singleNet').val());
    $(ia(IpConfig).m_AlarmInfoXML).find('portNo').eq(0).text($('#alarmHostPort_singleNet').val());

    var xmlObj = parseXmlFromStr(xmlToStr(ia(IpConfig).m_AlarmInfoXML));
    $.ajax({
        type: "put",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/Event/notification/httpHost/1",
        timeout: syncTime,
        processData: false,
        data: xmlObj,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        complete:function(xhr, textStatus) {
            SaveState(xhr);
        }
    });

}
/*************************************************
 Function:		setMulticast
 Description:	设置多播地址
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function setMulticast()
{
    if($("#dvMulticast").css("display") == "none")
    {
        return;
    }
    var xmlDoc = parseXmlFromStr(g_szMulticastXml);
    var szMulticast = $("#Multicast").val();
    if(m_strIpVersion == 'v4')
    {
        $(xmlDoc).find("Transport").eq(0).children("Multicast").eq(0).find("destIPAddress").eq(0).text(szMulticast==""?"0.0.0.0":szMulticast)
    }
    else
    {
        $(xmlDoc).find("Transport").eq(0).children("Multicast").eq(0).find("destIPv6Address").eq(0).text(szMulticast==""?"::":szMulticast)
    }
    var oMulticast = parseXmlFromStr('<?xml version="1.0" encoding="UTF-8"?><StreamingChannel><Transport></Transport></StreamingChannel>');
    var oTransport = $(oMulticast).find("Transport").eq(0);
    oTransport.append($(xmlDoc).find("Transport").eq(0).clone().children("ControlProtocolList"));
    oTransport.append($(xmlDoc).find("Transport").eq(0).clone().children("Multicast"));

    $.ajax(
        {
            type: "PUT",
            url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Streaming/channels/101",
            processData: false,
            data: oMulticast,
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            complete:function(xhr, textStatus)
            {
                var xmlDoc =xhr.responseXML;
                var state = $(xmlDoc).find('statusCode').eq(0).text();
                if("7" == state)	//Reboot Required
                {
                    if(g_bIsRestart)
                    {
                        g_bIsRestart = false;
                        SaveState(xhr);
                    }
                }
                else
                {
                    SaveState(xhr);
                }
            }
        });
}
/*******************  IP config end **********************************/


/*************************************************
Function:		TimeSettings
Description:	构造函数，Singleton派生类
Input:			无			
Output:			无
return:			无				
*************************************************/
function TimeSettings() {
	SingletonInheritor.implement(this);
	this.m_dtDeviceTime = null; // 获得的设备时间的Date对象，原systemTimeInit为String类型
	this.m_timerPerSecond = null; // 秒钟定时器
	this.m_timerSyncDeviceTime = null; // 设备时间同步时钟
	this.m_szDeviceTimeZone = null; // 获得的设备时区，原timeZoneInit
}
SingletonInheritor.declare(TimeSettings);

(function() { // TimeSettings implementation

	/*************************************************
	Function:		initCSS 类方法
	Description:	初始化CSS
	Input:			无
	Output:			无
	return:			无
	*************************************************/
	TimeSettings.prototype.initCSS = function() {
		$("#diTimeConfig :text").addClass("timetext");
		$("#diTimeConfig :button").addClass("button");
		$("#diTimeConfig :checkbox").addClass("checkbox");
	};

    TimeSettings.changeNtpTimeDiv = function(){
        if($('#ntpTimeCheck').prop("checked")){
            $('#ntpTimeDiv').css("display","block");
            $('#teSelectTime').prop("disabled",true);
            $('#chTimeSyncWithPC').prop("disabled",true);
        }else{
            $('#ntpTimeDiv').css("display","none");
            $('#teSelectTime').prop("disabled",false);
            $('#chTimeSyncWithPC').prop("disabled",false);
        }
    }

	/*************************************************
	Function:		setRadioItem 类方法
	Description:	设置单选框的选中项
	Input:			parentId: 单选框父id
					index: 选中项的序号，从0开始
	Output:			无
	return:			无
	*************************************************/
	TimeSettings.prototype.setRadioItem = function(parentId, index) {
		ia(TimeSettings).setTimeSyncMode(index);
		pr(SingletonInheritor.base).setRadioItem.apply(this, arguments);
	}
	
	/*************************************************
	Function:		dateFormat 类方法
	Description:	格式化Date对象
					月(M)、日(d)、12小时(h)、24小时(H)、分(m)、秒(s)、周(E)、季度(q) 可以用 1-2 个占位符
					年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)   
					eg:
					pr(TimeSettings).DateFormat((new Date()), "yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
					pr(TimeSettings).DateFormat((new Date()), "yyyy-MM-dd E HH:mm:ss") ==> 2009-03-10 二 20:09:04
					pr(TimeSettings).DateFormat((new Date()), "yyyy-MM-dd EE hh:mm:ss") ==> 2009-03-10 周二 08:09:04
					pr(TimeSettings).DateFormat((new Date()), "yyyy-MM-dd EEE hh:mm:ss") ==> 2009-03-10 星期二 08:09:04
					pr(TimeSettings).DateFormat((new Date()), "yyyy-M-d h:m:s.S") ==> 2006-7-2 8:9:4.18
	Input:			date: Date对象
					format: 格式
	Output:			无
	return:			无
	*************************************************/
	TimeSettings.prototype.dateFormat = function(date, format) {
		var o = {
		"M+" : date.getMonth()+1, //月份
		"d+" : date.getDate(), //日
		"h+" : date.getHours()%12 == 0 ? 12 : date.getHours()%12, //小时
		"H+" : date.getHours(), //小时
		"m+" : date.getMinutes(), //分
		"s+" : date.getSeconds(), //秒
		"q+" : Math.floor((date.getMonth()+3)/3), //季度
		"S" : date.getMilliseconds() //毫秒
		};
		var week = {
		"0" : "\u65e5",
		"1" : "\u4e00",
		"2" : "\u4e8c",
		"3" : "\u4e09",
		"4" : "\u56db",
		"5" : "\u4e94",
		"6" : "\u516d"
		};
		if (/(y+)/.test(format)) {
			format = format.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
		}
		if (/(E+)/.test(format)) {
			format = format.replace(RegExp.$1, ((RegExp.$1.length>1) ? (RegExp.$1.length>2 ? "\u661f\u671f" : "\u5468") : "") + week[date.getDay() + ""]);
		}
		for (var k in o){
			if (new RegExp("("+ k +")").test(format)){
				format = format.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
			}
		}
		return format;
	}

	/*************************************************
	Function:		clickTimeSyncWithPC 类方法
	Description:	点击chTimeSyncWithPC复选框
	Input:			无
	Output:			this.m_dtDeviceTime的字符串表示
	return:			无
	*************************************************/	
	TimeSettings.prototype.clickTimeSyncWithPC = function()
	{
		if ($("#chTimeSyncWithPC").prop("checked"))
		{ // 与本地时间同步
			var dtNow = new Date();
			$("#teSelectTime").val(this.dateFormat(dtNow, "yyyy-MM-ddTHH:mm:ss")); // 电脑时间
			$("#teSelectTime").prop("disabled", true);
			var iTZOffset = dtNow.getTimezoneOffset();
			var iHour = Math.abs(parseInt(iTZOffset / 60));
			var iSecond = iTZOffset % 60;
			var szPCTZ = "CST" + ((iTZOffset >= 0) ? "+" : "-") + iHour + ((iSecond >= 30) ? ":30:00" : ":00:00");
		}
		else
		{
			$("#teSelectTime").prop("disabled", false);
		}
	}
	
	/*************************************************
	Function:		update
	Description:	更新
	Input:			无	
	Output:			无
	return:			无				
	*************************************************/
	TimeSettings.prototype.update = function()
	{
		$("#SaveConfigBtn").show();
		$("#SetResultTips").html("");
		
		g_transStack.clear();
		var that = this;
		g_transStack.push(function() {
			that.setLxd(parent.translator.getLanguageXmlDoc(["System", "TimeSettings"]));
			parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
			parent.translator.translatePage(that.getLxd(), document);
		}, true);
		
		$("#chTimeSyncWithPC").prop("checked", false); // 从其它tab页切换回来的情况
		// 设置秒钟定时器
		function updatePCTime() {
			if ($("#chTimeSyncWithPC").prop("checked"))
			{
				$("#teSelectTime").val(that.dateFormat(new Date(), "yyyy-MM-ddTHH:mm:ss"));
			}
			if (that.m_dtDeviceTime !== null)
			{
				that.m_dtDeviceTime = new Date(that.m_dtDeviceTime.getTime() + 1000);
				$("#teDeviceTime").val(that.dateFormat(that.m_dtDeviceTime, "yyyy-MM-ddTHH:mm:ss"));
			}
		}
		updatePCTime();
		if (this.m_timerPerSecond !== null)
		{
			clearInterval(this.m_timerPerSecond);
		}
		this.m_timerPerSecond = setInterval(updatePCTime, 1000);
		// 设置设备时间同步定时器
		if (this.m_timerSyncDeviceTime !== null)
		{
			clearInterval(this.m_timerSyncDeviceTime);
		}
		this.m_timerSyncDeviceTime = setInterval(this.syncDeviceTime, 300000); // 五分钟同步一次
		$.ajax({
			type: "get",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/time",
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				var xmlU = new XmlUtils(xmlDoc);
				var timeMode = xmlU.val("timeMode");
				
				var szDeviceTime = xmlU.val("localTime").substring(0, 19);
				var arDTms = szDeviceTime.match(/(\d+)-(\d+)-(\d+)(\D+)(\d+):(\d+):(\d+)/);
				if (arDTms.length !== 8)
				{
					return;
				}
				that.m_dtDeviceTime = new Date(arDTms[1], arDTms[2] - 1, arDTms[3], arDTms[5], arDTms[6], arDTms[7]);
				
				that.m_szDeviceTimeZone = xmlU.val("timeZone");
				if (timeMode == "NTP")
				{
					that.setTimeSyncMode(0);
					that.updateNtpInfo();
                    $('#ntpTimeCheck').prop("checked", true);
                    TimeSettings.changeNtpTimeDiv();
				}
				else
				{
					that.setTimeSyncMode(1);
					$("#teDeviceTime").val((that.dateFormat(that.m_dtDeviceTime, "yyyy-MM-ddTHH:mm:ss")));
				}

				/*$("#diDST").show();
				var iDSTPos = that.m_szDeviceTimeZone.indexOf("DST");
				if (iDSTPos != -1)
				{
					$("#IsEnableDST").prop("checked", true);
					$("#diDST select").prop("disabled", !$("#IsEnableDST").prop("checked"));
					$("#seTimeZone").val(that.m_szDeviceTimeZone.substring(0, iDSTPos));
					
					var startTime = that.m_szDeviceTimeZone.split(",")[1];
					var stopTime = that.m_szDeviceTimeZone.split(",")[2];
					$("#StartMonth").val(startTime.split(".")[0]);
					$("#StartWeek").val(startTime.split(".")[1]);
					$("#StartWeekDay").val(startTime.split(".")[2].split("/")[0]);
					$("#StartTime").val(startTime.split(".")[2].split("/")[1].split(":")[0]);
					$("#StopMonth").val(stopTime.split(".")[0]);
					$("#StopWeek").val(stopTime.split(".")[1]);
					$("#StopWeekDay").val(stopTime.split(".")[2].split("/")[0]);
					$("#StopTime").val(stopTime.split(".")[2].split("/")[1].split(":")[0]);
					
					$("#DSTBias").val(that.m_szDeviceTimeZone.substring(iDSTPos+3,iDSTPos+11));
				}
				else
				{
					$("#seTimeZone").val(that.m_szDeviceTimeZone);
					$("#IsEnableDST").prop("checked", false);
					$("#diDST select").prop("disabled", !$("#IsEnableDST").prop("checked"));
				}*/
				autoResizeIframe();
			},
			error: function(xhr, textStatus, errorThrown) {
				alert(m_szError400);
			}
		});
	}
	/*************************************************
	Function:		updateDST
	Description:	更新夏令时
	Input:			无	
	Output:			无
	return:			无				
	*************************************************/
	/*TimeSettings.prototype.updateDST = function()
	{
		if($.browser.msie && parseInt($.browser.version, 10) == 6)
		{
            $(".timehidden").show();
			$(".232hidden").hide();
			$(".485hidden").hide();
			$("#dvTelecontrol").find("select").hide();
		}		
		$("#SaveConfigBtn").show();
		$("#SetResultTips").html("");
		
		g_transStack.clear();
		var that = this;
		g_transStack.push(function() {
			that.setLxd(parent.translator.getLanguageXmlDoc(["System", "TimeSettings"]));
			parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
			parent.translator.translatePage(that.getLxd(), document);
		}, true);
		
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/time",
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				var xmlU = new XmlUtils(xmlDoc);
				
				that.m_szDeviceTimeZone = $(xmlDoc).find("timeZone").eq(0).text();
				$("#diDST").show();
				var iDSTPos = that.m_szDeviceTimeZone.indexOf("DST");
				if (iDSTPos != -1)
				{
					$("#IsEnableDST").prop("checked", true);
					$("#seTimeZone").val(that.m_szDeviceTimeZone.substring(0, iDSTPos));
					
					var startTime = that.m_szDeviceTimeZone.split(",")[1];
					var stopTime = that.m_szDeviceTimeZone.split(",")[2];
					$("#StartMonth").val(startTime.split(".")[0]);
					$("#StartWeek").val(startTime.split(".")[1]);
					$("#StartWeekDay").val(startTime.split(".")[2].split("/")[0]);
					$("#StartTime").val(startTime.split(".")[2].split("/")[1].split(":")[0]);
					$("#StopMonth").val(stopTime.split(".")[0]);
					$("#StopWeek").val(stopTime.split(".")[1]);
					$("#StopWeekDay").val(stopTime.split(".")[2].split("/")[0]);
					$("#StopTime").val(stopTime.split(".")[2].split("/")[1].split(":")[0]);
					
					$("#DSTBias").val(that.m_szDeviceTimeZone.substring(iDSTPos+3,iDSTPos+11));
				}
				else
				{
					$("#seTimeZone").val(that.m_szDeviceTimeZone);
					$("#IsEnableDST").prop("checked", false);
				}
				$("#dvDST select").prop("disabled", !$("#IsEnableDST").prop("checked"));
				autoResizeIframe();
			},
			error: function(xhr, textStatus, errorThrown) {
				alert(m_szError400);
			}
		});
	}*/
	/*************************************************
	Function:		syncDeviceTime
	Description:	同步设备时间到m_dtDeviceTime，异步
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TimeSettings.prototype.syncDeviceTime = function() {
		var that = this;
		$.ajax({
			type: "get",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/time",
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");  
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				var xmlU = new XmlUtils(xmlDoc);
				var timeMode = xmlU.val("timeMode");
				var szDeviceTime = xmlU.val("localTime").substring(0, 19);
				var arDTms = szDeviceTime.match(/(\d+)-(\d+)-(\d+)(\D+)(\d+):(\d+):(\d+)/);
				if (arDTms.length !== 8)
				{
					return;
				}
				that.m_dtDeviceTime = new Date(arDTms[1], arDTms[2] - 1, arDTms[3], arDTms[5], arDTms[6], arDTms[7]);
			}
		});
	}
	
	/*************************************************
	Function:		updateNtpInfo 类方法
	Description:	更新NTP服务器配置信息，异步
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TimeSettings.prototype.updateNtpInfo = function()
	{
		$.ajax({
			type: "get",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/time/ntpServers/1",
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");  
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				var xmlU = new XmlUtils(xmlDoc);
				if (xmlU.doc.documentElement.hasChildNodes())
				{
				   if ("hostname" == xmlU.val("addressingFormatType"))
				   {
						$("#teNtpServer").val(xmlU.val("hostName")); 
				   }
				   else
				   {
						try
						{
							$("#teNtpServer").val(xmlU.val("ipAddress"));
						}
						catch (oError)
						{
							$("#teNtpServer").val(xmlU.val("ipv6Address"));
						}
				   }
				   $("#teNtpPort").val(xmlU.val("portNo"));
				   if (xmlU.elem("Extensions").hasChildNodes())
				   {
					   $("#teNtpInterval").val(xmlU.val("synchronizeInterval"));
				   }
				   else
				   {
						$("#teNtpInterval").val("");
				   }
				   $("#teNtpServer").prop("disabled", false);
				   $("#teNtpPort").prop("disabled", false);
				   $("#teNtpInterval").prop("disabled", false);
				}	
			},
			error: function(xhr, textStatus, errorThrown) {
				alert(m_szError400); 
			}
		});
	}
	
	/*************************************************
	Function:		setTimeSyncMode
	Description:	设置校时方式
	Input:			mode 校时方式	，0-自动校时，1-手动校时		
	Output:			无
	return:			无
	*************************************************/
	TimeSettings.prototype.setTimeSyncMode = function(mode)
	{
		if (mode == 0)
		{ // 自动校时
			//$("#teNtpServer").prop("disabled", false);
			//$("#teNtpPort").prop("disabled", false);
			//$("#teNtpInterval").prop("disabled", false);
			$("#chTimeSyncWithPC").prop("disabled", true);
			$("#teSelectTime").prop("disabled", true);
			$("#seTimeZone").prop("disabled", false);
		}
		else
		{ // 手动校时
			//$("#teNtpServer").prop("disabled", true);
			//$("#teNtpPort").prop("disabled", true);
			//$("#teNtpInterval").prop("disabled", true);
			$("#chTimeSyncWithPC").prop("disabled", false);
			if (!$("#chTimeSyncWithPC").prop("checked"))
			{
				$("#teSelectTime").prop("disabled", false);
				$("#seTimeZone").prop("disabled", false);
			}
			this.updateSystemTime();
			TimeSettings.prototype.clickTimeSyncWithPC();
		}
	}
	
	/*************************************************
	Function:		updateSystemTime
	Description:	根据所选时区，更新$("#teDeviceTime").val()，并非通过设备来更新
	Input:			无
	Output:			无
	return:			无	
	*************************************************/
	TimeSettings.prototype.updateSystemTime = function()
	{
		if ($("#chTimeSyncWithPC").prop("checked"))
		{
			return;
		}
		var iDeviceTime = this.m_dtDeviceTime.getTime(); // ms
		var arDTZms = this.m_szDeviceTimeZone.match(/\D+([+-])(\d+):(\d+):(\d+)/);
		if (arDTZms !== null && arDTZms.length === 5)
		{
			var iDInc = (parseInt(arDTZms[2]) * 3600 + parseInt(arDTZms[3]) * 60 + parseInt(arDTZms[4])) * 1000; // ms
			iDInc = (arDTZms[1] === "+") ? iDInc : -iDInc;
		}
		else
		{
			arDTZms = this.m_szDeviceTimeZone.match(/\D+([+-])(\d+)/);
			var iDInc = parseInt(arDTZms[2]) * 3600000; // ms
			iDInc = (arDTZms[1] === "+") ? iDInc : -iDInc;
		}
		var szTimeZone = $("#seTimeZone").val(); // 当前选择时区
		if (szTimeZone == null)
		{ // 刷新时，$("#seTimeZone")尚未得到？？
			return;
		}
		var arTZms = szTimeZone.match(/\D+([+-])(\d+):(\d+):(\d+)/);
		var iInc = (parseInt(arTZms[2]) * 3600 + parseInt(arTZms[3]) * 60 + parseInt(arTZms[4])) * 1000; // ms
		if (arTZms.length !== 5)
		{
			return;
		}
		iInc = (arTZms[1] === "+") ? iInc : -iInc;
		var dtTime = new Date(iDeviceTime + iDInc - iInc);
		$("#teSelectTime").val(this.dateFormat(dtTime, "yyyy-MM-ddTHH:mm:ss"));
	}
	
	/*************************************************
	Function:		clickDST 类方法
	Description:	点击IsEnableDST复选框
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	TimeSettings.prototype.clickDST = function()
	{
		$("#dvDST select").prop("disabled", !$("#IsEnableDST").prop("checked"));
	}
	
	/*************************************************
	Function:		submit
	Description:	提交时间设置
	Input:			无
	Output:			无
	return:			无
	*************************************************/
	TimeSettings.prototype.submit = function()
	{
		$("#laNtpServerTips").html("");
		$("#laNtpPortTips").html("");
		$("#laNtpIntervalTips").html("");
		$("#laDeviceTimeTips").html("");
		
		var szXml = "<?xml version='1.0' encoding='utf-8'?><Time>";
		
		if ($("#ntpTimeCheck").prop('checked')){ // 自动校时(NTP校时)
			if (!CheackStringLenthNull($("#teNtpServer").val(), "laNtpServerTips", "laServerAdd", 64))
			{
				return;
			}
			if (!CheackServerIDIntNum($("#teNtpPort").val(), "laNtpPortTips", "NtpPortRangeTips", 1, 65535))
			{
				return;
			}
			if (!CheackServerIDIntNum($("#teNtpInterval").val(), "laNtpIntervalTips", "NTPIntervalRangeTips", 1, 10080))
			{
				return;
			}
			szXml+="<timeMode>NTP</timeMode><localTime>"+$("#teDeviceTime").val()+"</localTime>";
		}
		else
		{ // 手动校时
			szXml+="<timeMode>manual</timeMode>";
			if ($.isEmpty($("#teDeviceTime").val()))   
			{
				var szAreaNameInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
				$("#laDeviceTimeTips").html(szAreaNameInfo + parent.translator.translateNode(this.getLxd(), "TimeIsNuLLTips")); 
				return;
			}
			szXml+="<localTime>"+$("#teSelectTime").val()+"</localTime>";
		}
		var iDSTPos = this.m_szDeviceTimeZone.indexOf("DST");
		if(iDSTPos != -1)
		{
			szXml+="<timeZone>"+$("#seTimeZone").val()+this.m_szDeviceTimeZone.substring(iDSTPos, this.m_szDeviceTimeZone.length)+"</timeZone>";
		}
		else
		{
			szXml+="<timeZone>"+$("#seTimeZone").val()+"</timeZone>";
		}
		szXml+="</Time>";
		
		var xmlDoc = parseXmlFromStr(szXml);
		
		var that = this;
		$.ajax({
			type: "put",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/time",
			data: xmlDoc,
			processData: false,
			async: true,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");  
				
				xhr.setRequestHeader("Content-Type", "text/xml");
			},
			success: function(xmlDoc, textStatus, xhr) {
				that.syncDeviceTime(); // 重新获取设备时间
				that.m_szDeviceTimeZone = $("#seTimeZone").val();
				var xmlU = new XmlUtils(xmlDoc);
				var state = xmlU.val("statusCode");
				var szRetInfo = "";
				switch (state)
				{
					case "1": // OK
						if ($("#ntpTimeCheck").prop('checked'))
						{
							submitNtpInfo();
							return;
						}
						else
						{
							szRetInfo = m_szSuccessState + m_szSuccess1;
						}
						break;
					case "2": // Device Busy
						szRetInfo = m_szErrorState + m_szError7;
						break;
					case "3": // Device Error
						szRetInfo = m_szErrorState + m_szError6;
						break;
					case "4": // Invalid Operation
						szRetInfo = m_szErrorState + m_szError5;
						break;
					case "5": // Invalid XML Format
						szRetInfo = m_szErrorState + m_szError4;
						break;
					case "6": // Invalid XML Content
						szRetInfo = m_szErrorState + m_szError13;
						break;
					case "7": // Reboot Required
						if($("#diTimeConfig :radio")[0].checked)
						{
							submitNtpInfo();
						}
						else
						{
							pr(Maintain).confirmAndRestart();
						}
						szRetInfo = m_szSuccessState + m_szSuccess5;
						break;
					default: // 不应该到这里
						break;
				}
				$("#SetResultTips").html(szRetInfo);
			},
			error: function(xhr, textStatus, errorThrown) {
				if (xhr.status === 403) {
					var szRetInfo = m_szErrorState + m_szError8;
					$("#SetResultTips").html(szRetInfo);
				}
				else {
					var szRetInfo = m_szErrorState + m_szError1;
					$("#SetResultTips").html(szRetInfo);
				};
			},
			complete: function()
			{
				setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			}
		});
	}
	/*************************************************
	Function:		submitDST
	Description:	提交夏令时设置
	Input:			无
	Output:			无
	return:			无
	*************************************************/
	TimeSettings.prototype.submitDST = function()
	{
		var iDSTPos = this.m_szDeviceTimeZone.indexOf("DST");
		var szTimeZone = "";
		if(iDSTPos == -1)
		{
			szTimeZone = this.m_szDeviceTimeZone;
		}
		else
		{
			szTimeZone = this.m_szDeviceTimeZone.substring(0, iDSTPos);
		}
		if($("#IsEnableDST").prop("checked"))
		{
			if ($("#DSTBias").val() == null)
			{
				$("#SetResultTips").html(m_szErrorState + parent.translator.translateNode(this.getLxd(), "DSTBiasIsNullTips"));
				return;
			}
			if ($("#StartMonth").val() == $("#StopMonth").val())
			{
				$("#SetResultTips").html(m_szErrorState + parent.translator.translateNode(this.getLxd(), "DSTMonthSameTips"));
				return;
			}
			var szTemp = "";
			if ($("#DSTBias").val() == null)
			{
				szTemp = szTimeZone + "DST" + "00:00:00";
			}
			else
			{
				szTemp = szTimeZone + "DST" + $("#DSTBias").val();
			}
			var szStartTime = $("#StartMonth").val() + "." + $("#StartWeek").val() + "." + $("#StartWeekDay").val() + "/" + $("#StartTime").val() + ":00:00";
			var szStopTime = $("#StopMonth").val() + "." + $("#StopWeek").val() + "." + $("#StopWeekDay").val() + "/" + $("#StopTime").val() + ":00:00";
			szTimeZone = szTemp + "," + szStartTime + "," + szStopTime;
		}
		
		$.ajax({
			type: "PUT",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/time/timeZone",
			data: szTimeZone,
			processData: false,
			async: true,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");  
				
				xhr.setRequestHeader("Content-Type", "text/xml");
			},
			complete: function(xhr, textStatus){
				SaveState(xhr);
			}
		});
	}
	/*************************************************
	Function:		submitNtpInfo
	Description:	提交NTP服务器信息
	Input:			无			
	Output:			无
	return:			无				
	*************************************************/
	function submitNtpInfo()
	{
		var xmlDoc = new createxmlDoc();
		var instruction = xmlDoc.createProcessingInstruction("xml","version='1.0' encoding='utf-8'");
		xmlDoc.appendChild(instruction);
		var root = xmlDoc.createElement("NTPServer");	
		
		var element = xmlDoc.createElement("id");
		var text = xmlDoc.createTextNode("1");
		element.appendChild(text);
		root.appendChild(element);
		
		element = xmlDoc.createElement("addressingFormatType"); // 服务器地址类型
		var szIpAddressType = CheckAddressingType($("#teNtpServer").val());
		if (szIpAddressType === "hostName")
		{
			text = xmlDoc.createTextNode("hostname");
		}
		else
		{
			text = xmlDoc.createTextNode("ipaddress");
		}	
		element.appendChild(text);
		root.appendChild(element);
	
		element = xmlDoc.createElement(szIpAddressType);		
		text = xmlDoc.createTextNode($("#teNtpServer").val());
		element.appendChild(text);	
		root.appendChild(element);
		
		element = xmlDoc.createElement("portNo");
		text = xmlDoc.createTextNode($("#teNtpPort").val());
		element.appendChild(text);	
		root.appendChild(element);
		
		var extensions = xmlDoc.createElement("Extensions");
		element = xmlDoc.createElement("synchronizeInterval");
		text = xmlDoc.createTextNode($("#teNtpInterval").val());
		element.appendChild(text);	
		extensions.appendChild(element);
		root.appendChild(extensions);

		xmlDoc.appendChild(root);
		
		$.ajax({
			type: "put",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/time/ntpServers/1",
			data: xmlDoc,
			processData: false,
			async: true,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");  
				
				xhr.setRequestHeader("Content-Type", "text/xml");
			},
			complete:function(xhr, textStatus)
			{
				SaveState(xhr);
			}
		});
	}
	
})(); // TimeSettings implementation


/************************************************
Function:		Telecontrol
Description:	构造函数，Singleton派生类
Input:			无			
Output:			无
return:			无				
************************************************/
function Telecontrol() {
	SingletonInheritor.implement(this);
	this.m_xmLDoc = null;
}
SingletonInheritor.declare(Telecontrol);

(function() { // RS485Config implementation
	/************************************************
	Function:		initCSS 类方法
	Description:	初始化CSS
	Input:			无			
	Output:			无
	return:			无				
	************************************************/
	Telecontrol.prototype.initCSS = function()
	{
		$("#dvTelecontrol").find("select[id='seDelayTime']").change(function()
		{
			if(this.value == '-1')
			{
				$(this).next().show();
			}
			else
			{
				$(this).next().hide();
			}
		});
		$("#seHardType").change(function()
		{
			if(this.value == 'tel')
			{
				$(this).nextAll().hide();
			}
			else
			{
				$(this).nextAll().show();
			}
		});
		//
		$("#seArmOrDisarm").change(function()
		{
			if(this.value == "arm")
			{
				if($("#seDelayTime").val() == "-1")
				{
					$("#seDelayTime").show();
					$("#teCustomizeDelay").show();
					$("#laCustomizeDelay").show();
				}
				else
				{
					$("#seDelayTime").show();
					$("#teCustomizeDelay").hide();
					$("#laCustomizeDelay").hide();
				}
			}
			else
			{
				$("#seDelayTime").hide();
				$("#teCustomizeDelay").hide();
				$("#laCustomizeDelay").hide();
			}
		});
		if(g_bSupportWLS)
		{
			$("#seHardType").append('<option value="wls" name="laWirelessAlarm">'+getNodeValue("laWirelessAlarm")+'</option>').after('<select id="seWLSID" style="display:none; width:100px; vertical-align:middle;"><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option></select>');
		}
	};	  
	/***********************************************
	Function:		Telecontrol
	Description:	更新遥控器
	Input:			无	
	Output:			无
	return:			无				
	***********************************************/
	Telecontrol.prototype.update = function()
	{
		if($.browser.msie && parseInt($.browser.version, 10) == 6)
		{
            $(".timehidden").hide();
			$(".232hidden").hide();
			$(".485hidden").hide();
			$("#dvTelecontrol").find("select").show();
			$("#seHardType").change();
		}
		$("#SaveConfigBtn").hide();
		$("#SetResultTips").html("");
		
		$.ajax(
		{
			type:"GET",
			url:m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Telecontrol",
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");  
				
			},
			success: function(xmlDoc, textStatus, xhr) 
			{
				var arr = ["0", "10", "30", "60", "180", "300"];
				var szEnable = $(xmlDoc).find("enabled").eq(0).text();
				if(szEnable == "true")
				{
					$("#seArmOrDisarm").val("arm");
					var szArmingDelay = $(xmlDoc).find("armingdelay").eq(0).text();
					if($.inArray(szArmingDelay, arr) != -1)
					{
						$("#seDelayTime").val(szArmingDelay);
					}
					else
					{
						$("#seDelayTime").val('-1').change();
						$("#teCustomizeDelay").val(szArmingDelay);
					}
				}
				else
				{
					$("#seArmOrDisarm").val("disarm");
					$("#seDelayTime").hide();
					$("#teCustomizeDelay").hide();
					$("#laCustomizeDelay").hide();
				}
			}
		});	
		
		g_transStack.clear();
		var that = this;
		g_transStack.push(function() {
			that.setLxd(parent.translator.getLanguageXmlDoc(["System", "Telecontrol"]));
			parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
			parent.translator.translatePage(that.getLxd(), document);
		}, true);
	}
	/***********************************************
	Function:		study
	Description:	学习
	Input:			无	
	Output:			无
	return:			无				
	***********************************************/
	Telecontrol.prototype.study = function()
	{
		var szURL = "";
		if($("#seHardType").val() == "tel")
		{
			szURL = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Telecontrol/study";
		}
		else
		{
			szURL = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/WLSensors/"+$("#seWLSID").val()+"/study";
		}
		$.ajax(
		{
			type:"PUT",
			url: szURL,
			beforeSend: function(xhr)
			{
				xhr.setRequestHeader("If-Modified-Since", "0");  
				
			},
			complete: function(xhr, textStatus) 
			{
				SaveState(xhr);
			}
		});	
	}
	/***********************************************
	Function:		set
	Description:	设置布/撤防
	Input:			无	
	Output:			无
	return:			无				
	***********************************************/
	Telecontrol.prototype.set = function()
	{
		var szXml = "";
		if($("#seArmOrDisarm").val() == "arm")
		{
			if($("#seDelayTime").val() == "-1")
			{
				if(!CheackServerIDIntNum($("#teCustomizeDelay").val(),'spDelayTips','laDelay',0,300))
				{
					return;
				}
				szXml = "<?xml version='1.0' encoding='UTF-8'?><telecontrol><enabled>true</enabled><delay><armingdelay>"+$("#teCustomizeDelay").val()+"</armingdelay></delay></telecontrol>";
			}
			else
			{
				szXml = "<?xml version='1.0' encoding='UTF-8'?><telecontrol><enabled>true</enabled><delay><armingdelay>"+$("#seDelayTime").val()+"</armingdelay></delay></telecontrol>";
			}
			var xmlDoc = parseXmlFromStr(szXml);
			$.ajax(
			{
				type:"PUT",
				url:m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Telecontrol",
				data:xmlDoc,
				processData: false,
				beforeSend: function(xhr)
				{
					xhr.setRequestHeader("If-Modified-Since", "0");  
					
				},
				complete: function(xhr, textStatus) 
				{
					SaveState(xhr);
				}
			});	
		}
		else
		{
			/*if($("#seDelayTime").val() == "-1")
			{
				szXml = "<?xml version='1.0' encoding='UTF-8'?><telecontrol><enabled>false</enabled><delay><disarmingdelay>"+$("#teCustomizeDelay").val()+"</disarmingdelay></delay></telecontrol>";
			}
			else
			{
				szXml = "<?xml version='1.0' encoding='UTF-8'?><telecontrol><enabled>false</enabled><delay><disarmingdelay>"+$("#seDelayTime").val()+"</disarmingdelay></delay></telecontrol>";
			}*/
			$.ajax(
			{
				type:"PUT",
				url:m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Telecontrol/disarming",
				processData: false,
				beforeSend: function(xhr)
				{
					xhr.setRequestHeader("If-Modified-Since", "0");  
					
				},
				complete: function(xhr, textStatus) 
				{
					SaveState(xhr);
				}
			});
		}
	}
})(); // Telecontrol
/*************************************************
Function:		GetNetworkVersion
Description:	获取设备是否支持IPV6
Input:			无			
Output:			无
return:			无				
*************************************************/
function GetNetworkVersion()
{
	var szURL = m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces";
	$.ajax(
	{
		type: "GET",
		url: szURL,
		async: false,
		beforeSend: function(xhr) 
		{
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr)
		{
			m_strIpVersion = $(xmlDoc).find('ipVersion').eq(0).text();
		}
	});
}


System.watchCarDetectorInfo = function(){

    if($('#carDetectorInfoDiv').css("display")=="none"){

        $('#watchCarLinkDiv').css({display:"none"});
        $('#carDetectorInfoDiv').css("margin-top","10px");
        $('#carDetectorInfoDiv').css({display:"block"});
    }
    autoResizeIframe();
}

System.hiddenCarDetectorInfo = function(){

    if($('#carDetectorInfoDiv').css("display")=="block"){

        $('#carDetectorInfoDiv').css({display:"none"});
        $('#watchCarLinkDiv').css({display:"block"});
    }
    autoResizeIframe();
};
/************************************************
Function:		DeviceStatus
Description:	构造函数，Singleton派生类
Input:			无			
Output:			无
return:			无				
************************************************/

function DeviceStatus() {
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(DeviceStatus);

(function () {  // DeviceStatus implementation

	/************************************************
	Function:		initCSS 类方法
	Description:	初始化CSS
	Input:			无			
	Output:			无
	return:			无				
	************************************************/
	DeviceStatus.prototype.initCSS = function()
	{
	}

	/************************************************
	Function:		DeviceStatus
	Description:	获取设备状态
	Input:			无	
	Output:			无
	return:			无				
	************************************************/
	DeviceStatus.prototype.update = function()
	{
		$("#SaveConfigBtn").hide();
		$("#SetResultTips").html("");

		g_transStack.clear();
		var that = this;
		g_transStack.push(function() {
			that.setLxd(parent.translator.getLanguageXmlDoc(["System", "DeviceStatus"]));
			parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
			parent.translator.translatePage(that.getLxd(), document);
		}, true);

		var that = this;
		var xmlStreamStatus = null;
		var xmlDeviceStatus = null;
		var strFirstPreviewIp = "";
		var strFirstAlarmIp = "";
		var strFirstAlarmLevel = "";
		$("#DeviceIpAdd").val(m_strIp);
		$.ajax({
		   type: 'GET',
		   url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/ITCStatus",
		   beforeSend: function(xhr) {
			   xhr.setRequestHeader("If-Modified-Since", "0"); 
			   
			   xhr.setRequestHeader("Content-Type", "text/xml");
		   },
		   success: function(xmlDoc, textStatus, xhr) {
			   xmlDeviceStatus = xmlDoc;

               //预览连接数  previewCountIP  previewCount
               PreviewCount = $(xmlDeviceStatus).find("previewCount").eq(0).text();
               var previewCountIP = $(xmlDeviceStatus).find("previewCountIP").eq(0).text();
               strFirstPreviewIp = $(xmlDeviceStatus).find("previewCfgList").eq(0).find("previewIP").eq(0).text();
			   var fortifyLinkCount = $(xmlDeviceStatus).find("fortifyLinkCount").eq(0).text(); //布防连接数
			   if(fortifyLinkCount > 0) {
				   strFirstAlarmIp = $(xmlDeviceStatus).find("fortifyLinkIP").eq(0).text();     //布防连接IP
				   strFirstAlarmLevel = $(xmlDeviceStatus).find("fortifyLinkPriority").eq(0).text();
			   }

			   var frameRate =  $(xmlDeviceStatus).find("previewCfg").eq(0).find('frameRate').eq(0).text()/100;
               if(frameRate == '0'){
                   frameRate = getNodeValue('allFrameRate');
               }else if(frameRate == (1/100)){
                   frameRate = '';
               }else if(frameRate < 1 && frameRate > 0){

                   var rateInt = frameRate * 100;
                   if(rateInt == 6){
                       frameRate = '1/16';
                   }else if(rateInt == 12){
                       frameRate = '1/8';
                   }else if(rateInt == 25){
                       frameRate = '1/4';
                   }else if(rateInt == 50){
                       frameRate = '1/2';
                   }
               }
			   var Resolution = $(xmlDeviceStatus).find("previewCfg").eq(0).find("resolutionWidth").eq(0).text() + "*" + $(xmlDeviceStatus).find("previewCfg").eq(0).find("resolutionHeight").eq(0).text();
               if($(xmlDeviceStatus).find("previewCfg").eq(0).find("resolutionWidth").eq(0).text() == 0 && $(xmlDeviceStatus).find("previewCfg").eq(0).find("resolutionHeight").eq(0).text() == 0){
                   Resolution = "";
               }
			   var snapResolution = $(xmlDeviceStatus).find("snapResolutionWidth").eq(0).text() + "*" + $(xmlDeviceStatus).find("snapResolutionHeight").eq(0).text();
				var triggerType = "";       //触发模式
				if($(xmlDeviceStatus).find("triggerType").eq(0).text() == "normal") {
				   triggerType = getNodeValue("triggerTypeNormal");
			   } else {
				   triggerType = getNodeValue("triggerTypeVT");
			   }
               var channelType = "";
               if($(xmlDeviceStatus).find("previewCfg").eq(0).find("channelType").eq(0).text() == "mainChannel") {
                   channelType = getNodeValue("streamTypeOpt1");
               } else if($(xmlDeviceStatus).find("previewCfg").eq(0).find("channelType").eq(0).text() == "subChannel") {
                   channelType = getNodeValue("streamTypeOpt2");
               }else{
                   channelType = "";
               }

               InsertDeviceList(PreviewCount,strFirstPreviewIp,frameRate, Resolution,channelType,fortifyLinkCount,strFirstAlarmIp, strFirstAlarmLevel, snapResolution, triggerType);

               for(i = 1; i < PreviewCount; i++) {
                   strFirstPreviewIp = $(xmlDeviceStatus).find("previewCfg").eq(i).find("previewIP").eq(0).text();
                   if($(xmlDeviceStatus).find("previewCfg").eq(i).find("channelType").eq(0).text() == "mainChannel") {
                       channelType = getNodeValue("streamTypeOpt1");
                   }else if($(xmlDeviceStatus).find("previewCfg").eq(i).find("channelType").eq(0).text() == "subChannel") {
                       channelType = getNodeValue("streamTypeOpt2");
                   }else{
                       channelType = "";
                   }
                   frameRate = $(xmlDeviceStatus).find("previewCfg").eq(i).find('frameRate').eq(0).text()/100;

                   if(frameRate == '0'){
                       frameRate = getNodeValue('allFrameRate');
                   }else if(frameRate == (1/100)){
                       frameRate = '';
                   }else if(frameRate < 1 && frameRate > 0){

                       var rateInt = frameRate * 100;
                       if(rateInt == 6){
                           frameRate = '1/16';
                       }else if(rateInt == 12){
                           frameRate = '1/8';
                       }else if(rateInt == 25){
                           frameRate = '1/4';
                       }else if(rateInt == 50){
                           frameRate = '1/2';
                       }
                   }
                   Resolution = $(xmlDeviceStatus).find("previewCfg").eq(i).find("resolutionWidth").eq(0).text() + "*" + $(xmlDeviceStatus).find("previewCfg").eq(i).find("resolutionHeight").eq(0).text();
                   InsertDeviceList("",strFirstPreviewIp,frameRate, Resolution,channelType,"","", "","", "");
               }
			   for(i = fortifyLinkCount; i > 1; i--) { //布防连接数
				   strFirstAlarmIp = $(xmlDeviceStatus).find("fortifyLinkIP").eq(parseInt(i) - 1).text();
				   strFirstAlarmLevel = $(xmlDeviceStatus).find("fortifyLinkPriority").eq(parseInt(i) - 1).text();
				   InsertDeviceList("","","", "","","",strFirstAlarmIp, strFirstAlarmLevel, "","");
			   }
			   g_transStack.push(function()
			   {
					if($(xmlDoc).find("detectorLinkState").eq(0).text() == "connected") {
						$("#CarDetectorConnection").val(getNodeValue("laDetectorconnected"));
                        $("#CarDetectorConnection").css('color','#000000');
					} else {
						$("#CarDetectorConnection").val(getNodeValue("laDetectordisconnected"));
                        $("#CarDetectorConnection").css('color','#ff0000');
					}
					for(var i = 0; i< $(xmlDoc).find("DetectorState").length; i++) {
						var laneId = $(xmlDoc).find("DetectorState").eq(i).find("id").eq(0).text();
						var firstCoilState = $(xmlDoc).find("firstCoilState").eq(i).text();
						var secondCoilState = $(xmlDoc).find("secondCoilState").eq(i).text();
						var thirdCoilState = $(xmlDoc).find("thirdCoilState").eq(i).text();
						InsertDetectorItemList(laneId, firstCoilState, secondCoilState, thirdCoilState);
					}
			   }, true);

               $('#carDetectorInfoDiv').css({display:"none"});
		   },
		   error: function(XMLHttpRequest, textStatus, errorThrown) {
			   that.Get232Serial();
		   }
	   });

		autoResizeIframe();
	}
})();
/*************************************************
Function:		InsertDeviceList
Description:	插入文件条目信息到List中
Input:			
Output:			无
return:			无
*************************************************/
function InsertDeviceList(a,b,c,d,e,f,g,h,i,k) {
	var ObjTr;
   var ObjTd;
   ObjTr = document.getElementById("CameraStatusList").insertRow(document.getElementById("CameraStatusList").rows.length);
   ObjTr.style.height = 22 + 'px';
   ObjTr.style.cursor = "pointer";
   for(j = 0;j < document.getElementById("CameraStatusList").rows[0].cells.length;j++)
   {
		ObjTd = ObjTr.insertCell(j);
		$(ObjTd).css({border:"1px solid #d7d7d7",background:"#ffffff",padding:"0 0 0 5px"});
		switch(j)
		{
	    	case 0:
		    	ObjTd.innerHTML = a;
			   	ObjTd.id = "itemtdA"+ a;
				ObjTd.style.color = "#39414A";
			   	break;
		  	case 1:
		       	ObjTd.innerHTML = b;
			  	ObjTd.id = "itemtdB"+ a;
				ObjTd.style.color = "#39414A";
			  	break;
		  	case 2:
		  		ObjTd.innerHTML = c;
			  	ObjTd.id = "itemtdC"+ a;
				ObjTd.style.color = "#39414A";
			   	break;
			case 3:
		  		ObjTd.innerHTML = d;
			  	ObjTd.id = "itemtdD"+ a;
				ObjTd.style.color = "#39414A";
			   	break;
			case 4:
		    	ObjTd.innerHTML = e;
			   	ObjTd.id = "itemtdE"+ a;
				ObjTd.style.color = "#39414A";
			   	break;
		  	case 5:
		       	ObjTd.innerHTML = f;
			  	ObjTd.id = "itemtdF"+ a;
				ObjTd.style.color = "#39414A";
			  	break;
		  	case 6:
		  		ObjTd.innerHTML = g;
			  	ObjTd.id = "itemtdG"+ a;
				ObjTd.style.color = "#39414A";
			   	break;
			case 7:
		  		ObjTd.innerHTML = h;
			  	ObjTd.id = "itemtdH"+ a;
				ObjTd.style.color = "#39414A";
			   	break;
			case 8:
		  		ObjTd.innerHTML = i;
			  	ObjTd.id = "itemtdI"+ a;
				ObjTd.style.color = "#39414A";
			   	break;
			case 9:
		  		ObjTd.innerHTML = k;
			  	ObjTd.id = "itemtdK"+ a;
				ObjTd.style.color = "#39414A";
			   	break;
			default:
				break;
	   }
    }
}
/*************************************************
Function:		InsertItemList
Description:	插入文件条目信息到List中
Input:			a : 车道号
                b : 线圈1
				c : 线圈2
				d : 线圈3
Output:			无
return:			无
*************************************************/
function InsertDetectorItemList(a,b,c,d)
{
   var ObjTr;
   var ObjTd;
   ObjTr = document.getElementById("CarDetectorStatusList").insertRow(document.getElementById("CarDetectorStatusList").rows.length);
   ObjTr.style.height = 22 + 'px';
   ObjTr.style.cursor = "pointer";
   for(j = 0;j < document.getElementById("CarDetectorStatusList").rows[0].cells.length;j++)
   {
		ObjTd = ObjTr.insertCell(j);
		$(ObjTd).css({border:"1px solid #d7d7d7",background:"#ffffff",padding:"0 0 0 5px"});
		switch(j)
		{
	    	case 0:
		    	ObjTd.innerHTML = getNodeValue("laLaneNumIndex") + a;
			   	ObjTd.id = "itemtdA"+ a;
				ObjTd.style.color = "#39414A";
			   	break;
		  	case 1:
		       	ObjTd.innerHTML = TurnDetectorState(b);
			  	ObjTd.id = "itemtdB"+ a;
				ObjTd.style.color = "#39414A";
			  	break;
		  	case 2:
		  		ObjTd.innerHTML = TurnDetectorState(c);
			  	ObjTd.id = "itemtdC"+ a;
				ObjTd.style.color = "#39414A";
			   	break;
			case 3:
		  		ObjTd.innerHTML = TurnDetectorState(d);
			  	ObjTd.id = "itemtdC"+ a;
				ObjTd.style.color = "#39414A";
			   	break;
			default:
				break;
	   }
    }
}
/*************************************************
Function:		TurnDetectorState
Description:	状态转换
Input:			strStatus: 状态             
Output:			无
return:			无
*************************************************/
function TurnDetectorState(strStatus) {
	var strDetectorStaus = "";
	switch(strStatus) {
		case "unused":
		    strDetectorStaus = getNodeValue("DetectorSatusUnused");
			break;
		case "normal":
		    strDetectorStaus = getNodeValue("DetectorSatusNormal");
			break;
		case "short":
		    strDetectorStaus = getNodeValue("DetectorSatusShort");
			break;
		case "broken":
		    strDetectorStaus = getNodeValue("DetectorSatusBroken");
			break;
		default:
		    break;
	}
	return strDetectorStaus;
}



/*************************************************
相机架设参数类
*************************************************/
function SnapSetup() {
	SingletonInheritor.implement(this);

	this.longitude = {
		flag: 'E',
		degree:'0',
		minute: '0',
		second: '0',

		toString: function () {
			var self = this;
			return "{0}{1}D{2}M{3}S".format(self.flag, 
				self.degree.toString().padLeft(3, '0'),
				self.minute.toString().padLeft(2, '0'),
				self.second.toString().padLeft(2, '0'))
		},
		fromString: function (str) {
			if (str.length != 11) {
				return;
			};

			this.flag = str.charAt(0).toUpperCase();
			this.degree = parseInt(str.substr(1, 3), 10);
			this.minute = parseInt(str.substr(5, 2), 10);
			this.second = parseInt(str.substr(8, 2), 10);
		}
	};
	this.latitude = {
		flag: 'N',
		degree:'0',
		minute: '0',
		second: '0',

		toString: function () {
			var self = this;
			return "{0}{1}D{2}M{3}S".format(self.flag, 
				self.degree.toString().padLeft(3, '0'),
				self.minute.toString().padLeft(2, '0'),
				self.second.toString().padLeft(2, '0'))
		},
		fromString: function (str) {
			if (str.length != 11) {
				return;
			};

			this.flag = str.charAt(0).toUpperCase();
			this.degree = parseInt(str.substr(1, 3), 10);
			this.minute = parseInt(str.substr(5, 2), 10);
			this.second = parseInt(str.substr(8, 2), 10);
		}
	};


}
SingletonInheritor.declare(SnapSetup);

/************************************************
Function:		initCSS 类方法
Description:	初始化CSS
Input:			无			
Output:			无
return:			无				
************************************************/
SnapSetup.prototype.initCSS = function()
{

}

SnapSetup.prototype.initSlider = function () {
	InitSlider2();
}

pr(SnapSetup).autoGetGpsChanged = function () {
	var v = $('select[x-model=autoGetGps]').val();
	if (v == '1') {
		$('#longitudeWrapper, #latitudeWrapper').hide();
	}else{
		$('#longitudeWrapper, #latitudeWrapper').show();
	}
	autoResizeIframe();
}
/*************************************************
Function:		update
Description:	更新相机架设参数信息
Input:			无
Output:			无
return:			无
*************************************************/
pr(SnapSetup).update = function(){

	if($.browser.msie && parseInt($.browser.version, 10) == 6){
		
		$("#taSnapSetup").find("select").show();
	}

	$('#SetResultTips').html('');
	$("#SaveConfigBtn").show();
	HWP.Stop(0);
	g_transStack.clear();
	var that = this;
	g_transStack.push(function () {
		that.setLxd(parent.translator.getLanguageXmlDoc(["System", "SnapSetup"]));
		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	}, true);
	
	

	$.ajax({
		type: "GET",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/ITCSetUp",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) {
			$("#focalType").val($(xmlDoc).find("focalType").eq(0).text());
			$("#setUpHeight").val($(xmlDoc).find("setUpHeight").eq(0).text());
            $("#SceneDis").val($(xmlDoc).find("SceneDis").eq(0).text());
            /*if(picMaxObject == null)
            {
                picMaxObject = new qsoft.PopBigImage("imageLeft_1",-240,0,1,1);
                picMaxObject.render();
            }
            else
            {
                picMaxObject.resize("imageLeft_1");
            }*/
		}
	});

	$.ajax({
		type: "GET",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/VideoMark",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		}
	}).done(function (xmlDoc) {
		var $xmlDoc = $(xmlDoc);

		SetSliderValue('horizontalFieldSlider', $xmlDoc.find('horizontalField').text());
		SetSliderValue('verticalFieldSlider', $xmlDoc.find('verticalField').text());

		//$.g.setField2('*[x-model=autoGetGps]', $xmlDoc.find('autoGetGps').eq(0).text());

		$.each(['autoGetGps', 'longitude', 'latitude'], function (i, n) {
				$.g.setField2('*[x-model='+n+']', $xmlDoc.find(n).eq(0).text());
			});

		var longitude = $xmlDoc.find('longitude').eq(0).text();
		var latitude = $xmlDoc.find('latitude').eq(0).text();

		that.longitude.fromString(longitude);
		that.latitude.fromString(latitude);


		that.autoGetGpsChanged();

	});
	autoResizeIframe();
}

function editLL () {
	var longObj = ia(SnapSetup).longitude;
	var latiObj = ia(SnapSetup).latitude;

	var $pp = $('#llPopDiv');
	$.g.setField2('#llPopDiv #longFlag', longObj.flag);
	$.g.setField2('#llPopDiv #latiFlag', latiObj.flag);

	$.g.setField2('#llPopDiv #longD', longObj.degree);
	$.g.setField2('#llPopDiv #longM', longObj.minute);
	$.g.setField2('#llPopDiv #longS', longObj.second);

	$.g.setField2('#llPopDiv #latiD', latiObj.degree);
	$.g.setField2('#llPopDiv #latiM', latiObj.minute);
	$.g.setField2('#llPopDiv #latiS', latiObj.second);

	tips('');

	function tips (str) {
		$('#llpoptips').text(str);	
	}

	$.dialog({
		content: $pp[0],
		lock: true,
		ok: function(w){
			if (!$.g.isInRange('#llPopDiv #longD', 0, 179)) {
				tips('*'+getNodeValue('errRangeLong'))
				return false;
			};

			if (!$.g.isInRange('#llPopDiv #longD', 0, 89)) {
				tips('* '+getNodeValue('errRangeLati'))
				return false;
			};

			if (!$.g.isInRange('#llPopDiv #longM', 0, 59)
				|| !$.g.isInRange('#llPopDiv #latiM', 0, 59)
				|| !$.g.isInRange('#llPopDiv #longS', 0, 59)
				|| !$.g.isInRange('#llPopDiv #latiS', 0, 59)) {
				tips('* '+getNodeValue('errRangeMS'))
				return false;
			};

			longObj.flag = $('#llPopDiv #longFlag').val();
			longObj.degree = $('#llPopDiv #longD').val();
			longObj.minute = $('#llPopDiv #longM').val();
			longObj.second = $('#llPopDiv #longS').val();

			latiObj.flag = $('#llPopDiv #latiFlag').val();
			latiObj.degree = $('#llPopDiv #latiD').val();
			latiObj.minute = $('#llPopDiv #latiM').val();
			latiObj.second = $('#llPopDiv #latiS').val();
			
			$('#longitude').val(longObj.toString());
			$('#latitude').val(latiObj.toString());
			return true;
		},
		okVal:getNodeValue("laSaveBtn"),
		cancel:function(){return true;},
		cancelVal:getNodeValue("laCancel")
	});
}
/*************************************************
Function:		submit
Description:	设置相机架设参数信息
Input:			无
Output:			无
return:			无
*************************************************/

pr(SnapSetup).submit = function () {
    if(!CheackServerIDIntNum($("#setUpHeight").val(),"SetResultTips","lasetUpHeight",0,2000, 'cm')) {
        $("#setUpHeight").focus();
        return;
    }
    if(!CheackServerIDIntNum($("#SceneDis").val(),"SetResultTips","laSceneDis",0,6000, 'cm')) {
        $("#SceneDis").focus();
        return;
    }
    var szXml = "<?xml version='1.0' encoding='UTF-8'?><ITCSetUp>";
    szXml += "<focalType>" + $("#focalType").val() + "</focalType>";
    szXml += "<setUpHeight>" + $("#setUpHeight").val() + "</setUpHeight>";
    szXml += "<SceneDis>" + $("#SceneDis").val() + "</SceneDis></ITCSetUp>";

    var xmlDoc = parseXmlFromStr(szXml);

    var xml2 = "<?xml version='1.0' encoding='UTF-8'?>"+
    			"<VideoMarkInfo>";

    xml2 += '<horizontalField>' + GetSliderValue('horizontalFieldSlider') + '</horizontalField>';	
    xml2 += '<verticalField>' + GetSliderValue('verticalFieldSlider') + '</verticalField>';	

    $.each(['autoGetGps', 'longitude', 'latitude'], function (i, n) {
				var e = $('*[x-model='+n+']');
				if (e.length) {
					var v = e.val();
					xml2 += '<'+n+'>' + v + '</'+n+'>';	
				};
				
			});

    xml2 += 	"</VideoMarkInfo>";

    // ,
    //     complete:function(xhr, textStatus) {
    //         SaveState(xhr);
    //     }

    var ajax1 = $.ajax({
        type: "put",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/ITCSetUp",
        data: xmlToStr(xmlDoc),
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        }
    });

    var ajax2 = $.ajax({
		type: "PUT",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/VideoMark",
		data: xml2,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		}
	});

	$.when(ajax1, ajax2).then(function (args1, args2) {
		SaveMultiState(args1[2], args2[2]);
	}, function (args1, args2) {
		if (typeof args2 == 'string') {
			SaveState(args1);
		}else{
			SaveMultiState(args1, args2);	
		}
	});
}




/*************************************************
 串口参数类。
 *************************************************/
 //选中某个命名项
var m_iSelectItem = -1;//记录上一次点击的int值。
var paramItem = ""; //记录上一次点击时的列值。
var selectItemVal = '';
var m_strItem = new Array();
for(var i = 0; i < 5; i++) {
    m_strItem[i] = '';
}

function PortParam() {
    SingletonInheritor.implement(this);
    this.m_iRS232Index = 0;
    this.m_iRS232Count = 0;
    this.m_xmLDoc = null;
    this.m_iRS485Count = 0;
    this.m_iRS485Index = 0;
}
SingletonInheritor.declare(PortParam);

PortParam.click232Param = function(){
    if($('#rs232AdvancedSetDiv').css("display")=="none"){

        $('#rs232AdvancedSetDiv').css({display:"block"});
        $('#displayAdvanceSetDiv').css({display:"none"});
    }else{
        $('#rs232AdvancedSetDiv').css({display:"none"});
        $('#displayAdvanceSetDiv').css({display:"block"});
    }
}

/************************************************
 Function:		initCSS 类方法
 Description:	初始化CSS
 Input:			无
 Output:			无
 return:			无
 ************************************************/
PortParam.prototype.initCSS = function()
{
}
/*************************************************
 Function:		update
 Description:	更新串口参数信息
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(PortParam).update = function(){

	m_iSelectItem = -1;
    $("#SaveConfigBtn").show();
    $("#SetResultTips").html("");

    HWP.Stop(0);
    g_transStack.clear();
    var that = this;
    g_transStack.push(function () {
        that.setLxd(parent.translator.getLanguageXmlDoc(["System", "PortParam"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);

    that.GetSerial();
    autoResizeIframe();
}
/************************************************
 Function:		GetSerial
 Description:	获取串口信息(232,485)
 Input:			无
 Output:			无
 return:			无
 ************************************************/
pr(PortParam).GetSerial = function()
{
    var that = this;
    $.ajax({
        type: "get",
        async: false,
        url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Serial/ports",
        beforeSend: function(xhr)
        {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
            xhr.setRequestHeader("Content-Type", "text/xml");
        },
        success: function(xmlDoc, textStatus, xhr)
        {
            that.m_xmlDoc = xmlDoc;
            var xmlU = new XmlUtils(that.m_xmlDoc);
            var iNo = xmlU.elems('serialPortType').length;

            that.m_iRS232Count = 0;
            that.m_iRS485Count = 0;
            var len = 0;
            try
            {
                var len = document.getElementById("485ParamList").rows.length;
            }
            catch(e)
            {
                len = 0;
            }
            for(var i = 1; i < len; i++){
                document.getElementById("485ParamList").deleteRow(1);
            }

            for(var i = 0; i < iNo; i++)
            {
                if(xmlU.elems('serialPortType')[i].childNodes[0].nodeValue == "RS232")
                {
                    that.m_iRS232Index = xmlU.elems('id')[i].childNodes[0].nodeValue;
                    that.m_iRS232Count++;
                }
                if(xmlU.elems('serialPortType')[i].childNodes[0].nodeValue == "RS485")
                {

                    var parityType = xmlU.elems('parityType')[i].childNodes[0].nodeValue; //none Even Odd
                    var flowCtrl = xmlU.elems('flowCtrl')[i].childNodes[0].nodeValue; //none Hardware  Soft Flow Control
                    var rsId = xmlU.elems('id')[i].childNodes[0].nodeValue;
                    insertRS485SerialParamList(rsId, xmlU.elems('baudRate')[i].childNodes[0].nodeValue, xmlU.elems('dataBits')[i].childNodes[0].nodeValue,
                    xmlU.elems('stopBits')[i].childNodes[0].nodeValue, getNodeValue('parityType' + ETrim(parityType,'g')), getNodeValue('flowCtrl'+ ETrim(flowCtrl,'g')),ETrim(parityType,'g'),ETrim(flowCtrl,'g'),rsId);
                }
            }

            if(that.m_iRS232Count > 0)
            {
                that.Get232SerialInEach();
            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown)
        {
            alert(m_szError400);
        }
    })
}

/************************************************
 Function:		Get232SerialInEach
 Description:	获取每个RS232信息
 Input:			无
 Output:			无
 return:			无
 ************************************************/
pr(PortParam).Get232SerialInEach = function()
{
    var that = this;
    $.ajax(
        {
            type: "get",
            url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Serial/ports/" + that.m_iRS232Index,
            beforeSend: function(xhr)
            {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
                xhr.setRequestHeader("Content-Type", "text/xml");
            },
            success: function(xmlDoc, textStatus, xhr)
            {
                that.m_xmlDoc = xmlDoc;
                var xmlU = new XmlUtils(that.m_xmlDoc);

                $("#baudRate232").val(xmlU.val("baudRate"));
                $("#dataBits232").val(xmlU.val("dataBits"));
                $("#stopRate232").val(xmlU.val("stopBits"));
                $("#parityType232").val(xmlU.val("parityType"));
                if(xmlU.elems('workMode').length > 0)
                {
                    $("#workMode232").val(xmlU.val("workMode"));
                }
                if(xmlU.elems('flowCtrl').length > 0)
                {
                    $("#flowControl232").val(xmlU.val("flowCtrl"));
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown)
            {
                alert(m_szError400);
            }
        });
}

/************************************************
 Function:		Get485Serial
 Description:	获取单个485串口信息        !!该方法已作废
 Input:			无
 Output:			无
 return:			无
 ************************************************/
pr(PortParam).Get485Serial = function()
{
    var that = this;
    $.ajax({
        type: "GET",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/Serial/ports/" + that.m_iRS485Index,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
            xhr.setRequestHeader("Content-Type", "text/xml");
        },
        success: function(xmlDoc, textStatus, xhr) {
            that.m_xmlDoc = xmlDoc;
            var xmlU = new XmlUtils(xmlDoc);

            /* $("#baudRate485").val(xmlU.val("baudRate"));
             $("#dataBits485").val(xmlU.val("dataBits"));
             $("#stopRate485").val(xmlU.val("stopBits"));
             $("#parityType485").val(xmlU.val("parityType"));
             $("#flowControl485").val(xmlU.val("flowCtrl"));
             $("#controlProtocol485").val(xmlU.val("controlProtocol"));
             $("#controlAddress485").val(xmlU.val("controlAddress"));*/

        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            alert(m_szError400);
        }
    });
}

/*************************************************
 Function:		submit
 Description:	设置串口参数信息
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(PortParam).submit = function () {

    ia(PortParam).setRS232Param();

    var rsLen = document.getElementById("485ParamList").rows.length;

    for(var i= 1; i < rsLen; i++){

        var rsNum = $('#485ParamList #itemtd' + i).html();
        var baudRate = $('#baudRateItem'+i).length > 0 ? $('#baudRateItem'+i).val(): $('#485ParamList #baudRate485' + i).html();
        var dataBit = $('#dataBitsItem'+i).length > 0 ? $('#dataBitsItem'+i).val(): $('#485ParamList #dataBits485' + i).html();
        var stopBit = $('#stopRateItem'+i).length > 0 ? $('#stopRateItem'+i).val(): $('#485ParamList #stopRate485' + i).html();
        var parityType = $('#parityTypeItem'+i).length > 0 ? $('#parityTypeItem'+i).val():  $('#485ParamList #parityType485' + i).prop('name');
        var flowCtrl = $('#flowControlItem'+i).length > 0 ? $('#flowControlItem'+i).val(): $('#485ParamList #flowControl485' + i).prop('name');

        ia(PortParam).setRS485Param(rsNum,baudRate, dataBit, stopBit, parityType, flowCtrl);
    }

}

/*************************************************
 Function:		setRS232Param
 Description:	设置RS232参数
 Input:			无
 Output:			无
 return:			无
 *************************************************/
ia(PortParam).setRS232Param = function(){

    var szXml = "<?xml version='1.0' encoding='UTF-8'?><SerialPort>";
    szXml += "<id>" +ia(PortParam).m_iRS232Index + "</id>";
    szXml += "<enabled>true</enabled>";
    szXml += "<serialPortType>RS232</serialPortType>";
    szXml += "<duplexMode>half</duplexMode>";
    szXml += "<baudRate>" +$("#baudRate232").val()+ "</baudRate>";
    szXml += "<dataBits>" +$("#dataBits232").val()+ "</dataBits>";
    szXml += "<stopBits>" +$("#stopRate232").val()+ "</stopBits>";
    szXml += "<parityType>" +$("#parityType232").val()+ "</parityType>";
    szXml += "<flowCtrl>" + $("#flowControl232").val() + "</flowCtrl>";
    szXml += "<workMode>" + $("#workMode232").val() + "</workMode>";
    szXml += "</SerialPort>";

    var xmlDoc = parseXmlFromStr(szXml);
    $.ajax({
        type: "put",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/Serial/ports/" + ia(PortParam).m_iRS232Index,
        timeout: 15000,
        processData: false,
        async: false,
        data: xmlDoc,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        complete:function(xhr, textStatus) {
            SaveState(xhr);
        }
    });
}

/*************************************************
 Function:		setRS485Param
 Description:	设置RS485参数
 Input:			    无
 Output:			无
 return:			无
 *************************************************/
ia(PortParam).setRS485Param = function(rsId,baudRate, dataBit, stopBit, parityType, flowCtrl){

    var szXml = "<?xml version='1.0' encoding='UTF-8'?><SerialPort>";
    szXml += "<id>" + rsId + "</id>";
    szXml += "<enabled>true</enabled>";
    szXml += "<serialPortType>RS485</serialPortType>";
    szXml += "<duplexMode>half</duplexMode>";
    szXml += "<baudRate>" + baudRate + "</baudRate>";
    szXml += "<dataBits>" + dataBit + "</dataBits>";
    szXml += "<stopBits>" + stopBit + "</stopBits>";
    szXml += "<parityType>" + parityType + "</parityType>";
    szXml += "<flowCtrl>" + flowCtrl + "</flowCtrl></SerialPort>";

    var xmlDoc = parseXmlFromStr(szXml);
    $.ajax({
        type: "put",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/Serial/ports/" + rsId,
        timeout: 15000,
        processData: false,
        async: false,
        data: xmlDoc,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        complete:function(xhr, textStatus) {
           SaveState(xhr);
        }
    });


}

/*************************************************
 Function:		choice485Td
 Description:	选中cell函数
 Input:	ObjTdId
 Input:	selectedItem
 Input:	tdValue
 Output:			无
 return:			无
 *************************************************/
System.choice485Td = function(ObjTdId, selectedItem,tdValue){

    var szInfo = "";
    if(ObjTdId.indexOf("baudRate") == 0){
        paramItem = "baudRate";
        szInfo = "<select name='baudRateItem" + selectedItem + "' id='baudRateItem" + selectedItem + "' class='width145'><option value='600'>600 bps</option><option value='1200'>1200 bps</option><option value='2400'>2400 bps</option><option value='4800'>4800 bps</option><option value='9600'>9600 bps</option><option value='19200'>19200 bps</option><option value='38400'>38400 bps</option><option value='57600'>57600 bps</option><option value='76800'>76800 bps</option><option value='115200'>115200 bps</option></select>";
        $("#baudRate485" + selectedItem).html(szInfo);
        $("#baudRateItem" + selectedItem).val(tdValue);
    }
    if(ObjTdId.indexOf("dataBits") == 0){
        paramItem = "dataBits";
        szInfo = "<select name='dataBitsItem" + selectedItem + "' id='dataBitsItem" + selectedItem + "' class='width85'><option value='5'>5</option><option value='6'>6</option><option value='7'>7</option><option value='8'>8</option></select>";
        $("#dataBits485" + selectedItem).html(szInfo);
        $("#dataBitsItem" + selectedItem).val(tdValue);
    }
    if(ObjTdId.indexOf("stopRate") == 0){
        paramItem = "stopRate";
        szInfo = "<select name='stopRateItem" + selectedItem + "' id='stopRateItem" + selectedItem + "' class='width85'><option value='1'>1</option><option value='2'>2</option></select>";
        $("#stopRate485" + selectedItem).html(szInfo);
        $("#stopRateItem" + selectedItem).val(tdValue);
    }
    if(ObjTdId.indexOf("parityType") == 0){
        paramItem = "parityType";
        szInfo = "<select name='parityTypeItem" + selectedItem + "' id='parityTypeItem" + selectedItem + "' class='width85'><option value='none' id='parityTypenone' name='parityTypenone'>" + getNodeValue('parityType' + ETrim('none','g')) + "</option><option value='even' id='parityTypeeven' name='parityTypeeven'>" + getNodeValue('parityType' + ETrim('even','g')) + "</option><option value='odd' id='parityTypeodd' name='parityTypeodd'>" + getNodeValue('parityType' + ETrim('odd','g')) + "</option></select>";
        $("#parityType485" + selectedItem).html(szInfo);
        $("#parityTypeItem" + selectedItem).val($('#485ParamList #parityType485' + selectedItem).prop('name'));
        selectItemVal = '';
    }
    if(ObjTdId.indexOf("flowControl") == 0){
        paramItem = "flowControl";
        szInfo = "<select name='flowControlItem" + selectedItem + "' id='flowControlItem" + selectedItem + "' class='width85'><option value='none' id='flowCtrlnone' name='flowCtrlnone'>" + getNodeValue('flowCtrl'+ ETrim('none','g')) + "</option><option value='hardware' id='flowCtrlhardware' name='flowCtrlhardware'>" + getNodeValue('flowCtrl'+ ETrim('hardware','g')) + "</option><option value='software' id='flowCtrlsoftware' name='flowCtrlsoftware'>" + getNodeValue('flowCtrl'+ ETrim('software','g')) + "</option></select>";
        $("#flowControl485" + selectedItem).html(szInfo);
        $("#flowControlItem" + selectedItem).val($('#485ParamList #flowControl485' + selectedItem).prop('name'));
        selectItemVal = '';
    }
}

/*************************************************
 Function:		getLastChoiceValue
 Description:	获取上一次选中的值并赋值给自身td 设值。
 Input:	paramItem
 Input:	m_iSelectItem
 Output:			无
 return:			无
 *************************************************/
System.getLastChoiceValue = function(paramItem, m_iSelectItem){

    if(paramItem == "baudRate"){
        $("#baudRate485" + (m_iSelectItem + 1)).html($("#baudRateItem" + (m_iSelectItem + 1)).val());
    }
    if(paramItem == "dataBits"){
        $("#dataBits485" + (m_iSelectItem + 1)).html($("#dataBitsItem" + (m_iSelectItem + 1)).val());
    }
    if(paramItem == "stopRate"){
        $("#stopRate485" + (m_iSelectItem + 1)).html($("#stopRateItem" + (m_iSelectItem + 1)).val());
    }
    if(paramItem == "parityType"){
        selectItemVal = $("#parityTypeItem" + (m_iSelectItem + 1)).val();
        $("#parityType485" + (m_iSelectItem + 1)).html(getNodeValue('parityType' + ETrim(selectItemVal,'g')));
        $("#parityType485" + (m_iSelectItem + 1)).prop("name", selectItemVal);
    }
    if(paramItem == "flowControl"){
        selectItemVal = $("#flowControlItem" + (m_iSelectItem + 1)).val();
        $("#flowControl485" + (m_iSelectItem + 1)).html(getNodeValue('flowCtrl'+ ETrim($('#flowControlItem' + (m_iSelectItem + 1)).val(),'g')));
        $("#flowControl485" + (m_iSelectItem + 1)).prop("name", selectItemVal);
    }
}

System.Select485TableTd = function(event)
{
    event = event?event:(window.event?window.event:null);
    var ObjTable = event.srcElement?event.srcElement:event.target;

    if(ObjTable.tagName == "TD")
    {
        var tdId = ObjTable.id;
        var tdValue = ObjTable.innerText;

        while(ObjTable.tagName != "TR")
        {
            ObjTable = ObjTable.parentNode;
        }
        ObjParent = ObjTable.parentNode;
        var m_iSelFileIndex = ObjTable.rowIndex - 1;
        if(m_iSelFileIndex == -1)
        {
            return;
        }
        while(ObjParent.tagName!="TABLE")
        {
            ObjParent = ObjParent.parentNode;
            if(m_iSelectItem >=  0)  //选择非本行时需要清除选择的颜色并赋值选中项。
            {
                $("#itemtd" + (m_iSelectItem + 1)).css({ color: "#39414A", background: "#ffffff" });
                $("#baudRate485" + (m_iSelectItem + 1)).css({ color: "#39414A", background: "#ffffff" });
                $("#dataBits485" + (m_iSelectItem + 1)).css({ color: "#39414A", background: "#ffffff" });
                $("#stopRate485" + (m_iSelectItem + 1)).css({ color: "#39414A", background: "#ffffff" });
                $("#parityType485" + (m_iSelectItem + 1)).css({ color: "#39414A", background: "#ffffff" });
                $("#flowControl485" + (m_iSelectItem + 1)).css({ color: "#39414A", background: "#ffffff" });

                System.getLastChoiceValue(paramItem,m_iSelectItem);
                paramItem = "";
            }

            for(var i = 1;i < ObjParent.rows.length;i ++)
            {
                if(ObjTable.rowIndex == i)
                {
                    m_iSelectItem = i - 1;

                    $("#itemtd" + (m_iSelectItem + 1)).css({ color: "#ffffff", background: "#316ac5" });
                    $("#baudRate485" + (m_iSelectItem + 1)).css({ color: "#ffffff", background: "#316ac5" });
                    $("#dataBits485" + (m_iSelectItem + 1)).css({ color: "#ffffff", background: "#316ac5" });
                    $("#stopRate485" + (m_iSelectItem + 1)).css({ color: "#ffffff", background: "#316ac5" });
                    $("#parityType485" + (m_iSelectItem + 1)).css({ color: "#ffffff", background: "#316ac5" });
                    $("#flowControl485" + (m_iSelectItem + 1)).css({ color: "#ffffff", background: "#316ac5" });

                    System.choice485Td(tdId, i,tdValue);
                }
            }
        }
    }
}

function insertRS485SerialParamList( num, baudRate, dataBits, stopBits, parityType, flowCtrl,parityTypeName, flowCtrlName,rsId){

    var ObjTr;
    var ObjTd;

    ObjTr = document.getElementById("485ParamList").insertRow(document.getElementById("485ParamList").rows.length);
    ObjTr.style.height = 22 + 'px';
    ObjTr.style.cursor = "pointer";

    for(var j = 0; j < document.getElementById('485ParamList').rows[0].cells.length; j++){
        ObjTd = ObjTr.insertCell(j);
        $(ObjTd).css({border:"1px solid #d7d7d7",background:"#ffffff",padding:"0 0 0 5px"});
        switch(j)
        {
            case 0:
                ObjTd.innerHTML = num;
                ObjTd.id = "itemtd"+ num;
                ObjTd.name = rsId;
                ObjTd.style.color = "#39414A";
                break;
            case 1:
                ObjTd.innerHTML = baudRate;
                ObjTd.id = "baudRate485"+ num;
                ObjTd.style.color = "#39414A";
                break;
            case 2:
                ObjTd.innerHTML = dataBits;
                ObjTd.id = "dataBits485"+ num;
                ObjTd.style.color = "#39414A";
                break;
            case 3:
                ObjTd.innerHTML = stopBits;
                ObjTd.id = "stopRate485"+ num;
                ObjTd.style.color = "#39414A";
                break;
            case 4:
                ObjTd.innerHTML = parityType;
                ObjTd.id = "parityType485"+ num;
                ObjTd.style.color = "#39414A";
                ObjTd.name = parityTypeName;
                break;
            case 5:
                ObjTd.innerHTML = flowCtrl;
                ObjTd.id = "flowControl485"+ num;
                ObjTd.style.color = "#39414A";
                ObjTd.name = flowCtrlName;
                break;
            default:
                break;
        }
    }
}

/*************************************************
 网口参数基本类
 *************************************************/
function NetworkParam(){
    SingletonInheritor.implement(this);
    this.sz_backupXML = null;
    this.sz_isolationXML = null;
    this.networkPortType = 0;
	this.sz_beifenDestIPAddress = null;
	this.sz_geliDestIPAddress = null;
	this.sz_beifenPortNo = null;
	this.sz_geliPortNo = null;
}
SingletonInheritor.declare(NetworkParam);

/*************************************************
 Function:		update
 Description:	更新网口参数信息
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(NetworkParam).update = function () {

    $('#SetResultTips').html('');
    $("#SaveConfigBtn").show();

    g_transStack.clear();
    var that = this;
    g_transStack.push(function () {
        that.setLxd(parent.translator.getLanguageXmlDoc(["System", "IpConfig"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);

    ia(NetworkParam).getNetworkBackupInfo();
    $('#networkModeSelect').val(ia(NetworkParam).networkPortType);
    ia(NetworkParam).changeNetworkModel(ia(NetworkParam).networkPortType);
}

/*************************************************
 Function:		getNetworkBackupInfo
 Description:	获取双网口备份配置
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(NetworkParam).getNetworkBackupInfo = function(){
    $.ajax({    //双网备份
        type: "GET",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/HIK/Bond",
        async: false,
        timeout: 15000,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {
            ia(NetworkParam).sz_backupXML = xmlDoc;

            $('#laDoubleMTU').css("color","gray");
            $('#laDoubleMacAddress').css("color","gray");

            if($(xmlDoc).find("enabled").eq(0).text()=="true"){
                ia(NetworkParam).networkPortType = 1;
            }else{
                ia(NetworkParam).networkPortType = 2;
            }

            if($(xmlDoc).find('autoNegotiation').eq(0).text() == 'true'){
                $("#mutiNetworkType").val('5');
            }else if($(xmlDoc).find('speed').eq(0).text() == '10'){
                if($(xmlDoc).find('duplex').eq(0).text() == 'half'){
                    $("#mutiNetworkType").val('1');
                }else if($(xmlDoc).find('duplex').eq(0).text() == 'full'){
                    $("#mutiNetworkType").val('2');
                }
            }else if($(xmlDoc).find('speed').eq(0).text() == '100'){

                if($(xmlDoc).find('duplex').eq(0).text() == 'half'){
                    $("#mutiNetworkType").val('3');
                }else if($(xmlDoc).find('duplex').eq(0).text() == 'full'){
                    $("#mutiNetworkType").val('4');
                }
            }else if($(xmlDoc).find('speed').eq(0).text() == '1000'){
                $("#mutiNetworkType").val('6');
            }else{
                document.getElementById('mutiNetworkType').selectedIndex = -1;
            }

            $('#DoubleNetIpAddress').val($(xmlDoc).find("ipAddress").eq(0).text());
            $('#DoubleNetSubNetMask').val($(xmlDoc).find("subnetMask").eq(0).text());
            $('#DoubleDefaultGateway').val($(xmlDoc).find("DefaultGateway").eq(0).text());
            $('#doubleMTU').val($(xmlDoc).find("MTU").eq(0).text());
            $('#doubleMacAddress').val($(xmlDoc).find("MACAddress").eq(0).text());

            $('#firstDNSAddress_backup').val($(xmlDoc).find("PrimaryDNS").eq(0).text());
            $('#personDomainAddress_backup').val($(xmlDoc).find("ipResolver").eq(0).text());
			
			$('#alarmHostAddress_backup').val($(xmlDoc).find("ipAddress").eq(0).text());//主机地址
            $('#alarmHostPort_backup').val($(xmlDoc).find("portNo").eq(0).text());//多播地址
        }
    });
	$.ajax({    //双网备份
        type: "GET",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/Event/notification/httpHost/1",
        async: false,
        timeout: 15000,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {
			ia(NetworkParam).sz_beifenPortNo = xmlDoc;
            $('#alarmHostAddress_backup').val($(xmlDoc).find("ipAddress").eq(0).text());
            $('#alarmHostPort_backup').val($(xmlDoc).find("portNo").eq(0).text());
        }
    });
	 $.ajax({    //双网备份
        type: "GET",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Streaming/channels/101",
        async: false,
        timeout: 15000,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {
			ia(NetworkParam).sz_beifenDestIPAddress = xmlDoc;
            $('#multiAddress_backup').val($(xmlDoc).find("Multicast").eq(0).find("destIPAddress").eq(0).text());//多播地址
        }
    });
}
/*************************************************
 Function:		getNetworkIsolationInfo
 Description:	获取双网口隔离配置
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(NetworkParam).getNetworkIsolationInfo = function(){

    $.ajax({    //双网隔离
        type: "GET",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces",
        async: false,
        timeout: 15000,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {

            ia(NetworkParam).sz_isolationXML = xmlDoc;

            var tempXmlDoc = parseXmlFromStr($(xmlDoc).find('ITCMultiNetParam'));

            if($(xmlDoc).find("enabled").eq(0).text()=="true"){
                ia(NetworkParam).networkPortType = 2;
            }
            var mLength = $(xmlDoc).find("NetworkInterface").length;
            for(var i=0; i< mLength; i++){

                if($(xmlDoc).find("id").eq(i).text() == '1'){    //双网口环境。 如果是多网口，那么需要在后面加业务实现。

                    $('#NetCardMode1').val($(xmlDoc).find("cardType").eq(i).text());

                    if($(xmlDoc).find("addressingType").eq(i).text() == 'static'){  // static,dynamic,apipa 如果是static，不能使用自动获取IP
                        $('#IsUseDHCPCard1').prop("disabled","disabled");
                        $('#laNetCardFetchIP1').css("color","gray");
                        $('#laModeMTU1').css("color","gray");
                        $('#laDoubleMacAddress1').css("color","gray");
                    }
					$('#NetCardMode1').val($(xmlDoc).find("addressingType").eq(i).text());
                    $('#ModeNetIpAddress1').val($(xmlDoc).find("ipAddress").eq(i).text());
                    $('#ModeNetSubNetMask1').val($(xmlDoc).find("subnetMask").eq(i).text());
                    $('#ModeDefaultGateway1').val($(xmlDoc).find("DefaultGateway").eq(i).text());
                    $('#modeMTU1').val($(xmlDoc).find("MTU").eq(i).text());
                    $('#ModeMacAddress1').val($(xmlDoc).find("MACAddress").eq(i).text());

                    if($(xmlDoc).find('autoNegotiation').eq(i).text() == 'true'){

                        $("#NetCardType1").val('5');
                    }else if($(xmlDoc).find('speed').eq(i).text() == '10'){

                        if($(xmlDoc).find('duplex').eq(i).text() == 'half'){
                            $("#NetCardType1").val('1');
                        }else if($(xmlDoc).find('duplex').eq(i).text() == 'full'){
                            $("#NetCardType1").val('2');
                        }
                    }else if($(xmlDoc).find('speed').eq(i).text() == '100'){

                        if($(xmlDoc).find('duplex').eq(i).text() == 'half'){
                            $("#NetCardType1").val('3');
                        }else if($(xmlDoc).find('duplex').eq(i).text() == 'full'){
                            $("#NetCardType1").val('4');
                        }
                    }else if($(xmlDoc).find('speed').eq(i).text() == '1000'){
                        $("#NetCardType1").val('6');
                    }else{
                        document.getElementById('NetCardType1').selectedIndex = -1;
                    }

                }else if($(xmlDoc).find("id").eq(i).text() == '2'){
                    $('#NetCardMode2').val($(xmlDoc).find("cardType").eq(i).text());
                    if($(xmlDoc).find("addressingType").eq(i).text() == 'static'){  // static,dynamic,apipa 如果是static，不能使用自动获取IP
                        $('#IsUseDHCPCard2').prop("disabled","disabled");
                        $('#laNetCardFetchIP2').css("color","gray");
                        $('#laModeMTU2').css("color","gray");
                        $('#laDoubleMacAddress2').css("color","gray");
                    }
					$('#NetCardMode2').val($(xmlDoc).find("addressingType").eq(i).text());
                    $('#ModeNetIpAddress2').val($(xmlDoc).find("ipAddress").eq(i+2).text());
                    $('#ModeNetSubNetMask2').val($(xmlDoc).find("subnetMask").eq(i).text());
                    $('#ModeDefaultGateway2').val($(xmlDoc).find("DefaultGateway").eq(i).text());
                    $('#modeMTU2').val($(xmlDoc).find("MTU").eq(i).text());
                    $('#ModeMacAddress2').val($(xmlDoc).find("MACAddress").eq(i).text());

                    if($(xmlDoc).find('autoNegotiation').eq(i).text() == 'true'){

                        $("#NetCardType2").val('5');
                    }else if($(xmlDoc).find('speed').eq(i).text() == '10'){

                        if($(xmlDoc).find('duplex').eq(i).text() == 'half'){
                            $("#NetCardType2").val('1');
                        }else if($(xmlDoc).find('duplex').eq(i).text() == 'full'){
                            $("#NetCardType2").val('2');
                        }
                    }else if($(xmlDoc).find('speed').eq(i).text() == '100'){

                        if($(xmlDoc).find('duplex').eq(i).text() == 'half'){
                            $("#NetCardType2").val('3');
                        }else if($(xmlDoc).find('duplex').eq(i).text() == 'full'){
                            $("#NetCardType2").val('4');
                        }
                    }else if($(xmlDoc).find('speed').eq(i).text() == '1000'){
                        $("#NetCardType2").val('6');
                    }else{
                        document.getElementById('NetCardType2').selectedIndex = -1;
                    }
                }

                if($(xmlDoc).find('cardTypeSupport') != null){

                    var cardTypeSupport = $(xmlDoc).find('cardTypeSupport').eq(i).text().split(','); //cardTypeSupport
                    if(cardTypeSupport.length > 0){

                        var a = 0;
                        var b = 0;
                        var c = 0;

                        for(var j=0; j< cardTypeSupport.length; j++){

                            if(cardTypeSupport[j] =='in'){
                                a++;
                            }if(cardTypeSupport[j] =='out'){
                                b++;
                            }if(cardTypeSupport[j] =='common'){ //common
                                c++;
                            }
                        }
                        $('#NetCardMode' +(i+1)).empty();

                        if(c > 0){ //普通网卡
                            $('<option id="NetCardModeOpt0" name="NetCardModeOpt0" value="0">'+getNodeValue('NetCardModeOpt0')+'</option>').appendTo('#NetCardMode' +(i+1));
                        }
                        if(a > 0){ //内网网卡
                            $('<option id="NetCardModeOpt1" name="NetCardModeOpt1" value="1">'+getNodeValue('NetCardModeOpt1')+'</option>').appendTo('#NetCardMode' +(i+1));
                        }
                        if(b > 0){ //外网网卡
                            $('<option id="NetCardModeOpt2" name="NetCardModeOpt2" value="2">'+getNodeValue('NetCardModeOpt2')+'</option>').appendTo('#NetCardMode' +(i+1));
                        }
                    }

                }
            }

            $('#modeNetworkAlarmIp').val($(xmlDoc).find("ManagerAddress").eq(0).text());
            $('#modeNetworkPort').val($(xmlDoc).find("ManagerPort").eq(0).text());
            //$('#modeDefaultRoute').val($(xmlDoc).find("DefaultRoute").eq(0).text());  //默认路由
            $('#modeDomainServerIP').val($(xmlDoc).find("PrimaryDNS").eq(0).text());  //首选DNS地址
            $('#modeLotPlayAddress').val($(xmlDoc).find("multicastIpAddr").eq(0).text());//多播地址

        }
    });
	$.ajax({    //双网隔离
        type: "GET",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/Event/notification/httpHost/1",
        async: false,
        timeout: 15000,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
        },
        success: function(xmlDoc, textStatus, xhr) {
			ia(NetworkParam).sz_geliPortNo = xmlDoc;
            $('#modeNetworkAlarmIp').val($(xmlDoc).find("ipAddress").eq(0).text());
            $('#modeNetworkPort').val($(xmlDoc).find("portNo").eq(0).text());
        }
    });
	$.ajax({    //双网隔离
        type: "GET",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Streaming/channels/101",
        async: false,
        timeout: 15000,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {
			ia(NetworkParam).sz_geliDestIPAddress = xmlDoc;
            $('#modeLotPlayAddress').val($(xmlDoc).find("Multicast").eq(0).find("destIPAddress").eq(0).text());//多播地址
        }
    });
}

/*************************************************
 Function:		submit
 Description:	提交
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(NetworkParam).submit = function () {
	var optType = $('#networkModeSelect').val();
	if (optType == '1') {  // 双网备份
		if(!CheckDIPadd($("#DoubleNetIpAddress").val(),'DoubleServerIPtips','laIpAddress')){
        return;
	    }
	    if(!CheckMaskIP($("#DoubleNetSubNetMask").val(),'DoubleServerMaskIPtips','jsMaskAdd')){
	        return;
	    }
	    if(!CheckIPAddress($("#DoubleDefaultGateway").val(),'DoubleServerGateWayIPtips','laDoubleDefaultGateWay')){
	        return;
	    }
	    if(!CheckDNSIPadd($("#firstDNSAddress_backup").val(),'firstDNStips_backup','jsFirstDNS')){
	        return;
	    }
	    if(!CheckMulticastIP($("#multiAddress_backup").val(),'multiAddressTips_backup','laMulticast')){
	        return;
	    }
	    if(!CheckIPAddress($("#alarmHostAddress_backup").val(),'alarmHostAddressTips_backup','laAlarmHostAddress')){
	        return;
	    }
	}else if (optType == '2') {
		if(!CheckDIPadd($("#ModeNetIpAddress1").val(),'ModeServerIPtips1','laIpAddress')){
	        return;
	    }
	    if(!CheckMaskIP($("#ModeNetSubNetMask1").val(),'ModeServerMaskIPtips1','jsNetMask')){
	        return;
	    }
	    if(!CheckIPAddress($("#ModeDefaultGateway1").val(),'ModeServerGateWayIPtips1','laDoubleDefaultGateWay')){
	        return;
	    }
	    if(!CheckDIPadd($("#ModeNetIpAddress2").val(),'ModeServerIPtips2','laIpAddress')){
	        return;
	    }
	    if(!CheckMaskIP($("#ModeNetSubNetMask2").val(),'ModeServerMaskIPtips2','jsNetMask')){
	        return;
	    }
	    if(!CheckIPAddress($("#ModeDefaultGateway2").val(),'ModeServerGateWayIPtips2','laDoubleDefaultGateWay')){
	        return;
	    }
	    if(!CheckIPAddress($("#modeNetworkAlarmIp").val(),'doubleModeNetworkAlarmtips','laAlarmHostAddress')){
	        return;
	    }
	    if(!CheckDNSIPadd($("#modeDomainServerIP").val(),'doubleModeDomainIpTips','jsFirstDNS')){
	        return;
	    }
	    if(!CheckMulticastIP($("#modeLotPlayAddress").val(),'doubleModeLotPlayTips','laLotPlayAddress')){
	        return;
	    }
	};
    
    var XmlDoc = new createxmlDoc();
    var Instruction = XmlDoc.createProcessingInstruction("xml","version='1.0' encoding='utf-8'");
    XmlDoc.appendChild(Instruction);
    var szURL = "";
    
    if(optType == '1'){ 
	//双网备份
		var BondObject = XmlDoc.createElement("Bond");
		
		Element = XmlDoc.createElement("id");
        text =  XmlDoc.createTextNode("1");
        Element.appendChild(text);
        BondObject.appendChild(Element);
		
        Element = XmlDoc.createElement("enabled");
        text =  XmlDoc.createTextNode("true");
        Element.appendChild(text);
        BondObject.appendChild(Element);
		
		Element = XmlDoc.createElement("workMode");
        text =  XmlDoc.createTextNode($(ia(NetworkParam).sz_backupXML).find("workMode").eq(0).text());
        Element.appendChild(text);
        BondObject.appendChild(Element);
        
		Element = XmlDoc.createElement("primaryIf");
        text =  XmlDoc.createTextNode($(ia(NetworkParam).sz_backupXML).find("primaryIf").eq(0).text());
        Element.appendChild(text);
        BondObject.appendChild(Element);
		
		var slaveIfListObject= XmlDoc.createElement("slaveIfList");
        BondObject.appendChild(slaveIfListObject);
		
		Element = XmlDoc.createElement("ethernetIfId");
        text =  XmlDoc.createTextNode($(ia(NetworkParam).sz_backupXML).find("ethernetIfId").eq(0).text());
        Element.appendChild(text);
        slaveIfListObject.appendChild(Element);
		
		IPAdressObject = XmlDoc.createElement("IPAdress");
        slaveIfListObject.appendChild(IPAdressObject);
		
		Element = XmlDoc.createElement("ipVersion");
        text =  XmlDoc.createTextNode($(ia(NetworkParam).sz_backupXML).find("ipVersion").eq(0).text());
        Element.appendChild(text);
        IPAdressObject.appendChild(Element);

        Element = XmlDoc.createElement("addressingType");
        text =  XmlDoc.createTextNode($(ia(NetworkParam).sz_backupXML).find("addressingType").eq(0).text());
        Element.appendChild(text);
        IPAdressObject.appendChild(Element);

        Element = XmlDoc.createElement("ipAddress");
        text =  XmlDoc.createTextNode($('#DoubleNetIpAddress').val());
        Element.appendChild(text);
        IPAdressObject.appendChild(Element);

        Element = XmlDoc.createElement("subnetMask");
        text =  XmlDoc.createTextNode($('#DoubleNetSubNetMask').val());
        Element.appendChild(text);
        IPAdressObject.appendChild(Element);

        DefaultGatewayObject = XmlDoc.createElement("DefaultGateway");
        IPAdressObject.appendChild(DefaultGatewayObject);
		
		Element = XmlDoc.createElement("ipAddress");
        text =  XmlDoc.createTextNode($('#DoubleDefaultGateway').val());
        Element.appendChild(text);
        DefaultGatewayObject.appendChild(Element);
		
		PrimaryDNSObject = XmlDoc.createElement("PrimaryDNS");
        IPAdressObject.appendChild(PrimaryDNSObject);
		
		Element = XmlDoc.createElement("ipAddress");
        text =  XmlDoc.createTextNode($('#firstDNSAddress_backup').val());
        Element.appendChild(text);
        PrimaryDNSObject.appendChild(Element);

        SecondDNSObject = XmlDoc.createElement("SecondDNS");
        IPAdressObject.appendChild(SecondDNSObject);
		
		Element = XmlDoc.createElement("ipAddress");
        text =  XmlDoc.createTextNode($('#DoubleNetSubNetMask').val());
        Element.appendChild(text);
        SecondDNSObject.appendChild(Element);

        linkObject = XmlDoc.createElement("Link");

        Element = XmlDoc.createElement("MACAddress");
        text =  XmlDoc.createTextNode($('#doubleMacAddress').val());
        Element.appendChild(text);
        linkObject.appendChild(Element);

        var netCardType = $('#mutiNetworkType').val();

        var negotiationEnabled = "false";
        var speedVal = "";
        var duplexVal = "";

        switch (netCardType){
            case '5':
                negotiationEnabled = "true";
                speedVal = "10";
                duplexVal = "full";
                break;
            case '1':
                negotiationEnabled = "false";
                speedVal = "10";
                duplexVal = "half";
                break;
            case '2':
                negotiationEnabled = "false";
                speedVal = "10";
                duplexVal = "full";
                break;
            case '3':
                negotiationEnabled = "false";
                speedVal = "100";
                duplexVal = "half";
            case '4':
                negotiationEnabled = "false";
                speedVal = "100";
                duplexVal = "full";
                break;
            case '6':
                negotiationEnabled = "false";
                speedVal = "1000";
                duplexVal = "full";
                break;
            default :
                negotiationEnabled = "false";
                speedVal = "";
                duplexVal = "";
                break;
        }

        Element = XmlDoc.createElement("autoNegotiation");
        text =  XmlDoc.createTextNode(negotiationEnabled);
        Element.appendChild(text);
        linkObject.appendChild(Element);

        Element = XmlDoc.createElement("speed");
        text =  XmlDoc.createTextNode(speedVal);
        Element.appendChild(text);
        linkObject.appendChild(Element);

        Element = XmlDoc.createElement("duplex");
        text =  XmlDoc.createTextNode(duplexVal);
        Element.appendChild(text);
        linkObject.appendChild(Element);

        Element = XmlDoc.createElement("MTU");
        text =  XmlDoc.createTextNode($('#doubleMTU').val());
        Element.appendChild(text);
        linkObject.appendChild(Element);
		BondObject.appendChild(linkObject);
        
        XmlDoc.appendChild(BondObject);

        szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/HIK/Bond/1"
		
		$.ajax({
	        type: "put",
	        url: szURL,
	        timeout: 15000,
	        processData: false,
	        data: XmlDoc,
	        beforeSend: function(xhr) {
	            xhr.setRequestHeader("If-Modified-Since", "0");
	        },
	        complete:function(xhr, textStatus) {
	            ia(NetworkParam).networkPortType =  $('#networkModeSelect').val();
	            SaveState(xhr);
	        },
	        error: function(xhr, textStatus, errorThrown) {
	            alert(m_szError6)
	        }
	    });
    }else if(optType == '2'){ //双网隔离
		var resultObj = []
		for(var szIndex =1;szIndex<=2;szIndex++){		
			var XmlDoc = new createxmlDoc();
	        var Instruction = XmlDoc.createProcessingInstruction("xml","version='1.0' encoding='utf-8'");
	        XmlDoc.appendChild(Instruction);
			
			var NetworkInterfaceObject = XmlDoc.createElement("NetworkInterface");
			
			idObject = XmlDoc.createElement("id");
			text =  XmlDoc.createTextNode(szIndex);
	        idObject.appendChild(text);
	        NetworkInterfaceObject.appendChild(idObject);
			
			IPAddressObject = XmlDoc.createElement("IPAddress");
	        NetworkInterfaceObject.appendChild(IPAddressObject);
			
			Element = XmlDoc.createElement("ipVersion");
	        text =  XmlDoc.createTextNode($(ia(NetworkParam).sz_isolationXML).find("ipVersion").eq(szIndex-1).text());
	        Element.appendChild(text);
	        IPAddressObject.appendChild(Element);
			
			Element = XmlDoc.createElement("addressingType");
	        text =  XmlDoc.createTextNode($(ia(NetworkParam).sz_isolationXML).find("addressingType").eq(szIndex-1).text());
	        Element.appendChild(text);
	        IPAddressObject.appendChild(Element);
			
			Element = XmlDoc.createElement("ipAddress");
	        text =  XmlDoc.createTextNode($("#ModeNetIpAddress"+szIndex).val());
	        Element.appendChild(text);
	        IPAddressObject.appendChild(Element);
			
			Element = XmlDoc.createElement("subnetMask");
	        text =  XmlDoc.createTextNode($("#ModeNetSubNetMask"+szIndex).val());
	        Element.appendChild(text);
	        IPAddressObject.appendChild(Element);
			
			DefaultGatewayObject = XmlDoc.createElement("DefaultGateway");
	        IPAddressObject.appendChild(DefaultGatewayObject);
			
			Element = XmlDoc.createElement("ipAddress");
	        text =  XmlDoc.createTextNode($("#ModeDefaultGateway"+szIndex).val());
	        Element.appendChild(text);
	        DefaultGatewayObject.appendChild(Element);
			
			PrimaryDNSObject = XmlDoc.createElement("PrimaryDNS");
	        IPAddressObject.appendChild(PrimaryDNSObject);
			
			Element = XmlDoc.createElement("ipAddress");
	        text =  XmlDoc.createTextNode($("#modeDomainServerIP").val());
	        Element.appendChild(text);
	        PrimaryDNSObject.appendChild(Element);
			
			ExtensionsObject = XmlDoc.createElement("Extensions");
	        NetworkInterfaceObject.appendChild(ExtensionsObject);
			
			LinkObject = XmlDoc.createElement("Link");
	        ExtensionsObject.appendChild(LinkObject);
			
	        Element = XmlDoc.createElement("MACAddress");
	        text =  XmlDoc.createTextNode($(ia(NetworkParam).sz_isolationXML).find("MACAddress").eq(szIndex-1).text());
	        Element.appendChild(text);
	        LinkObject.appendChild(Element);

	        var speed = $(ia(NetworkParam).sz_isolationXML).find("speed").eq(szIndex-1).text();
	        var duplex = $(ia(NetworkParam).sz_isolationXML).find("duplex").eq(szIndex-1).text();

	        var cardType = $("#NetCardType"+szIndex).val();
	        if(cardType == '5'){
	        	Element = XmlDoc.createElement("autoNegotiation");
		        text =  XmlDoc.createTextNode("true");
		        Element.appendChild(text);
		        LinkObject.appendChild(Element);
	        }else{
	        	Element = XmlDoc.createElement("autoNegotiation");
		        text =  XmlDoc.createTextNode("false");
		        Element.appendChild(text);
		        LinkObject.appendChild(Element);
	        }

	        if (cardType == '1') {
	        	speed = 10;
	        	duplex = 'half'
	        }else if (cardType == '2') {
	        	speed = 10;
	        	duplex = 'full';
	        }else if (cardType == '3') {
	        	speed = 100;
	        	duplex = 'half';
	        }else if (cardType == '4') {
	        	speed = 100;
	        	duplex = 'full';
	        }
			
			Element = XmlDoc.createElement("speed");
	        text =  XmlDoc.createTextNode(speed);
	        Element.appendChild(text);
	        LinkObject.appendChild(Element);
			
			Element = XmlDoc.createElement("duplex");
	        text =  XmlDoc.createTextNode(duplex);
	        Element.appendChild(text);
	        LinkObject.appendChild(Element);
			
			Element = XmlDoc.createElement("MTU");
	        text =  XmlDoc.createTextNode($(ia(NetworkParam).sz_isolationXML).find("MTU").eq(szIndex-1).text());
	        Element.appendChild(text);
	        LinkObject.appendChild(Element);
			
			XmlDoc.appendChild(NetworkInterfaceObject);
			
	        szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces/"+szIndex
			
			var iidx = szIndex;

			$.ajax({
		        type: "put",
		        url: szURL,
		        timeout: 15000,
		        processData: false,
		        data: XmlDoc,
		        beforeSend: function(xhr) {
		            xhr.setRequestHeader("If-Modified-Since", "0");
		        },
		        complete:function(xhr, textStatus) {
		            ia(NetworkParam).networkPortType =  $('#networkModeSelect').val();
		            resultObj.push({
		            	xhr: xhr,
		            	error: !(xhr.status >= 200 && xhr.status < 300)
		            })

		            if (resultObj[0] && resultObj[1]) {
		            	var r = resultObj[0].error ? resultObj[0].xhr : resultObj[1].xhr;
		            	SaveState(r);
		            };
		            // SaveState(xhr);
		        },
		        error: function(xhr, textStatus, errorThrown) {
		            // alert(m_szError6)
		        }
		    });
		}
	}
	if(optType == '1'){
		xmlDoc = parseXmlFromStr(xmlToStr(ia(NetworkParam).sz_beifenPortNo));
		$(xmlDoc).find("ipAddress").eq(0).text($('#alarmHostAddress_backup').val());
		$(xmlDoc).find("portNo").eq(0).text($('#alarmHostPort_backup').val());
		$.ajax({    //双网备份
			type: "put",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/Event/notification/httpHost/1",
			async: false,
			timeout: 15000,
			processData: false,
			data: xmlDoc,
			beforeSend: function(xhr) {
			    xhr.setRequestHeader("If-Modified-Since", "0");
			},
			success: function(xmlDoc, textStatus, xhr) {
			}
	    });
		xmlDoc = parseXmlFromStr(xmlToStr(ia(NetworkParam).sz_beifenDestIPAddress));
		$(xmlDoc).find("Multicast").eq(0).find("destIPAddress").eq(0).text($('#multiAddress_backup').val());//多播地址
	    $.ajax({    //双网备份
	        type: "put",
	        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Streaming/channels/101",
	        async: false,
	        timeout: 15000,
			processData: false,
			data: xmlDoc,
	        beforeSend: function(xhr) {
	            xhr.setRequestHeader("If-Modified-Since", "0");
	        }
	    });
	}else if(optType == '2'){
		xmlDoc = parseXmlFromStr(xmlToStr(ia(NetworkParam).sz_geliPortNo));
		$(xmlDoc).find("ipAddress").eq(0).text($('#modeNetworkAlarmIp').val());
        $(xmlDoc).find("portNo").eq(0).text($('#modeNetworkPort').val());
		$.ajax({    //双网隔离
	        type: "put",
	        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/Event/notification/httpHost/1",
	        async: false,
	        timeout: 15000,
			processData: false,
			data: xmlDoc,
	        beforeSend: function(xhr) {
	            xhr.setRequestHeader("If-Modified-Since", "0");            
	        },
	        success: function(xmlDoc, textStatus, xhr) {
	        }
	    });
	
		xmlDoc = parseXmlFromStr(xmlToStr(ia(NetworkParam). sz_geliDestIPAddress));
		$(xmlDoc).find("Multicast").eq(0).find("destIPAddress").eq(0).text($('#modeLotPlayAddress').val());//多播地址
	    $.ajax({    //双网隔离
	        type: "put",
	        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Streaming/channels/101",
	        async: false,
	        timeout: 15000,
			processData: false,
			data: xmlDoc,
	        beforeSend: function(xhr) {
	            xhr.setRequestHeader("If-Modified-Since", "0");	            
	        },
	        success: function(xmlDoc, textStatus, xhr) {
	        }
	    });
	}
	autoResizeIframe();
}

/*************************************************
 Function:		modifyNetworkEnabledInfo
 Description:	修改 另外一个网口类型的使能.
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(NetworkParam).modifyNetworkEnabledInfo = function(){

    var optType = $('#networkModeSelect').val();

    var sz_enabledURL = "";
    var sz_enabledXML = "";

    if(optType == '2'){   //双网口隔离
        sz_enabledXML = ia(NetworkParam).sz_isolationXML;
        $(sz_enabledXML).find("enabled").eq(0).text("false");
        sz_enabledURL =  m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCMultiNetCfg";
    }else{              //双网口备份
        sz_enabledXML = ia(NetworkParam).sz_backupXML;
        $(sz_enabledXML).find("enabled").eq(0).text("false");
        sz_enabledURL =  m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/HIK/Bond";
    }
    $.ajax({
        type: "put",
        url:sz_enabledURL,
        async: false,
        timeout: 15000,
        processData: false,
        data: sz_enabledXML,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        complete:function(xhr, textStatus) {
            SaveState(xhr);
        }
    });
}

/*************************************************
 Function:		changeNetworkModel
 Description:	切换双网口模式的方法
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(NetworkParam).changeNetworkModel = function(modalTypeId){

    if(modalTypeId == "1"){

        $('#DoubleNetworkBackupDiv').css("display","block");
        $('#DoubleNetworkIsolationDiv').css("display","none");

        ia(NetworkParam).getNetworkBackupInfo();

    }else if(modalTypeId == "2"){

        $('#DoubleNetworkBackupDiv').css("display","none");
        $('#DoubleNetworkIsolationDiv').css("display","block");

        ia(NetworkParam).getNetworkIsolationInfo();
    }
    autoResizeIframe();
}

/*************************************************
 交通采集参数类
 *************************************************/
function TrafficParam() {
    SingletonInheritor.implement(this);
}
SingletonInheritor.declare(TrafficParam);

TrafficParam.changeTrafficInfo = function(){
    if($('#trafficParamEnable').prop("checked")){
        $('#trafficContentDiv').css("display","block");
    }else{
        $('#trafficContentDiv').css("display","none");
    }
}

/*************************************************
 Function:		update
 Description:	更新交通采集参数信息
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(TrafficParam).update = function () {

    $('#trafficParamEnable').prop("checked",false);
    $('#SetResultTips').html('');
    $("#SaveConfigBtn").show();
    HWP.Stop(0);
    g_transStack.clear();
    var that = this;
    g_transStack.push(function () {
        that.setLxd(parent.translator.getLanguageXmlDoc(["System", "TrafficParam"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);

    $.ajax({
        type: "GET",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/trafficParam",
        async: false,
        timeout: 15000,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {
            $("#trafficParamEnable").prop("checked", ($(xmlDoc).find("enable").eq(0).text() == "true" ? true:false));
            TrafficParam.changeTrafficInfo();
            $("#statisticsMinute").val($(xmlDoc).find("statisticsMinute").eq(0).text());
        }
    });

    autoResizeIframe();
}
/*************************************************
 Function:		submit
 Description:	设置交通采集参数信息
 Input:			无
 Output:			无
 return:			无
 *************************************************/
pr(TrafficParam).submit = function () {
    if(!CheackServerIDIntNum($("#statisticsMinute").val(),"statisticsMinutetips","lastatisticsMinute",0,43200)) {
        $("#statisticsMinute").focus();
        return;
    }
    var szXml = "<?xml version='1.0' encoding='UTF-8'?><trafficParam>";
    szXml += "<enable>" + $("#trafficParamEnable").prop("checked").toString() + "</enable>";
    szXml += "<statisticsMinute>" + $("#statisticsMinute").val() + "</statisticsMinute></trafficParam>";

    var xmlDoc = parseXmlFromStr(szXml);
    $.ajax({
        type: "put",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/trafficParam",
        timeout: 15000,
        processData: false,
        data: xmlDoc,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        complete:function(xhr, textStatus) {
            SaveState(xhr);
        }
    });
}

function PortConfig() {
    SingletonInheritor.implement(this);
}
SingletonInheritor.declare(PortConfig);
pr(PortConfig).update = function() {
    $('#SetResultTips').html('');
    $("#SaveConfigBtn").show();
    g_transStack.clear();
    var that = this;
    g_transStack.push(function() {
        that.setLxd(parent.translator.getLanguageXmlDoc(["System", "PortConfig"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);
    initPortConfig();
}


function Service() {
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(Service);

(function () {
	/************************************************
	 Function:        initCSS 类方法
	 Description:    初始化CSS
	 Input:            无
	 Output:            无
	 return:            无
	 ************************************************/
	/*Service.prototype.initCSS = function () {
		
	};*/
	/***********************************************
	 Function:        Service
	 Description:    更新服务
	 Input:            无
	 Output:            无
	 return:            无
	 ***********************************************/
	Service.prototype.update = function () {
		if ($.browser.msie && parseInt($.browser.version, 10) == 6) {
			$(".timehidden").hide();
			$(".232hidden").hide();
			$(".485hidden").hide();
			$("#seHardType").change();
		}
		$("#SaveConfigBtn").show();
		window.parent.$("#dvErrorTips").hide().html("");
		$("#SetResultTips").html("");

		g_transStack.clear();
		var that = this;
		g_transStack.push(function () {
			that.setLxd(parent.translator.getLanguageXmlDoc(["System", "Service"]));
			parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
			parent.translator.translatePage(that.getLxd(), document);
		}, true);
		// this.getHardwareService();
		this.getTelnetEnable();
	}

	/***********************************************
	 Function:       getTelnetEnable
	 Description:    获取Telnet是否启用
	 Input:          无
	 Output:         无
	 return:         无
	 ***********************************************/
	Service.prototype.getTelnetEnable = function () {
		$.ajax({
			type:"GET",
			url:m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/telnetd",
			beforeSend:function (xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success:function (xmlDoc, textStatus, xhr) {
				$("#dvSoftwareArea").show();
				$("#chEnableTelnet").prop("checked", $(xmlDoc).find("enabled").eq(0).text() == "true");
				$("#chRadarMsgEnabled").prop("checked", $(xmlDoc).find("RadarMsgEnabled").eq(0).text() == "true");
			},
			error:function (xhr, textStatus, errorThrown) {
				$("#dvSoftwareArea").hide();
			}
		});
	}
	/***********************************************
	 Function:       submit
	 Description:    设置服务
	 Input:          无
	 Output:         无
	 return:         无
	 ***********************************************/
	Service.prototype.submit = function () {
		
		//设置Telnet
		var szXml = "<?xml version='1.0' encoding='UTF-8'?><Telnetd><enabled>"+$("#chEnableTelnet").prop("checked").toString()+"</enabled><RadarMsgEnabled>"+$("#chRadarMsgEnabled").prop("checked").toString()+"</RadarMsgEnabled></Telnetd>";
		xmlDoc = parseXmlFromStr(szXml);
		$.ajax({
			type:"PUT",
			url:m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/telnetd",
			data:xmlDoc,
			processData:false,
			beforeSend:function (xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			complete:function (xhr, textStatus) {
				SaveState(xhr);
			}
		});
	}
})(); // Service