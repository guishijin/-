var sliderBright = null;
var sliderContrast = null;
var sliderSaturation = null;
var sliderHue = null;
var sliderGain = null;
var sliderSharpness = null;
var sliderDayNightFilterTime = null;
var sliderWDRLevel1 = null;
var sliderWDRLevel2 = null;
var sliderWDRContrastLevel = null;
var sliderBLCLevel = null;
var sliderWhiteBlanceRed = null;
var sliderWhiteBlanceBlue = null;
var sliderAutoIrisLevel = null;
var sliderBlackPwl = null;
var SliderSnapGain = null;
var generalLevel = null;
var interFrameNoiseReduceLevel = null;
var frameNoiseReduceLevel = null;
var g_oSliderDehazeLevel = null;
var g_oSliderEISLevel = null;
var g_oSliderCSLevel = null;
var g_oSliderHLCLevel = null;
var g_oSliderExpCompLevel = null;
var g_oIRLightBrightSlider = null;
var g_oIRLightSenSlider = null;
var g_oSliderGamaCorrLevel = null;
var g_bSupportBlackPwl = null;
var g_oSliderDarkEnhanceLevel = null;
var sliderSnapContrast = null;

var DayNightFilterThSlider = null;
var ExceptionCatchThSlider = null;

var m_VideoEffectBright = 0;                //视频亮度信息
var m_VideoEffectContrast = 0;              //视频对比度信息
var m_VideoEffectSaturation = 0;      		//视频饱和度信息
var m_VideoEffectHue = 0;             		//视频色度信息
var isSupportGain = false;            		//是否支持增益
var isSupportWDRLevel = false;        		//是否支持宽动态等级
var isSupportWDRLevel1 = false;       		//是否支持宽动态等级1
var isSupportWDRLevel2 = false;       		//是否支持宽动态等级2
var isSupportWDRContrastLevel = false;		//是否支持宽动态对比度等级
var isSupportBLCLevel = false;        		//是否支持背光补偿等级
var isSupportBLCMode = false;       		//是否支持背光补偿区域
var isSupportWhiteBlanceRed = false;		//是否支持白平衡红增益
var isSupportWhiteBlanceBlue = false;		//是否支持白平衡蓝增益
var isSupportAutoIrisLevel = false;		//是否支持自动光圈灵敏度
var g_IsSupportDehaze = false;		    //是否支持去雾
var g_IsSupportDehazeLevel = false;		//是否支持去雾等级
var g_IsSupportDayNightLevel = false;   //是否支持日夜转换灵敏度
var g_bSupportShutter = false;          //是否支持快门
var g_bSupportIris = false;          //是否支持光圈
var g_bSupportSharpness = false;     //是否支持锐度

var DSSLevelEnabled = 0;

//var m_szDefaultFlipStyle = "";              //存储默认镜像翻转方向
var m_szDefaultBLCMode = "";                //存储默认背光补偿模式
var m_strSnapFileName = "";

/*************************************************
Function:		GetFrontParaConfig
Description:	获取前端参数
Input:			无
Output:			无
return:			无
*************************************************/
function GetFrontParaConfig()
{
	var szInfo = getNodeValue('laPlugin');
	if(checkPlugin('1', szInfo, 1, 'textoverlay'))
	{
		if(!CompareFileVersion())
		{
			UpdateTips();
		}

		if (!HWP.wnds[0].isPlaying)
		{
			setTimeout(function() {
				if (HWP.Play() !== 0) {
					alert(getNodeValue("previewfailed"));
				}
			}, 10);
		}
	}
	$.ajax(
	{
		type: "GET",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1",
		async: false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr)
		{
			GetFrontParaCapabilities(xmlDoc);
		}
	});
}
/*************************************************
Function:		延时赋值
Description:	setValueDelay
Input:			无
Output:			无
return:			无
*************************************************/
function setValueDelayIE6(szId, oXml, szXmlNode, szValue)
{
	if($.browser.msie && parseInt($.browser.version, 10) == 6)
	{
		setTimeout(function()
	    {
		    if(szValue == undefined || szValue == null || szValue == "")
		    {
			    $("#" + szId).val( $(oXml).find(szXmlNode).eq(0).text() );
		    }
		    else
		    {
			    $("#" + szId).val(szValue);
		    }
	   },  20);
	}
	else
	{
		if(szValue == undefined || szValue == null || szValue == "")
		{
			$("#" + szId).val( $(oXml).find(szXmlNode).eq(0).text() );
		}
		else
		{
			$("#" + szId).val(szValue);
		}
	}
}
/*************************************************
Function:		GetFrontParaCapabilities
Description:	获取设备前端参数能力集
Input:			xmlDocVal 前端参数的实际值
Output:			无
return:			无
*************************************************/
function GetFrontParaCapabilities(xmlDocVal)
{
	var xmlDoc1 = xmlDocVal;
	$.ajax(
	{
		type: "GET",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/capabilities",
		async: false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr)
		{
            //是否启用ICR配置
            if($(xmlDoc).find("ICRCtrl_Preset").length > 0 || $(xmlDoc).find("ICRCtrl_Mode").length > 0){

//                $('#icrModeOpts').val($(xmlDoc1).find('ICRMode').eq(0).text());

                if($(xmlDoc).find("ICRCtrl_Preset").length > 0){  //预置点个数大于0

                    ia(BaseVideoSettings).g_presetModeParam = 1;

                }else if($(xmlDoc).find("ICRCtrl_Mode").length > 0){

                    ia(BaseVideoSettings).g_presetModeParam = 0;
                }
                ia(BaseVideoSettings).changeICRMode();

            }else{
                $('#icrParamSettingDiv').hide();
            }
            
            //饱和度
            if($(xmlDoc).find("Color").eq(0).find('saturationLevel').length > 0)
            {
                $("#VideoSaturation_tr").show();
                sliderSaturation.wsetValue(parseInt($(xmlDoc1).find('saturationLevel').eq(0).text(), 10));
                g_transStack.push(function() { sliderSaturation.setTitle(getNodeValue('laSaturation') + ":" + sliderSaturation.getValue()); }, true);
            }
            //色度
            if($(xmlDoc).find("Color").eq(0).find('hueLevel').length > 0)
            {
                $("#VideoHue_tr").show();
                sliderHue.wsetValue(parseInt($(xmlDoc1).find('hueLevel').eq(0).text(), 10));
                g_transStack.push(function() { sliderHue.setTitle(getNodeValue('laHue') + ":" + sliderHue.getValue()); }, true);
            }
            //增益
            if($(xmlDoc).find('GainLevel').length > 0)
            {
                isSupportGain = true;
                $("#VideoGain_tr").show();
                sliderGain.wsetValue(parseInt($(xmlDoc1).find('GainLevel').eq(0).text(), 10));
                g_transStack.push(function() { sliderGain.setTitle(getNodeValue('laGain') + ":" + sliderGain.getValue()); }, true);
            }
            //锐度模式
            if($(xmlDoc).find('SharpnessMode').length > 0)
            {
                $("#dvSharpnessMode").show();
                var szSharpnessModeOptions = $(xmlDoc).find('SharpnessMode').eq(0).attr("opt").split(",");
                insertOptions2Select(szSharpnessModeOptions, ["auto", "manual"], ["aModeAuto", "aModeManual"], "selSharpnessMode");
                setValueDelayIE6("selSharpnessMode", xmlDoc1, "SharpnessMode");
            }
            //锐度
            if($(xmlDoc).find('SharpnessLevel').length > 0)
            {
                g_bSupportSharpness = true;
                $("#Sharpness_tr").show();
                sliderSharpness.wsetValue(parseInt($(xmlDoc1).find('SharpnessLevel').eq(0).text(), 10));
                g_transStack.push(function() { sliderSharpness.setTitle(getNodeValue('laSharpness') + ":" + sliderSharpness.getValue()); }, true);
            }
            
			//抓拍对比度
            if($(xmlDoc).find("capContrastLevel").length > 0)
            {
                $("#SnapContrast_tr").show();
                sliderSnapContrast.wsetValue(parseInt($(xmlDoc1).find('capContrastLevel').eq(0).text(), 10));
                g_transStack.push(function() { sliderSnapContrast.setTitle(getNodeValue('laSnapContrast') + ":" + sliderSnapContrast.getValue()); }, true);
            }
            //黑电平
            if($(xmlDoc).find('BlackPwl').length > 0)
            {
                g_bSupportBlackPwl = true;
                $("#BlackPwl_tr").show();
                sliderBlackPwl.wsetValue(parseInt($(xmlDoc1).find('blackPwlLevel').eq(0).text(), 10));
                g_transStack.push(function() { sliderBlackPwl.setTitle(getNodeValue('laBlackPwl') + ":" + sliderBlackPwl.getValue()); }, true);
            }
            if($(xmlDoc).find('resetImage').length > 0)
            {
                $("#ImageReset_tr").show();
            }
            //聚焦模式
            if($(xmlDoc).find('FocusStyle').length > 0)
            {
                $("#FocusMode_tr").show();
                var szFocusStyleOptions = $(xmlDoc).find('FocusStyle').eq(0).attr("opt").split(",");
                insertOptions2Select(szFocusStyleOptions, ["AUTO", "MANUAL", "SEMIAUTOMATIC"], ["aModeAuto", "aModeManual", "FocusModeAutoManual"], "FocusMode");
                setValueDelayIE6("FocusMode", xmlDoc1, "FocusStyle");
            }
            //曝光模式
            if($(xmlDoc).find('ExposureType').length > 0)
            {
                $("#IrisMode_tr").show();
                var szExposureTypeOptions = $(xmlDoc).find('ExposureType').eq(0).attr("opt").split(",");
                insertOptions2Select(szExposureTypeOptions, ["auto", "IrisFirst", "manual", "ShutterFirst", "gainFirst"], ["aModeAuto", "IrisFirst", "aModeManual", "ShutterFirst", "GainFirst"], "IrisMode");
                setValueDelayIE6("IrisMode", xmlDoc1, "ExposureType");
            }
            //自动光圈灵敏度
            if($(xmlDoc).find('autoIrisLevel').length > 0)
            {
                isSupportAutoIrisLevel = true;
                $("#AutoIrisLevel_tr").show();
                sliderAutoIrisLevel.wsetValue(parseInt($(xmlDoc1).find('autoIrisLevel').eq(0).text(), 10));
                g_transStack.push(function() { sliderAutoIrisLevel.setTitle(getNodeValue('laAutoIrisLevel') + ":" + sliderAutoIrisLevel.getValue()); }, true);
            }
            //视频快门速度
            if($(xmlDoc).find('ShutterLevel').length > 0)
            {
                g_bSupportShutter = true;
                $("#Shutter_tr").show();
                SutterMin = parseInt($(xmlDoc).find('ShutterLevel').eq(0).attr("min"), 10);
                ShutterMax = parseInt($(xmlDoc).find('ShutterLevel').eq(0).attr("max"), 10);
                $("#Shutter").val($(xmlDoc1).find('ShutterLevel').eq(0).text());
            }
            
            //JPEG图片大小
            if($(xmlDoc).find('JPEGParam').length > 0)
            {
                $("#dvJpegParam_tr").show();
                JPEGSizeMin = parseInt($(xmlDoc).find('JPEGSize').eq(0).attr("min"), 10);
                JPEGSizeMax = parseInt($(xmlDoc).find('JPEGSize').eq(0).attr("max"), 10);
                $("#JPEGSize").val($(xmlDoc1).find('JPEGSize').eq(0).text());
            }
            //光圈
            if($(xmlDoc).find('IrisLevel').length > 0)
            {
                g_bSupportIris = true;
                $("#IrisLevel_tr").show();
                var IrisLevelOptions = $(xmlDoc).find('IrisLevel').eq(0).attr("opt").split(",");
                for(i = 0;i < IrisLevelOptions.length; i++)
                {
                    if("close" == IrisLevelOptions[i])
                    {
                        $("<option value='close' name='aStyleClose'></option>").appendTo("#IrisLevel");
                    }
                    else
                    {
                        $("<option value='"+ IrisLevelOptions[i] +"'>"+ IrisLevelOptions[i] +"</option>").appendTo("#IrisLevel");
                    }
                }
                setValueDelayIE6("IrisLevel", xmlDoc1, "IrisLevel");
            }
            //最小聚焦限制
            if($(xmlDoc).find('FocusLimited').length > 0)
            {
                FocusLimitedenable = 1;
                $("#FocusLimited").empty();
                $("#FocusLimited_tr").show();
                var FocusLimitedOptions = $(xmlDoc).find('FocusLimited').eq(0).attr("opt").split(",");
                for(i = 0;i < FocusLimitedOptions.length; i++)
                {
                    $("<option value='"+ FocusLimitedOptions[i] +"'>"+ FocusLimitedOptions[i] +"</option>").appendTo("#FocusLimited");
                }
                setValueDelayIE6("FocusLimited", xmlDoc1, "FocusLimited");
            }
            //低照度电子快门
            if($(xmlDoc).find('DSS').length > 0)
            {
                if($(xmlDoc).find('DSS').eq(0).children().length > 0)
                {
                    $("#DSS_tr").show();
                    if("true" == $(xmlDoc1).find('DSS').eq(0).find('enabled').eq(0).text())
                    {
                        $("#DSSEnabled").prop("checked",true);
                        $("#DSSLevel").prop("disabled",false);
                    }
                    else
                    {
                        $("#DSSEnabled").prop("checked",false);
                        $("#DSSLevel").prop("disabled",true);
                    }
                }
                //低照度电子快门等级
                if($(xmlDoc).find('DSSLevel').length > 0)
                {
                    $("#DSSLevel").empty();
                    DSSLevelEnabled = 1;
                    $("#DSSLevel_tr").show();
                    var DSSLevelOptions = $(xmlDoc).find('DSSLevel').eq(0).attr("opt").split(",");
                    insertOptions2Select(DSSLevelOptions, ["low", "normal", "*"], ["aLevelLow", "aLevelNormal", "aLevelHigh"], "DSSLevel");
                    if($(xmlDoc1).find('DSSLevel').length > 0)
                    {
                        setValueDelayIE6("DSSLevel", xmlDoc1, "DSSLevel");
                    }
                }
            }
            //视频制式
            if($(xmlDoc).find('powerLineFrequencyMode').length > 0)
            {
                $("#powerLine_tr").show();
                var powerLineFrequencyModeOptions = $(xmlDoc).find('powerLineFrequencyMode').eq(0).attr("opt").split(",");
                for(i = 0;i < powerLineFrequencyModeOptions.length; i++)
                {
                    $("<option value='"+ powerLineFrequencyModeOptions[i] +"'>"+ powerLineFrequencyModeOptions[i] +"</option>").appendTo("#PowerLineFrequencyMode");
                }
                setValueDelayIE6("PowerLineFrequencyMode", xmlDoc1, "powerLineFrequencyMode");
            }
            //日夜切换
            if($(xmlDoc).find('IrcutFilterType').length > 0)
            {
                $("#DayNightFilterType_tr").show();
                var IrcutFilterTypeOptions = $(xmlDoc).find('IrcutFilterType').eq(0).attr("opt").split(",");
                insertOptions2Select(IrcutFilterTypeOptions, ["auto", "day", "night"], ["aModeAuto", "IrcutFilterTypeDay", "IrcutFilterTypeNight"], "DayNightFilterType");
                setValueDelayIE6("DayNightFilterType", xmlDoc1, "IrcutFilterType");
            }
            //日夜转换等级
            if(!window.parent.g_bIsIPDome)
            {
                if($(xmlDoc).find('IrcutFilterLevel').length > 0)
                {
                    g_IsSupportDayNightLevel = true;
                    $("#DayToNightFilterLevel_tr").show();
                    var IrcutFilterLevelOptions = $(xmlDoc).find('IrcutFilterLevel').eq(0).attr("opt").split(",");
                    insertOptions2Select(IrcutFilterLevelOptions, ["low", "normal", "high"], ["aLevelLow", "aLevelNormal", "aLevelHigh"], "DayToNightFilterLevel");
                    setValueDelayIE6("DayToNightFilterLevel", xmlDoc1, "IrcutFilterLevel");
                }
            }
            else
            {
                if($(xmlDoc).find('nightToDayFilterLevel').length > 0)
                {
                    g_IsSupportDayNightLevel = true;
                    $("#DayToNightFilterLevel_tr").show();
                    var IrcutFilterLevelOptions = $(xmlDoc).find('nightToDayFilterLevel').eq(0).attr("opt").split(",");
                    insertOptions2Select(IrcutFilterLevelOptions, ["low", "normal", "high"], ["aLevelLow", "aLevelNormal", "aLevelHigh"], "DayToNightFilterLevel");
                    setValueDelayIE6("DayToNightFilterLevel", xmlDoc1, "nightToDayFilterLevel");
                }
            }
            //日夜转换时间
            if($(xmlDoc).find('IrcutFilterTime').length > 0)
            {
                $("#DayNightFilterTime_tr").show();

                DayNightFilterTimeMin = parseInt($(xmlDoc).find('IrcutFilterTime').eq(0).attr("min"), 10);
                DayNightFilterTimeMax = parseInt($(xmlDoc).find('IrcutFilterTime').eq(0).attr("max"), 10);
                sliderDayNightFilterTime = new neverModules.modules.slider(
                    {targetId: "DayNightFilterTime",
                        sliderCss: "imageslider1",
                        barCss: "imageBar2",
                        boxCss: "boxBar",
                        bBox:true,
                        min: DayNightFilterTimeMin,
                        max: DayNightFilterTimeMax,
                        hints:""
                    });
                sliderDayNightFilterTime.create();
                //sliderDayNightFilterTime.wsetValue(60);

                sliderDayNightFilterTime.onchange = function ()
                {
                    sliderDayNightFilterTime.setTitle(getNodeValue('laFilterTime') + ':' + sliderDayNightFilterTime.getValue());
                };
                sliderDayNightFilterTime.onend = function ()
                {
                    SetIrcutFilter();
                };

                sliderDayNightFilterTime.wsetValue(parseInt($(xmlDoc1).find('IrcutFilterTime').eq(0).text(), 10));
                g_transStack.push(function() { sliderDayNightFilterTime.setTitle(getNodeValue('laFilterTime') + ":" + sliderDayNightFilterTime.getValue()); }, true);
            }

            //镜像翻转方向
            if($(xmlDoc).find('ImageFlip').length > 0)
            {
                var szEnableImageFlip = $(xmlDoc1).find('ImageFlip').eq(0).find('enabled').eq(0).text();
                $("#ImageFlipStyle_tr").show();
                if($(xmlDoc).find('ImageFlipStyle').length > 0)
                {
                    var ImageFlipStyleOptions = $(xmlDoc).find('ImageFlipStyle').eq(0).attr("opt").split(",");
                    insertOptions2Select(ImageFlipStyleOptions, ["LEFTRIGHT", "UPDOWN", "CENTER"], ["ImageFlipStyleLR", "ImageFlipStyleUD", "aModeCenter"], "ImageFlipStyle");
                    $("<option id='aStyleClose' name='aStyleClose' value='false'></option>").appendTo("#ImageFlipStyle");
                    //是否启用镜像翻转
                    if(szEnableImageFlip == "true")
                    {
                        setValueDelayIE6("ImageFlipStyle", xmlDoc1, "ImageFlipStyle");
                    }
                    else
                    {
                        setValueDelayIE6("ImageFlipStyle", null, "", "false");
                    }
                }
                else
                {
                    $("<option name='laEnable' value='true'></option><option name='aStyleClose' value='false'></option>").appendTo("#ImageFlipStyle");
                    //是否启用镜像翻转
                    if(szEnableImageFlip == "true")
                    {
                        setValueDelayIE6("ImageFlipStyle", null,"", "true");
                    }
                    else
                    {
                        setValueDelayIE6("ImageFlipStyle", null, "", "false");
                    }
                }
            }
            //宽动态
            if(!window.parent.g_bIsIPDome)
            {
                if($(xmlDoc).find('WDR').length > 0)//支持宽动态
                {
                    if($(xmlDoc).find('WDR').eq(0).find('enabled').length > 0)
                    {
                        $("#WDR_tr").show();
                        //2011-07-14 [guibo] add  宽动态支持3种模式   START
                        var szWDROptions = $(xmlDoc).find('WDR').eq(0).find('enabled').eq(0).attr("opt").split(",");
                        insertOptions2Select(szWDROptions, ["false", "true", "auto"], ["aStyleClose", "laEnable", "aModeAuto"], "WDREnabled");
                        //2011-07-14 [guibo] add  宽动态支持3种模式   END

                        if($(xmlDoc).find('WDRLevel').length > 0)  //2012-02-08 [chenxiangzhen] 条件修改
                        {
                            isSupportWDRLevel = true;
                            var szWDRLevelOpt = $(xmlDoc).find('WDRLevel').eq(0).attr("opt");
                            if(szWDRLevelOpt)
                            {
                                var rMatch = szWDRLevelOpt.match(/B/ig);
                                if(rMatch)
                                {
                                    isSupportWDRLevel2 = true;
                                    if(rMatch.length < szWDRLevelOpt.split(",").length)
                                    {
                                        isSupportWDRLevel1 = true;
                                    }
                                }
                                else
                                {
                                    isSupportWDRLevel1 = true;
                                }
                            }
                        }

                        if($(xmlDoc).find('WDRContrastLevel').length > 0)  //支持宽动态对比度等级
                        {
                            isSupportWDRContrastLevel = true;
                        }
                        //宽动态当前参数值
                        var WDRCurValue = $(xmlDoc1).find('WDR').eq(0).find('enabled').eq(0).text();
                        if((WDRCurValue == "true") || (WDRCurValue == "auto")) //启用宽动态
                        {
                            setValueDelayIE6("WDREnabled", null, "", WDRCurValue);

                            if(isSupportWDRLevel)    //支持宽动态等级
                            {
                                if(isSupportWDRLevel1)  //支持宽动态等级1
                                {
                                    $("#WDRLevel_tr1").show();
                                    sliderWDRLevel1.wsetValue(parseInt($(xmlDoc1).find('WDRLevel').eq(0).text().split(',')[0], 10));
                                    g_transStack.push(function() { sliderWDRLevel1.setTitle(getNodeValue('laWDRLevel1') + ":" + sliderWDRLevel1.getValue()); }, true);
                                }
                                if(isSupportWDRLevel2)  //支持宽动态等级2
                                {
                                    $("#WDRLevel_tr2").show();
                                    sliderWDRLevel2.wsetValue(parseInt($(xmlDoc1).find('WDRLevel').eq(0).text().split('B')[1], 10));
                                    g_transStack.push(function() { sliderWDRLevel2.setTitle(getNodeValue('laWDRLevel2') + ":" + sliderWDRLevel2.getValue()); }, true);
                                }
                            }

                            if(isSupportWDRContrastLevel)  //支持宽动态对比度等级
                            {
                                $("#WDRContrastLevel_tr").show();
                                sliderWDRContrastLevel.wsetValue(parseInt($(xmlDoc1).find('WDRContrastLevel').eq(0).text(), 10));
                                g_transStack.push(function() { sliderWDRContrastLevel.setTitle(getNodeValue('laWDRContrast') + ":" + sliderWDRContrastLevel.getValue()); }, true);
                            }
                            //if(WDRCurValue == "auto")
                            //{
                            //$("#WDRLevel_tr1").hide();
                            //$("#WDRLevel_tr2").hide();
                            //}
                        }
                        else   //禁用宽动态
                        {
                            setValueDelayIE6("WDREnabled", null, "", "false");

                            $("#WDRLevel_tr1").hide();
                            $("#WDRLevel_tr2").hide();
                            $("#WDRContrastLevel_tr").hide();
                        }
                    }
                }
            }
            else   //球机
            {
                if($(xmlDoc).find('WDRExt').length > 0)//支持宽动态
                {
                    if($(xmlDoc).find('WDRExt').eq(0).find('mode').length > 0)
                    {
                        $("#WDR_tr").show();
                        //2011-07-14 [guibo] add  宽动态支持3种模式   START
                        var szWDROptions = $(xmlDoc).find('WDRExt').eq(0).find('mode').eq(0).attr("opt").split(",");
                        insertOptions2Select(szWDROptions, ["close", "open", "auto"], ["aStyleClose", "laEnable", "aModeAuto"], "WDREnabled");
                        //2011-07-14 [guibo] add  宽动态支持3种模式   END

                        if($(xmlDoc).find('WDRLevel').length > 0)
                        {
                            isSupportWDRLevel = true;
                            isSupportWDRLevel1 = true;
                        }
                        if($(xmlDoc).find('WDRLevelExt').eq(0).find("Level2").length > 0)
                        {
                            isSupportWDRLevel = true;
                            isSupportWDRLevel2 = true;
                        }
                        if($(xmlDoc).find('WDRContrastLevel').length > 0)  //支持宽动态对比度等级
                        {
                            isSupportWDRContrastLevel = true;
                        }
                        //宽动态当前参数值
                        var WDRCurValue = $(xmlDoc1).find('WDRExt').eq(0).find('mode').eq(0).text();
                        if((WDRCurValue == "open") || (WDRCurValue == "auto")) //启用宽动态
                        {
                            setValueDelayIE6("WDREnabled", null, "", WDRCurValue);

                            if(isSupportWDRLevel)    //支持宽动态等级
                            {
                                if(isSupportWDRLevel1)  //支持宽动态等级1
                                {
                                    $("#WDRLevel_tr1").show();
                                    sliderWDRLevel1.wsetValue(parseInt($(xmlDoc1).find('WDRLevel').eq(0).text(), 10));
                                    g_transStack.push(function() { sliderWDRLevel1.setTitle(getNodeValue('laWDRLevel1') + ":" + sliderWDRLevel1.getValue()); }, true);
                                }
                                if(isSupportWDRLevel2)  //支持宽动态等级2
                                {
                                    $("#WDRLevel_tr2").show();
                                    sliderWDRLevel2.wsetValue(parseInt($(xmlDoc1).find('Level2').eq(0).text(), 10));
                                    g_transStack.push(function() { sliderWDRLevel2.setTitle(getNodeValue('laWDRLevel2') + ":" + sliderWDRLevel2.getValue()); }, true);
                                }
                            }

                            if(isSupportWDRContrastLevel)  //支持宽动态对比度等级
                            {
                                $("#WDRContrastLevel_tr").show();
                                sliderWDRContrastLevel.wsetValue(parseInt($(xmlDoc1).find('WDRContrastLevel').eq(0).text(), 10));
                                g_transStack.push(function() { sliderWDRContrastLevel.setTitle(getNodeValue('laWDRContrast') + ":" + sliderWDRContrastLevel.getValue()); }, true);
                            }
                        }
                        else   //禁用宽动态
                        {
                            setValueDelayIE6("WDREnabled", null, "", "close");
                            $("#WDRLevel_tr1").hide();
                            $("#WDRLevel_tr2").hide();
                            $("#WDRContrastLevel_tr").hide();
                        }
                    }
                }
            }
            //镜头初始化
            if($(xmlDoc).find('LensInitialization').length > 0)
            {
                if($(xmlDoc).find('LensInitialization').eq(0).find('enabled').length > 0)
                {
                    $("#LensInit_tr").show();
                    $("#LensInitEnabled").prop("checked", $(xmlDoc1).find('LensInitialization').eq(0).find('enabled').eq(0).text() == "true"?true:false);
                }
            }
            //背光补偿
            if($(xmlDoc).find('BLC').length > 0)
            {
                if($(xmlDoc).find('BLC').eq(0).find('enabled').length > 0)
                {
                    if(window.parent.g_bIsIPDome)
                    {
                        $("#BLCMode_tr").show();
                        if($(xmlDoc).find('BLCMode').length > 0)
                        {
                            $("<option name='aStyleClose' value='false'></option>").appendTo("#BLCMode");
                            var BLCModeOptions = $(xmlDoc).find('BLCMode').eq(0).attr("opt").split(",");
                            insertOptions2Select(BLCModeOptions, ["UP", "DOWN", "LEFT", "RIGHT", "CENTER"], ["BLCModeUp", "BLCModeDown", "BLCModeLeft", "BLCModeRight", "aModeCenter"], "BLCMode");
                            isSupportBLCMode = true;
                        }
                        else
                        {
                            $("#laBLCMode").attr("name", "laBLC").html(getNodeValue("laBLC"));
                            $("<option name='laEnable' value='true'></option><option name='aStyleClose' value='false'></option>").appendTo("#BLCMode");
                        }
                    }
                    else
                    {
                        if(WDRCurValue == "false" || $("#WDR_tr").css("display") == "none")
                        {
                            $("#BLCMode_tr").show();
                        }
                        $("<option id='aStyleClose' name='aStyleClose' value='false'></option>").appendTo("#BLCMode");
                        if($(xmlDoc).find('BLCMode').length > 0)
                        {
                            var BLCModeOptions = $(xmlDoc).find('BLCMode').eq(0).attr("opt").split(",");
                            insertOptions2Select(BLCModeOptions, ["UP", "DOWN", "LEFT", "RIGHT", "CENTER"], ["BLCModeUp", "BLCModeDown", "BLCModeLeft", "BLCModeRight", "aModeCenter"], "BLCMode");
                            isSupportBLCMode = true;
                        }
                    }

                    //是否支持背光补偿等级
                    if($(xmlDoc).find('BLCLevel').length > 0)
                    {
                        isSupportBLCLevel = true;
                        $("#BLCLevel_tr").show();
                        sliderBLCLevel.wsetValue(parseInt($(xmlDoc1).find('BLCLevel').eq(0).text(), 10));
                        g_transStack.push(function() { sliderBLCLevel.setTitle(getNodeValue('laBLCLevel') + ":" + sliderBLCLevel.getValue()); }, true);
                        $("#BLCLevel_tr").hide();
                    }
                    var szEnableBLC = $(xmlDoc1).find('BLC').eq(0).find('enabled').eq(0).text();
                    if(szEnableBLC == "true")  //启用背光补偿
                    {
                        if(isSupportBLCMode)
                        {
                            setValueDelayIE6("BLCMode", xmlDoc1, "BLCMode");
                        }
                        else
                        {
                            setValueDelayIE6("BLCMode", null, "", "true");
                        }
                        if(isSupportBLCLevel)
                        {
                            if(WDRCurValue == "false" || $("#WDR_tr").css("display") == "none")
                            {
                                $("#BLCLevel_tr").show();
                            }
                        }
                    }
                    else
                    {
                        setValueDelayIE6("BLCMode", null, "", "false");
                        $("#BLCLevel_tr").hide();
                    }
                }
            }
            //白平衡
            if($(xmlDoc).find('WhiteBlanceStyle').length > 0)
            {
                $("#WhiteBlanceStyle_tr").show();
                var WhiteBlanceStyleOptions = $(xmlDoc).find('WhiteBlanceStyle').eq(0).attr("opt").split(",");
//                insertOptions2Select(WhiteBlanceStyleOptions, ["auto", "autoMode1", "autoMode2", "manual", "autotrace", "sodiumlight", "mercurylight", "onece","autoMode3"], ["WhiteBlanceStyleAuto", "WhiteBlanceStyle1", "WhiteBlanceStyle2", "WhiteBlanceStyleManual", "AutoTracing", "SodiumLight", "MercuryLight", "Onepush","WhiteBlanceStyle3"], "WhiteBlanceStyle");
                insertOptions2Select(WhiteBlanceStyleOptions, ["auto", "indoor", "outdoor", "manual", "autotrace", "sodiumlight", "mercurylight", "onece", "daylightLamp", "auto1", "auto2","autooutdoor","autosodiumlight", "locked", "incandescentlight", "warmlight", "naturallight"], ["WhiteBlanceStyleAuto", "SceneOptionIndoor", "SceneOptionOutdoor", "WhiteBlanceStyleManual", "autoTrack", "SodiumLight", "MercuryLight", "Onepush", "daylightLamp", "WhiteBlanceStyle1", "WhiteBlanceStyle2","OutdoorAuto","SodiumLightAuto", "WBLocked","IncandescentLamp","WarmLightLamp","NaturalLight"], "WhiteBlanceStyle");
                setValueDelayIE6("WhiteBlanceStyle", xmlDoc1, "WhiteBlanceStyle");
                //是否支持白平衡红色增益
                if($(xmlDoc).find('WhiteBlanceRed').length > 0)
                {
                    isSupportWhiteBlanceRed = true;
                }
                //是否支持白平衡蓝色增益
                if($(xmlDoc).find('WhiteBlanceBlue').length > 0)
                {
                    isSupportWhiteBlanceBlue = true;
                }

                if($(xmlDoc1).find('WhiteBlanceStyle').eq(0).text() == "manual")
                {
                    if(isSupportWhiteBlanceRed)
                    {
                        $("#WhiteBlanceRed_tr").show();
                        sliderWhiteBlanceRed.wsetValue(parseInt($(xmlDoc1).find('WhiteBlanceRed').eq(0).text(), 10));
                        g_transStack.push(function() { sliderWhiteBlanceRed.setTitle(getNodeValue('laWhiteBlanceRed') + ":" + sliderWhiteBlanceRed.getValue()); }, true);
                    }
                    if(isSupportWhiteBlanceBlue)
                    {
                        $("#WhiteBlanceBlue_tr").show();
                        sliderWhiteBlanceBlue.wsetValue(parseInt($(xmlDoc1).find('WhiteBlanceBlue').eq(0).text(), 10));
                        g_transStack.push(function() { sliderWhiteBlanceBlue.setTitle(getNodeValue('laWhiteBlanceBlue') + ":" + sliderWhiteBlanceBlue.getValue()); }, true);
                    }
                }
            }
            //数字降噪
            if($(xmlDoc).find('NoiseReduceExt').length > 0)
            {
                if($(xmlDoc).find('NoiseReduceExt').eq(0).find('mode').length > 0)
                {
                    $("#NosiseReduceExt_tr").show();
                    var szNosiseReduceModeOptions = $(xmlDoc).find('NoiseReduceExt').eq(0).find('mode').eq(0).attr("opt").split(",");
                    insertOptions2Select(szNosiseReduceModeOptions, ["general", "advanced", "*"], ["NosiseReduceGeneral", "NosiseReduceAdvanced", "aStyleClose"], "NosiseReduceExtMode");

                    var szCurNosiseMode = $(xmlDoc1).find('NoiseReduceExt').eq(0).find('mode').eq(0).text();
                    setValueDelayIE6("NosiseReduceExtMode", null, "", szCurNosiseMode);

                    $("#GeneralLevel_tr").show();
                    generalLevel.wsetValue(parseInt($(xmlDoc1).find('generalLevel').eq(0).text(), 10));
                    g_transStack.push(function() { generalLevel.setTitle(getNodeValue('laGeneralLevel') + ":" + generalLevel.getValue()); }, true);

                    $("#InterFrameNoiseReduceLevel_tr").show();
                    interFrameNoiseReduceLevel.wsetValue(parseInt($(xmlDoc1).find('InterFrameNoiseReduceLevel').eq(0).text(), 10));
                    g_transStack.push(function() { interFrameNoiseReduceLevel.setTitle(getNodeValue('laInterFrameNoiseReduce') + ":" + interFrameNoiseReduceLevel.getValue()); }, true);

                    $("#FrameNoiseReduceLevel_tr").show();
                    frameNoiseReduceLevel.wsetValue(parseInt($(xmlDoc1).find('FrameNoiseReduceLevel').eq(0).text(), 10));
                    g_transStack.push(function() { frameNoiseReduceLevel.setTitle(getNodeValue('laFrameNoiseReduce') + ":" + frameNoiseReduceLevel.getValue()); }, true);

                }
            }
            
            //电子云台
            if($(xmlDoc).find('EPTZ').length > 0)
            {
                $("#EPTZ_tr").show();
                var EPTZEnableOptions = $(xmlDoc).find('EPTZ').eq(0).find('enabled').eq(0).attr("opt").split(",");
                insertOptions2Select(EPTZEnableOptions, ["true", "false"], ["laEnable", "aStyleClose"], "selEPTZEnable");
                setValueDelayIE6("selEPTZEnable", $(xmlDoc1).find('EPTZ').eq(0), "enabled");
            }
            //室内外模式
            if($(xmlDoc).find('Scene').length > 0)
            {
                $("#Scene_tr").show();
                var SceneOptions = $(xmlDoc).find('Scene').eq(0).find('mode').eq(0).attr("opt").split(",");
                insertOptions2Select(SceneOptions, ["indoor", "outdoor"], ["SceneOptionIndoor", "SceneOptionOutdoor"], "selScene");
                setValueDelayIE6("selScene", $(xmlDoc1).find('Scene').eq(0), "mode");
            }
            //去雾
            if($(xmlDoc).find("Dehaze").length > 0)
            {
                g_IsSupportDehaze = true;
            }
            if($(xmlDoc).find("dehazeLevel").length > 0)
            {
                g_IsSupportDehazeLevel = true;
            }
            if(g_IsSupportDehaze)
            {
                $("#dvEnableDehaze").show();
                $("#chEnableDehaze").prop("checked", $(xmlDoc).find("Dehaze").eq(0).find("enabled").eq(0).text()=="true"?true:false);
            }
            if(g_IsSupportDehazeLevel)
            {
                $("#dvDehazeLevel").show();
            }

            var $xmlDoc = $(xmlDoc);
            if ($xmlDoc.find("DayNightFilterTh").length) {
                $('#dvDayNightFilterTh').show();
                var v = $xmlDoc.find('DayNightFilterTh').eq(0).text();
                DayNightFilterThSlider.wsetValue(parseInt(v, 10));
            }

            if ($xmlDoc.find("ExceptionCatchTh").length) {
                $('#dvExceptionCatchTh').show();
                var v = $xmlDoc.find('ExceptionCatchTh').eq(0).text();
                ExceptionCatchThSlider.wsetValue(parseInt(v, 10));
            }

            //变倍限制
            if($(xmlDoc).find('ZoomLimit').length > 0)
            {
                $("#dvZoomLimit").show();
                var ZoomLimitOptions = $(xmlDoc).find('ZoomLimitRatio').eq(0).attr("opt").split(",");
                for(i = 0;i < ZoomLimitOptions.length; i++)
                {
                    $("<option value='"+ ZoomLimitOptions[i] +"'>"+ ZoomLimitOptions[i] +"</option>").appendTo("#selZoomLimit");
                }
                setValueDelayIE6("selZoomLimit", xmlDoc1, "ZoomLimitRatio");
            }
            //电子防抖等级
            if($(xmlDoc).find('EIS').length > 0)
            {
                $("#dvEIS").show();
                $("#inEnableEIS").prop("checked", $(xmlDoc1).find("EIS").eq(0).find("enabled").eq(0).text()=="true"?true:false);
                if($(xmlDoc).find('EIS').eq(0).find("EISLevel").length >0)
                {
                    $("#dvEISLevel").show();
                    g_oSliderEISLevel.wsetValue(parseInt($(xmlDoc1).find('EISLevel').eq(0).text(), 10));
                    g_transStack.push(function() { g_oSliderEISLevel.setTitle(getNodeValue('laEISLevel') + ":" + g_oSliderEISLevel.getValue()); }, true);
                }

            }
            //色彩抑制等级
            if($(xmlDoc).find('ChromaSuppress').length > 0)
            {
                $("#dvChromaSuppress").show();
                g_oSliderCSLevel.wsetValue(parseInt($(xmlDoc1).find('ChromaSuppressLevel').eq(0).text(), 10));
                g_transStack.push(function() { g_oSliderCSLevel.setTitle(getNodeValue('laChromaSuppress') + ":" + g_oSliderCSLevel.getValue()); }, true);
            }
            //强光抑制等级
            if($(xmlDoc).find('HLC').length > 0)
            {
                $("#dvHLC").show();
                g_oSliderHLCLevel.wsetValue(parseInt($(xmlDoc1).find('HLCLevel').eq(0).text(), 10));
                g_transStack.push(function() { g_oSliderHLCLevel.setTitle(getNodeValue('laHLC') + ":" + g_oSliderHLCLevel.getValue()); }, true);
            }
            //曝光补偿等级
            if($(xmlDoc).find('ExpComp').length > 0)
            {
                $("#dvExpComp").show();
                g_oSliderExpCompLevel.wsetValue(parseInt($(xmlDoc1).find('ExpCompLevel').eq(0).text(), 10));
                g_transStack.push(function() { g_oSliderExpCompLevel.setTitle(getNodeValue('laExpComp') + ":" + g_oSliderExpCompLevel.getValue()); }, true);
            }
            //伽马校正等级
            if($(xmlDoc).find('gammaCorrection').length > 0)
            {
                $("#dvEnableGamaCorrect").show();
                $("#EnableGamaCorrect").prop("checked", $(xmlDoc1).find('gammaCorrectionEnabled').eq(0).text() == "true"? true:false);
                if($("#EnableGamaCorrect").prop("checked")) {
                    $("#dvGamaCorrect").show();
                    g_oSliderGamaCorrLevel.wsetValue(parseInt($(xmlDoc1).find('gammaCorrectionLevel').eq(0).text(), 10));
                    g_transStack.push(function() { g_oSliderGamaCorrLevel.setTitle(getNodeValue('laGamaCorrect') + ":" + g_oSliderGamaCorrLevel.getValue()); }, true);
                } else {
					$("#dvGamaCorrect").hide();
				}
            }

            //红外灯
            if($(xmlDoc).find('IrLight').length > 0)
            {
                $("#dvIRLight").show();
                //红外灯模式
                var aIRLightMode = $(xmlDoc).find('IrLight').eq(0).find("mode").eq(0).attr("opt").split(",");
                insertOptions2Select(aIRLightMode, ["auto", "manual"], ["aModeAuto", "aModeManual"], "selIRLightMode");
                setValueDelayIE6("selIRLightMode", $(xmlDoc1).find('IrLight').eq(0), "mode");
                if($(xmlDoc1).find('IrLight').eq(0).find("mode").eq(0).text() == "auto")
                {
                    $("#dvIRLightBright").hide();
                    $("#dvIRLightSen").show();
                    //红外灯灵敏度
                    g_oIRLightSenSlider.wsetValue(parseInt($(xmlDoc1).find('IrLight').eq(0).find('sensitivityLevel').eq(0).text(), 10));
                    g_transStack.push(function() { g_oIRLightSenSlider.setTitle(getNodeValue('laIRLightSen') + ":" + g_oIRLightSenSlider.getValue()); }, true);
                }
                else
                {
                    $("#dvIRLightBright").show();
                    $("#dvIRLightSen").hide();
                    //红外灯亮度
                    g_oIRLightBrightSlider.wsetValue(parseInt($(xmlDoc1).find('IrLight').eq(0).find('brightnessLevel').eq(0).text(), 10));
                    g_transStack.push(function() { g_oIRLightBrightSlider.setTitle(getNodeValue('laIRLightBright') + ":" + g_oIRLightBrightSlider.getValue()); }, true);
                }
            }
            //动态对比度
            if($(xmlDoc).find('DynamicContrast').length > 0)
            {
                $("#DynamicContrast_tr").show();
                var aDynamicContrastMode = $(xmlDoc).find('DynamicContrast').eq(0).find("enabled").eq(0).attr("opt").split(",");
                insertOptions2Select(aDynamicContrastMode, ["true", "false"], ["laEnable", "trDisabled"], "DynamicContrastMode");
                setValueDelayIE6("DynamicContrastMode", $(xmlDoc1).find('DynamicContrast').eq(0), "enabled");
                if($(xmlDoc1).find('DynamicContrast').eq(0).find("enabled").eq(0).text() == "true")
                {
                    $("#DynamicContrastLevel_tr").show();
                    SliderDynamicContrast.wsetValue(parseInt($(xmlDoc1).find('dynamicContrastLevel').eq(0).text(), 10));
                    g_transStack.push(function() { SliderDynamicContrast.setTitle(getNodeValue('laDynamicContrastLevel') + ":" + SliderDynamicContrast.getValue()); }, true);
                }
                else
                {
                    $("#DynamicContrastLevel_tr").hide();
                }
            }
            //图像旋转配置
            if($(xmlDoc).find('Flip').length > 0)
            {

                if($(xmlDoc).find('Flip').eq(0).children().length > 0)
                {
                    var flipEnabled = $(xmlDoc).find('Flip').eq(0).find('enabled').attr('opt').split(',');
                    if(flipEnabled.length == 2){
                        $("#Flip_tr").show();

                        if("true" == $(xmlDoc1).find('Flip').eq(0).find('enabled').eq(0).text())
                        {
                            $("#FlipEnabled").prop("checked",true);
                            $("#FlipStyle_tr").show();
                        }
                        else
                        {
                            $("#FlipEnabled").prop("checked",false);
                            $("#FlipStyle_tr").hide();
                        }
                    }
                }
                //图像旋转角度
                if($(xmlDoc).find('flipStyle').length > 0)
                {
                    var flipStyleOptions = $(xmlDoc).find('flipStyle').eq(0).attr("opt").split(",");
                    $("#FlipStyle").empty();
                    for(i = 0;i < flipStyleOptions.length; i++)
                    {
                        $("<option value='"+ flipStyleOptions[i] +"'>"+ flipStyleOptions[i] +"</option>").appendTo("#FlipStyle");
                    }
                    if($(xmlDoc1).find('flipStyle').length > 0)
                    {
                        setValueDelayIE6("FlipStyle", xmlDoc1, "flipStyle");
                    }
                }
                //车牌预期亮度
                if($(xmlDoc).find('PlateBright').length > 0)
                {
                    $("#dvSnapBright").show();
                    $("#IsUsePlateBright").prop("checked", $(xmlDoc1).find('plateBrightEnabled').eq(0).text() == "true"?true:false);
                    if($(xmlDoc1).find('plateBrightEnabled').eq(0).text() == "true")
                    {
                        /*$("#dvPlateExpectedBright").show();
                        SliderPlateExpectedBright.wsetValue(parseInt($(xmlDoc1).find('plateExpectedBright').eq(0).text(), 10));
                        g_transStack.push(function() { SliderPlateExpectedBright.setTitle(getNodeValue('laPlateExpectedBright') + ":" + SliderPlateExpectedBright.getValue()); }, true);*/
                        if($(xmlDoc).find('plateBrightSensitivity ').length > 0) {
                            $("#dvplateBrightSensitivity").show();
                            SliderplateBrightSensitivity.wsetValue(parseInt($(xmlDoc1).find('plateBrightSensitivity').eq(0).text(), 10));
                            g_transStack.push(function() { SliderplateBrightSensitivity.setTitle(getNodeValue('laplateBrightSensitivity') + ":" + SliderplateBrightSensitivity.getValue()); }, true);
                        }
                    }
                    else
                    {
                        $("#dvPlateExpectedBright").hide();
                        $("#dvplateBrightSensitivity").hide();
                    }
                    if(!$("#IsUsePlateBright").prop("checked")){
                        $('#dvPlateExpectedBright').hide();
                        $('#dvplateBrightSensitivity').hide();
                    }
                }
                //补光灯纠正系数
                if($(xmlDoc).find('correctFactorEnabled').length > 0)
                {
                    $("#dvIsUseCorrectFactor").show();
                    $("#IsUseCorrectFactor").prop("checked", $(xmlDoc1).find('correctFactorEnabled').eq(0).text() == "true"?true:false);
                    $("#dvCorrectFactor").show();
                    SliderCorrectFactor.wsetValue(parseInt($(xmlDoc1).find('correctFactor').eq(0).text(), 10));
                    g_transStack.push(function() { SliderCorrectFactor.setTitle(getNodeValue('laCorrectFactor') + ":" + SliderCorrectFactor.getValue()); }, true);
//                    if(!$("#IsUseCorrectFactor").prop("checked")){
//                        $('#dvCorrectFactor').css('display','none');
//                    }
                }
                //亮度增强
                if($(xmlDoc).find('brightEnhance').length > 0)
                {
                    $("#dvbrightEnhance").show();
                    SliderbrightEnhance.wsetValue(parseInt($(xmlDoc1).find('brightEnhanceLevel').eq(0).text(), 10));
                    g_transStack.push(function() { SliderbrightEnhance.setTitle(getNodeValue('labrightEnhance') + ":" + SliderbrightEnhance.getValue()); }, true);
                }
                //分段控制
                if($(xmlDoc).find('sectionCtrl').length > 0)
                {
                    $("#dvsectionCtrl").show();
                    $("#sectionCtrlEnabled").prop("checked", $(xmlDoc1).find("sectionCtrlEnabled").eq(0).text()=="true"?true:false);
                }
                
            }
            //自适应高度
            autoResizeIframe();
            /***********关联关系 start*********/
            //锐度模式和锐度关联关系
            if($(xmlDoc1).find('SharpnessMode').eq(0).text() == "auto")
            {
                $("#Sharpness_tr").hide();
            }
            //球机下曝光模式和增益的关联关系
            if(window.parent.g_bIsIPDome)
            {
                if($(xmlDoc1).find("ExposureType").eq(0).text() != "manual" && $(xmlDoc1).find("ExposureType").eq(0).text() != "gainFirst")
                {
                    $("#VideoGain_tr").hide();    //当日夜切换为"自动"时，增益无效
                }
            }
            //自动光圈和灵敏度的关联关系
            if("auto" != $(xmlDoc1).find('ExposureType').eq(0).text())
            {
                $("#AutoIrisLevel_tr").hide();
            }
            //球机下曝光模式和曝光时间的关联关系
            if(window.parent.g_bIsIPDome)
            {
                if($(xmlDoc1).find("ExposureType").eq(0).text() != "ShutterFirst" && $(xmlDoc1).find("ExposureType").eq(0).text() != "manual")
                {
                    $("#Shutter_tr").hide();
                }
            }
            //球机下曝光模式和光圈的关联关系
            if(window.parent.g_bIsIPDome)
            {
                if($(xmlDoc1).find("ExposureType").eq(0).text() != "IrisFirst" && $(xmlDoc1).find("ExposureType").eq(0).text() != "manual")
                {
                    $("#IrisLevel_tr").hide();
                }
            }
            //非球机日夜切换模式与增益的关联关系
            if(!window.parent.g_bIsIPDome)
            {
                if($(xmlDoc1).find("IrcutFilterType").eq(0).text() == "auto")
                {
                    $("#VideoGain_tr").hide();    //当日夜切换为"自动"时，增益无效
                }
            }
            //球机下曝光模式和日夜转换模式的关联关系
            if(window.parent.g_bIsIPDome)
            {
                if("auto"!=$(xmlDoc1).find("IrcutFilterType").eq(0).text() || "auto"!=$(xmlDoc1).find("ExposureType").eq(0).text())
                {
                    $("#DayToNightFilterLevel_tr").hide();
                }
            }
            //数字降噪关联关系
            if(szCurNosiseMode == "general")				//普通模式
            {
                $("#InterFrameNoiseReduceLevel_tr").hide();

                $("#FrameNoiseReduceLevel_tr").hide();
            }
            else if(szCurNosiseMode == "advanced")			//专家模式
            {
                $("#GeneralLevel_tr").hide();
            }
            else											//关闭
            {
                $("#GeneralLevel_tr").hide();

                $("#InterFrameNoiseReduceLevel_tr").hide();

                $("#FrameNoiseReduceLevel_tr").hide();
            }
            /***********关联关系 end*********/
                //翻译页面
            g_transStack.translate();
		}
	});
}

/*************************************************
Function:		SetVideoParamColor
Description:	设置视频参数的亮度
Input:
Output:			无
return:			无
*************************************************/
function SetVideoParamColor()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><Color><brightnessLevel>" + sliderBright.getValue() + "</brightnessLevel><contrastLevel>" + sliderContrast.getValue() +"</contrastLevel><capContrastLevel>" + sliderSnapContrast.getValue() + "</capContrastLevel><saturationLevel>" + sliderSaturation.getValue() + "</saturationLevel><hueLevel>" + sliderHue.getValue() + "</hueLevel></Color>";
	var xmlDoc = parseXmlFromStr(szXml);
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/Color";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		SetVideoGain
Description:	设置增益参数
Input:			无
Output:			无
return:			无
*************************************************/
function SetVideoGain()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><Gain><GainLevel>" + sliderGain.getValue() + "</GainLevel></Gain>";
	var xmlDoc = parseXmlFromStr(szXml);
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/Gain";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		SetSharpness
Description:	设置锐度参数
Input:			无
Output:			无
return:			无
*************************************************/
function SetSharpness()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var xmlDoc = null;
	var szXml = "";
	szXml = "<?xml version='1.0' encoding='UTF-8'?><Sharpness version='1.0' xmlns='urn:selfextension:psiaext-ver10-xsd'>";
	if($("#dvSharpnessMode").css("display") != "none")
	{
		if($("#selSharpnessMode").val() == "auto")
		{
			szXml += "<SharpnessMode>auto</SharpnessMode><SharpnessLevel>0</SharpnessLevel></Sharpness>";
		}
		else
		{
			szXml += "<SharpnessMode>manual</SharpnessMode><SharpnessLevel>" + sliderSharpness.getValue() + "</SharpnessLevel></Sharpness>";
		}
	}
	else
	{
		szXml += "<SharpnessLevel>" + sliderSharpness.getValue() + "</SharpnessLevel></Sharpness>";
	}
	xmlDoc = parseXmlFromStr(szXml);
	$.ajax(
	{
		type: "PUT",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/Sharpness",
		processData: false,
		data: xmlDoc,
		beforeSend: function(xhr)
		{
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		SetIrcutFilter
Description:	设置转换参数
Input:			无
Output:			无
return:			无
*************************************************/
function SetIrcutFilter()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var xmlDoc = null;
	var szXml = "";
	//球机使用EXT版本
	if(window.parent.g_bIsIPDome)
	{
		szXml = "<?xml version='1.0' encoding='UTF-8'?><IrcutFilterExt>";
	}
	else
	{
		szXml = "<?xml version='1.0' encoding='UTF-8'?><IrcutFilter>";
	}
	if($("#DayNightFilterType_tr").css("display")!="none")
	{
		szXml += "<IrcutFilterType>" + $("#DayNightFilterType").val() + "</IrcutFilterType>";
	}
	if($("#DayToNightFilterLevel_tr").css("display")!="none")
	{
		if(window.parent.g_bIsIPDome)
		{
			szXml += "<nightToDayFilterLevel>" + $("#DayToNightFilterLevel").val() + "</nightToDayFilterLevel>";
		}
		else
		{
			szXml += "<IrcutFilterLevel>" + $("#DayToNightFilterLevel").val() + "</IrcutFilterLevel>";
		}

	}
	if(sliderDayNightFilterTime != null)
	{
		szXml += "<IrcutFilterTime>" + sliderDayNightFilterTime.getValue() + "</IrcutFilterTime>";
	}
	if(window.parent.g_bIsIPDome)
	{
		szXml += "</IrcutFilterExt>";
	}
	else
	{
		szXml += "</IrcutFilter>";
	}

	xmlDoc = parseXmlFromStr(szXml);
	var szURL = "";
	if(window.parent.g_bIsIPDome)
	{
		szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/IrcutFilterExt";
	}
	else
	{
		szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/IrcutFilter";
	}

	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		SetDefault
Description:	恢复默认参数
Input:			无		
Output:			无
return:			无				
*************************************************/
function SetDefault()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	if(!confirm(getNodeValue('jsVideoDefault'), getNodeValue('jsTrue'), getNodeValue('jsFalse')))
	{
		return;
	}
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/restoreImageparam";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		SetShutter
Description:	设置曝光时间
Input:			无		
Output:			无
return:			无				
*************************************************/
function SetShutter()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	//校验数据正确性
	if(!CheackServerIDIntNum($("#Shutter").val(),"SetResultTips","laShutter",SutterMin,ShutterMax))
	{
		return;
	}
	var xmlDoc = null;
	var szXml = "";
	szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
"<Shutter version='1.0' xmlns='urn:selfextension:psiaext-ver10-xsd'>" +
"<ShutterLevel>" + $("#Shutter").val() + "</ShutterLevel>" +
"</Shutter>";
	xmlDoc = parseXmlFromStr(szXml);
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/Shutter";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		SetSnapShutter
Description:	设置抓拍快门速度
Input:			无		
Output:			无
return:			无				
*************************************************/
function SetSnapShutter()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	//校验数据正确性
	if(!CheackServerIDIntNum($("#SnapShutter").val(),"SetResultTips","laSnapShutter",SnapShutterMin,SnapShutterMax))
	{
		return;
	}
	var xmlDoc = null;
	var szXml = "";
	szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
"<SnapShutter version='1.0' xmlns='urn:selfextension:psiaext-ver10-xsd'>" +
"<snapShutterLevel>" + $("#SnapShutter").val() + "</snapShutterLevel>" +
"</SnapShutter>";
	xmlDoc = parseXmlFromStr(szXml);
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/SnapShutter";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
 Function:		SetJPEGSize
 Description:	设置JPEG图片大小
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function SetJPEGSize()
{
    if (!HWP.wnds[0].isPlaying)
    {
        return;
    }
    //校验数据正确性
    if(!CheackServerIDIntNum($("#JPEGSize").val(),"SetResultTips","laJPEGSize",JPEGSizeMin,JPEGSizeMax))
    {
        return;
    }
    var xmlDoc = null;
    var szXml = "";
    szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
        "<JPEGParam version='1.0' xmlns='urn:selfextension:psiaext-ver10-xsd'>" +
        "<JPEGSize>" + $("#JPEGSize").val() + "</JPEGSize>" +
        "</JPEGParam>";
    xmlDoc = parseXmlFromStr(szXml);
    var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/JPEGParam";
    $.ajax(
        {
            type: "PUT",
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            url: szURL,
            processData: false,
            data: xmlDoc,
            complete:function(xhr, textStatus)
            {
                SaveState(xhr);
            }
        });
}
/*************************************************
Function:		SetFocus
Description:	设置聚焦模式
Input:			无		
Output:			无
return:			无				
*************************************************/
function SetFocus()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var xmlDoc = null;
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><Focus><FocusStyle>" + $("#FocusMode").val() + "</FocusStyle>";
	if($("#FocusLimited_tr").css("display") != "none")
	{
		szXml += "<FocusLimited>" + $("#FocusLimited").val() + "</FocusLimited>";
	}
	else
	{
		szXml += "<FocusLimited>1m</FocusLimited>";
	}
	szXml += "</Focus>";
	xmlDoc = parseXmlFromStr(szXml);
	
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/Focus";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		SetExposure
Description:	设置曝光
Input:			无
Output:			无
return:			无
*************************************************/
function SetExposure()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var xmlDoc = null;
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><Exposure><ExposureType>" + $("#IrisMode").val() + "</ExposureType></Exposure>";
	xmlDoc = parseXmlFromStr(szXml);
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/Exposure";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		},
		success: function()
		{
			if(!window.parent.g_bIsIPDome)
			{
				$.ajax(
				{
					type: "GET",
					url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/capabilities",
					beforeSend: function(xhr) {
						xhr.setRequestHeader("If-Modified-Since", "0");
						
					},
					success: function(xmlDoc, textStatus, xhr)
					{
						if($(xmlDoc).find('autoIrisLevel').length > 0)
						{
							isSupportAutoIrisLevel = true;
							$("#AutoIrisLevel_tr").show();
							sliderAutoIrisLevel.wsetValue(parseInt($(xmlDoc).find('autoIrisLevel').eq(0).text(), 10));
							g_transStack.push(function() { sliderAutoIrisLevel.setTitle(getNodeValue('laAutoIrisLevel') + ":" + sliderAutoIrisLevel.getValue()); }, true);
						}
						else
						{
							isSupportAutoIrisLevel = false;
						}
						if($("#IrisMode").val() != "auto" || !isSupportAutoIrisLevel)
						{
							$("#AutoIrisLevel_tr").hide();
						}
						$("#Shutter").empty();
						if($(xmlDoc).find('ShutterLevel').length > 0)
						{
							g_bSupportShutter = true;
							$("#Shutter_tr").show();
							var ShutterOptions = $(xmlDoc).find('ShutterLevel').eq(0).attr("opt").split(",");
							for(i = 0;i < ShutterOptions.length; i++)
							{
								$("<option value='"+ ShutterOptions[i] +"'>"+ ShutterOptions[i] +"</option>").appendTo("#Shutter");
							}
							var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/Shutter";
							$.ajax(
							{
								type: "GET",
								beforeSend: function(xhr) {
									xhr.setRequestHeader("If-Modified-Since", "0");
									
								},
								url: szURL,
								success: function(xmlDocValue, textStatus, xhr)
								{
									$("#Shutter").val($(xmlDocValue).find("ShutterLevel").eq(0).text());
								}
							});
						}
					}
				});
			}
		}
	});
}
/*************************************************
Function:		SetIrisLevel
Description:	设置光圈
Input:			无		
Output:			无
return:			无				
*************************************************/
function SetIrisLevel()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var xmlDoc = null;
	var szXml = "";
	szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
"<Iris version='1.0' xmlns='urn:selfextension:psiaext-ver10-xsd'>" +
"<IrisLevel>" + $("#IrisLevel").val() + "</IrisLevel>" +
"</Iris>";
	xmlDoc = parseXmlFromStr(szXml);
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/Iris";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		EnableLensInit
Description:	镜头初始化
Input:			无		
Output:			无
return:			无				
*************************************************/
function EnableLensInit()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
"<LensInitialization version='1.0' xmlns='urn:selfextension:psiaext-ver10-xsd'>" +
"<enabled>" + $("#LensInitEnabled").prop("checked").toString() + "</enabled>" +
"</LensInitialization>";
	var xmlDoc = parseXmlFromStr(szXml);
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/LensInitialization";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		SetImageFlip
Description:	设置镜像翻转
Input:			无		
Output:			无
return:			无				
*************************************************/
function SetImageFlip()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var xmlDoc = null;
	var szXml = "";
	if($("#ImageFlipStyle").val() != "false" && $("#ImageFlipStyle").val() != "true")  //设置镜像翻转方向
	{
		szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
				"<ImageFlip>" +
				"<enabled>true</enabled>" +
				"<ImageFlipStyle>" + $("#ImageFlipStyle").val() + "</ImageFlipStyle>" +
				"</ImageFlip>";
	}
	else   //禁用镜像翻转
	{
		szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
				"<ImageFlip>" +
				"<enabled>"+$("#ImageFlipStyle").val()+"</enabled>" +
				"</ImageFlip>";
	}
	xmlDoc = parseXmlFromStr(szXml);
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/ImageFlip";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		Set2DNoiseReduceLevel
Description:	设置2D降噪
Input:			无		
Output:			无
return:			无				
*************************************************/
function Set2DNoiseReduceLevel()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var xmlDoc = null;
	var szXml = "";
	if($("#chEnable2DNoiseReduce").prop("checked"))  //设置降噪
	{
		$("#dv2DNoiseReduceLevel").show();
		szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
				"<NoiseReduce2D><NoiseReduce2DMode>" +
				$("#chEnable2DNoiseReduce").prop("checked").toString()+"</NoiseReduce2DMode>" +
				"<NoiseReduce2DLevel>" +  NoiseReduceLevel.getValue() + "</NoiseReduce2DLevel></NoiseReduce2D>";
	}
	else   //禁用
	{
		$("#dv2DNoiseReduceLevel").hide();
		szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
				"<NoiseReduce2D><NoiseReduce2DMode>" +
				$("#chEnable2DNoiseReduce").prop("checked").toString()+"</NoiseReduce2DMode></NoiseReduce2D>";
	}
	xmlDoc = parseXmlFromStr(szXml);
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/NoiseReduce2D";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		SetWDR
Description:	设置宽动态
Input:			无		
Output:			无
return:			无				
*************************************************/
function SetWDR()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var xmlDoc = null;
	var szXml = "";
	var szURL = "";
	var WDRCurValue = $("#WDREnabled").val();
	if(!window.parent.g_bIsIPDome)
	{
		if((WDRCurValue == "true") || (WDRCurValue == "auto"))
		{
			if(isSupportWDRLevel1 && isSupportWDRLevel2)
			{
				szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
						"<WDR>" +
						"<enabled>" + $("#WDREnabled").val() + "</enabled>" +
						"<WDRLevel>" + sliderWDRLevel1.getValue() + ",B" + sliderWDRLevel2.getValue() + "</WDRLevel>" +
						"<WDRContrastLevel>" + sliderWDRContrastLevel.getValue() + "</WDRContrastLevel>" +
						"</WDR>";
			}
			else if(isSupportWDRLevel1 && !isSupportWDRLevel2)
			{
				szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
						"<WDR>" +
						"<enabled>" + $("#WDREnabled").val() + "</enabled>" +
						"<WDRLevel>" + sliderWDRLevel1.getValue() + "</WDRLevel>" +
						"<WDRContrastLevel>" + sliderWDRContrastLevel.getValue() + "</WDRContrastLevel>" +
						"</WDR>";
			}
			else if(!isSupportWDRLevel1 && isSupportWDRLevel2)
			{
				szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
						"<WDR>" +
						"<enabled>" + $("#WDREnabled").val() + "</enabled>" +
						"<WDRLevel>" + ",B" + sliderWDRLevel2.getValue() + "</WDRLevel>" +
						"<WDRContrastLevel>" + sliderWDRContrastLevel.getValue() + "</WDRContrastLevel>" +
						"</WDR>";
			}
			else
			{
				szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
						"<WDR>" +
						"<enabled>" + $("#WDREnabled").val() + "</enabled>" +
						"<WDRLevel></WDRLevel>" +
						"<WDRContrastLevel>" + sliderWDRContrastLevel.getValue() + "</WDRContrastLevel>" +
						"</WDR>";
			}
		}
		else
		{
			szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
					"<WDR version='1.0' xmlns='urn:selfextension:psiaext-ver10-xsd'>" +
					"<enabled>false</enabled>" +
					"</WDR>";
		}
		szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/WDR";
	}
	else
	{
		szXml = "<?xml version='1.0' encoding='UTF-8'?><WDRExt><mode>" + $("#WDREnabled").val() + "</mode>";
		if((WDRCurValue == "open") || (WDRCurValue == "auto"))
		{
			if(isSupportWDRLevel1)
			{
				szXml += "<WDRLevel>" + sliderWDRLevel1.getValue() + "</WDRLevel>";
			}
			if(isSupportWDRLevel2)
			{
				szXml += "<WDRLevelExt><Level2>"+sliderWDRLevel2.getValue()+"</Level2></WDRLevelExt>";
			}
			if(isSupportWDRContrastLevel)
			{
				szXml += "<WDRContrastLevel>"+sliderWDRContrastLevel.getValue()+"</WDRContrastLevel>";
			}
		}
		szXml += "</WDRExt>";
		szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/WDRExt";
	}
	xmlDoc = parseXmlFromStr(szXml); 
	
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		SetBLC
Description:	设置背光补偿
Input:			无		
Output:			无
return:			无				
*************************************************/
function SetBLC()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var xmlDoc = null;
	var szXml = "";
	if(isSupportBLCLevel)		
	{		
		if($("#BLCMode").val() != 'false')
		{
			$("#BLCLevel_tr").show();
		}
		else
		{
			$("#BLCLevel_tr").hide();
		}
	}
	if($("#BLCMode").val() != 'false' && $("#BLCMode").val() != 'true')
	{
		if($("#BLCLevel_tr").css("display") != 'none')
		{
		    szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
				"<BLC>" +
				"<enabled>true</enabled>" +
				"<BLCMode>" + $("#BLCMode").val() + "</BLCMode>" +
				"<BLCLevel>" + sliderBLCLevel.getValue() + "</BLCLevel>" +
				"</BLC>";
		}
		else
		{
			szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
				"<BLC>" +
				"<enabled>true</enabled>" +
				"<BLCMode>" + $("#BLCMode").val() + "</BLCMode>" +
				"</BLC>";
		}
	}
	else
	{
		if($("#BLCLevel_tr").css("display") != 'none')
		{
			szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
					"<BLC>" +
					"<enabled>"+$("#BLCMode").val()+"</enabled>" +
					"<BLCLevel>" + sliderBLCLevel.getValue() + "</BLCLevel>" +
					"</BLC>";
		}
		else
		{
			szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
					"<BLC>" +
					"<enabled>"+$("#BLCMode").val()+"</enabled>" +
					"</BLC>";
		}
	}
	xmlDoc = parseXmlFromStr(szXml);
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/BLC";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		},
		success: function(xmlDoc, textStatus, xhr) 
		{
			
		}
	});
}
/*************************************************
Function:		SetWhiteBlance
Description:	设置白平衡
Input:			无		
Output:			无
return:			无				
*************************************************/
function SetWhiteBlance()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var szXml = "";
	if($("#WhiteBlanceStyle").val() == "manual")
	{
		szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
				"<WhiteBlance version='1.0' xmlns='urn:selfextension:psiaext-ver10-xsd'>" +
				"<enabled>true</enabled>" +
				"<WhiteBlanceStyle>" + $("#WhiteBlanceStyle").val() + "</WhiteBlanceStyle>" +
				"<WhiteBlanceRed>" + sliderWhiteBlanceRed.getValue() + "</WhiteBlanceRed>" +
				"<WhiteBlanceBlue>" + sliderWhiteBlanceBlue.getValue() + "</WhiteBlanceBlue>" +
				"</WhiteBlance>";
	}
	else
	{
		szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
				"<WhiteBlance version='1.0' xmlns='urn:selfextension:psiaext-ver10-xsd'>" +
				"<WhiteBlanceStyle>" + $("#WhiteBlanceStyle").val() + "</WhiteBlanceStyle>" +
				"</WhiteBlance>";
	}
	xmlDoc = parseXmlFromStr(szXml);
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/WhiteBlance",
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}


/*************************************************
Function:		SetPowerLineFrequencyMode
Description:	设置视频制式
Input:			无		
Output:			无
return:			无				
*************************************************/
function SetPowerLineFrequencyMode()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var xmlDoc = null;
	var szXml = "";
	szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
			"<powerLineFrequency version='1.0' xmlns='urn:selfextension:psiaext-ver10-xsd'>" +
			"<powerLineFrequencyMode>" + $("#PowerLineFrequencyMode").val() + "</powerLineFrequencyMode>" +
			"</powerLineFrequency>";
	xmlDoc = parseXmlFromStr(szXml);
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/powerLineFrequency";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		EnableImageFlip
Description:	启用（禁用）镜像翻转 -- 已无效
Input:			无		
Output:			无
return:			无				
*************************************************/
/*
function  EnableImageFlip()
{
	//镜像翻转
	if($("#flipEnabled").prop("checked"))  //需替换
	{
		document.getElementById("ImageFlipStyle_tr").style.display = "";
		document.getElementById("ImageFlipStyle").value = m_szDefaultFlipStyle;  //能力级默认值
	}
	else
	{
		document.getElementById("ImageFlipStyle_tr").style.display = "none";
		m_szDefaultFlipStyle = document.getElementById("ImageFlipStyle").value;
	}
	SetImageFlip();
}*/


/*************************************************
Function:		EnableWDR
Description:	设置宽动态的值
Input:			无		
Output:			无
return:			无				
*************************************************/
function EnableWDR()
{
	var WDRCurVal = $("#WDREnabled").val();
	/*if((WDRCurVal == "true") || (WDRCurVal == "auto"))
	{
		$("#BLCMode").val('OFF');
	}*/
	SetWDRAndBLC();
}
/*************************************************
Function:		SetWDRAndBLC
Description:	设置宽动态与背光补偿
Input:			无		
Output:			无
return:			无				
*************************************************/
function SetWDRAndBLC()
{
	var bRes = false;
	var WDRCurVal = $("#WDREnabled").val();
	if(!window.parent.g_bIsIPDome)
	{
		if((WDRCurVal == "true") || (WDRCurVal == "auto"))
		{
			bRes = true;
		}
	}
	else
	{
		
	}
	//宽动态
	if(bRes)
	{
		if(isSupportWDRLevel)
		{
			if(isSupportWDRLevel1)
			{
				$("#WDRLevel_tr1").show();
			}
			if(isSupportWDRLevel2)
			{
				$("#WDRLevel_tr2").show();
			}
		}
		if(isSupportWDRContrastLevel)
		{
			$("#WDRContrastLevel_tr").show();
		}
		/*if(WDRCurVal == "auto")
		{
		    $("#WDRLevel_tr1").hide();
			$("#WDRLevel_tr2").hide();
		}*/
		$("#BLCMode_tr").hide();
		$("#BLCLevel_tr").hide();
	}
	else
	{
		$("#WDRLevel_tr1").hide();
		$("#WDRLevel_tr2").hide();
		$("#WDRContrastLevel_tr").hide();
		if(isSupportBLCMode)
		{
			$("#BLCMode_tr").show();
		}
		if($("#BLCMode").val() != "false" && isSupportBLCLevel)
		{
			$("#BLCLevel_tr").show();
		}
	}
	SetWDR();
	//SetBLC();
}
/*************************************************
Function:		ChangeWhiteBlance
Description:	切换白平衡模式
Input:			无		
Output:			无
return:			无				
*************************************************/
function ChangeWhiteBlance()
{
	//白平衡
	if($("#WhiteBlanceStyle").val() == "manual")
	{
		if(isSupportWhiteBlanceBlue)
		{
			$("#WhiteBlanceBlue_tr").show();
		}
		if(isSupportWhiteBlanceRed)
		{
			$("#WhiteBlanceRed_tr").show();
		}
	}
	else
	{
		$("#WhiteBlanceBlue_tr").hide();
		$("#WhiteBlanceRed_tr").hide();
	}
	SetWhiteBlance();
    autoResizeIframe();
}


/*************************************************
Function:		ChangeNosiseReduceExtMode
Description:	切换数字降噪模式
Input:			无		
Output:			无
return:			无				
*************************************************/
function ChangeNosiseReduceExtMode()
{
	var szNosiseReduceMode = $("#NosiseReduceExtMode").val();
	if(szNosiseReduceMode == "general")  			//普通模式
	{
		$("#GeneralLevel_tr").show();
		$("#InterFrameNoiseReduceLevel_tr").hide();
		$("#FrameNoiseReduceLevel_tr").hide();
	}
	else if(szNosiseReduceMode == "advanced")		//专家模式
	{
		$("#GeneralLevel_tr").hide();
		$("#InterFrameNoiseReduceLevel_tr").show();
		$("#FrameNoiseReduceLevel_tr").show();
	}
	else											//关闭
	{
		$("#GeneralLevel_tr").hide();
		$("#InterFrameNoiseReduceLevel_tr").hide();
		$("#FrameNoiseReduceLevel_tr").hide();
	}
	
	SetNosiseReduceExt();
    autoResizeIframe();
}

/*************************************************
Function:		SetNosiseReduceExt
Description:	设置数字降噪
Input:			无		
Output:			无
return:			无				
*************************************************/
function SetNosiseReduceExt()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var szNosiseReduceExtMode = $("#NosiseReduceExtMode").val();
	var xmlDoc = null;
	var szXml = "";
	if(szNosiseReduceExtMode == "general")   		//普通模式
	{
		szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
				"<NoiseReduceExt version='1.0' xmlns='urn:selfextension:psiaext-ver10-xsd'>" +
				"<mode>general</mode>" +
				"<GeneralMode>" + 
				"<generalLevel>" + generalLevel.getValue() + "</generalLevel>" + 
				"</GeneralMode>" +
				"</NoiseReduceExt>";
	}
	else if(szNosiseReduceExtMode == "advanced")   //专家模式
	{
		szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
				"<NoiseReduceExt version='1.0' xmlns='urn:selfextension:psiaext-ver10-xsd'>" +
				"<mode>advanced</mode>" +
				"<AdvancedMode>" + 
				"<FrameNoiseReduceLevel>" + frameNoiseReduceLevel.getValue() + "</FrameNoiseReduceLevel>" + 
				"<InterFrameNoiseReduceLevel>" + interFrameNoiseReduceLevel.getValue() + "</InterFrameNoiseReduceLevel>" + 
				"</AdvancedMode>" +
				"</NoiseReduceExt>";
	}
	else										   //关闭
	{
		szXml = "<?xml version='1.0' encoding='UTF-8'?>" +
				"<NoiseReduceExt version='1.0' xmlns='urn:selfextension:psiaext-ver10-xsd'>" +
				"<mode>close</mode>" +
				"</NoiseReduceExt>";
	}
	xmlDoc = parseXmlFromStr(szXml); 
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/NoiseReduceExt";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}


/*************************************************
Function:		InitSlider
Description:	初始化预览页面滑动条
Input:			无
Output:			无
return:			无
*************************************************/
function InitVideoSlider()
{
    sliderBright = InitOneSlider({
        targetId: 'VideoBright',
        tipsId: 'laBrightness',
        valueChanged: SetVideoParamColor
    });
    

    sliderContrast = InitOneSlider({
        targetId: 'VideoContrast',
        tipsId: 'laContrast',
        valueChanged: SetVideoParamColor
    });

    sliderSaturation = InitOneSlider({
        targetId: 'VideoSaturation',
        tipsId: 'laSaturation',
        valueChanged: SetVideoParamColor
    });
	
    sliderHue = InitOneSlider({
        targetId: 'VideoHue',
        tipsId: 'laHue',
        valueChanged: SetVideoParamColor
    });

    sliderGain = InitOneSlider({
        targetId: 'VideoGain',
        tipsId: 'laGain',
        valueChanged: SetVideoGain
    });        

	sliderSharpness = InitOneSlider({
        targetId: 'Sharpness',
        tipsId: 'laSharpness',
        valueChanged: SetSharpness
    });   


    sliderBlackPwl = InitOneSlider({
        targetId: 'BlackPwl',
        tipsId: 'laBlackPwl',
        valueChanged: SetBlackPwl
    });   
    
    sliderWDRLevel1 = InitOneSlider({
        targetId: 'WDRLevel1',
        tipsId: 'laWDRLevel1',
        valueChanged: SetWDR
    });   
	
    sliderWDRLevel2 = InitOneSlider({
        targetId: 'WDRLevel2',
        tipsId: 'laWDRLevel2',
        valueChanged: SetWDR
    });   

    sliderWDRContrastLevel = InitOneSlider({
        targetId: 'WDRContrastLevel',
        tipsId: 'laWDRContrast',
        valueChanged: SetWDR
    });   

    sliderBLCLevel = InitOneSlider({
        targetId: 'BLCLevel',
        tipsId: 'laBLCLevel',
        valueChanged: SetBLC
    });      

    sliderWhiteBlanceRed = InitOneSlider({
        targetId: 'WhiteBlanceRed',
        tipsId: 'laWhiteBlanceRed',
        valueChanged: SetWhiteBlance
    });     

    sliderWhiteBlanceBlue = InitOneSlider({
        targetId: 'WhiteBlanceBlue',
        tipsId: 'laWhiteBlanceBlue',
        valueChanged: SetWhiteBlance
    });     

	
    generalLevel = InitOneSlider({
        targetId: 'GeneralLevel',
        tipsId: 'laGeneralLevel',
        valueChanged: SetNosiseReduceExt
    });  

    interFrameNoiseReduceLevel = InitOneSlider({
        targetId: 'InterFrameNoiseReduceLevel',
        tipsId: 'laInterFrameNoiseReduce',
        valueChanged: SetNosiseReduceExt
    });  


    frameNoiseReduceLevel = InitOneSlider({
        targetId: 'FrameNoiseReduceLevel',
        tipsId: 'laFrameNoiseReduce',
        valueChanged: SetNosiseReduceExt
    }); 	

    NoiseReduceLevel = InitOneSlider({
        targetId: 'dv2DNoiseReduceLevelSlider',
        tipsId: 'la2DNoiseReduceLevel',
        valueChanged: Set2DNoiseReduceLevel
    }); 

    sliderAutoIrisLevel = InitOneSlider({
        targetId: 'AutoIrisLevel',
        tipsId: 'laAutoIrisLevel',
        valueChanged: SetAutoIrisLevel
    }); 	


    g_oSliderDehazeLevel = InitOneSlider({
        targetId: 'dvDehazeLevelSlider',
        tipsId: 'laDehazeLevel',
        valueChanged: SetDehaze
    }); 

    g_oSliderCSLevel = InitOneSlider({
        targetId: 'dvCSLevelSlider',
        tipsId: 'laChromaSuppress',
        valueChanged: setCSLevel
    }); 
	
    g_oSliderHLCLevel = InitOneSlider({
        targetId: 'dvHLCLevelSlider',
        tipsId: 'laHLC',
        valueChanged: setHLCLevel
    }); 
	
    g_oSliderExpCompLevel = InitOneSlider({
        targetId: 'dvExpCompLevelSlider',
        tipsId: 'laExpComp',
        valueChanged: setExpCompLevel
    }); 
	
	
	//电子防抖等级
    g_oSliderEISLevel = InitOneSlider({
        targetId: 'dvEISLevelSlider',
        tipsId: 'laEISLevel',
        valueChanged: setEISLevel
    }); 
	
	//伽马校正等级
    g_oSliderGamaCorrLevel = InitOneSlider({
        targetId: 'dvGamaCorrectLevelSlider',
        tipsId: 'laGamaCorrect',
        valueChanged: setGamaCorrLevel
    }); 

	//动态对比度等级
    SliderDynamicContrast = InitOneSlider({
        targetId: 'DynamicContrastLevel',
        tipsId: 'laDynamicContrastLevel',
        valueChanged: SetDynamicContrast
    }); 

	

	//红外灯亮度
    g_oIRLightBrightSlider = InitOneSlider({
        targetId: 'dvIRLightBrightSlider',
        tipsId: 'laIRLightBright',
        valueChanged: setIR
    }); 

	
	//红外灯灵敏度
    g_oIRLightSenSlider = InitOneSlider({
        targetId: 'dvIRLightSenSlider',
        tipsId: 'laIRLightSen',
        valueChanged: setIR
    }); 

	
	//抓拍增益
    SliderSnapGain = InitOneSlider({
        targetId: 'dvSnapGainSlider',
        tipsId: 'laSnapGain',
        valueChanged: SetSnapGain
    }); 

    SliderPlateExpectedBright = InitOneSlider({
        targetId: 'PlateExpectedBrightSlider',
        tipsId: 'laPlateExpectedBright',
        valueChanged: SetPlateExpectedBright
    }); 	

    SliderplateBrightSensitivity = InitOneSlider({
        targetId: 'plateBrightSensitivitySlider',
        tipsId: 'laplateBrightSensitivity',
        valueChanged: SetPlateExpectedBright
    }); 	

    SliderCorrectFactor = InitOneSlider({
        targetId: 'CorrectFactorSlider',
        tipsId: 'laCorrectFactor',
        valueChanged: SetCorrectFactor
    });     

	
    //亮度增强
    SliderbrightEnhance = InitOneSlider({
        targetId: 'brightEnhanceSlider',
        tipsId: 'labrightEnhance',
        valueChanged: SetbrightEnhance
    }); 

	
	//抓拍对比度
    sliderSnapContrast = InitOneSlider({
        targetId: 'SnapContrast',
        tipsId: 'laSnapContrast',
        valueChanged: SetVideoParamColor
    }); 

	
	
	//暗区增强等级
    g_oSliderDarkEnhanceLevel = InitOneSlider({
        targetId: 'dvDarkEnhanceLevelSlider',
        tipsId: 'laDarkEnhanceLevel',
        valueChanged: setDarkEnhance
    }); 

    DayNightFilterThSlider = InitOneSlider({
        targetId: 'dvDayNightFilterThSlider',
        tipsId: 'laDayNightFilterTh',
        valueChanged: SetDetectCfg
    });

    ExceptionCatchThSlider = InitOneSlider({
        targetId: 'dvExceptionCatchThSlider',
        tipsId: 'laExceptionCatchTh',
        valueChanged: SetDetectCfg,
        max: 255
    });

}
/*************************************************
Function:		ToResetimage
Description:	机芯复位
Input:			无			
Output:			无
return:			无				
*************************************************/
function ToResetimage()
{
	if(!confirm(getNodeValue('jsResetimage')))
	{
		return;
	}
	else
	{
		ToResetimage1();
	}
}
function ToResetimage1()
{
	szXmlhttp = new getXMLHttpRequest();   
	szXmlhttp.onreadystatechange = ToResetimageCallBack;   
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort +  "/PSIA/Custom/SelfExt/ITCImage/channels/1/resetImage";
	
    var userPwdValue = g_oWebSession.getItem("userInfo"+m_lHttpPort);
    var userName = Base64.decode(userPwdValue).split(":")[0];
    var password = Base64.decode(userPwdValue).split(":")[1];

    szXmlhttp.open("PUT", szURL, true,userName,password); 
	szXmlhttp.setRequestHeader("If-Modified-Since","0");  
    szXmlhttp.send(null);
}

function ToResetimageCallBack()
{
	var szTips1 = getNodeValue('jsResetSucceed'); 
	var szTips2 = getNodeValue('jsResetFailed'); 
	var szTips3 = getNodeValue('jsResetWaiting');
	
	var szPic = "<img src='../images/config/wait.gif' class='verticalmiddle'>&nbsp;";
	$("#SetResultTips").html(szPic+szTips3);
	
	if(szXmlhttp.readyState == 4)
	{   
		if(szXmlhttp.status == 403)
		{
			szRetInfo = m_szErrorState + m_szError8;
		}else if(szXmlhttp.status == 200)
		{
			var xmlDoc = parseXmlFromStr(szXmlhttp.responseText);
			
			if("1" == xmlDoc.documentElement.getElementsByTagName('statusCode')[0].childNodes[0].nodeValue)
			{
				szRetInfo = m_szSuccessState + szTips1;
			}
			else
			{
				szRetInfo = m_szErrorState + szTips2;
			}
		}
		else
		{
			szRetInfo = m_szErrorState + m_szError9;
		}
		$("#SetResultTips").html(szRetInfo); 
	}
}
/*************************************************
Function:		ToRestoreimage()
Description:	恢复机芯默认值
Input:			无			
Output:			无
return:			无				
*************************************************/
function ToRestoreimage()
{
	if(!confirm(getNodeValue('jsRestoreimage')))
	{
		return;
	}
	else
	{
		ToRestoreimage1();
	}
}
function ToRestoreimage1()
{
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/restoreImageparam";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		complete:function(xhr, textStatus)
		{
			var szTips1 = getNodeValue('jsRestoreSucceed'); 
			var szTips2 = getNodeValue('jsRestoreFailed'); 
			var szTips3 = getNodeValue('jsRestoreWaiting'); 
			
			var szPic = "<img src='../images/config/wait.gif' class='verticalmiddle'>&nbsp;";
			$("#SetResultTips").html(szPic+szTips3);
			
			if(xhr.status == 403)
			{
				szRetInfo = m_szErrorState + m_szError8;
			}
			else if(xhr.status == 200)
			{
				var xmlDoc = xhr.responseXML;
				if("1" == xmlDoc.documentElement.getElementsByTagName('statusCode')[0].childNodes[0].nodeValue)
				{
					szRetInfo = m_szSuccessState + szTips1;
				}
				else
				{
					szRetInfo = m_szErrorState + szTips2;
				}
			}
			else
			{
				szRetInfo = m_szErrorState + m_szError9;
			}
			$("#SetResultTips").html(szRetInfo);
		}
	});
}
/************************************************
Function:		SetDSS
Description:	设置低照度电子快门
Input:			无
Output:			无
return:			无
************************************************/
function SetDSS()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
    var XmlDoc = new createxmlDoc();
	var Instruction = XmlDoc.createProcessingInstruction("xml","version='1.0' encoding='utf-8'");
	XmlDoc.appendChild(Instruction);
	var Root = XmlDoc.createElement("DSS");

	Element = XmlDoc.createElement("enabled");

	if($("#DSSEnabled").prop("checked"))
	{
		text = XmlDoc.createTextNode("true");
	    Element.appendChild(text);
		$("#DSSLevel").prop("disabled",false);
	}
	else
	{
		text = XmlDoc.createTextNode("false");
	    Element.appendChild(text);
		$("#DSSLevel").prop("disabled",true);
	}
	Root.appendChild(Element);

	if(DSSLevelEnabled)
	{
		Element = XmlDoc.createElement("DSSLevel");
		text = XmlDoc.createTextNode($("#DSSLevel").val());
	    Element.appendChild(text);
		Root.appendChild(Element);
	}

	XmlDoc.appendChild(Root);

	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort +  "/PSIA/Custom/SelfExt/ITCImage/channels/1/DSS";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: XmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/************************************************
Function:		setEPTZEnable
Description:	设置是否启用电子云台
Input:			无
Output:			无
return:			无
************************************************/
function SetEPTZEnable()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><EPTZ version='1.0'><enabled>" + $("#selEPTZEnable").val() + "</enabled></EPTZ>";
	var xmlDoc = parseXmlFromStr(szXml);
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/EPTZ";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/************************************************
Function:		SetScene
Description:	设置室内外模式
Input:			无
Output:			无
return:			无
************************************************/
function SetScene()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><Scene><mode>" + $("#selScene").val() + "</mode></Scene>";
	var xmlDoc = parseXmlFromStr(szXml);
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/Scene";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/************************************************
Function:		SetAutoIrisLevel
Description:	设置自动光圈灵敏度
Input:			无
Output:			无
return:			无
************************************************/
function SetAutoIrisLevel()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><Exposure><ExposureType>auto</ExposureType><autoIrisLevel>" + sliderAutoIrisLevel.getValue() + "</autoIrisLevel></Exposure>";
	var xmlDoc = parseXmlFromStr(szXml);
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/Exposure";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/************************************************
Function:		SetDehaze
Description:	设置去雾
Input:			无
Output:			无
return:			无
************************************************/
function SetDehaze()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var szXml = "";
	szXml = "<?xml version='1.0' encoding='UTF-8'?><Dehaze><enabled>"+$("#chEnableDehaze").prop("checked").toString()+"</enabled>";
	if(g_IsSupportDehazeLevel)
	{
   		szXml += "<dehazeLevel>" + g_oSliderDehazeLevel.getValue() + "</dehazeLevel>";
	}
    szXml += "</Dehaze>";
	var xmlDoc = parseXmlFromStr(szXml);
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/dehaze",
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/************************************************
Function:		setZoomLimit
Description:	设置变倍限制
Input:			无
Output:			无
return:			无
************************************************/
function setZoomLimit()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var szXml = "";
	szXml = "<?xml version='1.0' encoding='UTF-8'?><ZoomLimit><ZoomLimitRatio>" + $("#selZoomLimit").val() + "</ZoomLimitRatio></ZoomLimit>";
	var xmlDoc = parseXmlFromStr(szXml);
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/ZoomLimit",
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/************************************************
Function:		setEISLevel
Description:	设置电子防抖等级
Input:			无
Output:			无
return:			无
************************************************/
function setEISLevel()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var szXml = "";
	if($("#dvEISLevel").css("display") != "none")
	{
		szXml = "<?xml version='1.0' encoding='UTF-8'?><EIS><enabled>"+$("#inEnableEIS").prop("checked").toString()+"</enabled><EISLevel>" + g_oSliderEISLevel.getValue() + "</EISLevel></EIS>";
	}
	else
	{
		szXml = "<?xml version='1.0' encoding='UTF-8'?><EIS><enabled>"+$("#inEnableEIS").prop("checked").toString()+"</enabled></EIS>";
	}
	var xmlDoc = parseXmlFromStr(szXml);
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/EIS",
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/************************************************
Function:		setCSLevel
Description:	色彩抑制等级
Input:			无
Output:			无
return:			无
************************************************/
function setCSLevel()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var szXml = "";
	szXml = "<?xml version='1.0' encoding='UTF-8'?><ChromaSuppress><enabled>true</enabled><ChromaSuppressLevel>" + g_oSliderCSLevel.getValue() + "</ChromaSuppressLevel></ChromaSuppress>";
	var xmlDoc = parseXmlFromStr(szXml);
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/ChromaSuppress",
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/************************************************
Function:		setHLCLevel
Description:	强光抑制等级
Input:			无
Output:			无
return:			无
************************************************/
function setHLCLevel()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var szXml = "";
	szXml = "<?xml version='1.0' encoding='UTF-8'?><HLC><enabled>true</enabled><HLCLevel>" + g_oSliderHLCLevel.getValue() + "</HLCLevel></HLC>";
	var xmlDoc = parseXmlFromStr(szXml);
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/HLC",
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/************************************************
Function:		setExpCompLevel
Description:	曝光补偿等级
Input:			无
Output:			无
return:			无
************************************************/
function setExpCompLevel()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var szXml = "";
	szXml = "<?xml version='1.0' encoding='UTF-8'?><ExpComp><enabled>true</enabled><ExpCompLevel>" + g_oSliderExpCompLevel.getValue() + "</ExpCompLevel></ExpComp>";
	var xmlDoc = parseXmlFromStr(szXml);
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/ExpComp",
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/************************************************
Function:		setIR
Description:	设置红外灯
Input:			无
Output:			无
return:			无
************************************************/
function setIR()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var szXml = "";
	if($("#selIRLightMode").val() == "auto")
	{
		$("#dvIRLightBright").hide();
		$("#dvIRLightSen").show();
		szXml = "<?xml version='1.0' encoding='UTF-8'?><IrLight><mode>auto</mode><sensitivityLevel>" + g_oIRLightSenSlider.getValue() + "</sensitivityLevel></IrLight>";
	}
	else
	{
		$("#dvIRLightBright").show();
		$("#dvIRLightSen").hide();
		szXml = "<?xml version='1.0' encoding='UTF-8'?><IrLight><mode>manual</mode><brightnessLevel>" + g_oIRLightBrightSlider.getValue() + "</brightnessLevel></IrLight>";
	}

	var xmlDoc = parseXmlFromStr(szXml);
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/IrLight",
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/************************************************
Function:		setGamaCorrLevel
Description:	设置伽马校正
Input:			无
Output:			无
return:			无
************************************************/
function setGamaCorrLevel()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	if($("#EnableGamaCorrect").prop("checked")) {
		$("#dvLseCapdvGamaCorrect").show();
	} else {
		$("#dvGamaCorrect").hide();
	}
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><gammaCorrection><gammaCorrectionEnabled>" + $("#EnableGamaCorrect").prop("checked").toString() + "</gammaCorrectionEnabled><gammaCorrectionLevel>" + g_oSliderGamaCorrLevel.getValue() + "</gammaCorrectionLevel></gammaCorrection>";
	var xmlDoc = parseXmlFromStr(szXml);
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/gammaCorrection",
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
	autoResizeIframe();
}

function SetDetectCfg () {
    if (!HWP.wnds[0].isPlaying)
    {
        return;
    }
    
    var szXml = "<?xml version='1.0' encoding='UTF-8'?>"+
                "<darkEnhance>"+
                    "<darkEnhanceEnabled>" + 
                        $("#darkEnhanceEnabled").prop("checked").toString() +
                    "</darkEnhanceEnabled>"+
                    "<darkEnhanceLevel>" + 
                        g_oSliderDarkEnhanceLevel.getValue() +
                    "</darkEnhanceLevel>"+
                "</darkEnhance>";
    //var xmlDoc = parseXmlFromStr(szXml);
    var xmlDoc = szXml;
    $.ajax(
    {
        type: "PUT",
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/darkEnhance",
        processData: false,
        data: xmlDoc,
        complete:function(xhr, textStatus)
        {
            SaveState(xhr);
        }
    });
    autoResizeIframe();
}
/************************************************
Function:		setDarkEnhance
Description:	设置暗区增强
Input:			无
Output:			无
return:			无
************************************************/
function setDarkEnhance()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	if($("#darkEnhanceEnabled").prop("checked")) {
		$("#dvDarkEnhance").show();
	} else {
		$("#dvDarkEnhance").hide();
	}
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><darkEnhance><darkEnhanceEnabled>" + $("#darkEnhanceEnabled").prop("checked").toString() + "</darkEnhanceEnabled><darkEnhanceLevel>" + g_oSliderDarkEnhanceLevel.getValue() + "</darkEnhanceLevel></darkEnhance>";
	var xmlDoc = parseXmlFromStr(szXml);
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/darkEnhance",
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
	autoResizeIframe();
}
/*************************************************
Function:		SetBlackPwl
Description:	设置黑电平
Input:			无
Output:			无
return:			无
*************************************************/
function SetBlackPwl()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var xmlDoc = null;
	var szXml = "";
	szXml = "<?xml version='1.0' encoding='UTF-8'?><BlackPwl version='1.0' xmlns='urn:selfextension:psiaext-ver10-xsd'>";
	szXml += "<blackPwlLevel>" + sliderBlackPwl.getValue() + "</blackPwlLevel></BlackPwl>";
	xmlDoc = parseXmlFromStr(szXml);
	$.ajax(
	{
		type: "PUT",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/BlackPwl",
		processData: false,
		data: xmlDoc,
		beforeSend: function(xhr)
		{
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		SetDynamicContrast
Description:	设置动态对比度
Input:			无
Output:			无
return:			无
*************************************************/
function SetDynamicContrast()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	if($("#DynamicContrastMode").val() == "true")
	{
		$("#DynamicContrastLevel_tr").show();
	}
	else
	{
		$("#DynamicContrastLevel_tr").hide();
	}
	var xmlDoc = null;
	var szXml = "";
	szXml = "<?xml version='1.0' encoding='UTF-8'?><DynamicContrast version='1.0' xmlns='urn:selfextension:psiaext-ver10-xsd'>";
	szXml += "<enabled>" + $("#DynamicContrastMode").val() + "</enabled>";
	szXml += "<dynamicContrastLevel>" + SliderDynamicContrast.getValue() + "</dynamicContrastLevel></DynamicContrast>";
	xmlDoc = parseXmlFromStr(szXml);
	$.ajax(
	{
		type: "PUT",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/DynamicContrast",
		processData: false,
		data: xmlDoc,
		beforeSend: function(xhr)
		{
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		SetFlipEnabled
Description:	设置是否图像旋转
Input:			无
Output:			无
return:			无
*************************************************/
function SetFlipEnabled()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	if($("#FlipEnabled").prop("checked"))
	{
//        $('#FlipStyle').prop('disabled',true);
		$("#FlipStyle_tr").show();
	}
	else
	{
//        $('#FlipStyle').prop('disabled',false);
		$("#FlipStyle_tr").hide();
	}
	var xmlDoc = null;
	var szXml = "";
	szXml = "<?xml version='1.0' encoding='UTF-8'?><Flip version='1.0' xmlns='urn:selfextension:psiaext-ver10-xsd'>";
	szXml += "<enabled>" + $("#FlipEnabled").prop("checked").toString() + "</enabled>";
	if($("#FlipEnabled").prop("checked"))
	{
		szXml += "<flipStyle>" + $("#FlipStyle").val() + "</flipStyle>";
	}
	szXml += "</Flip>";
	xmlDoc = parseXmlFromStr(szXml);
	$.ajax(
	{
		type: "PUT",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/Flip",
		processData: false,
		data: xmlDoc,
		beforeSend: function(xhr)
		{
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
    autoResizeIframe();
}
/*************************************************
Function:		VideoEventBind
Description:	事件绑定
Input:			无
Output:			无
return:			无
*************************************************/
function VideoEventBind() {
	//回车事件
    $("body").bind({
		keydown: function (e) {
			if(e.keyCode === 13) {
				if(e.target.id == "Shutter") {
					SetShutter();
				} else if(e.target.id == "SnapShutter") {
					SetSnapShutter();
				}else if(e.target.id == "JPEGSize") {
                    SetJPEGSize();
                }
			}
		}
	});
}
/*************************************************
Function:		SetSnapGain
Description:	设置抓拍增益参数
Input:			无
Output:			无
return:			无
*************************************************/
function SetSnapGain()
{
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><SnapGain><snapGainLevel>" + SliderSnapGain.getValue() + "</snapGainLevel></SnapGain>";
	var xmlDoc = parseXmlFromStr(szXml);
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/SnapGain";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
Function:		SetPlateExpectedBright
Description:	设置车牌亮度补偿参数
Input:			无
Output:			无
return:			无
*************************************************/
function SetPlateExpectedBright() {
    if (!HWP.wnds[0].isPlaying)
    {
        return;
    }
    if($("#IsUsePlateBright").prop("checked")) {
        //$("#dvPlateExpectedBright").show();
        $("#dvplateBrightSensitivity").show();
        //SliderPlateExpectedBright.wsetValue(parseInt($(xmlDoc).find('brightnessThreld').eq(0).text(), 10));
    } else {
        $("#dvPlateExpectedBright").hide();
        $("#dvplateBrightSensitivity").hide();
    }
    var szXml = "<?xml version='1.0' encoding='UTF-8'?><PlateBright><plateBrightEnabled>" + $("#IsUsePlateBright").prop("checked").toString() + "</plateBrightEnabled>";
    if($("#IsUsePlateBright").prop("checked")) {
        szXml += "<plateExpectedBright>" + SliderPlateExpectedBright.getValue() + "</plateExpectedBright>";
        szXml += "<plateBrightSensitivity>" + SliderplateBrightSensitivity.getValue() + "</plateBrightSensitivity>";
    }
    szXml += "</PlateBright>";
    var xmlDoc = parseXmlFromStr(szXml);
    var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/PlateBright";
    $.ajax(
        {
            type: "PUT",
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            url: szURL,
            processData: false,
            data: xmlDoc,
            complete:function(xhr, textStatus)
            {
                if($('#IsUsePlateBright').prop('checked')){

                    //$('#dvPlateExpectedBright').css('display','block');
                    $('#dvplateBrightSensitivity').css('display','block');

                    if($('#IsUseCorrectFactor').prop('checked')){
                        $('#IsUseCorrectFactor').prop('checked',false);
                        SetCorrectFactor();
                    }
                }else{
                    $('#dvPlateExpectedBright').css('display','none');
                    $('#dvplateBrightSensitivity').css('display','none');
                }
                SaveState(xhr);
            }
        });
    autoResizeIframe();
}
/*************************************************
Function:		SetCorrectFactor
Description:	设置补光灯纠正系数
Input:			无
Output:			无
return:			无
*************************************************/
function SetCorrectFactor() {

	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
    if($('#IsUseCorrectFactor').prop('checked')){

        if($('#IsUsePlateBright').prop('checked')){
            $('#IsUsePlateBright').prop('checked',false);
            SetPlateExpectedBright();
        }
    }
	var szXml = "<?xml version='1.0' encoding='UTF-8'?><PlateBright><correctFactorEnabled>" + $("#IsUseCorrectFactor").prop("checked").toString() + "</correctFactorEnabled>";
	szXml += "<correctFactor>" + SliderCorrectFactor.getValue() + "</correctFactor>";
	szXml += "</PlateBright>";
	var xmlDoc = parseXmlFromStr(szXml);
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/PlateBright";
	$.ajax(
	{
		type: "PUT",
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		url: szURL,
		processData: false,
		data: xmlDoc,
		complete:function(xhr, textStatus)
		{
			SaveState(xhr);
		}
	});
}
/*************************************************
 Function:		SetbrightEnhance
 Description:	设置亮度增强
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function SetbrightEnhance() {
    if (!HWP.wnds[0].isPlaying)
    {
        return;
    }
    var szXml = "<?xml version='1.0' encoding='UTF-8'?><brightEnhance><brightEnhanceLevel>" + SliderbrightEnhance.getValue() + "</brightEnhanceLevel></brightEnhance>";
    var xmlDoc = parseXmlFromStr(szXml);
    var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/brightEnhance";
    $.ajax(
        {
            type: "PUT",
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            url: szURL,
            processData: false,
            data: xmlDoc,
            complete:function(xhr, textStatus)
            {
                SaveState(xhr);
            }
        });
}

/*************************************************
 Function:		SetsectionCtrlEnabled
 Description:	设置分段控制
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function SetsectionCtrlEnabled() {
    if (!HWP.wnds[0].isPlaying)
    {
        return;
    }
    var szXml = "<?xml version='1.0' encoding='UTF-8'?><sectionCtrl><sectionCtrlEnabled>" + $("#sectionCtrlEnabled").prop("checked").toString() + "</sectionCtrlEnabled></sectionCtrl>";
    var xmlDoc = parseXmlFromStr(szXml);
    var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITCImage/channels/1/sectionCtrl";
    $.ajax(
        {
            type: "PUT",
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            url: szURL,
            processData: false,
            data: xmlDoc,
            complete:function(xhr, textStatus)
            {
                SaveState(xhr);
            }
        });
}

//抓拍测试功能
function SnapTest() {
	if (!HWP.wnds[0].isPlaying)
	{
		return;
	}
	if(m_PictureDisplayWindow && m_PictureDisplayWindow.open && !m_PictureDisplayWindow.closed) {
		m_PictureDisplayWindow.close();
	}
	//调用抓拍测试接口
	var myDate = new Date();
	m_strSnapFileName = myDate.Format("yyyyMMddhhmmssS") + ".jpg";
	var iDownloadID = -1;
	try
	{
		iDownloadID = HWP.StartSnapPicDownLoad(m_lHttp+m_szHostName+":"+m_lHttpPort+"/PSIA/Streaming/channels/1/picture", m_szUserPwdValue, m_strSnapFileName);
		m_PictureDisplayWindow = window.parent.open("about:blank",'PictureDisplay','height=620,width=941,top=250,left=300,toolbar=no,menubar=no,scrollbars=no,resizable=no,location=no,status=no');
	}catch(e)
	{
		iDownloadID = -1;
	}
}

/*************************************************
Function:		PluginEventHandler
Description:	图片回放事件响应
Input:			iEventType 事件类型, iParam1 参数1, iParam2 保留
Output:			无
return:			无
*************************************************/
function PluginEventHandler(iEventType, iParam1, iParam2) {
	if(66 == iEventType) {
		if(0 == iParam1){
			//调用成功弹图片显示界面
	        m_PictureDisplayWindow.location="picturedisplay.asp?FileName=" + m_strSnapFileName;   
			//m_PictureDisplayWindow = window.parent.open("picturedisplay.asp?FileName=" + m_strSnapFileName,'PictureDisplay','height=620,width=941,top=250,left=300,toolbar=no,menubar=no,scrollbars=no,resizable=no,location=no,status=no');
		} else {
			alert(getNodeValue("jsDownloadFailed"));	
		}
	} else if(67 == iEventType) {
        if($("#selTriggerMode").val() == "videoEpolice") {
            if(iParam2 > 3) {
                if(iParam2 == 4) {
                    $("#lineType").prop("disabled", false);
                } else {
                    $("#lineType").prop("disabled", true);
                }
                var iIndex = parseInt(iParam2) - 4;
                $("#lineType").val(ia(TriggerMode).m_strCommonLineType[iIndex]);
                ia(TriggerMode).m_strSelLineNum = "0:" + iParam2;
            } else {
                if(iParam2 == 0) {
                    $("#lineType").prop("disabled", false);
                } else {
                    $("#lineType").prop("disabled", true);
                }
                $("#lineType").val(ia(TriggerMode).m_strLineType[iParam1-1][iParam2]);
                ia(TriggerMode).m_strSelLineNum = iParam1 + ":" + iParam2;
            }
        }
	}
}
