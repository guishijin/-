
function postHVTTriggerModeS(){
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(postHVTTriggerModeS);

postHVTTriggerModeS.prototype.updateLang=function(){
	$('#CommendParamBtn,#SaveConfigBtn').hide();

	g_transStack.clear();
	var that=ia(postHVTTriggerModeS);
	g_transStack.push(function(){
		var prsDoc=parent.translator.getLanguageXmlDoc("postHVTTriggerMode");
		that.setLxd(prsDoc);

		var tModeDoc=parent.translator.getLanguageXmlDoc("TriggerMode");
		parent.translator.appendLanguageXmlDoc(that.getLxd(),tModeDoc);

		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	},true);
};

(function(window){
	var postHVTTriggerMode=window.postHVTTriggerMode||{};

	m_postHVTXml = null;
	m_PlateRecognitionXml = null;

	var m_iCurSelIONum = 1;
    var m_iLastSelIONum = 0;
    var m_bSetTriggerMode = false;
	var m_bRebootRequired = false;
	var m_iSyncOutNum=0;

	postHVTTriggerMode.updateLang=function(){
		ia(postHVTTriggerModeS).updateLang();
	};
    
    //加载页面数据
	postHVTTriggerMode.updateParam=function(iValueType){
		if ($("#main_plugin").html() == "") {
			if (checkPlugin('2', getNodeValue('laPlugin'), 1, 'snapdraw', 0)) {
				if (!CompareFileVersion()) {
					UpdateTips();
				}
			}
		}
		HWP.Stop(0);
		HWP.Play();
        
        //填充车道数据界面
        $("#dvTriggerParam").html($("#dvpostHVT").html());
		$("#laTriggerParam").html(getNodeValue("postHVTTitle"));
        
        //$('#drawRightRegionContent').css("display","block");
        $('#drawRightRegionContent').html($('#rightPostHVTContent').html());

        postHVTTriggerMode.m_iSyncOutNum = pr(DeviceInfo).queryAlarmOutNum();
        var szDivInfo = "";
		for(var i = 0; i < postHVTTriggerMode.m_iSyncOutNum; i++) {
            if(i == 3 || i == 6){
                szDivInfo += "<br>";
            }
			szDivInfo += "<div style='display:inline-block;margin-bottom:7px;'><input class='checkbox' name='AlarmOutputCheckbox' id='AlarmOutputCheckboxChanO-"+ (i + 1)+"' type='checkbox'>&nbsp;"+"F" + (i + 1) + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>";
		}
		$("#DisPlayLinkageList").html(szDivInfo); 
        
        postHVTTriggerMode.GetPlateRecognition("postHVT", 0);
        postHVTTriggerMode.GetPostHVTParamCap();
	    postHVTTriggerMode.GetPostHVTParam(0);
        
        autoResizeIframe();
	};

	postHVTTriggerMode.getCommendParam=function(){
		postHVTTriggerMode.GetPlateRecognition("postHVT", 1);
        postHVTTriggerMode.GetPostHVTParamCap();
	    postHVTTriggerMode.GetPostHVTParam(1);
	}

	//保存页面数据
	postHVTTriggerMode.submitParam=function(){
		this.setHVTAdvanceParam();
		this.StoreHVTGParam();
		
		var iLastIndex = parseInt(m_iCurSelIONum) - 1;  
		this.StoreHVTLaneParam(iLastIndex);

		postHVTTriggerMode.m_bSetTriggerMode = false;
		var laneCount = $('#RelatedLaneCount_postHVT').val();
		$(postHVTTriggerMode.m_postHVTXml).find('RelatedLaneCount').eq(0).text(laneCount);

		var eff = 0;
		if ($('#leftTriggerLine_HVT').prop('checked')) {
			eff |= 1;
		}

		if ($('#rightTriggerLine_HVT').prop('checked')) {
			eff |= (1 << 1);
		}

		if ($('#objectDetectAera_HVT').prop('checked')) {
			eff |= (1 << 2);
		}

		$(postHVTTriggerMode.m_postHVTXml).find('trigLineEffect').eq(0).text(eff);

		this.CopyPostHVTParam(iLastIndex);	
		this.CopyPostHVTRadarParam(iLastIndex);

		$.ajax({
			type: "put",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/PostHVT",
			timeout: 15000,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			data: xmlToStr(postHVTTriggerMode.m_postHVTXml),
			processData: false,

			complete:function(xhr, textStatus) {
				if(xhr.status != 200) {
					if(xhr.status == 403) {
						var szErrorInfo = m_szError8;
						szRetInfo = m_szErrorState + szErrorInfo;
					} else {
						var xmlDoc =xhr.responseXML;
						if($(xmlDoc).find("detailedStatusCode").eq(0).text() != "") {
							var szErrorInfo = getNodeValue("Error" + $(xmlDoc).find("detailedStatusCode").eq(0).text());
						} else {
							var szErrorInfo = m_szError13;
						}
						szRetInfo = m_szErrorState + szErrorInfo;
					}
		            $("#SetResultTips").html(szRetInfo); 
			        setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			        return;	
				} else {
					if($(xhr.responseXML).find("statusCode").eq(0).text() == "7") {
						postHVTTriggerMode.m_bRebootRequired = true;
					}else{
						postHVTTriggerMode.m_bRebootRequired = false;
					}
					postHVTTriggerMode.m_bSetTriggerMode = true;
				    postHVTTriggerMode.SetPlateRecognition("postHVT");
				}
			}
		});
	};
    
    //获取卡口混合车道的能力集
	postHVTTriggerMode.GetPostHVTParamCap = function () {
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/PostHVT/capabilities",
			timeout: 15000,
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				var min =  $(xmlDoc).find("RelatedLaneCount").eq(0).attr("min");
				var max =  $(xmlDoc).find("RelatedLaneCount").eq(0).attr("max");

				min = parseInt(min, 10);
				max = parseInt(max, 10);
				fillLaneCountOptions(min, max, null);
				g_transStack.translate();
			},
			error: function (xmlDoc) {
				var min = 1;
				var max = 3;
				fillLaneCountOptions(min, max, null);
				g_transStack.translate();
			}
		});
	}

	//获取卡口混合车道的参数
	postHVTTriggerMode.GetPostHVTParam = function (iValueType) {
		var szUrl = "/PSIA/Custom/SelfExt/ITC/PostHVT";
		if(iValueType == 1) {
			szUrl += "/recommendation";
		}
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + szUrl,
			timeout: 15000,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				postHVTTriggerMode.m_postHVTXml = parseXmlFromStr(xmlToStr(xmlDoc));
				
				g_transStack.translate();		

                $.ajax(
                    {
                        type: "GET",
                        async: false,
                        url:  m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/deviceInfo",
                        beforeSend: function(xhr) {
                            xhr.setRequestHeader("If-Modified-Since", "0");
                            
                        },
                        success: function(xmlDoc, textStatus, xhr) {
                            radarRS485Num = $(xmlDoc).find('maxRS485Num').eq(0).text();
                        }
                });

                var $sel = $('#dvTriggerParam #radarEnableDiv_HVT').find('#radarRS485_HVT');
            	$sel.find('option').each(function(i, n){
            		var v = $(this).attr('value');
            		if (parseInt(v) > radarRS485Num) {
            			$(this).remove();
            		}
            	});

                if(radarRS485Num == 1){
                    $('#dvTriggerParam #radarEnableDiv_HVT').css('display','none');
                    $sel.find('#RadarEnabledOpt0_HVT').remove();
                }else{                	
                    $('#dvTriggerParam #radarEnableDiv_HVT').css('display','block');
                }

                postHVTTriggerMode.PostHVTAdvanceParam();
                $.each(['sceneMode', 'capMode', 'speedDetector', 'snapType','enableComLoopTrig', 
                		'eCarHighSpeed','eCarLowSpeed','eBigCarHighSpeed','eBigCarLowSpeed'], function(i,n){
                		var sel = '#taTriggerMode_postHVT *[x-model='+n+'] ';
                		var v = $(xmlDoc).find(n).eq(0).text();
                		$.g.setField2(sel, v);

                		if (n == 'speedDetector') {
                			postHVTTriggerMode.changeSpeedDetectorHVT(v);
                		};
                });

				for(var i = 1; i <= 5; i++) {
					if(i > parseInt($(xmlDoc).find("RelatedLaneCount").eq(0).text())) {
					    $("#dvTriggerParam #liHVT" + i).hide();
					} else {
						$("#dvTriggerParam #liHVT" + i).show();
					}
				}

				postHVTTriggerMode.changeSpeedParam();
				
				$.g.setField2('#RelatedLaneCount_postHVT', $(xmlDoc).find("RelatedLaneCount").eq(0).text());
				postHVTTriggerMode.SetLineEffect();

				postHVTTriggerMode.DisplayHVTLaneParam(0);


				m_iCurSelIONum = 1;
				m_iLastSelIONum = 1;

				
				PostHVTReDisplay();
			}
		});		
	}

    function fillLaneCountOptions(min, max, curVal){
		if (min <= 0) {
			min = 1;
		}
        var $s = $('#RelatedLaneCount_postHVT');
        $s.find('option').remove();
        for (var i=min; i <= max; i++) {
            var opt = "<option value='"+i+"' ";
            if (curVal != null && i == curVal) {
                opt += " selected='selected' ";
            }
            opt += ">"+i+"</option>";
            
            $s.append(opt);
        }
    }

    postHVTTriggerMode.PostHVTAdvanceParam = function () {
		if(postHVTTriggerMode.m_postHVTXml == null) {
			return;
		}
		var intType = $(postHVTTriggerMode.m_postHVTXml).find("intervalType").eq(0).text();
		$.g.setField2("#postHVT_g_params_div #IntervalType", intType);
		
		var $doc = $(postHVTTriggerMode.m_postHVTXml);

		postHVTTriggerMode.changeHVTIntervalType($(postHVTTriggerMode.m_postHVTXml).find("intervalType").eq(0).text(), true);
		
		var $intvs = $doc.find('intervalValue');
		for (var i = 0; i < $intvs.length; i++) {
			if (i < 2) {
				var v = $intvs.eq(i).text();
				$('#postHVT_g_params_div #Interval'+(i+1)).val(v);
			}
		};

		$.each(['post', 'reverse', 'overSpeed','lowSpeed', 'banSign', 'driveLine','nonDriveWay','emergency'], function(i,n){
			var $capNo = $('#postHVT_g_params_div #vt'+n+'CapNo');
			//$capNo.find('option').remove();

			$.g.setField2('#postHVT_g_params_div #vt'+n, $doc.find(n).text());

            //$.g.setField2('#postHVT_g_params_div #vtdriveLineSensitivity', $doc.find('driveLineSensitivity').text());

			//if($("#taTriggerMode_postHVT #capMode_HVT").val() == "capFrame") { // 爆闪 1-3
				// for (var i = 1; i <= 3; i++) {
				// 	$capNo.append("<option value='"+i+"'>"+i+"</option>");
				// };
				var v = $doc.find(n+"CapNo").text();
				$.g.setField2('#postHVT_g_params_div #vt'+n+"CapNo", v);
				$capNo.prop('disabled', false).attr('disabled', false);
			// } else {
			// 	if(n != "post") {
			// 		$capNo.append("<option value='"+2+"'>"+2+"</option>");
			// 		$.g.setField2('#vt'+n+"CapNo", 2);
			// 		$("#vt" + n + "CapNo").prop("disabled", true).attr('disabled', true);
			// 	}else{  // post  1-2
			// 		for (var i = 1; i < 3; i++) {
			// 			$capNo.append("<option value='"+i+"'>"+i+"</option>");
			// 		};
			// 		var v = $doc.find(n+"CapNo").text();
			// 		$.g.setField2('#postHVT_g_params_div #vt'+n+"CapNo", v);
			// 		$capNo.prop('disabled', false).attr('disabled', false);
			// 	}
			// }


			
		});
	    //$("#postHVT_g_params_div").modal();
	}

	//改变连拍间隔类型
	postHVTTriggerMode.changeHVTIntervalType=function (strType, isVtcoil) {
		if(strType == "time") {
			$("#postHVT_g_params_div #IntervalUnit").html("ms");
			$("#postHVT_g_params_div .IntervalUnit").html("ms");
			$("#postHVT_g_params_div #IntervalUnit1").html("ms");
			$("#postHVT_g_params_div #DelayIntervalUnit").html("ms");
			$(".width34").unbind("blur").blur(function () {
				if(this.value != "" && !isVtcoil) {
				    CheackTriggerIntNum(this, this.value,'laInterval',0,60000,'ms');
				}
			});
			$(".width75").unbind("blur").blur(function () {
				if(this.value != "" && !isVtcoil) {
				    CheackTriggerIntNum(this, this.value,'laInterval',0,60000,'ms');
				}
			});
		} else {
			$("#postHVT_g_params_div #IntervalUnit").html("dm");
			$("#postHVT_g_params_div .IntervalUnit").html("dm");
			$("#postHVT_g_params_div #IntervalUnit1").html("dm");
			$("#postHVT_g_params_div .width34").unbind("blur").blur(function () {
				if(this.value != "" && !isVtcoil) {
				    CheackTriggerIntNum(this, this.value,'laInterval',0,50,'dm');
				}
			});
			$("#postHVT_g_params_div .width75").unbind("blur").blur(function () {
				if(this.value != "" && !isVtcoil) {
				    CheackTriggerIntNum(this, this.value,'laInterval',0,50,'dm');
				}
			});
			$("#postHVT_g_params_div #DelayIntervalUnit").html("dm");
		}
	}

	postHVTTriggerMode.changeSpeedDetectorHVT=function(value) {
		if (value == 'radarSpeed') {
			$('#dvTriggerParam #radarEnabledContent').show();
		}else{
			$('#dvTriggerParam #radarEnabledContent').hide();
		}

		postHVTTriggerMode.changeSpeedParam();
	}

	postHVTTriggerMode.changeCapModeHVT=function(){

	}

	postHVTTriggerMode.changeSpeedParam=function() {
		var value = $('*[x-model=speedDetector]').val();

		if ((value == 'radarSpeed' || value == 'videoSpeed')
				&& ($('#vtoverSpeed').prop('checked') || $('#vtlowSpeed').prop('checked'))) {
			$('#speedParamDiv, #taTriggerMode_postHVT #drawRightRegionContent').show();
		}else{
			$('#speedParamDiv, #taTriggerMode_postHVT #drawRightRegionContent').hide();
		}
		autoResizeIframe();
	}

	postHVTTriggerMode.SetLineEffect = function(){
		var v = $(postHVTTriggerMode.m_postHVTXml).find('trigLineEffect').eq(0).text();
		v = parseInt(v, 10);

		$.g.setField2('#leftTriggerLine_HVT', (v & 1) ? true : false);
		$.g.setField2('#rightTriggerLine_HVT', (v & (1 << 1)) ? true : false);
		$.g.setField2('#objectDetectAera_HVT', (v & (1 << 2)) ? true : false);
	}

	postHVTTriggerMode.DisplayHVTLaneParamInner = function (laneIndex) {
		laneIndex = parseInt(laneIndex, 10);
		var xmlDoc = postHVTTriggerMode.m_postHVTXml;

		var $firstLaneXmlDoc = $(xmlDoc).find('HvtLane').eq(laneIndex);
		$.each(['laneNO','laneDirectionType','relatedDriveWay', 'laneUsage', 'trucksType','laneType','signSpeed', 'highSpeedLimit',
				 'lowSpeedLimit', 'bigCarSignSpeed', 'bigCarHighSpeedLimit','bigCarLowSpeedLimit',
				 'radarType', 'radarRS485', 'radarSensitivity', 'radarAngle', 'validRadarSpeedTime', 
				 'radarLinearCorrection', 'radarConstantCorrection',
				 'flashMode' ], function  (i, n) {
			var sel = '#dvTriggerParam *[x-model='+n+']';
    		var v = $firstLaneXmlDoc.find(n).eq(0).text();
    		if (v != '') {
    			$.g.setField2(sel, v, true);	
    		}
    		if (n == 'laneUsage') {
	    		if(v == "banTrucks"){
		            $('#postHVTTriggerPanesDiv #dvbanTrucksTimeSwitch').css("display","block");
                    $('#postHVTTriggerPanesDiv #dvtrucksTypeSwitch').css("display","block");
		        }else{
		            $('#postHVTTriggerPanesDiv #dvbanTrucksTimeSwitch').css("display","none");
                    $('#postHVTTriggerPanesDiv #dvtrucksTypeSwitch').css("display","none");
		        }	
    		};
		});

		$("#dvTriggerParam #carDriveDirect").val($firstLaneXmlDoc.find("carDriveDirect").eq(0).text());
		function _tm2(v) {
			v = parseInt(v, 10);
			if (v < 10) {
				return "0"+v;
			}
			return v;
		}

		//大车禁行时间段
		$bTTList = $firstLaneXmlDoc.find('banTrucksTimeSwitch');
		var $bttdom = $('#dvTriggerParam #dvbanTrucksTimeSwitch');
		var arr = [];
		for (var i = 0; i < 4; i++) {
			var $n = $bTTList.eq(i);
			
			var startTime = _tm2($n.find('startHour').text())+":"+_tm2($n.find("startMinute").text());
			var endTime = _tm2($n.find('endHour').text())+":"+_tm2($n.find("endMinute").text());
			
			$bttdom.find('*[x-model=time'+(i+1)+'Start]').val(startTime);
			$bttdom.find('*[x-model=time'+(i+1)+'End]').val(endTime);
		};

		$firstLaneXmlDoc.find('IOOut').each(function (i, n) {
			var id = $(n).find('id').text();
			var enabled = $(n).find('enabled').text().toLowerCase() == 'true';
			$.g.setField2('#dvTriggerParam #AlarmOutputCheckboxChanO-'+id, enabled);
		});	
	}

	postHVTTriggerMode.DisplayHVTLaneParam = function (laneIndex) {
		$('#dvTriggerParam #tabpostHVT li').find('a').removeClass('current');
		$('#dvTriggerParam #tabpostHVT li#liHVT'+(laneIndex+1)).find('a').addClass('current');

		this.DisplayHVTLaneParamInner(laneIndex);

		getTriggerIOCopyRadarForHVT();
        getTriggerIOCopyInfoForHVT();	
	}

	function getTriggerIOCopyRadarForHVT(){
        $('#TriggerIOCopyRadarDiv_HVT').find('div.singleIo_checkbox_copy_div').remove();
        var len = $('#RelatedLaneCount_postHVT').val();

        for(var i=0; i < len; i++){

            var disStr = '';
            if($('#tabpostHVT #liHVT' + (i+1)).find('a').first().is('.current')){
                disStr = 'disabled="disabled" checked="checked" ';
            }
            var arr = ['<div class="singleIo_checkbox_copy_div">',
                '<input id="HVT_copyRadar_checkbox_'+(i+1)+'" ioIdx="'+(i+1)+'" type="checkbox" ',
                disStr,
                'class="singleIo_checkbox"><label for="HVT_copyRadar_checkbox_'+(i+1)+'" ',
                ' class="singleIo_checkbox">'+getNodeValue('aRelatedLane'+(i+1))+'</label></div>'];

            $('#TriggerIOCopyRadarDiv_HVT').append(arr.join(' '));
        }
    }

    function getTriggerIOCopyInfoForHVT(){

        $('#TriggerIOCopyDiv_HVT').find('div.singleIo_checkbox_copy_div').remove();
        var len = $('#RelatedLaneCount_postHVT').val();

        for(var i=0; i < len; i++){

            var disStr = '';
            if($('#tabpostHVT #liHVT' + (i+1)).find('a').first().is('.current')){
                disStr = 'disabled="disabled" checked="checked" ';
            }
            var arr = ['<div class="singleIo_checkbox_copy_div">',
                '<input id="HVT_copy_checkbox_'+(i+1)+'" ioIdx="'+(i+1)+'" type="checkbox" ',
                disStr,
                'class="singleIo_checkbox"><label for="HVT_copy_checkbox_'+(i+1)+'" ',
                ' class="singleIo_checkbox">'+getNodeValue('aRelatedLane'+(i+1))+'</label></div>'];

            $('#TriggerIOCopyDiv_HVT').append(arr.join(' '));
        }
    }

	function PostHVTReDisplay () {
		HWP.ClearSnapInfo(4);
		if ($('#drawAllPicCheck').prop('checked')) {
			var laneCount = $('#RelatedLaneCount_postHVT').val();
			var arr = [];
			for (var i = 1; i <= laneCount; i++) {
				arr.push(i);
			}
			DisplayPlateRegionEx(arr, null, null);
	    	DisplayPostHVTRegion(arr, null, {r:255,g:0,b:0});
		}else{
			DisplayPlateRegionEx([m_iCurSelIONum], null, null);
	    	DisplayPostHVTRegion([m_iCurSelIONum], null, {r:255,g:0,b:0});
		}
		HWP.SetSnapDrawMode(-1);
	}

	var postHVTTemp;
	function DisplayPostHVTRegion (regionIdArray, ocxSel, color, useTmpXmlEle, dispOpt) {

		var domEle;
		if (useTmpXmlEle && postHVTTemp) {
			domEle = postHVTTemp;
		}else{
			domEle = postHVTTriggerMode.m_postHVTXml;	
		}

		if (!ocxSel) {
			ocxSel = '#PreviewActiveX';
		}
		
		var ocx = $(ocxSel)[0];

		try{	
			//ocx.HWP_ClearSnapInfo(4);
		}catch(e){}

		var opts = {
			laneLine: true,
			laneRightBoundaryLine: true,
			triggerLine: true,
			leftTriggerLine: $('#leftTriggerLine_HVT').prop('checked'),
			rightTriggerLine: $('#rightTriggerLine_HVT').prop('checked'),
			objectDetectAera: $('#objectDetectAera_HVT').prop('checked')
		};

		opts = $.extend({}, opts, dispOpt);

		var $regionList = $(domEle).find('HvtLane');

		var polygonArray = [];
		var obj = {
			SnapPolygonList:{
				SnapPolygon: []
			}
		};

		if (!color) {
			color = {r: 255, g:255, b:0};
		}

		if(opts.objectDetectAera){
			var pts = [];
			var $r = $(domEle).find('ObjectDetectAera');

			var $_pts = $r.find('AeraCoordinates');
			$_pts.each(function (i, n) {
				var tx = parseInt($(n).find('positionX').text());
				var ty = parseInt($(n).find('positionY').text());
				pts.push({
					x:(tx/1000).toFixed(3),
					y:(ty/1000).toFixed(3)
				});
			});

	        var objDetColor = {r: 255, g:0, b:255};

			obj['SnapPolygonList']['SnapPolygon'].push({
				id: 100,
				polygonType: 1,
				color: objDetColor,
				tips: getNodeValue("ObjectDetectAera"),
				isClosed: "true",
				pointList: {
					point:pts
				}
			});
		}

		var xml = x2js.json2xml_str(obj, true);

		try{	
			ocx.HWP_SetSnapPolygonInfo(xml);
		}catch(e){}

		

		var snapLines = {
			SnapLineList: {
				SnapLine:[]
			}
		};
		if (opts.laneLine) {
			$(domEle).find('HvtLane').each(function () {
				var $line = $(this).find('LaneLine').eq(0);
				var coilId = parseInt($(this).find('HvtLaneNum').text());

				if (_.contains(regionIdArray, coilId)) {
					var lineName = $line.find('lineName').eq(0).text();
					var itype = $line.find("lineType").text();
					$("#lineType"+coilId).val(itype);

					if (lineName == 'laneLine') {
						var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
						var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
						var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
						var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

						var LineType = postHVTTriggerMode.TransLineType(lineName);

						var color = {r: 0, g: 0, b: 255};

						var _line = {
							id: 200+coilId,
							LineType: LineType,
							Tips:  getNodeValue(szTips[LineType])+coilId,
							StartPos: {
								x: startX,
								y: startY
							},
							EndPos: {
								x: endX,
								y: endY
							},
							color: color
						};

						snapLines.SnapLineList.SnapLine.push(_line);
					}
				}
			});
		}

		if (opts.laneRightBoundaryLine) {
			var $line = $(domEle).find('LaneRightBoundaryLine').eq(0);
			var lineName = $line.find('lineName').eq(0).text();
            		var itype = $line.find('lineTypeRight').eq(0).text();
            		$("#lineTypeRight").val(itype);
			if (lineName == 'laneRightBoundaryLine') {
				var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
				var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
				var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
				var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

				var LineType = postHVTTriggerMode.TransLineType(lineName);

				var color = {r: 0, g: 0, b: 255};

				var _line = {
					id: LineType*100,
					LineType: LineType,
					Tips:  getNodeValue(szTips[LineType]),
					StartPos: {
						x: startX,
						y: startY
					},
					EndPos: {
						x: endX,
						y: endY
					},
					color: color
				};

				snapLines.SnapLineList.SnapLine.push(_line);
			}
		}

		if (opts.triggerLine) {
			var $line = $(domEle).find('TriggerLine').eq(0);
			var lineName = $line.find('lineName').eq(0).text();

			if (lineName == 'triggerLine') {
				var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
				var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
				var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
				var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

				var LineType = postHVTTriggerMode.TransLineType(lineName);

				var color = {r: 255, g: 0, b: 0};

				var _line = {
					id: LineType*100,
					LineType: LineType,
					Tips:  getNodeValue("HVTtriggerLine"),
					StartPos: {
						x: startX,
						y: startY
					},
					EndPos: {
						x: endX,
						y: endY
					},
					color: color
				};

				snapLines.SnapLineList.SnapLine.push(_line);
			}
		}	

		if (opts.leftTriggerLine) {
			var $line = $(domEle).find('LeftTriggerLine').eq(0);
			var lineName = $line.find('lineName').eq(0).text();

			if (lineName == 'leftTriggerLine') {
				var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
				var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
				var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
				var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

				var LineType = postHVTTriggerMode.TransLineType(lineName);

				var color = {r: 0, g: 255, b: 0};

				var _line = {
					id: LineType*100+1,
					LineType: LineType,
					Tips:  getNodeValue("HVTleftTriggerLine"),
					StartPos: {
						x: startX,
						y: startY
					},
					EndPos: {
						x: endX,
						y: endY
					},
					color: color
				};

				snapLines.SnapLineList.SnapLine.push(_line);
			}
		}	

		if (opts.rightTriggerLine) {
			var $line = $(domEle).find('RightTriggerLine').eq(0);
			var lineName = $line.find('lineName').eq(0).text();

			if (lineName == 'rightTriggerLine') {
				var startX = (parseFloat($line.find('positionX').eq(0).text())/1000).toFixed(4);
				var startY = (parseFloat($line.find('positionY').eq(0).text())/1000).toFixed(4);
				var endX = (parseFloat($line.find('positionX').eq(1).text())/1000).toFixed(4);
				var endY = (parseFloat($line.find('positionY').eq(1).text())/1000).toFixed(4);

				var LineType = postHVTTriggerMode.TransLineType(lineName);
				
				var color = {r: 0, g: 255, b: 0};
				

				var _line = {
					id: LineType*100+2,
					LineType: LineType,
					Tips:  getNodeValue('HVTrightTriggerLine'),
					StartPos: {
						x: startX,
						y: startY
					},
					EndPos: {
						x: endX,
						y: endY
					},
					color: color
				};

				snapLines.SnapLineList.SnapLine.push(_line);
			}
		}	

		if (snapLines.SnapLineList.SnapLine.length) {
			var szLineInfo = x2js.json2xml_str(snapLines);
			ocx.HWP_SetSnapLineInfo(szLineInfo);

			ocx.HWP_SetSnapDrawMode(0, 3);
		}
	}

	postHVTTriggerMode.okPostHVTModal=function() {
		$("#main_plugin").show();
	    if (HWP.Play() !== 0) {
	        alert(getNodeValue("previewfailed"));
	    }

	   	var tmpObj = {};
	    $('#leftTriggerLine_HVT, #rightTriggerLine_HVT, #objectDetectAera_HVT').each(function (i, n) {
	    	var v = $(this).prop('checked');
	    	
	    	tmpObj[$(this).attr('id')] = v;
	    });

	    RestorePlateRegion('#HVTDrawActiveX', true);
	    RestoreHVTRegion();

		postHVTTriggerMode.m_postHVTXml = x2js.parseXmlString(xmlToStr(postHVTTemp));
		postHVTTriggerMode.m_PlateRecognitionXml = x2js.parseXmlString(xmlToStr(plateRegionEleTemp));
	    $.modal.impl.close();

	    $.each(['leftTriggerLine_HVT', 'rightTriggerLine_HVT', 'objectDetectAera_HVT'], function (i, n) {
	    	$('#'+n).prop('checked', tmpObj[n]);
	    });

	   	PostHVTReDisplay();
	}

	function RestorePlateRegion(ocxSel, useTmpXmlEle) {
		var domEle;
		var useTmp = false;
		if (useTmpXmlEle && plateRegionEleTemp) {
			domEle = plateRegionEleTemp;
			useTmp = true;
		}else{
			domEle = postHVTTriggerMode.m_PlateRecognitionXml;	
		}

		var ocx = $(ocxSel)[0];
		try{
	    	var xml = ocx.HWP_GetSnapPolygonInfo();

	    	var regionJson = x2js.xml_str2json(xmlToStr(domEle));

	    	var pregions = regionJson.PlateRecognition.PlateRegionList.PlateRegion_asArray;
	    	$(parseXmlFromStr(xml)).find('SnapPolygon').each(function (i, p) {
	    		var regionId = $(p).find('id').text();
	    		for (var i = 0; i < pregions.length; i++) {
	    			var r = pregions[i];
	    			if (r.regionId == regionId) {
	    				var sarr = [];
	    				$(p).find('point').each(function (i,n) {
	    					var x = Math.floor(parseFloat($(n).find('x').text())*1000);
	    					var y = Math.floor(parseFloat($(n).find('y').text())*1000);
	    					sarr.push({
	    						positionX: x,
	    						positionY: y
	    					});
	    				});

	    				r.RegionCoordinatesList = {
	    					RegionCoordinates: sarr
	    				};
	    				break;
	    			}
	    		};
	    	});

	    	if (useTmp) {
	    		plateRegionEleTemp = x2js.json2xml(regionJson);
	    	}else{
	    		postHVTTriggerMode.m_PlateRecognitionXml = x2js.json2xml(regionJson);	
	    	}
	    }catch(e){
	    	log("error:"+e.message);
	    }
	}

	function RestoreHVTRegion(restoreAll) {
		var ocx = $('#HVTDrawActiveX')[0];
		try{
	    	var xml = ocx.HWP_GetSnapPolygonInfo();
	    	var lineXml = ocx.HWP_GetSnapLineInfo();

	    	var regionJson = x2js.xml_str2json(xmlToStr(postHVTTemp));

	    	// 目标检测区域
	    	if($('#objectDetectAera_HVT').prop('checked') || restoreAll){
	    		var objArea = regionJson.PostHVT.ObjectDetectAera;
		    	$(parseXmlFromStr(xml)).find('SnapPolygon').each(function (i, p) {
		    		var regionId = $(p).find('id').text();
		    		regionId = parseInt(regionId);

		    		if (regionId == '100') {
		    			var sarr = [];
						$(p).find('point').each(function (i,n) {
							var x = Math.floor(parseFloat($(n).find('x').text())*1000);
							var y = Math.floor(parseFloat($(n).find('y').text())*1000);
							sarr.push({
								positionX: x,
								positionY: y
							});
						});

						objArea.AeraCoordinatesList = {
							AeraCoordinates: sarr
						};
		    		};
		    	});
	    	}
	    	

	    	$(parseXmlFromStr(lineXml)).find('SnapLine').each(function () {
	    		var lineId = $(this).find('id').eq(0).text();

	    		var $st = $(this).find("StartPos");
	    		var $et = $(this).find("EndPos");

	    		var sx = Math.round(parseFloat($st.find('x').text())*1000);
				var sy = Math.round(parseFloat($st.find('y').text())*1000);
				var ex = Math.round(parseFloat($et.find('x').text())*1000);
				var ey = Math.round(parseFloat($et.find('y').text())*1000);

				var laneRightBoundaryLineType = postHVTTriggerMode.TransLineType('laneRightBoundaryLine');
				var triggerLineType = postHVTTriggerMode.TransLineType('triggerLine');
				var leftTriggerLineType = postHVTTriggerMode.TransLineType('leftTriggerLine');
				var rightTriggerLineType = postHVTTriggerMode.TransLineType('rightTriggerLine');

				if (($('#rightTriggerLine_HVT').prop('checked') || restoreAll)
						 && lineId == (rightTriggerLineType*100+2)) {
					var rts = regionJson.PostHVT.RightTriggerLineList.RightTriggerLine.RegionCoordinatesList;
	    			delete rts.RegionCoordinates_asArray;
	    			rts.RegionCoordinates = [{
	    				positionX: sx,
	    				positionY: sy
	    			},{
	    				positionX: ex,
	    				positionY: ey
	    			}];
				}else if (($('#leftTriggerLine_HVT').prop('checked') || restoreAll)
							 && lineId == (leftTriggerLineType*100+1)) {
					var rts = regionJson.PostHVT.LeftTriggerLineList.LeftTriggerLine.RegionCoordinatesList;
	    			delete rts.RegionCoordinates_asArray;
	    			rts.RegionCoordinates = [{
	    				positionX: sx,
	    				positionY: sy
	    			},{
	    				positionX: ex,
	    				positionY: ey
	    			}];
				}else if (lineId == triggerLineType*100) {  // 正背向触发线
					var rts = regionJson.PostHVT.TriggerLineList.TriggerLine.RegionCoordinatesList;
	    			delete rts.RegionCoordinates_asArray;
	    			rts.RegionCoordinates = [{
	    				positionX: sx,
	    				positionY: sy
	    			},{
	    				positionX: ex,
	    				positionY: ey
	    			}];
				}else if (lineId == laneRightBoundaryLineType*100) {  // 右车道线
	    			var rts = regionJson.PostHVT.LaneRightBoundaryLineList.LaneRightBoundaryLine.RegionCoordinatesList;
                    		var itype = $("#lineTypeRight").val();
                    		rts.lineTypeRight = itype;
	    			delete rts.RegionCoordinates_asArray;
	    			rts.RegionCoordinates = [{
	    				positionX: sx,
	    				positionY: sy
	    			},{
	    				positionX: ex,
	    				positionY: ey
	    			}];
	    		}else if (lineId > 200 && lineId < 300) {  // 车道线
	    			var cid = lineId%200;
	    			var lrts = regionJson.PostHVT.HvtLaneList.HvtLane_asArray;
	    			var vtc = null;
	    			for (var i = 0; i < lrts.length; i++) {
	    				var r = lrts[i];
	    				if (r.HvtLaneNum == cid) {	    					
	    					var itype = $("#lineType"+cid).val();
	    					r.LaneLineList.LaneLine.lineType = itype;
	    					var rl = r.LaneLineList.LaneLine.RegionCoordinatesList;
	    					delete rl.RegionCoordinates_asArray;
	    					rl.RegionCoordinates = [{
			    				positionX: sx,
			    				positionY: sy
			    			},{
			    				positionX: ex,
			    				positionY: ey
			    			}];
	    					break;
	    				}
	    			};
	    		};
	    	});
	   
	    	postHVTTemp = x2js.json2xml(regionJson);
	    }catch(e){
	    	_log(e.message);
	    }
	}

	postHVTTriggerMode.cancelPostHVTModal=function() {
		$("#main_plugin").show();
	    if (HWP.Play() !== 0) {
	        alert(getNodeValue("previewfailed"));
	    }
	    $('#HVTDraw_plugin').html('');
	    $.modal.impl.close();

	    PostHVTReDisplay();
	}

	postHVTTriggerMode.setHVTAdvanceParam = function () {
		var intType = $("#postHVT_g_params_div #IntervalType").val();
		var res = true;

		var $xml = $(postHVTTriggerMode.m_postHVTXml);
		$.each(['post', 'reverse', 'overSpeed','lowSpeed', 'banSign', 'driveLine','nonDriveWay','emergency'], function(i,n){
			var sel = '#postHVT_g_params_div #vt'+n;
			$xml.find(n).eq(0).text($(sel).prop("checked")? "true": "false");
			$xml.find(n+'CapNo').eq(0).text($('#postHVT_g_params_div #vt' + n +'CapNo').val());

			// if (n == 'driveLine') {
			// 	$xml.find('driveLineSensitivity').eq(0).text($('#postHVT_g_params_div #vtdriveLineSensitivity').val());				
			// };
	    });
		$xml.find("intervalType").eq(0).text($("#postHVT_g_params_div #IntervalType").val());
		$xml.find('intervalValue').eq(0).text($('#postHVT_g_params_div #Interval1').val());
		$xml.find('intervalValue').eq(1).text($('#postHVT_g_params_div #Interval2').val());

		//$.modal.impl.close();
	}

	postHVTTriggerMode.StoreHVTGParam = function (laneIndex) {
		var $xmlDoc = $(postHVTTriggerMode.m_postHVTXml);

		$.each(['sceneMode', 'capMode', 'speedDetector', 'snapType'], function(i,n){
        		var sel = '#taTriggerMode_postHVT *[x-model='+n+'] ';
        		var v = $(sel).val();
        		$xmlDoc.find(n).eq(0).text(v);
        });

        var sel = '#taTriggerMode_postHVT *[x-model=enableComLoopTrig] ';
        if($(sel).length>0){
        	var v=$(sel).prop("checked").toString();
        	$xmlDoc.find("enableComLoopTrig").eq(0).text(v);
        }

        $.each(['eCarHighSpeed','eCarLowSpeed','eBigCarHighSpeed','eBigCarLowSpeed'], function(i,n){
    		var sel = '#taTriggerMode_postHVT #drawRightRegionContent *[x-model='+n+'] ';
    		var v = $(sel).val();
    		$xmlDoc.find(n).eq(0).text(v);
        });

		var lc = $('#RelatedLaneCount_postHVT').val();
		$xmlDoc.find("RelatedLaneCount").eq(0).text(lc);
	}

	postHVTTriggerMode.StoreHVTLaneParam = function (laneIndex) {
		laneIndex = parseInt(laneIndex, 10);
		var xmlDoc = postHVTTriggerMode.m_postHVTXml;

		var $firstLaneXmlDoc = $(xmlDoc).find('HvtLane').eq(laneIndex);
		$.each(['laneNO','laneDirectionType','relatedDriveWay', 'laneUsage', 'laneType','trucksType','carDriveDirect', 'signSpeed', 'highSpeedLimit',
				 'lowSpeedLimit', 'bigCarSignSpeed', 'bigCarHighSpeedLimit','bigCarLowSpeedLimit',
				 'radarType', 'radarRS485', 'radarSensitivity', 'radarAngle', 'validRadarSpeedTime', 
				 'radarLinearCorrection', 'radarConstantCorrection',
				 'flashMode' ], function  (i, n) {
			var sel = '#dvTriggerParam *[x-model='+n+']';
    		
    		var $d = $(sel);
    		if ($d.length) {
    			var v = $d.val();
	    		if ($d.is(":checkbox")) {
	    			v = $d.prop('checked') ? "true":"false";
	    		}
	    		$firstLaneXmlDoc.find(n).eq(0).text(v);
    		};
    		
		});

		function _pi(v) {
			var v = parseInt(v, 10);
			if (!v && v != '0') {
				v = 0;
			};
			return v;
		}

		//大车禁行时间段
		$bTTList = $firstLaneXmlDoc.find('banTrucksTimeSwitch');
		var $bttdom = $('#dvTriggerParam #dvbanTrucksTimeSwitch');
		var arr = [];
		for (var i = 0; i < 4; i++) {
			var $n = $bTTList.eq(i);
			
			var startTime = $bttdom.find('*[x-model=time'+(i+1)+'Start]').val();
			var endTime = $bttdom.find('*[x-model=time'+(i+1)+'End]').val();

			var startTimeArr = startTime.split(':');
			var endTimeArr = endTime.split(":")

			$n.find("startHour").text(_pi(startTimeArr[0]));
			$n.find("startMinute").text(_pi(startTimeArr[1]));
			$n.find("endHour").text(_pi(endTimeArr[0]));
			$n.find("endMinute").text(_pi(endTimeArr[1]));
		};

		$firstLaneXmlDoc.find('IOOut').each(function (i, n) {
			var id = $(n).find('id').text();	
			var v = $('#dvTriggerParam #AlarmOutputCheckboxChanO-'+id).prop('checked') ? "true" : "false";
			
			$(n).find('enabled').text(v);
		});
	}

	postHVTTriggerMode.CopyPostHVTParam = function (srcIndex) {
		var $xmlDoc = $(postHVTTriggerMode.m_postHVTXml);
		var copySrc = $xmlDoc.find('HvtLane').eq(srcIndex);

		if (!copySrc.length) {
			return;
		};

		$('#dvTriggerParam #TriggerIOCopyDiv_HVT').find('input[ioidx]:enabled:checked').not(":hidden").each(function  (i, n) {
			var idx = parseInt($(this).attr('ioidx'), 10) - 1;
			var $dst = $xmlDoc.find("HvtLane").eq(idx);

			SimpleCopyXmlNode(copySrc[0],$dst[0],
						['laneType','laneUsage','trucksType','laneDirectionType','trucksType','carDriveDirect','signSpeed', 'highSpeedLimit',
				 'lowSpeedLimit', 'bigCarSignSpeed', 'bigCarHighSpeedLimit','bigCarLowSpeedLimit','flashMode',
							{propName: 'banTrucksTimeSwitchList', type: 'subNode'},
                            {propName: 'IOOutList', type: 'subNode'}]
                        );
		});
	}

	postHVTTriggerMode.CopyPostHVTRadarParam = function (srcIndex) {
        var sel = '#taTriggerMode_postHVT *[x-model=speedDetector] ';
        if ($(sel).val() != 'radarSpeed') {
        	return;
        };

		var $xmlDoc = $(postHVTTriggerMode.m_postHVTXml);
		var copySrc = $xmlDoc.find('HvtLane').eq(srcIndex).find('Radar');

		if (!copySrc.length) {
			return;
		};

		$('#dvTriggerParam #TriggerIOCopyRadarDiv_HVT').find('input[ioidx]:enabled:checked').not(":hidden").each(function  (i, n) {
			var idx = parseInt($(this).attr('ioidx'), 10) - 1;
			var $dst = $xmlDoc.find("HvtLane").eq(idx).find('Radar');

			SimpleCopyXmlNode(copySrc[0],$dst[0], ['radarType', 'radarSensitivity', 
							'radarAngle',  'radarRS485',
							'validRadarSpeedTime', 'radarLinearCorrection', 
							'radarLinearCorrection']);
		});
	}

	//设置牌识区域参数
	postHVTTriggerMode.SetPlateRecognition = function (strType) {
		//触发模式保存失败则返回
		if(!postHVTTriggerMode.m_bSetTriggerMode) {
			szRetInfo = m_szErrorState + m_szError1;
		    $("#SetResultTips").html(szRetInfo); 
			setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			return;
		}
		var xmlDoc = postHVTTriggerMode.m_PlateRecognitionXml;
		if(strType == "postHVT" ) {
			$(xmlDoc).find("PlateRegionCount").eq(0).text($("#RelatedLaneCount_postHVT").val());
		}
		var iIndex = m_iCurSelIONum - 1; 
		
		$.ajax({
			type: "put",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/PlateRecognition/" + strType,
			timeout: 15000,
			async: false,
			data: xmlToStr(xmlDoc),
			processData: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				$("#CurTriggerMode").html(getNodeValue("a" + $("#selTriggerMode").val()));
				if(postHVTTriggerMode.m_bRebootRequired) {
					szRetInfo = m_szSuccessState + m_szSuccess5;
				} else {
					szRetInfo = m_szSuccessState + m_szSuccess1;
				}
				$("#SetResultTips").html(szRetInfo); 
			    setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			},
			error:function(xmlDoc, textStatus, xhr){
				szRetInfo = m_szErrorState + m_szError1;
		        $("#SetResultTips").html(szRetInfo); 
			    setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			}
		});
	}

	postHVTTriggerMode.selectHVT = function(laneIndex){
	 	var iLastIndex = parseInt(m_iCurSelIONum) - 1;  
		if(laneIndex == iLastIndex) {
			return;
		}
		$("#dvTriggerParam #tabpostHVT").find("li a").removeClass('current');
		$("#dvTriggerParam #tabpostHVT").find("#liHVT"+(laneIndex+1)).find("a").eq(0).addClass("current");
		
		postHVTTriggerMode.StoreHVTLaneParam(iLastIndex);
		postHVTTriggerMode.DisplayHVTLaneParam(laneIndex);

		m_iCurSelIONum = laneIndex + 1;

		//PostHVTReDisplay();
		m_iLastSelIONum = m_iCurSelIONum;
	}

	postHVTTriggerMode.changeLaneCount=function(v){
		var $t = $("#dvTriggerParam #tabpostHVT");
		for (var i = 0; i < $t.find('li').length; i++) {
			if (i < v ) {
                $t.find('li#liHVT'+(i+1)).show();
            }else{
                $t.find('li#liHVT'+(i+1)).hide();
            }
		};
		var l = $t.find('li').not(':hidden').find('a.current').length;
        if (l == 0) {
            this.selectHVT(0);
        }
		PostHVTReDisplay();
	}

	var plateRegionEleTemp;

	function InitPlateRegionTempEle () {
		var x = xmlToStr(postHVTTriggerMode.m_PlateRecognitionXml);
		plateRegionEleTemp = x2js.parseXmlString(x);
	}

	function DisplayPlateRegionEx (regionIdArray, ocxSel, color, useTmpXmlEle) {
		var domEle;
		if (useTmpXmlEle && plateRegionEleTemp) {
			domEle = plateRegionEleTemp;
		}else{
			domEle = postHVTTriggerMode.m_PlateRecognitionXml;	
		}
		 
		var $regionList = $(domEle).find('PlateRegion');

		var polygonArray = [];
		var obj = {
			SnapPolygonList:{
				SnapPolygon: []
			}
		};

		if (!color) {
			color = {r: 255, g:255, b:0};
		}

		$regionList.each(function (i, r) {
			var $r = $(r);
			var rid = parseInt($r.find('regionId').text());
			if (_.contains(regionIdArray, rid)) {
				var pts = [];
				var $_pts = $r.find('RegionCoordinates');
				$_pts.each(function (i, n) {
					var tx = parseInt($(n).find('positionX').text());
					var ty = parseInt($(n).find('positionY').text());
					pts.push({
						x:(tx/1000).toFixed(3),
						y:(ty/1000).toFixed(3)
					});
				});
				obj['SnapPolygonList']['SnapPolygon'].push({
					id: rid,
					polygonType: 1,
					color: color,
					tips: getNodeValue("PlateRegion")+rid,
					isClosed: "true",
					pointList: {
						point:pts
					}
				});
					
			};
		});
		var xml = x2js.json2xml_str(obj, true);
		//_log("RegionXml="+xml);
		try{
			if (!ocxSel) {
				ocxSel = '#PreviewActiveX';
			}
			var ocx = $(ocxSel)[0];
			ocx.HWP_ClearSnapInfo(1);
			ocx.HWP_SetSnapPolygonInfo(xml);
		}catch(e){}
	}
    
    //转换线类型
	postHVTTriggerMode.TransLineType = function (strType) {
		var iType = 0;
		switch(strType){
			case "laneLine":
				iType = 0;
				break;
			case "stopLine":
				iType = 1;
				break;
			case "waitLine":
				iType = 2;
				break;
			case "cancelLine":
				iType = 3;
				break;
			case "laneRightBoundaryLine":
				iType = 4;
				break;
			case "turnLeftLine":
				iType = 5;
				break;
			case "turnRightLine":
				iType = 6;
				break;
			case "redlightLine":
				iType = 7;
				break;

			case "triggerLine":
				iType = 21;
				break;

			case "leftTriggerLine":
				iType = 102;
				break;

			case "rightTriggerLine":
				iType = 102;
				break;			

			default:
			    iType = 8;
			    break;
		}
		return iType;
	}
	
	//设置线属性
	postHVTTriggerMode.changelineType = function (strType) {
		if(postHVTTriggerMode.m_strSelLineNum != ""){
			var szSelLineNum = postHVTTriggerMode.m_strSelLineNum.split(":");
			if(szSelLineNum[0] == 0) {
				postHVTTriggerMode.m_strCommonLineType[szSelLineNum[1]-4] = strType;
			} else {
				postHVTTriggerMode.m_strLineType[szSelLineNum[0]-1][szSelLineNum[1]] = strType;
			}
		}
	}

	//获取牌识参数
	postHVTTriggerMode.GetPlateRecognition = function (strType, iValueType) {
		
		var szUrl = "";
		if(iValueType == 1) {
			szUrl = "/PSIA/Custom/SelfExt/ITC/PlateRecognition/" + strType + "/recommendation";
		} else {
			szUrl = "/PSIA/Custom/SelfExt/ITC/PlateRecognition/" + strType;
		}
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + szUrl,
			timeout: 15000,
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				postHVTTriggerMode.m_PlateRecognitionXml = xmlDoc;
				$("#defaultCHN").val($(xmlDoc).find("defaultCHN").eq(0).text());
				$("#PlateRecogEnabled").prop("checked", $(xmlDoc).find("plateRecogEnabled").eq(0).text() === "true" ? true : false);
				$("#colorEnabled").prop("checked", $(xmlDoc).find("colorEnabled").eq(0).text() === "true" ? true : false);
				$("#farmVehicleEnabled").prop("checked", $(xmlDoc).find("farmVehicleEnabled").eq(0).text() === "true" ? true : false);
				$("#fuzzyDiscEnabled").prop("checked", $(xmlDoc).find("fuzzyDiscEnabled").eq(0).text() === "true" ? true : false);
				if($(xmlDoc).find("frontPlateRecoEnabled").eq(0).text() === "true") {
					$(document.getElementsByName("PlateRecoDirection")).eq(0).prop("checked", true);
					$(document.getElementsByName("PlateRecoDirection")).eq(1).prop("checked", false);
				}
				else
				{
					$(document.getElementsByName("PlateRecoDirection")).eq(0).prop("checked", false);
					$(document.getElementsByName("PlateRecoDirection")).eq(1).prop("checked", true);
				}
				if($(xmlDoc).find("smallPlateRecoEnabled").eq(0).text() === "true") {
					$(document.getElementsByName("PlateRecoType")).eq(0).prop("checked", true);
					$(document.getElementsByName("PlateRecoType")).eq(1).prop("checked", false);
				}
				else
				{
					$(document.getElementsByName("PlateRecoType")).eq(0).prop("checked", false);
					$(document.getElementsByName("PlateRecoType")).eq(1).prop("checked", true);
				}

				// ClearPolygon(4);
				PostHVTReDisplay();
			}
		});
	}
	

	postHVTTriggerMode.showAllShapes=function() {

	    //var triggerMode = postHVTTriggerMode.m_CurTriggerMode;
		PostHVTReDisplay();
	}

	function InitHVTTempEle() {
		var x = xmlToStr(postHVTTriggerMode.m_postHVTXml);
		postHVTTemp = x2js.parseXmlString(x);
	}

	postHVTTriggerMode.ShowPostHVTModel=function() {
		var count = $('#RelatedLaneCount_postHVT').val();
		count = parseInt(count);

	    if (!g_bIsIE) {
	        $("#HVTDraw_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='HVTDrawActiveX' width='100%' height='100%' name='HVTDrawActiveX' align='center' wndtype='1' playmode='snapdraw'>");
	    } else {
	        $("#HVTDraw_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='HVTDrawActiveX' width='100%' height='100%' name='HVTDrawActiveX' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
	    }

	    InitHVTTempEle();
	    InitPlateRegionTempEle();

	    $('#leftTriggerLine_HVT, #rightTriggerLine_HVT, #objectDetectAera_HVT').unbind().click(function () {
	    	RestorePlateRegion('#HVTDrawActiveX', true);
	    	RestoreHVTRegion(true);


	    	var ocx = $("#HVTDrawActiveX")[0];
	    	ocx.HWP_ClearSnapInfo(4);

	    	var selIdx = -1;
	    	var idxArr = [];

	    	for (var i = 0; i < count; i++) {
	    		idxArr.push(i+1);
	    	};

	    	DisplayPlateRegionEx(idxArr, '#HVTDrawActiveX', null,  true);
	    	DisplayPostHVTRegion(idxArr, '#HVTDrawActiveX', {r:255,g:0,b:0}, true);
	    	

	    	if ($(this).attr('id') == 'objectDetectAera_HVT') {
	    		if ($(this).prop('checked')) {
	    			$('#HVTDrawObjectDetectArea_wrapper').show();
	    		}else{
	    			$('#HVTDrawObjectDetectArea_wrapper').hide();
	    		}
	    	};
	    });

	    if ($('#objectDetectAera_HVT').prop('checked')) {
			$('#HVTDrawObjectDetectArea_wrapper').show();
		}else{
			$('#HVTDrawObjectDetectArea_wrapper').hide();
		}

	    $('#postHVTModalDiv').modal();

	    for(var i = 1; i <= 5; i++){
	    	if (i > count) {
	    		$('#HVTDrawSignArea'+i+ ", #HVTDrawSignArea"+i+"_wrapper").hide();
	    	}else{
	    		$('#HVTDrawSignArea'+i+ ", #HVTDrawSignArea"+i+"_wrapper").show();
	    	}
	    }

	    HWP.Stop();
	    $("#main_plugin").hide();

	    var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
	    var iRet = $("#HVTDrawActiveX")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
	    if (iRet !== 0) {
	        alert(getNodeValue("previewfailed"));
	    }

	    var ocx = $('#HVTDrawActiveX')[0];	

	    try {
	        ocx.HWP_ClearSnapInfo(4);
	        setTimeout(function () {
	        	var opt = {
		        	laneLine: true,
		        	laneRightBoundaryLine: true,
		        	leftTriggerLine: $('#leftTriggerLine_HVT').prop('checked'),
		    		rightTriggerLine: $('#rightTriggerLine_HVT').prop('checked'),
		    		objectDetectAera: $('#objectDetectAera_HVT').prop('checked')
		        };

		        var idxArr = [];
		        for (var i = 1; i <= count; i++) {
		        	idxArr.push(i);
		        };

	        	DisplayPlateRegionEx(idxArr, '#HVTDrawActiveX', null,  true);
	        	DisplayPostHVTRegion(idxArr, '#HVTDrawActiveX', {r:255,g:0,b:0}, true, opt);
				ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
	        }, 500);
	    } catch(e) {
	    } 	  
	}

	postHVTTriggerMode.reDrawHVTPlateRegion=function(laneNum) {
		reDrawPlateRegion(laneNum, '#HVTDrawActiveX');
	}

	postHVTTriggerMode.reDrawHVTObjectDetectArea=function() {
		if($('#objectDetectAera_HVT').prop('checked')){
			reDrawPolygon(100, '#HVTDrawActiveX', {r: 255, g:0, b:255}, getNodeValue("ObjectDetectAera"));	
		}
		
	}

	postHVTTriggerMode.setPostHVTModelAdvanceInfo = function(){
		var $dv = $('#advanceSetting_HVTModel #postHVTAdvanceContent');
		if ($dv.is(":hidden")) {
			$dv.show();
		}else{
			$dv.hide();
		}
        autoResizeIframe();
	}

	postHVTTriggerMode.changeUseageType = function(strType, parentDivSel) {
		if (!parentDivSel) {
    		parentDivSel = '';
    	};

		if(strType == "banTrucks"){
            $(parentDivSel+' #dvbanTrucksTimeSwitch').css("display","block");
            $(parentDivSel+' #dvtrucksTypeSwitch').css("display","block");
        }else{
            $(parentDivSel+' #dvbanTrucksTimeSwitch').css("display","none");
            $(parentDivSel+' #dvtrucksTypeSwitch').css("display","none");
        }
        autoResizeIframe();
	}

	//清除区域
	function ClearPolygon(iType) {
		if(arguments.length > 0)
		{
			iClearType = iType;
		} else {
			iClearType = 4;
		}
		try{
			var iRet = HWP.ClearSnapInfo(iClearType);
			if(iRet != 0) {
				alert(getNodeValue("ClearFailed"));
			}
		}
		catch(e)
		{}
	}







	window.postHVTTriggerMode=postHVTTriggerMode;
})(window);

