var TotalTriggerModes=["postIOSpeed","postSingleIO","postRS485","postRadar",
"postVTCoil","epoliceIOTL","epoliceRS485","postEpoliceRS485","videoEpolice",
"PostMpr","videoMonitor", "postHVT","TPS","ITS","BusOnLane","PostPRS","dodgePedestrian",
"personRunRedLight","radarMpr","faceDetect","DriverLine"];

(function(window){
	var ExtendTriggerModes=["postHVT","TPS","BusOnLane","PostPRS","dodgePedestrian",
    "personRunRedLight","radarMpr","faceDetect","DriverLine","ITS"];
	var TriggerModeExt=window.TriggerModeExt||{};
    
    //判断是不是采用新代码结构实现的模式
    TriggerModeExt.changeTriggerModeExt=function(trigMode){
    	if(!trigMode){
    		trigMode=this.curTriggerMode;
    	};
    	this.curSelMode=trigMode;

    	if(_.contains(ExtendTriggerModes,trigMode)){
    		this.changeTriggerModeType(trigMode);
    		return true;
    	}
    	return false;
    }

    //新老代码结构实现的模式切换中转
    TriggerModeExt.changeTriggerModeType=function(trigMode){
        if(!trigMode){
        	trigMode=this.curTriggerMode;
        };
        this.curSelMode=trigMode;

        if(_.contains(ExtendTriggerModes,trigMode)){
        	changeToExtendTriggerMode(trigMode);
        }else{
            ia(TriggerMode).m_CurEnabledMode = this.curTriggerMode;
            ia(TriggerMode).m_CurTriggerMode = this.curSelMode;

        	changeToOriginalTriggerMode(trigMode);
        }
    }

    //转到新模式访问加载
    function changeToExtendTriggerMode(trigMode){
    	$.ajax({
    		url:"params/"+trigMode+"TriggerMode.asp",
            type:"GET",
            dataType:"html",
            error:function(){
            	showmenuconfig(szMenu,iMode,szMainMenu);
            },
            success:function(msg){
            	$("#EditAreaContent").html(msg);
            	
            	var objstr=trigMode+'TriggerMode';
            	if(window[objstr]&&window[objstr].updateLang){
            		window[objstr].updateLang();
            	};

                g_oCurrentTab=$(".tabs.tm").tabs(".pane.tm",{remember:false,markCurrent:false});

            	if(window[objstr]&&window[objstr].initPage){
            		window[objstr].initPage();
            	};

            	TriggerModeExt.initTriggerModeOptions('selTriggerMode','#CurTriggerMode');
            }
    	});
    }

    //备用模式切换
    function changeToExtendTriggerMode_backupMode(trigMode){
        $.ajax({
            url:"params/"+trigMode+"TriggerMode.asp",
            type:"GET",
            dataType:"html",
            error:function(){
                showmenuconfig(szMenu,iMode,szMainMenu);
            },
            success:function(msg){
                $("#EditAreaContent").html(msg);
                $("#triggerBackupModel_postHVT").show();
                var objstr=trigMode+'TriggerMode';
                if(window[objstr]&&window[objstr].updateLang){
                    window[objstr].updateLang();
                };

                g_oCurrentTab=$(".tabs.tm").tabs(".pane.tm",{remember:false,markCurrent:false});

                if(window[objstr]&&window[objstr].initPage){
                    window[objstr].initPage();
                };

                $.g.setField2('#selTriggerMode',"postRS485");
                $("#CurTriggerMode").html(getNodeValue("apostRS485"));
            }
        });
    }

    //转到旧模式加载访问
    function changeToOriginalTriggerMode(trigMode){
        $.ajax({
    		url:"params/TriggerMode.asp",
    		type:"GET",
    		dataType:"html",
    		error:function(){
    			showmenuconfig(szMenu,iMode,szMainMenu);
    		},
    		success:function(msg){
                // $("#EditAreaContent").html("");
    			$("#EditAreaContent").html(msg);
    			
    			$('#CommendParamBtn').show();

    			setTimeout(initSlider,300);
    			ia(TriggerMode).updateLang();
    			TriggerModeExt.initTriggerModeOptions('selTriggerMode','#CurTriggerMode');
    			// ia(TriggerMode).changeTriggerMode(trigMode);

                g_oCurrentTab=$(".tabs").tabs(".pane",{remember:false,markCurrent:false});
    		}
    	});
    }

    //加载设备支持的触发模式
    TriggerModeExt.supportedTriggerModes=[];
    TriggerModeExt.getSupportedTriggerModes=function(){
    	var self=this;
    	$.ajax({
    		type:"GET",
    		url:m_lHttp+m_szHostName+":"+m_lHttpPort+"/PSIA/Custom/SelfExt/ITC/TriggerMode/capabilities",
    		async:false,
    		timeout:15000,
    		beforeSend:function(xhr){
    			xhr.setRequestHeader("If-Modified-Since","0");
    			
    		},
    		success:function(xmlDoc,textStatus,xhr){
    			var opts = $(xmlDoc).find('usedTriggerMode').eq(0).attr("opt");
				if (!opts) {
					opts = '';
				};
				var szTriggerModeOptions = opts.split(",");

                //test
                //szTriggerModeOptions = ["postIOSpeed","postSingleIO","postRS485","postRadar",
                 // "postVTCoil","epoliceIOTL","epoliceRS485","postEpoliceRS485",
                 // "videoEpolice","PostMpr", "videoMonitor", "postHVT","TPS","ITS",
                 // "BusOnLane","PostPRS","dodgePedestrian","personRunRedLight","radarMpr",
                 //"facedetect","DriverLine"];
                //test

				self.supportedTriggerModes.length = 0;
				for (var i = 0; i < szTriggerModeOptions.length; i++) {
					var t = szTriggerModeOptions[i];
					if(t){
						self.supportedTriggerModes.push($.trim(t));
					}
				};

				_log("supportedTriggerModes="+self.supportedTriggerModes);

				var curMode = $(xmlDoc).find("usedTriggerMode").eq(0).text();
                
				self.curTriggerMode = curMode;
                ia(TriggerMode).m_CurEnabledMode = curMode;
    		}

    	});
    }

    //初始化触发模式操作
    TriggerModeExt.initTriggerModeOptions=function(selId,curSel){
    	insertOption2Select(this.supportedTriggerModes,TotalTriggerModes,_.map(TotalTriggerModes,function(t){
    		return 'a'+t;
    	}),selId);
    	$.g.setField2('#'+selId,this.curSelMode);
    	$(curSel).html(getNodeValue("a"+this.curTriggerMode));
    	g_transStack.translate();
    }

    window.TriggerModeExt=TriggerModeExt;

})(window);