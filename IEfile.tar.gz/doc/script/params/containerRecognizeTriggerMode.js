function containerRecognizeTriggerModeS(){
	SingletonInheritor.implement(this);
}
SingletonInheritor.declare(containerRecognizeTriggerModeS);

containerRecognizeTriggerModeS.prototype.updateLang=function(){
	$('#CommendParamBtn,#SaveConfigBtn').hide();

	g_transStack.clear();
	var that=ia(containerRecognizeTriggerModeS);
	g_transStack.push(function(){
		var prsDoc=parent.translator.getLanguageXmlDoc("containerRecognizeTriggerMode");
		that.setLxd(prsDoc);

		var tModeDoc=parent.translator.getLanguageXmlDoc("TriggerMode");
		parent.translator.appendLanguageXmlDoc(that.getLxd(), tModeDoc);

		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	},true);
};

(function(){
	var containerRecognizeTriggerMode=window.containerRecognizeTriggerMode||{};
	var m_containerRecognizeXml=null;
	var originalXmlDoc=null;

    var m_iLastSelIONum = 0;
    var m_bSetTriggerMode = false;
	var m_bRebootRequired = false;

	containerRecognizeTriggerMode.updateLang = function () {
		ia(containerRecognizeTriggerModeS).updateLang();
	}

	containerRecognizeTriggerMode.updateParam=function(iValueType){
        if ($("#main_plugin").html() == "") {
			if (checkPlugin('2', getNodeValue('laPlugin'), 1, 'snapdraw', 0)) {
				if (!CompareFileVersion()) {
					UpdateTips();
				}
			}
		}
		HWP.Stop(0);
		HWP.Play();

		var szUrl = "/PSIA/Custom/SelfExt/ITC/ContainerRecognize";
		if(iValueType == 1) {
			szUrl += "/recommendation";
		}
        
		var self = this;
		
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + szUrl,
			timeout: 15000,
			async: false,
			dataType:"text",
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			}
		}).done(function (xmlDoc, textStatus, xhr) {
			m_containerRecognizeXml = parseXmlFromStr(xmlDoc);
			$("#laTriggerParam").html(getNodeValue("lacontainerRecognizeDataTitle"));

			self.loadLinkIO();
			self.getcontainerRecognizeParam(0);
		});
	}

	// 加载关联同步输出
	containerRecognizeTriggerMode.loadLinkIO=function(){
		var m_iSyncOutNum = pr(DeviceInfo).queryAlarmOutNum();
		var szDivInfo = "";
		for(var i = 0; i < m_iSyncOutNum; i++) {
            if(i == 3 || i == 6){
                szDivInfo += "<br>";
            }
			szDivInfo += "<div style='display:inline-block;margin-bottom:7px;'><input class='checkbox' name='AlarmOutputCheckbox' id='AlarmOutputCheckboxChanO-"+ (i + 1)+"' type='checkbox'>&nbsp;"+"F" + (i + 1) + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>";
		}
		$("#DisPlayLinkageList").html(szDivInfo); 
	}

	//保存数据
	containerRecognizeTriggerMode.savecontainerRecognizeParam = function () {
		
		var $xml = $(m_containerRecognizeXml);
		$.each(['relatedDriveWay','defaultStatus','snapTimes','intervalType','flashMode'],function(i,n){			
			$xml.find(n).text($("#"+n).val());
		});

		$xml.find("containerRecogEnable").text($("#containerRecogEnable").prop("checked").toString());

		for(var i=0;i<4;i++){
			$xml.find("IntervalList").eq(0).find("Interval").eq(i).find("value").text($("#Interval"+i).val());
		}

		$xml.find("IOOutList").eq(0).find("IOOut").each(function(i,n){
			$(n).find("enabled").text($("#AlarmOutputCheckboxChanO-"+(i+1)).prop("checked").toString());
		})

		$.ajax({
			type: "put",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/ContainerRecognize",
			timeout: 15000,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			data: xmlToStr(m_containerRecognizeXml),
			processData: false,
			complete:function(xhr, textStatus) {
				if(xhr.status != 200) {
					if(xhr.status == 403) {
						var szErrorInfo = m_szError8;
						szRetInfo = m_szErrorState + szErrorInfo;
					} else {
						var xmlDoc =xhr.responseXML;
						if($(xmlDoc).find("detailedStatusCode").eq(0).text() != "") {
							var szErrorInfo = getNodeValue("Error" + $(xmlDoc).find("detailedStatusCode").eq(0).text());
						} else {
							var szErrorInfo = m_szError13;
						}
						szRetInfo = m_szErrorState + szErrorInfo;
					}
		            $("#SetResultTips").html(szRetInfo); 
			        setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			        return;	
				} else {
					if($(xhr.responseXML).find("statusCode").eq(0).text() == "7") {
						m_bRebootRequired = true;
					}
					m_bSetTriggerMode = true;

					// $("#CurTriggerMode").html(getNodeValue("a" + $("#selTriggerMode").val()));

					if(m_bRebootRequired) {
						szRetInfo = m_szSuccessState + m_szSuccess5;
					} else {
						szRetInfo = m_szSuccessState + m_szSuccess1;
					}

					$("#SetResultTips").html(szRetInfo); 
				    setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
				}
			}
		});
	}

	containerRecognizeTriggerMode.getcontainerRecognizeParam = function (laneIndex) {
		var $xml=$(m_containerRecognizeXml);
		$.each(['containerRecogEnable','relatedDriveWay','defaultStatus','snapTimes','intervalType','flashMode'],function(i,n){			
			$("#"+n).val($xml.find(n).text());
		});

		$("#containerRecogEnable").prop("checked",$xml.find("containerRecogEnable").text()=="true"?true:false);

		for(var i=0;i<4;i++){
			$("#Interval"+i).val($xml.find("IntervalList").eq(0).find("Interval").eq(i).find("value").text());
		}

		$xml.find("IOOutList").eq(0).find("IOOut").each(function(i,n){
			$("#AlarmOutputCheckboxChanO-"+(i+1)).prop("checked",$(n).find("enabled").text()=="true"?true:false);
		})
		drawcontainerRecognizeShapes();
	}
    
    // 画图,判别是否显示全部图
	function drawcontainerRecognizeShapes () {
		HWP.ClearSnapInfo(4);
		DisplaycontainerRecognizeRegion([], null, {r:255,g:0,b:0});
		HWP.SetSnapDrawMode(-1);
	}

	var containerRecognizeTemp;
	//useTmpXmlEle表示是否使用临时存储
	function DisplaycontainerRecognizeRegion (regionIdArray, ocxSel, color, useTmpXmlEle) {
		var domEle;
		if (useTmpXmlEle && containerRecognizeTemp) {
			domEle = containerRecognizeTemp;
		}else{
			domEle = m_containerRecognizeXml;	
		}

		if (!color) {
			color = {r: 255, g:0, b:0};
		}

		if (!ocxSel) {
			ocxSel = '#PreviewActiveX';
		}
		var ocx = $(ocxSel)[0];

		var obj = {
			SnapPolygonList:{
				SnapPolygon: []
			}
		};

		var obj1 = {
			SnapPolygonList:{
				SnapPolygon: []
			}
		};

		var ContainerRegionPts = getcontainerRecognizeRegionPts($(domEle).find("ContainerRegion")[0]);
		var PlateRegionPts = getcontainerRecognizeRegionPts($(domEle).find('PlateRegion')[0]);
		// 牌识区域
		obj['SnapPolygonList']['SnapPolygon'].push({
			id: 100,
			polygonType: 1,
			color: {r: 255, g: 0, b: 0},
			tips: getNodeValue("plateRegion"),
			isClosed: "true",
			PointNumMax:11,
			MinClosed:5,
			pointList: {
				point:PlateRegionPts
			}
		});
		// 箱号识别区域
		obj1['SnapPolygonList']['SnapPolygon'].push({
			id: 200,
			polygonType: 0,
			color: {r: 0, g: 255, b: 0},
			tips: getNodeValue("recognizeRegion"),
			isClosed: "true",
			PointNumMax:5,
			MinClosed:5,
			pointList: {
				point:ContainerRegionPts
			}
		});

		ocx.HWP_ClearSnapInfo(4);

		try{	
			var xml = x2js.json2xml_str(obj, true);
			// xml="<?xml version='1.0' encoding='UTF-8'?><SnapPolygonList><SnapPolygon><id>100</id><polygonType>1</polygonType><color><r>255</r><g>0</g><b>0</b></color><tips>牌识区域</tips><isClosed>true</isClosed><PointNumMax>11</PointNumMax><MinClosed>5</MinClosed><pointList><point><x>0.10</x><y>0.45</y></point><point><x>0.45</x><y>0.45</y></point><point><x>0.45</x><y>0.20</y></point><point><x>0.10</x><y>0.20</y></point></pointList></SnapPolygon></SnapPolygonList>";
			ocx.HWP_SetSnapPolygonInfo(xml);
			var xml1=x2js.json2xml_str(obj1, true);
			// xml1="<?xml version='1.0' encoding='UTF-8'?><SnapPolygonList><SnapPolygon><id>200</id><polygonType>0</polygonType><color><r>0</r><g>255</g><b>0</b></color><tips>识别区域</tips><isClosed>true</isClosed><PointNumMax>5</PointNumMax><MinClosed>5</MinClosed><pointList><point><x>0.50</x><y>0.85</y></point><point><x>0.85</x><y>0.85</y></point><point><x>0.85</x><y>0.50</y></point><point><x>0.50</x><y>0.50</y></point></pointList></SnapPolygon></SnapPolygonList>";
			ocx.HWP_SetSnapPolygonInfo(xml1);
		}catch(e){}
		//设置选择模式
		ocx.HWP_SetSnapDrawMode(0, 3);
	}

	function getcontainerRecognizeRegionPts (ele) {
		if (!ele) {
			throw new Error("ele is empty!!");
		};

		var $r = $(ele);

		var pts = [];
		var $_pts = $r.find('RegionCoordinates');
		$_pts.each(function (i, n) {
			var tx = parseInt($(n).find('positionX').text());
			var ty = parseInt($(n).find('positionY').text());
			pts.push({
				x:(tx/1000).toFixed(3),
				y:(ty/1000).toFixed(3)
			});
		});

		return pts;
	}

    containerRecognizeTriggerMode.showAllShapes=function(){
    	drawcontainerRecognizeShapes();
    }

    containerRecognizeTriggerMode.ShowcontainerRecognizeModal=function() {
		if (!g_bIsIE) {
	        $("#containerRecognize_Draw_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='containerRecognizeDrawPlugin' width='100%' height='100%' name='containerRecognizeDrawPlugin' align='center' wndtype='1' playmode='snapdraw'>");
	    } else {
	        $("#containerRecognize_Draw_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='containerRecognizeDrawPlugin' width='100%' height='100%' name='containerRecognizeDrawPlugin' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
	    }

	    $('#containerRecognizeModalDiv').modal();

	    containerRecognizeTemp = x2js.parseXmlString(xmlToStr(m_containerRecognizeXml));
	    setTimeout(function () {
	    	var ocx = $('#containerRecognizeDrawPlugin')[0];	
	    	ocx.HWP_ClearSnapInfo(4);

	    	DisplaycontainerRecognizeRegion([], '#containerRecognizeDrawPlugin', {r:255,g:0,b:0}, true);
	    		
			try{
				ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
			}catch(e){}
	    }, 500);

	    HWP.Stop();
	    $("#main_plugin").hide();

	    var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
	    var iRet = $("#containerRecognizeDrawPlugin")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
	    if (iRet !== 0) {
	        alert(getNodeValue("previewfailed"));
	    }
	}

	containerRecognizeTriggerMode.okcontainerRecognizeModal=function() {
		RestorecontainerRecognize();

		m_containerRecognizeXml = x2js.parseXmlString(xmlToStr(containerRecognizeTemp));
	    $.modal.impl.close();
	    
	    try{
	    	var ocx = $('#containerRecognizeDrawPlugin')[0];
	    	ocx.HWP_Stop(0);
	    }catch(e){}

	    $("#main_plugin").show();
	    if (HWP.Play() !== 0) {
	        alert(getNodeValue("previewfailed"));
	    }

	   	drawcontainerRecognizeShapes();
	}
    
    //存储绘制识牌区的数据
	function RestorecontainerRecognize (ocxSel) {
		var ocx = $('#containerRecognizeDrawPlugin')[0];
		try{
			//牌识区域和识别区域
	    	var xml = ocx.HWP_GetSnapPolygonInfo();
	    	var regionJson = x2js.xml_str2json(xmlToStr(containerRecognizeTemp));

	    	var $polygon = $(parseXmlFromStr(xml));

	    	$polygon.find('SnapPolygon').each(function () {
	    		var $p = $(this);
	    		var id = parseInt($p.find('id').text());
	    		var ptype = Math.floor(id/100);

	    		var sarr = [];
				$p.find('point').each(function (i,n) {
					var x = Math.floor(parseFloat($(n).find('x').text())*1000);
					var y = Math.floor(parseFloat($(n).find('y').text())*1000);
					sarr.push({
							// RegionCoordinates:{positionX: x,positionY: y}
							positionX: x,
							positionY: y
						});
				});

				if(regionJson){
					// 检测是否有交叉
					// if (!LineCheckPoint(tmpPoints)) {
			  //       	alert(getNodeValue("jsAreaInterSect"));
			  //       	return false;
			  //       };
	    			if (ptype == '1') {  // 牌识区域
	    				regionJson.ContainerRecognize.PlateRegion.RegionCoordinatesList= {
	    					'RegionCoordinates': sarr
	    				};
	    			}else if (ptype == '2') {  // 识别区域
	    				regionJson.ContainerRecognize.ContainerRegion.RegionCoordinatesList = {
	    					'RegionCoordinates': sarr
	    				};
	    			}
				}
				
	    	});

	    	containerRecognizeTemp = x2js.json2xml(regionJson);
	    }catch(e){
	    	// _log(e.message);
	    }
	}

	containerRecognizeTriggerMode.cancelcontainerRecognizeModal=function() {
		$("#main_plugin").show();
	    if (HWP.Play() !== 0) {
	        alert(getNodeValue("previewfailed"));
	    }
	    $('#containerRecognize_Draw_plugin').html('');
	    $.modal.impl.close();

	    drawcontainerRecognizeShapes();
	}

    
    //重绘牌识区域
	containerRecognizeTriggerMode.reDrawcontainerRecognizeRegion=function() {
		reDrawPolygonRegion(100, 
			'#containerRecognizeDrawPlugin', 
			{r: 255, g:0, b:0}, 
			 getNodeValue("plateRegion"));	
	}

	function reDrawPolygonRegion (regionId, ocxSel, color, polygonName) {
		if (!color) {
			color = {r: 255, g: 255, b: 0};
		};
		var type;
		var mode;
		if(100==regionId){
			type=1;
			mode=2
		}else{
			type=0;
			mode=1;
		}
		var szInfo3 = "<?xml version='1.0' encoding='utf-8'?><SnapPolygonList><SnapPolygon><id>"
					+ regionId
					+ "</id><polygonType>"+type+"</polygonType><tips>" + polygonName
					+ "</tips><isClosed>false</isClosed><PointNumMax>11</PointNumMax><MinClosed>5</MinClosed>"
					+ "<color><r>"+color.r+"</r><g>"+color.g+"</g><b>"+color.b+"</b></color><pointList/></SnapPolygon></SnapPolygonList>";
		var ocx = $(ocxSel)[0];
		try{
			var iRet = ocx.HWP_SetSnapPolygonInfo(szInfo3);
		}catch(e){}
		try{
			ocx.HWP_SetSnapDrawMode(0, mode);  //设置为选择模式
		}catch(e){}
	}
    
    //重绘识别区域
	containerRecognizeTriggerMode.reDrawcontainerRecognizeVirtualRegion=function() {	
		reDrawPolygonRegion(200, 
			'#containerRecognizeDrawPlugin', 
			{r: 0, g:255, b:0}, 
			 getNodeValue("recognizeRegion"));	
	}
    
	/*
	Function:检测绘制区域是否有交叉线；
	points:  绘制区域的坐标点集；
	bOpened: 绘制区域是否闭合，false--闭合；true--开合；
	Return:  true - 无交叉； false - 有交叉；
	*/
	function LineCheckPoint(points){
		var bOpened = false;
	    var iLength = points.length;
		if(iLength <4) {
			return true;
		}
		for(var i = 2; i < iLength; i++) {
			for(var j=0; j <= i - 2; j++) {
				if(i == iLength -1 && j == 0) {
					continue;
				}
				if(bOpened && typeof points[i+1] != 'object') {
					continue;
				}
				if(intersectLineLine(points[i],typeof points[i+1] == 'object'?points[i+1]:points[0], points[j], points[j+1])) {
					return false;
				}
			}
		}
		return true;
	}

	/*
	Function:检测两条线是否有交叉;
	a1:      第一条线段的起点坐标；
	a2：     第一条线段的终点坐标；
	b1：     第二条线段的起点坐标；
	b2：     第二条线段的终点坐标；
	Return： true--有交叉；false--无交叉；
	*/
	function intersectLineLine(a1, a2, b1, b2) {
	    var ua_t = (b2.x - b1.x) * (a1.y - b1.y) - (b2.y - b1.y) * (a1.x - b1.x);
	    var ub_t = (a2.x - a1.x) * (a1.y - b1.y) - (a2.y - a1.y) * (a1.x - b1.x);
	    var u_b  = (b2.y - b1.y) * (a2.x - a1.x) - (b2.x - b1.x) * (a2.y - a1.y);

	    if ( u_b != 0 ) {
	        var ua = ua_t / u_b;
	        var ub = ub_t / u_b;

	        if ( 0 <= ua && ua <= 1 && 0 <= ub && ub <= 1 ) {
				return true;
	        } else {
				return false;
	        }
	    } else {
	        if ( ua_t == 0 || ub_t == 0 ) {
				return true;
	        } else {
				return false;
	        }
	    }
	}



	window.containerRecognizeTriggerMode = containerRecognizeTriggerMode;
})()