
function EHOME() {
    SingletonInheritor.implement(this);
    
    this.vpnxml=null;
    this.capabilitiesXml=null;
    this.capabilities3g=false;
    this.submitVpnflag=false;
    this.vpnXhr=null;
}
SingletonInheritor.declare(EHOME);

pr(EHOME).Open3GChange=function(){
    if($("#dvEHOME #open3G").prop('checked')){
        $('#dvEHOME #divbVpn').show();
    }else{
        $('#dvEHOME #divbVpn').hide();
    }
    autoResizeIframe();
}

//获得是否启用3G的能力集
pr(EHOME).getCapabilities3G=function(){
    var that=this;
    $.ajax({
        type: "GET",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/MobileNetwork/capabilities",
        timeout: syncTime,
        dataType:"text",
        async: false,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success:function(xmlDoc, textStatus, xhr){
            that.capabilitiesXml=parseXmlFromStr(xmlDoc);
            var $capabilitiesXml=$(that.capabilitiesXml);
            if($capabilitiesXml.find("MobileNetSupport").eq(0).text()==="true"){
                that.capabilities3g=true;
            }
        },
        error:function(){
            return false;
        }
    });
}

pr(EHOME).validateVpnParam=function(){
    $("#telephoneTips,#APNTips,#userNameTips,#passwordTips,#verifyProtocalTips").html("");
    var res=true;
     var bVpnEnabled= $("#dvEHOME #bVpn").prop("checked");
    if(!bVpnEnabled){
        return res;
    }
    
    var warnTipsIcon = '<img src="../images/config/tips.png" class="verticalmiddle">&nbsp;';
    var telephoneStr=$('#dvEHOME #telephone').val();
    // if(!$.isPhoneCall(telephoneStr) && !$.isMobile(telephoneStr)){
    //     $('#dvEHOME #telephoneTips').html(warnTipsIcon+"联系方式格式不对！");
    //     res=false;
    // }
    if(!telephoneStr){
        $('#dvEHOME #telephoneTips').html(warnTipsIcon+"拨号号码不能为空！");
        res=false;
    }
    var apnStr=$('#dvEHOME #APN').val();
    if(!apnStr){
        $('#dvEHOME #APNTips').html(warnTipsIcon+"APN不能为空！");
        res=false;
    }
    var userNameStr=$('#dvEHOME #userName').val();
    if(!userNameStr){
        $('#dvEHOME #userNameTips').html(warnTipsIcon+"用户名不能为空！");
        res=false;
    }
    var passwordStr=$('#dvEHOME #password').val();
    if(!passwordStr){
        $('#dvEHOME #passwordTips').html(warnTipsIcon+"密码不能为空！");
        res=false;
    }
    var verifyProtocalStr=$('#dvEHOME #verifyProtocal').val();
    if(!verifyProtocalStr){
        $('#dvEHOME #verifyProtocalTips').html(warnTipsIcon+"PPP验证协议不能为空！");
        res=false;
    } 
    return res;

}

pr(EHOME).updateVpnParam=function(){
    var that=this;
    this.getCapabilities3G();
    if(this.capabilities3g){
        $('#dvEHOME #divopen3G').show();
        $.ajax({
            url:m_lHttp+m_szHostName+":"+m_lHttpPort+"/PSIA/Custom/SelfExt/MobileNetwork",
            type:"GET",
            dataType:"text",
            timeout:syncTime,
            beforeSend:function(xhr){
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            success:function(xmlDoc, textStatus, xhr){
                that.vpnxml=parseXmlFromStr(xmlDoc);
                var $vpnxml=$(that.vpnxml);
                $.each(["open3G","bVpn"],function(i,n){
                    $.g.setField2("#dvEHOME #"+n,$vpnxml.find(n).eq(0).text()==="1"?"true":"false");
                });
                $.each(["telephone","APN","userName",
                    "password","verifyProtocal"],function(i,n){
                    $.g.setField2("#dvEHOME #"+n,$vpnxml.find(n).eq(0).text());
                });
                pr(EHOME).Open3GChange();
            },
            error:function(){
                return false;
            }
        });
    }
    
}

pr(EHOME).update = function() {
    g_transStack.clear();
    var that = this;
    g_transStack.push(function() {
        that.setLxd(parent.translator.getLanguageXmlDoc(["System", "EHOME"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);
    
    this.updateVpnParam();

    $("#SaveConfigBtn").show();

    $.ajax({
        type: "GET",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/EHOME",
        timeout: syncTime,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {
            that.eHomeXml = xmlDoc;
            var $xmlDoc = $(that.eHomeXml);

            $.each(["FrontID","PlatIpAddrV4","PlatIpPort"/*, "b3gFlg"*/], function(i, n){
                $.g.setField2('#dvEHOME #'+n, $xmlDoc.find(n).text());
            });
            $.g.setField2('#dvEHOME #bPlatProtocol', $xmlDoc.find("bPlatProtocol").text()==="1"?"true":"false");
        }
    });
    autoResizeIframe();

}

pr(EHOME).validateForm = function(){
    var res = true;

    $('#FrontIDTips, #PlatIpAddrV4Tips, #PlatIpPortTips').html('');

    var warnTipsIcon = '<img src="../images/config/tips.png" class="verticalmiddle">&nbsp;';

    var FrontID = $('#dvEHOME #FrontID').val();
    if (!FrontID) {
        $('#FrontIDTips').html(warnTipsIcon+"不能为空");
        res = false;
    };

    var maxlength = $('#dvEHOME #FrontID').attr("maxlength");
    if (!maxlength) {
        maxlength = 31;
    }else{
        maxlength = parseInt(maxlength, 10);
    }

    if (FrontID.length > maxlength) {
        $('#FrontIDTips').html(warnTipsIcon+"长度不能超过"+maxlength);
        res = false;
    };


    var ip = $('#dvEHOME #PlatIpAddrV4').val();
    if (!$.isIpAddress(ip)) {
        res = false;
        $('#PlatIpAddrV4Tips').html(warnTipsIcon+"IP地址不正确");
    };

    var port = $('#dvEHOME #PlatIpPort').val();
    port = Number(port);

    if (!port || port <= 0 || port > 65535) {
        res = false;
        $('#PlatIpPortTips').html(warnTipsIcon+"端口不正确");  
    };

    return res;
}

pr(EHOME).submitVpnParam=function(){
    var that=this;
    var $vpnxml=$(this.vpnxml);
    $.each(["open3G","bVpn"],function(i,n){
        $vpnxml.find(n).eq(0).text($("#dvEHOME #"+n).prop("checked")?"1":"0");
    });
    $.each(["telephone","APN","userName",
        "password","verifyProtocal"],function(i,n){
        $vpnxml.find(n).eq(0).text($("#dvEHOME #"+n).val());
    });
    var xmlStr=xmlToStr(this.vpnxml);
    $.ajax({
        url:m_lHttp+m_szHostName+":"+m_lHttpPort+"/PSIA/Custom/SelfExt/MobileNetwork",
        type:"put",
        timeout: 15000,
        processData: false,
        data:xmlStr,
        async:false,
        beforeSend:function(xhr){
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        complete:function(xhr,textStatus){
            if(xhr.status==200){
                that.submitVpnflag=true;
            }
            that.vpnXhr=xhr;

        }
    });
}

pr(EHOME).submit = function(){
    var that=this;
     if (!this.validateForm()) {
        return;
    };
    //this.capabilities3g=true;
    //this.getCapabilities3G();
    //var open3GEnabled= $("#dvEHOME #open3G").prop("checked");
    if(this.capabilities3g){
        if(this.validateVpnParam()){
            this.submitVpnParam();
        }else{
            return;
        }
    }else{
        that.submitVpnflag=true;
    }

    var $xmlDoc = $(this.eHomeXml);

    $.each(["FrontID","PlatIpAddrV4","PlatIpPort"/*, "b3gFlg"*/], function(i, n){
        var v = $('#dvEHOME #'+n).val();
        $xmlDoc.find(n).text(v);
    });
    $xmlDoc.find("bPlatProtocol").text($("#dvEHOME #bPlatProtocol").prop("checked")?"1":"0");

    var xml = xmlToStr(this.eHomeXml);
    $.ajax({
        type: "put",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/EHOME",
        timeout: 15000,
        processData: false,
        data: xml,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        complete:function(xhr, textStatus) {
            if(that.submitVpnflag){
                SaveState(xhr);
            }else{
                SaveState(that.vpnXhr);
            }
            
        }
    });
}

var g_bIsErorr=false;
//违法字典
function IllegalDictionary(){
    SingletonInheritor.implement(this);
    this.m_xmLDoc=null;
    this.illTable=null;
}
SingletonInheritor.declare(IllegalDictionary);

//选中某个命名项
var m_iSelectItem = -1;//记录上一次点击的int值。
var paramItem = ""; //记录上一次点击时的列值。
var selectItemVal = '';
var m_strItem = new Array();
for(var i = 0; i < 5; i++) {
    m_strItem[i] = '';
}

//更新违法字典数据
pr(IllegalDictionary).update=function(iflag){
    g_transStack.clear();
    var that = this;
    g_transStack.push(function() {
        that.setLxd(parent.translator.getLanguageXmlDoc(["System", "IllegalDictionary"]));
        parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
        parent.translator.translatePage(that.getLxd(), document);
    }, true);
    $.ajax({
        url:m_lHttp + m_strIp + ":" + m_lHttpPort+"/PSIA/Custom/SelfExt/IllegalDictionary",
        //url:"/doc/test/capabilities.xml",
        type:"GET",
        async:false,
        dataType:"text",
        beforeSend: function(xhr){
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success:function(xmlDoc,textStatus,xhr){
            that.m_xmLDoc=parseXmlFromStr(xmlDoc);
            var $xmlDoc=$(that.m_xmLDoc);
            var idxLen=$xmlDoc.find("IllegalCodeItem").length;
            var rowLen=0;
            try{
                rowLen=document.getElementById("tbIllegalDictionary").rows.length;
            }
            catch(e){
                rowLen=0;
            }
            for(var i=1;i<rowLen;i++){
                document.getElementById("tbIllegalDictionary").deleteRow(1);
            }
            for(var j=0;j<idxLen;j++){
                var IllegalCodeItem=$xmlDoc.find("IllegalCodeItem").eq(j);
                var illegalIdx=$(IllegalCodeItem).find("idx").eq(0).text();
                var illegalCode=$(IllegalCodeItem).find("illegalCode").eq(0).text();
                var illegalName=$(IllegalCodeItem).find("illegalName").eq(0).text();
                insertTbIllegalDictionary(illegalIdx,illegalCode,illegalName);
            }
            $("#IllegalDictionaryReTips").html(m_szSuccessState+"读取数据成功!");
            
        },
        error:function(XMLHttpRequest, textStatus, errorThrown){
            $("#IllegalDictionaryReTips").html(m_szErrorState+"读取数据失败!");
        }

    });
    setTimeout(function(){
        $("#IllegalDictionaryReTips").html("");
    },5000);
    autoResizeIframe();
}

//违法字典恢复默认参数
pr(IllegalDictionary).recoveryParam=function(iflag){
    var warning=confirm("确认恢复默认参数?");
    if(warning){
        $.ajax({
            url:m_lHttp + m_strIp + ":" + m_lHttpPort+"/PSIA/Custom/SelfExt/IllegalDictionary/reset",
            type:"PUT",
            async:false,
            data:null,
            beforeSend: function(xhr){
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            success:function(xmlDoc,textStatus,xhr){
                
                if("200"==xhr.status){
                    $("#IllegalDictionaryReTips").html(m_szSuccessState+"恢复默认成功,重启后生效!");
                    if($(xmlDoc).find('statusCode').eq(0).text()=="7"){
                        ia(Maintain).confirmAndRestart();
                    }
                    
                }
            },
            error:function(XMLHttpRequest, textStatus, errorThrown){
                $("#IllegalDictionaryReTips").html(m_szErrorState+"恢复默认失败!");
            }
        });
        setTimeout(function(){
            $("#IllegalDictionaryReTips").html("");
        },5000);
    }
    autoResizeIframe();
}

//插入违法字典到表格中
function insertTbIllegalDictionary(illegalIdx,illegalCode,illegalName){
    var objTr;
    var objTd;
    //document.getElementById("485ParamList").rows.length
    objTr=document.getElementById("tbIllegalDictionary").insertRow(document.getElementById("tbIllegalDictionary").rows.length);
    objTr.style.height=22+'px';
    objTr.style.cursor="pointer";
    for(var i=0;i<document.getElementById("tbIllegalDictionary").rows[0].cells.length;i++){
        objTd=objTr.insertCell(i);
        if(i!=3){
            $(objTd).css({border:"1px solid #d7d7d7",background:"#ffffff",padding:"0 0 0 5px"});
        }
        switch(i){
            case 0:
                objTd.innerHTML=illegalIdx;
                objTd.disabled=true;
                objTd.id="illegalIdxItemtd"+illegalIdx;
                objTd.name="illegalIdxItemtd"+illegalIdx;
                objTd.style.color="#39414A";
                break;
            case 1:
                objTd.innerHTML=illegalCode;
                objTd.id="illegalCodeItemtd"+illegalIdx;
                objTd.name="illegalCodeItemtd"+illegalIdx;
                objTd.style.color="#39414A";
                break;
            case 2:
                $(objTd).css("");
                objTd.innerHTML=illegalName;
                objTd.id="illegalNameItemtd"+illegalIdx;
                objTd.name="illegalNameItemtd"+illegalIdx;
                objTd.style.color="#39414A";
                break;
            case 3:
                objTd.innerHTML="";
                objTd.id="illegalTipsItemtd"+illegalIdx;
                objTd.name="illegalTipsItemtd"+illegalIdx;
                objTd.style.color="#39414A";
                break;
            default:
                break;
        }
    }
}

//违法字典数据的保存
pr(IllegalDictionary).submit=function(){
    var that=this;
    var $xmlDoc=$(that.m_xmLDoc);
    var rowLen=document.getElementById("tbIllegalDictionary").rows.length-1;
    
    for(var i=0;i<rowLen;i++){
        var IllegalCodeItem=$xmlDoc.find("IllegalCodeItem").eq(i);
        var illegalIdx=$(IllegalCodeItem).find("idx").eq(0).text();

        var illegalCode="";
        var illegalName="";
        
        if($("#illegalNameItem"+illegalIdx).length!=0){
            illegalName=$("#illegalNameItem"+illegalIdx).val();
        }else{
            illegalName=$("#illegalNameItemtd"+illegalIdx).html();
        }
        if(illegalName==""||illegalName.length>32){
            g_bIsErorr=true;
            $("#illegalTipsItemtd"+(illegalIdx)).html(m_szErrorState+"违法类型的长度不能大于31字节且不能为空!");
            
        }else{
            g_bIsErorr=false;
            $("#illegalTipsItemtd"+(illegalIdx)).html("");

            if($("#illegalCodeItem"+illegalIdx).length!=0){
                illegalCode=$("#illegalCodeItem"+illegalIdx).val();
            }else{
                illegalCode=$("#illegalCodeItemtd"+illegalIdx).html();
            }
            if(illegalCode==""|| !checkInputInt(illegalCode)){
                g_bIsErorr=true;
                $("#illegalTipsItemtd"+(illegalIdx)).html(m_szErrorState+"违法代码必须为整型且不能为空!");
            }else{
                var code=parseInt(illegalCode);
                if(code>2147483647||code<0){
                    g_bIsErorr=true;
                    $("#illegalTipsItemtd"+(illegalIdx)).html(m_szErrorState+"违法代码不能为负数且超过2147483647!");
                }else{
                    g_bIsErorr=false;
                    $("#illegalTipsItemtd"+(illegalIdx)).html("");
                }
            }
        }
        
        if(g_bIsErorr){
            $("#SetResultTips").html(m_szErrorState+"参数错误!");
            setTimeout(function(){$("#SetResultTips").html("");},5000);
            return;
        }
        $(IllegalCodeItem).find("illegalCode").eq(0).text(illegalCode);
        $(IllegalCodeItem).find("illegalName").eq(0).text(illegalName);
    }

    
    $.ajax({
        url:m_lHttp + m_strIp + ":" + m_lHttpPort+"/PSIA/Custom/SelfExt/IllegalDictionary",
        type:"PUT",
        async:false,
        data:xmlToStr(that.m_xmLDoc),
        beforeSend: function(xhr){
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        complete:function(xhr, textStatus) {
            SaveState(xhr);
        }
    });
}

//选中cell函数
System.choiceIllegalDictionaryTd = function(ObjTdId, selectedItem,tdValue){

    var szInfo = "";
    if(ObjTdId.indexOf("illegalIdxItemtd") == 0){
        paramItem = "illegalIdx";
       
    }
    if(ObjTdId.indexOf("illegalCodeItemtd") == 0){
        paramItem = "illegalCode";
        szInfo = "<input type='text' name='illegalCodeItem" + selectedItem + "' id='illegalCodeItem" + selectedItem + "' class='width145'/>";
        $("#illegalCodeItemtd" + (selectedItem)).html(szInfo);
        $("#illegalCodeItem" + selectedItem).val(tdValue);
    }
    if(ObjTdId.indexOf("illegalNameItemtd") == 0){
        paramItem = "illegalName";
        szInfo = "<input type='text' name='illegalNameItem" + selectedItem + "' id='illegalNameItem" + selectedItem + "' class='width145'/>";
        $("#illegalNameItemtd" + (selectedItem)).html(szInfo);
        $("#illegalNameItem" + selectedItem).val(tdValue);
    }
    if(ObjTdId.indexOf("illegalTipsItemtd")==0){
        paramItem="illegalTips";
    }
    
}

//获取上一次选中的值并赋值给自身td 设值。
System.getLastChoiceIllegalDictionaryValue = function(paramItem, m_iLastSelectItem){

    if(paramItem == "illegalIdx"){
        //$("#illegalIdxItemtd" + (m_iLastSelectItem)).html($("#illegalIdxItem" + (m_iLastSelectItem)).val());
    }
    
    if(paramItem == "illegalCode"){
        var illegalCode="";
        illegalCode=$("#illegalCodeItem" + (m_iLastSelectItem)).val();
        if(illegalCode==""|| !checkInputInt(illegalCode)){
            g_bIsErorr=true;
            $("#illegalTipsItemtd"+(m_iLastSelectItem)).html(m_szErrorState+"违法代码必须为整型且不能为空!");
        }else{
            var code=parseInt(illegalCode);
            if(code>2147483647||code<0){
                g_bIsErorr=true;
                $("#illegalTipsItemtd"+(m_iLastSelectItem)).html(m_szErrorState+"违法代码不能为负数且超过2147483647!");
            }else{
                g_bIsErorr=false;
                $("#illegalTipsItemtd"+(m_iLastSelectItem)).html("");
            }
        }
        $("#illegalCodeItemtd" + (m_iLastSelectItem)).html(illegalCode);
    }else if(paramItem == "illegalName"){
        var illegalName="";
        illegalName=$("#illegalNameItem" + (m_iLastSelectItem)).val();
        if(illegalName=="" || illegalName.length>32){
            g_bIsErorr=true;
            $("#illegalTipsItemtd"+(m_iLastSelectItem)).html(m_szErrorState+"违法类型的长度不能大于31字节且不能为空!");
            
        }else{
            g_bIsErorr=false;
            $("#illegalTipsItemtd"+(m_iLastSelectItem)).html("");
        }
        $("#illegalNameItemtd" + (m_iLastSelectItem)).html(illegalName);
    }
    if(paramItem == "illegalTips"){
        //$("#illegalTipsItemtd"+(m_iLastSelectItem)).html("");
    }
    
}

System.SelectIllegalDictionaryTableTd = function(event)
{
    event = event?event:(window.event?window.event:null);
    var ObjTable = event.srcElement?event.srcElement:event.target;

    if(ObjTable.tagName == "TD")
    {
        var tdId = ObjTable.id;
        var tdValue = ObjTable.innerText;

        while(ObjTable.tagName != "TR"){
            ObjTable = ObjTable.parentNode;
        }
        ObjParent = ObjTable.parentNode;
        var m_iSelFileIndex = ObjTable.rowIndex - 1;
        if(m_iSelFileIndex == -1){
            return;
        }
        while(ObjParent.tagName!="TABLE"){
            ObjParent = ObjParent.parentNode;
            //选择非本行时需要清除选择的颜色并赋值选中项
            if(m_iSelectItem >=  0){
                $("#illegalIdxItemtd" + (m_iSelectItem)).css({ color: "#39414A", background: "#ffffff" });
                $("#illegalCodeItemtd" + (m_iSelectItem)).css({ color: "#39414A", background: "#ffffff" });
                $("#illegalNameItemtd" + (m_iSelectItem)).css({ color: "#39414A", background: "#ffffff" });
                
                System.getLastChoiceIllegalDictionaryValue(paramItem,m_iSelectItem);
                paramItem = "";
            }

            for(var i = 1;i < ObjParent.rows.length;i ++){
                if(ObjTable.rowIndex == i){
                    m_iSelectItem = i-1;

                    $("#illegalIdxItemtd" + (m_iSelectItem)).css({ color: "#ffffff", background: "#316ac5" });
                    $("#illegalCodeItemtd" + (m_iSelectItem)).css({ color: "#ffffff", background: "#316ac5" });
                    $("#illegalNameItemtd" + (m_iSelectItem)).css({ color: "#ffffff", background: "#316ac5" });
                   
                    System.choiceIllegalDictionaryTd(tdId, m_iSelectItem,tdValue);
                }
            }
        }
    }
}

