function BusOnLaneTriggerModeS () {
	SingletonInheritor.implement(this);	
}

SingletonInheritor.declare(BusOnLaneTriggerModeS);

BusOnLaneTriggerModeS.prototype.updateLang = function () {
	$('#CommendParamBtn, #SaveConfigBtn').hide();

	g_transStack.clear();
	var that = ia(BusOnLaneTriggerModeS);
	g_transStack.push(function() {
		var busOneLaneDoc = parent.translator.getLanguageXmlDoc("BusOnLaneTriggerMode");
		that.setLxd(busOneLaneDoc);

		var tModeDoc = parent.translator.getLanguageXmlDoc("TriggerMode");
		parent.translator.appendLanguageXmlDoc(that.getLxd(), tModeDoc);

		parent.translator.appendLanguageXmlDoc(that.getLxd(), g_lxdParamConfig);
		parent.translator.translatePage(that.getLxd(), document);
	}, true);
};

(function() {
	var BusOnLaneTriggerMode = window.BusOnLaneTriggerMode || {};

	var ParamLoaded = false;
	
	var originalXml = null;
	var $xml = null;

	
	function GetParam(cmd){
		ParamLoaded = false;

		var tail = '';
		if (cmd) {
			tail = '/recommendation'
		};

		// var lanecount = parseInt($(xmlDoc).find("laneCount").eq(0).text());
		var laneCountRes = GetLaneCount();
		
		$.ajax({
	        type: "GET",
	        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/BusOnLane"+tail,
	        timeout: 15000,
	        dataType: 'text', 
	        beforeSend: function(xhr) {
	            xhr.setRequestHeader("If-Modified-Since", "0");
	            
	        },
	        success: function(xmlDoc, textStatus, xhr) {
	            originalXml = parseXmlFromStr(xmlDoc);
	            $xml = $(originalXml);

	            var laneCount = $xml.find('laneCount').eq(0).text();

	            ParamLoaded = true;

	            fillLaneCountOptions(laneCountRes.min, laneCountRes.max, laneCount);

	            $.each([/*'samePlateCapInterval',*/ 'trigCapInterval',
					'bYellowLineDect', 'yellowLineSen', 'plateConfidence'], function (i, n) {
						$.g.setField2($('#'+n), $xml.find(n).eq(0).text());
					});

	           $xml.find('busOnLaneTimeSwitch').each(function(i, n){
	           		var $s = $(this);
	           		var timeId = $s.find('timeId').eq(0).text();
	           		var startHour = $s.find('startHour').text().padLeft(2, '0');
	           		var startMinute = $s.find('startMinute').text().padLeft(2, '0');
	           		var endHour = $s.find('endHour').text().padLeft(2, '0');
	           		var endMinute = $s.find('endMinute').text().padLeft(2, '0');

	           		$('#busOnLaneStartTime'+timeId).val(startHour+":"+startMinute);
	           		$('#busOnLaneStopTime'+timeId).val(endHour+":"+endMinute);
	           });

	            BusOnLaneTriggerMode.lastLaneIndex = false;
	            BusOnLaneTriggerMode.changeBusOnLaneCount(laneCount);

	            GetPlateRegionParam();
	            YellowLineDectClick();
	        },
	        error: function(xhr, textStatus, errorThrown) {
	            
	        }
	    });
	}

	function GetPlateRegionParam(cmd){
		var url = m_lHttp + m_szHostName + ":"+m_lHttpPort + 
				"/PSIA/Custom/SelfExt/ITC/PlateRecognition/BusOnLane";
		//var url = "/doc/test/busOnLane.xml";
		if (cmd) {
			url += "/recommendation";
		}

		var laneCount = $('#RelatedLaneCount_busOnLane').val();

		PlateRegion.GetPlateRecognition(url, function(){
			displayRegions();
		});
	}

	function GetLaneCount () {
		var url = m_lHttp + m_szHostName + ":"+m_lHttpPort 
					+ '/PSIA/Custom/SelfExt/ITC/BusOnLane/capabilities';
		var res = {
			min: 1, 
			max: 1
		};
		$.ajax({
			type: "GET",
			url: url,
			timeout: 15000,
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) {
				var $nd = $(xmlDoc).find('laneCount').eq(0);
				if ($nd.length) {
					min = parseInt($nd.attr('min'));
					max = parseInt($nd.attr('max'));

					if (min >=0 && max >= 1) {
						res.min = min;
						res.max = max;
					};
				};
			}
		});

		return res;
	}

	function fillLaneCountOptions(min, max, curVal){
		if (min <= 0) {
			min = 1;
		}
        var $s = $('#RelatedLaneCount_busOnLane');
        $s.find('option').remove();
        for (var i=min; i <= max; i++) {
            var opt = "<option value='"+i+"' ";
            if (curVal != null && i == curVal) {
                opt += " selected='selected' ";
            }
            opt += ">"+i+"</option>";
            
            $s.append(opt);
        }
    }

    //检验起效时间
    function checkbusOnLaneTime(){
    	var startTime1=parseInt($('#busOnLaneStartTime1').val().replace(":",""));
    	var endTime1=parseInt($('#busOnLaneStopTime1').val().replace(":",""));
    	if(startTime1!=0&&endTime2!=0){
    		if(startTime1>=endTime1){
	    		return false;
	    	}
    	}
    	
    	var startTime2=parseInt($('#busOnLaneStartTime2').val().replace(":",""));
    	var endTime2=parseInt($('#busOnLaneStopTime2').val().replace(":",""));

    	if(startTime2!=0&&endTime2!=0){
    		if(startTime2>=endTime2){
	    		return false;
	    	}
    	}
    	
    	if((startTime1!=endTime1)&&(startTime2!=endTime2)){
    		if((startTime2>=startTime1&&startTime2<=endTime1)
	    		||(endTime2>=startTime1&&endTime2<=endTime1)){
	    		return false;
	    	}
	    	if(startTime2<=startTime1&&endTime2>=endTime1){
	    		return false;
	    	}
    	}
    	
    	return true;
    }

	function SetParam(callback){
		ia(TriggerMode).m_bRebootRequired = false;
		var ret=checkbusOnLaneTime();
		if(!ret){
			$("#SetResultTips").html("抓拍起效时间设置错误！");
			setTimeout(function(){
				$("#SetResultTips").html("");
			},5000);
			return;
		}
		BusOnLaneTriggerMode.restoreLaneParam();

		$.each([/*'samePlateCapInterval',*/ 'trigCapInterval',
					/*'bYellowLineDect',*/ 'yellowLineSen', 'plateConfidence'], function (i, n) {
				var v = $.g.getEleVal('#'+n);
				$xml.find(n).eq(0).text(v);
			});

		$xml.find('bYellowLineDect').eq(0).text($('#bYellowLineDect').prop('checked') ? "1":"0");

       $xml.find('busOnLaneTimeSwitch').each(function(i, n){
       		var $s = $(this);
       		var timeId = $s.find('timeId').eq(0).text();

       		var startTime = $('#busOnLaneStartTime'+timeId).val();
       		var endTime = $('#busOnLaneStopTime'+timeId).val();

       		var st = startTime.split(":");
       		var et = endTime.split(":");
       		if (st.length == 2) {
       			$s.find('startHour').text(st[0]);
       			$s.find('startMinute').text(st[1]);
       		};

			if (et.length == 2) {
       			$s.find('endHour').text(et[0]);
       			$s.find('endMinute').text(et[1]);
       		};       		
       });


		$.ajax({
	        type: "PUT",
	        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/BusOnLane",
	        timeout: 15000,
	        beforeSend: function(xhr) {
	            xhr.setRequestHeader("If-Modified-Since", "0");
	            
	        },
	        data: xmlToStr(originalXml),
			processData: false,
			complete:function(xhr, textStatus) {
				if(xhr.status != 200) {
					if(xhr.status == 403) {
						var szErrorInfo = m_szError8;
						szRetInfo = m_szErrorState + szErrorInfo;
					} else {
						var xmlDoc =xhr.responseXML;
						if($(xmlDoc).find("detailedStatusCode").eq(0).text() != "") {
							var szErrorInfo = getNodeValue("Error" + $(xmlDoc).find("detailedStatusCode").eq(0).text());
						} else {
							var szErrorInfo = m_szError13;
						}
						szRetInfo = m_szErrorState + szErrorInfo;
					}
		            $("#SetResultTips").html(szRetInfo); 
			        setTimeout(function(){$("#SetResultTips").html("");},5000);  //5秒后自动清除
			        return;	
				} else {
					if($(xhr.responseXML).find("statusCode").eq(0).text() == "7") {
						ia(TriggerMode).m_bRebootRequired = true;
					}

					if (callback) {
						callback();
					}
				}
			}
	    });
	}

	BusOnLaneTriggerMode.changeBusOnLaneCount = function (laneCount) {
		if (!laneCount) {
			laneCount = 1;
		};

		$('#tabBusOnLane li').each(function (i, n) {
			if (i < laneCount) {
				$(this).show();
			}else{
				$(this).hide();
			}
		});

		var current = $('#tabBusOnLane a.current').not(":hidden");
		if (current.length == 0) {
			this.selectLane(0);
		}else{
			var idx = current.eq(0).attr('id').replace("aBusOnLaneLane", "");
			idx = parseInt(idx, 10) - 1;
			this.selectLane(idx);
		}

		displayRegions();
	}

	BusOnLaneTriggerMode.updateLang = function () {
		ia(BusOnLaneTriggerModeS).updateLang();
	}

	BusOnLaneTriggerMode.initEvt = function(){
		$('#recordEnable').unbind('click').click(function(){
			if ($(this).prop('checked')) {
				// $('#preRecordType, #preRecordTime, #recordTimeOut')
			};
		})
	}

	BusOnLaneTriggerMode.update = function () {
		if ($("#main_plugin").html() == "") {
			if (checkPlugin('2', getNodeValue('laPlugin'), 1, 'snapdraw', 0)) {
				if (!CompareFileVersion()) {
					UpdateTips();
				}
			}
		}

		InitSlider2();

		GetParam();
		
		
		setTimeout(function(){
			if (HWP.Play() !== 0) {
				alert(getNodeValue("previewfailed"));
			}
		}, 300);

		autoResizeIframe();
	}

	BusOnLaneTriggerMode.restoreLaneParam = function (laneIndex) {
		if (typeof laneIndex == 'undefined') {
			laneIndex = this.lastLaneIndex;
		};
		if (this.lastLaneIndex === false) {
			return;
		};

		var $lane = $xml.find('LaneParam').eq(laneIndex);

		$xml.find('recordEnable').eq(0).text($('#recordEnable').prop('checked') ? "1":"0");

		$.each(["preRecordType","laneDirectionType", 
				"preRecordTime","recordTimeOut"], function(i, n){
			$lane.find(n).text($.g.getEleVal('#'+n));
		});
	}

	BusOnLaneTriggerMode.displayLaneParam = function (laneIndex) {
		if (typeof laneIndex == 'undefined') {
			return;
		};
		var $lane = $xml.find('LaneParam').eq(laneIndex);

		$.each(["recordEnable", "preRecordType","laneDirectionType", 
				"preRecordTime","recordTimeOut"], function(i, n){
			$.g.setField2('#'+n, $lane.find(n).eq(0).text());
		});
	}
	BusOnLaneTriggerMode.selectLane = function (laneIndex) {
		var $a = $('#tabBusOnLane a').eq(laneIndex);
		if (!$a.length) {
			return;
		};

		$('#tabBusOnLane a').removeClass('current');
		$a.addClass('current');

		this.restoreLaneParam();
		this.displayLaneParam(laneIndex);

		this.lastLaneIndex = laneIndex;
	}

	BusOnLaneTriggerMode.GetCommendParam = function(){
		GetParam(true);
	}

	BusOnLaneTriggerMode.SetParam = function(){
		SetParam(function(){
			var url = m_lHttp + m_szHostName + ":"+m_lHttpPort + 
				"/PSIA/Custom/SelfExt/ITC/PlateRecognition/BusOnLane";
			PlateRegion.SetPlateRecognition(url);
		});
	}

	BusOnLaneTriggerMode.showAllShapes = function(){
		var idxArr = [];

		var v = $('#drawPicCheck').prop('checked');
		if (v) {
			var laneCount = $('#RelatedLaneCount_busOnLane').val();
	    	laneCount = parseInt(laneCount, 10);

	    	idxArr = $.g.range(laneCount, 1);
		}else{
			if (this.lastLaneIndex === false) {
				idxArr = [1];
			}else{
				idxArr.push(this.lastLaneIndex+1);
			}
		}

		PlateRegion.DisplayPlateRegionEx(idxArr);
	}

	BusOnLaneTriggerMode.ShowDrawPolygonModal = function() {
		if (!g_bIsIE) {
	        $("#busOnLane_Draw_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='BusOnLaneDrawPlugin' width='100%' height='100%' name='BusOnLaneDrawPlugin' align='center' wndtype='1' playmode='snapdraw'>");
	    } else {
	        $("#busOnLane_Draw_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='BusOnLaneDrawPlugin' width='100%' height='100%' name='BusOnLaneDrawPlugin' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
	    }

	    var idxArr = [];

	    var laneCount = $('#RelatedLaneCount_busOnLane').val();
	    laneCount = parseInt(laneCount, 10);
	    for (var i = 0; i < 6; i++) {
	    	$('#busOnLaneDrawBtn'+(i+1)).unbind();
	    	if (i < laneCount) {
	    		idxArr.push(i+1);
	    		var j = i+1;
	    		$('#busOnLaneDrawBtn'+(i+1)).show().click(function(){
	    			PlateRegion.reDrawPlateRegion(j, '#BusOnLaneDrawPlugin');
	    		});
	    	}else{
	    		$('#busOnLaneDrawBtn'+(i+1)).hide();
	    	}
	    };
        
        $('#busOnLaneModalDiv').modal();

        setTimeout(function () {
         	PlateRegion.DisplayPlateRegionEx(idxArr, '#BusOnLaneDrawPlugin');
	        var ocx = $('#BusOnLaneDrawPlugin')[0];		
			try{
				ocx.HWP_SetSnapDrawMode(0, 3);  //设置为选择模式
			}catch(e){}
        }, 500);

        HWP.Stop();
        $("#main_plugin").hide();

        var szURL = "rtsp://" + m_szHostName + ":" + m_lRtspPort + "/PSIA/streaming/channels/101";
        var iRet = $("#BusOnLaneDrawPlugin")[0].HWP_Play(szURL, m_szUserPwdValue, 0, "", "");
        if (iRet !== 0) {
            alert(getNodeValue("previewfailed"));
        }
	}


	function displayRegions(){
		BusOnLaneTriggerMode.showAllShapes();

		// var laneCount = $('#RelatedLaneCount_busOnLane').val();
	 //    var arr = $.g.range(laneCount, 1);
		// PlateRegion.DisplayPlateRegionEx(arr);
	}


	BusOnLaneTriggerMode.OkModel = function(){
		$("#main_plugin").show();
	    if (HWP.Play() !== 0) {
	        alert(getNodeValue("previewfailed"));
	    }
	    
	   	PlateRegion.RestorePlateRegion('#BusOnLaneDrawPlugin');

	    $.modal.impl.close();

	   displayRegions();
	}

	BusOnLaneTriggerMode.CancelModel = function () {
		$("#main_plugin").show();
	    if (HWP.Play() !== 0) {
	        alert(getNodeValue("previewfailed"));
	    }
	    $.modal.impl.close();

	    displayRegions();
	}

	function YellowLineDectClick(){
		if($('#bYellowLineDect').prop('checked')){
			$('#divyellowLineSen').show();
		}else{
			$('#divyellowLineSen').hide();
		}
		autoResizeIframe();
	}

	BusOnLaneTriggerMode.bYellowLineDectClick=function(){
		YellowLineDectClick();
	}

	window.BusOnLaneTriggerMode = BusOnLaneTriggerMode;
})();

function changePrerecordType(){

}