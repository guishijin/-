﻿var m_xmlDoc=null;

var m_oXmlDoc = null;             //模拟通道
var m_oDigXmlDoc = null;          //数字通道
var m_oZeroXmlDoc = null;         //零通道

var m_PreviewOCX=null;
var m_szHostName="";
var m_lHttpPort="80";
var m_lHttp="http://";
var m_lRtspPort="554";
var m_lHttpsPort = 443;

var m_szUserPwdValue="";
var m_iStreamType = 0; //码流类型
var m_iChannelId = new Array(); //通道对应的ID号
for(var i=0;i<64;i++)
{
	m_iChannelId[i] = -1;
}

var m_iAnalogChannelNum=0;
var m_iDigitalChannelNum=0;
var m_iZeroChanNum = 0;

m_lHttp = location.protocol + "//";
m_szHostName = location.hostname;
if(isIPv6Add(m_szHostName))
{
	m_szHostName = "[" + m_szHostName + "]";
}
if(location.port != "")
{
	m_lHttpPort = location.port;
}
else if(m_lHttp == "https://")
{
	m_lHttpPort = "443";
}

var HWP = null;  //插件对象
var m_PictureDisplayWindow = null;
var m_PicUpWindow = null;

g_bIsIE  = !(/(msie\s|trident.*rv:)([\w.]+)/.exec( navigator.userAgent.toLowerCase()) == null);
var g_lMapRtspPort = null;
/*************************************************
 Function:		trim, ltrim, rtrim
 Description:	字符串左右去空格
 Input:
 Output:			无
 return:			无
 *************************************************/
String.prototype.Trim = function()
{
    return this.replace(/(^\s*)|(\s*$)/g, "");
}
String.prototype.LTrim = function()
{
    return this.replace(/(^\s*)/g, "");
}
String.prototype.RTrim = function()
{
    return this.replace(/(\s*$)/g, "");
}
/*************************************************
 Function:		ETrim
 Description:	去除两边空余字符
 Input:
 Output:			无
 return:			无
 *************************************************/
function ETrim(str,is_global)
{
    var result;
    result = str.replace(/(^\s+)|(\s+$)/g,"");
    if(is_global.toLowerCase()=="g")
        result = result.replace(/\s/g,"");
    return result;
}
/*************************************************
Function:		replaceAll
Description:	替换所有
Input:			szDir:源字符
				szTar:目标字符
Output:			无
return:			无
*************************************************/
String.prototype.replaceAll = function(szDir,szTar)
{
	return this.replace(new RegExp(szDir,"g"), szTar);
}
/*************************************************
Function:		toHex
Description:	转换为16进制
Input:			szStr:源字符
Output:			无
return:			无
*************************************************/
String.prototype.toHex = function()
{
	var szRes = "";
    var szArr = new Array();
	for(var i = 0; i < this.length; i++)
	{
        szArr.push(this.charCodeAt(i).toString(16));
//		szRes += this.charCodeAt(i).toString(16);
	}
    szRes = szArr.join('');
	return szRes;
}
/*************************************************
Function:		chooseLanguage
Description:	选择语言
Input:			lan：语言
Output:			无
return:			无				
*************************************************/
function chooseLanguage(lan) {
    if(translator.szCurLanguage != lan) {
	    ChangeFrameLanguage(lan);
	}
	$('#laCurrentLanguage').html($('#' + lan).html());
	$('#divLanguageChoose').hide();
}
/*************************************************
Function:		UnloadPage
Description:	子页面销毁时，修改cookie为当前页
Input:			src:页面路径
				index:ID序号
Output:			无
return:			无				
*************************************************/
function UnloadPage(src,index) {
	$.cookie('page',src+"%"+index);
	if(1 == index) {
		if(window.parent.$(".fishmodechoose").length > 0) {
		    window.parent.$("#dvFishModeChoose").remove();
		}
		window.parent.$("#dvChangeSize").hide();
		//检测关闭实时搜图窗口
		if(m_PicUpWindow && m_PicUpWindow.open && !m_PicUpWindow.closed) {
			m_PicUpWindow.close();
		}
	}
	if(2 == index) {  //回放页面关闭下载窗口
		if(m_DownWindow && m_DownWindow.open && !m_DownWindow.closed) {
			m_DownWindow.close();
		}
	}
	if(3 == index) {  //图片下载页面删除预览测试图片
		try {
	        m_PicPreviewOCX.HWP_DelSnapTestPic();
		} catch(e) {
		}
	}
	if(5 == index) {  //配置页面关闭手动抓拍弹出图片页面
		if(m_PictureDisplayWindow && m_PictureDisplayWindow.open && !m_PictureDisplayWindow.closed) {
			m_PictureDisplayWindow.close();
		}
	}
	try {
		HWP.Stop(0);
	} catch(e) {
    }
}
/*************************************************
Function:		parseXml
Description:	从xml文件中解析xml
Input:			无
Output:			无
return:			xmlDoc				
*************************************************/
function parseXml(fileRoute)
{
	return $.ajax({
		url: fileRoute,
		dataType: "xml",
		type: "get",
		async: false
	}).responseXML;
}

/*************************************************
Function:		parseXmlFromStr
Description:	从xml字符串中解析xml
Input:			szXml xml字符串
Output:			无
return:			xml文档				
*************************************************/
function parseXmlFromStr(szXml)
{
	if(null == szXml || '' == szXml)
	{
		return null;
	}
	var xmlDoc=new createxmlDoc();
	if(!$.browser.msie)
	{
		var oParser = new DOMParser();
		xmlDoc = oParser.parseFromString(szXml,"text/xml");
	}
	else
	{
		xmlDoc.loadXML(szXml);
	}
	return xmlDoc;
}
/*************************************************
Function:		xmlToStr
Description:	xml转换字符串
Input:			Xml xml文档
Output:			无
return:			字符串				
*************************************************/
function xmlToStr(Xml)
{
	if(Xml == null)
	{
	    return;	
	}
	var XmlDocInfo = '';
	try{
		var oSerializer = new XMLSerializer();
		XmlDocInfo = oSerializer.serializeToString(Xml);
	} catch(e) {
		try {
			XmlDocInfo = Xml.xml;
		} catch(e) {
			return "";
		}
	}
	if(XmlDocInfo.indexOf('<?xml') == -1)
	{
		XmlDocInfo = "<?xml version='1.0' encoding='utf-8'?>" + XmlDocInfo;
	}
	return XmlDocInfo;
}

/*************************************************
Function:		Base64
Description:	Base64加密解密
Input:			无		
Output:			无
return:			无				
*************************************************/
 var Base64 = {
 
	// private property
	_keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
 
	// public method for encoding
	encode : function (input) {
		var output = "";
		var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
		var i = 0;
 
		input = Base64._utf8_encode(input);
 
		while (i < input.length) {
 
			chr1 = input.charCodeAt(i++);
			chr2 = input.charCodeAt(i++);
			chr3 = input.charCodeAt(i++);
 
			enc1 = chr1 >> 2;
			enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
			enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
			enc4 = chr3 & 63;
 
			if (isNaN(chr2)) {
				enc3 = enc4 = 64;
			} else if (isNaN(chr3)) {
				enc4 = 64;
			}
 
			output = output +
			this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +
			this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);
 
		}
 
		return output;
	},
 
	// public method for decoding
	decode : function (input) {
		var output = "";
		var chr1, chr2, chr3;
		var enc1, enc2, enc3, enc4;
		var i = 0;
 
		input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
 
		while (i < input.length) {
 
			enc1 = this._keyStr.indexOf(input.charAt(i++));
			enc2 = this._keyStr.indexOf(input.charAt(i++));
			enc3 = this._keyStr.indexOf(input.charAt(i++));
			enc4 = this._keyStr.indexOf(input.charAt(i++));
 
			chr1 = (enc1 << 2) | (enc2 >> 4);
			chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
			chr3 = ((enc3 & 3) << 6) | enc4;
 
			output = output + String.fromCharCode(chr1);
 
			if (enc3 != 64) {
				output = output + String.fromCharCode(chr2);
			}
			if (enc4 != 64) {
				output = output + String.fromCharCode(chr3);
			}
 
		}
 
		output = Base64._utf8_decode(output);
 
		return output;
 
	},
 
	// private method for UTF-8 encoding
	_utf8_encode : function (string) {
		string = string.replace(/\r\n/g,"\n");
		var utftext = "";
 
		for (var n = 0; n < string.length; n++) {
 
			var c = string.charCodeAt(n);
 
			if (c < 128) {
				utftext += String.fromCharCode(c);
			}
			else if((c > 127) && (c < 2048)) {
				utftext += String.fromCharCode((c >> 6) | 192);
				utftext += String.fromCharCode((c & 63) | 128);
			}
			else {
				utftext += String.fromCharCode((c >> 12) | 224);
				utftext += String.fromCharCode(((c >> 6) & 63) | 128);
				utftext += String.fromCharCode((c & 63) | 128);
			}
 
		}
 
		return utftext;
	},
 
	// private method for UTF-8 decoding
	_utf8_decode : function (utftext) {
		var string = "";
		var i = 0;
		var c = c1 = c2 = 0;
 
		while ( i < utftext.length ) {
 
			c = utftext.charCodeAt(i);
 
			if (c < 128) {
				string += String.fromCharCode(c);
				i++;
			}
			else if((c > 191) && (c < 224)) {
				c2 = utftext.charCodeAt(i+1);
				string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
				i += 2;
			}
			else {
				c2 = utftext.charCodeAt(i+1);
				c3 = utftext.charCodeAt(i+2);
				string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
				i += 3;
			}
 
		}
 
		return string;
	} 
}
/*************************************************
Function:		checkPlugin
Description:	检测是否安装插件及向页面插入插件元素
Input:			iType:表示插入插件的位置，0表示本地配置或远程升级等，1表示字符叠加等，2表示预览节界面
				szInfo:提示信息  该参数无效  modified by chenxiangzhen 2012-02-17
				iWndType:窗口分割模式
Output:			true:插件已安装；false:插件未安装
return:			无				
*************************************************/
function checkPlugin(iType, szInfo, iWndType, szPlayMode)
{
	if (!g_bIsIE)
	{
		if ($("#main_plugin").html() !== "" && $("#PreviewActiveX").length !== 0)
		{
			var iPlayMode = 0;
			switch (szPlayMode)
			{
				case "normal":
					//iPlayMode = 0;
					break;
				case "motiondetect":
					iPlayMode = 1;
					break;
				case "tamperdetect":
					iPlayMode = 2;
					break;
				case "privacymask":
					iPlayMode = 3;
					break;
				case "textoverlay":
					iPlayMode = 4;
					break;
				case "osdsetting":
					iPlayMode = 5;
					break;
				default:
					//iPlayMode = 0;
					break;
			}
			HWP.SetPlayModeType(iPlayMode);
			//HWP.ArrangeWindow(parseInt(iWndType));
			return true;
		}
		
		var bInstalled = false;
		for (var i = 0, len = navigator.mimeTypes.length; i < len; i++)
		{
			if (navigator.mimeTypes[i].type.toLowerCase() == "application/hwitcp-webvideo-plugin")
			{
				bInstalled = true;
				if (iType == '0')
				{
				    $("#main_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='PreviewActiveX' width='1' height='1' name='PreviewActiveX' align='center' wndtype='"+iWndType+"' playmode='"+szPlayMode+"'>");
					setTimeout(function() { $("#PreviewActiveX").css('height','0px'); }, 10); // 避免插件初始化不完全
				}
				else if (iType == '1')
				{
					$("#main_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='PreviewActiveX' width='352' height='288' name='PreviewActiveX' align='center' wndtype='"+iWndType+"' playmode='"+szPlayMode+"'>");
				}
				else
				{
					$("#main_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='PreviewActiveX' width='100%' height='100%' name='PreviewActiveX' align='center' wndtype='"+iWndType+"' playmode='"+szPlayMode+"'>");
				}
				$("#PreviewActiveX").css('width','99.99%');
				break;
			}
		}
		if (!bInstalled)
		{
			if (navigator.platform == "Win32")
			{
				szInfo = getNodeValue('laPlugin');
				$("#main_plugin").html("<label name='laPlugin' onclick='window.open(\"../../codebase/ITCPWebComponents.exe\",\"_self\")' class='pluginLink' onMouseOver='this.className =\"pluginLinkSel\"' onMouseOut='this.className =\"pluginLink\"'>"+szInfo+"</label>");
			}
			else if (navigator.platform == "Mac68K" || navigator.platform == "MacPPC" || navigator.platform == "Macintosh")
			{
				szInfo = getNodeValue('laNotWin32Plugin');
				$("#main_plugin").html("<label name='laNotWin32Plugin' onclick='' class='pluginLink' style='cursor:default; text-decoration:none;'>"+szInfo+"</label>");
			}
			else
			{
				szInfo = getNodeValue('laNotWin32Plugin');
				$("#main_plugin").html("<label name='laNotWin32Plugin' onclick='' class='pluginLink' style='cursor:default; text-decoration:none;'>"+szInfo+"</label>");
			}
		  	return false;
		}
	}
	else
	{
		if ($("#main_plugin").html() !== "" && $("#PreviewActiveX").length !== 0 && $("#PreviewActiveX")[0].object !== null)
		{
			var iPlayMode = 0;
			switch (szPlayMode)
			{
				case "normal":
					//iPlayMode = 0;
					break;
				case "motiondetect":
					iPlayMode = 1;
					break;
				case "tamperdetect":
					iPlayMode = 2;
					break;
				case "privacymask":
					iPlayMode = 3;
					break;
				case "textoverlay":
					iPlayMode = 4;
					break;
				case "osdsetting":
					iPlayMode = 5;
					break;
				default:
					//iPlayMode = 0;
					break;
			}
			HWP.SetPlayModeType(iPlayMode);
			//HWP.ArrangeWindow(parseInt(iWndType));
			return true;
		}
		
		$("#main_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='PreviewActiveX' width='100%' height='100%' name='ocx' align='center' ><param name='wndtype' value='"+iWndType+"'><param name='playmode' value='"+szPlayMode+"'></object>");
		var previewOCX=document.getElementById("PreviewActiveX");
		if(previewOCX == null || previewOCX.object == null)
		{
			if((navigator.platform == "Win32"))
			{
				szInfo = getNodeValue('laPlugin');
				$("#main_plugin").html("<label name='laPlugin' onclick='window.open(\"../../codebase/ITCPWebComponents.exe\",\"_self\")' class='pluginLink' onMouseOver='this.className =\"pluginLinkSel\"' onMouseOut='this.className =\"pluginLink\"'>"+szInfo+"<label>");
			}
			else
			{
				szInfo = getNodeValue('laNotWin32Plugin');
				$("#main_plugin").html("<label name='laNotWin32Plugin' onclick='' class='pluginLink' style='cursor:default; text-decoration:none;'>"+szInfo+"<label>");
			}
			
		  return false;
		}
	}
	return true;
}

/*************************************************
 Function:		checkPlugins
 Description:	检测是否安装插件及向页面插入插件元素
 Input:			iType:表示插入插件的位置，0表示本地配置或远程升级等，1表示字符叠加等，2表示预览节界面
 szInfo:提示信息  该参数无效
 iWndType:窗口分割模式
 iNeedBorder: 是否需要边框 0-不需要， 1-需要
 Output:			true:插件已安装；false:插件未安装
 return:			无
 *************************************************/
function checkPlugins(iType, szInfo, iWndType, szPlayMode, pluginContainID, pluginID, iNeedBorder)
{
    var iDrawBorder = 1; //需要绘制边框

    if (pluginContainID == null || pluginID == null || typeof pluginContainID == "undefined" || typeof pluginID == "undefined") {
        return;
    }

    if (iNeedBorder != "" && typeof iNeedBorder != 'undefined' || iNeedBorder != null) {
        iDrawBorder = iNeedBorder;
    }

    var szPluginContain = "#"+pluginContainID;
    var szPluginID = pluginID;
    var szPluginobj = "#"+pluginID;

    if (!$.browser.msie)
    {
        if ($(szPluginContain).html() !== "" && $(szPluginobj).length !== 0)
        {
            var iPlayMode = 0;
            switch (szPlayMode)
            {
                case "normal":
                    //iPlayMode = 0;
                    break;
                case "motiondetect":
                    iPlayMode = 1;
                    break;
                case "tamperdetect":
                    iPlayMode = 2;
                    break;
                case "privacymask":
                    iPlayMode = 3;
                    break;
                case "textoverlay":
                    iPlayMode = 4;
                    break;
                case "osdsetting":
                    iPlayMode = 5;
                    break;
                case "snapdraw":
                    iPlayMode = 6;
                    break;
                case "fisheye":
                    iPlayMode = 7;
                    break;
                case "linedetect":
                    iPlayMode = 8;
                    break;
                case "fielddetect":
                    iPlayMode = 9;
                    break;
                default:
                    //iPlayMode = 0;
                    break;
            }
            HWP.SetPlayModeType(iPlayMode);
            //HWP.ArrangeWindow(parseInt(iWndType));
            return true;
        }

        var bInstalled = false;
        for (var i = 0, len = navigator.mimeTypes.length; i < len; i++)
        {
            if (navigator.mimeTypes[i].type.toLowerCase() == "application/hwitcp-webvideo-plugin")
            {
                bInstalled = true;
                if (iType == '0')
                {
                    $(szPluginContain).html("<embed type='application/hwitcp-webvideo-plugin' id='"+szPluginID+"' width='1' height='1' name='"+szPluginID+"' align='center' wndtype='"+iWndType+"' playmode='"+szPlayMode+"' needborder='"+iDrawBorder+"'>");
                    setTimeout(function() { $(szPluginobj).css('height','0px'); }, 10); // 避免插件初始化不完全
                }
                else if (iType == '1')
                {
                    $(szPluginContain).html("<embed type='application/hwitcp-webvideo-plugin' id='"+szPluginID+"' width='352' height='288' name='"+szPluginID+"' align='center' wndtype='"+iWndType+"' playmode='"+szPlayMode+"' needborder='"+iDrawBorder+"'>");
                }
                else
                {
                    $(szPluginContain).html("<embed type='application/hwitcp-webvideo-plugin' id='"+szPluginID+"' width='100%' height='100%' name='"+szPluginID+"' align='center' wndtype='"+iWndType+"' playmode='"+szPlayMode+"' needborder='"+iDrawBorder+"'>");
                }
                $(szPluginobj).css('width','99.99%');
                $(szPluginobj).css('height','99.99%');
                break;
            }
        }
        if (!bInstalled)
        {
            if (navigator.platform == "Win32")
            {
                szInfo = getNodeValue('laPlugin');
                $(szPluginContain).html("<label name='laPlugin' onclick='window.open(\"../../codebase/ITCPWebComponents.exe\",\"_self\")' class='pluginLink' onMouseOver='this.className =\"pluginLinkSel\"' onMouseOut='this.className =\"pluginLink\"'>"+szInfo+"</label>");
            }
            else if (navigator.platform == "Mac68K" || navigator.platform == "MacPPC" || navigator.platform == "Macintosh")
            {
                szInfo = getNodeValue('laNotWin32Plugin');
                $(szPluginContain).html("<label name='laNotWin32Plugin' onclick='' class='pluginLink' style='cursor:default; text-decoration:none;'>"+szInfo+"</label>");
            }
            else
            {
                szInfo = getNodeValue('laNotWin32Plugin');
                $(szPluginContain).html("<label name='laNotWin32Plugin' onclick='' class='pluginLink' style='cursor:default; text-decoration:none;'>"+szInfo+"</label>");
            }
            return false;
        }
    }
    else
    {
        if ($(szPluginContain).html() !== "" && $(szPluginobj).length !== 0 && $(szPluginobj)[0].object !== null)
        {
            var iPlayMode = 0;
            switch (szPlayMode)
            {
                case "normal":
                    //iPlayMode = 0;
                    break;
                case "motiondetect":
                    iPlayMode = 1;
                    break;
                case "tamperdetect":
                    iPlayMode = 2;
                    break;
                case "privacymask":
                    iPlayMode = 3;
                    break;
                case "textoverlay":
                    iPlayMode = 4;
                    break;
                case "osdsetting":
                    iPlayMode = 5;
                    break;
                case "snapdraw":
                    iPlayMode = 6;
                    break;
                case "fisheye":
                    iPlayMode = 7;
                    break;
                case "linedetect":
                    iPlayMode = 8;
                    break;
                case "fielddetect":
                    iPlayMode = 9;
                    break;
                default:
                    //iPlayMode = 0;
                    break;
            }
            HWP.SetPlayModeType(iPlayMode);
            //HWP.ArrangeWindow(parseInt(iWndType));
            return true;
        }

        $(szPluginContain).html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='"+szPluginID+"' width='100%' height='100%' name='ocx' align='center' ><param name='wndtype' value='"+iWndType+"'><param name='playmode' value='"+szPlayMode+"'><param name='needborder' value='"+iDrawBorder+"'></object>");
        var previewOCX=document.getElementById(szPluginID);
        if(previewOCX == null || previewOCX.object == null)
        {
            if((navigator.platform == "Win32"))
            {
                //szInfo = getNodeValue('laPlugin');
                $(szPluginContain).html("<label name='laPlugin' onclick='window.open(\"../../codebase/ITCPWebComponents.exe\",\"_self\")' class='pluginLink' onMouseOver='this.className =\"pluginLinkSel\"' onMouseOut='this.className =\"pluginLink\"'>"+szInfo+"<label>");
            }
            else
            {
                //szInfo = getNodeValue('laNotWin32Plugin');
                $(szPluginContain).html("<label name='laNotWin32Plugin' onclick='' class='pluginLink' style='cursor:default; text-decoration:none;'>"+szInfo+"<label>");
            }

            return false;
        }
    }
    return true;
}

function initTempPlugin (containerId, pluginId) {
    if (!g_bIsIE) {
        $("#"+containerId).html("<embed type='application/hwitcp-webvideo-plugin' id='"+pluginId+"' width='100%' height='100%' name='"+pluginId+"' align='center' wndtype='1'>");
    } else {
        $("#"+containerId).html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='"+pluginId+"' width='100%' height='100%' name='"+pluginId+"' align='center' ><param name='wndtype' value='1'></object>");
    }
}

/*************************************************
Function:		CompareFileVersion
Description:	比较文件版本
Input:			无
Output:			无
return:			false:需要更新 true：不需要更新
*************************************************/
function CompareFileVersion(pluginId)
{
    if(pluginId == null || pluginId == ''){
        pluginId = "PreviewActiveX";
    }
    var previewOCX = document.getElementById(pluginId);
	if(previewOCX == null)
	{
		return false;
	}
	var xmlDoc=parseXml("../xml/version.xml");
	var szXml = xmlToStr(xmlDoc);
	var bRes = false;
	try
	{
		bRes = !previewOCX.HWP_CheckPluginUpdate(szXml);
		return bRes;
	}
	catch(e)
	{
		if(m_szBrowser != 'Netscape')
		{
			if(1 == CompareVersion("ITCPWebVideoActiveX.ocx"))
			{
				return false;		//插件需要更新
			}
		}
		else
		{
			if(1 == CompareVersion("npITSWebVideoPlugin.dll"))
			{
				return false;		//插件需要更新
			}
		}
		
		if(1 == CompareVersion("PlayCtrl.dll"))
		{
			return false;		//插件需要更新
		}
		
		if(1 == CompareVersion("StreamTransClient.dll"))
		{
			return false;		//插件需要更新
		}
		
		if(1 == CompareVersion("NetStream.dll"))
		{
			return false;		//插件需要更新
		}
		
		if(1 == CompareVersion("SystemTransform.dll"))
		{
			return false;		//插件需要更新
		}
		
		return true;
	}
}
/*************************************************
Function:		CompareVersion
Description:	比较文件版本
Input:			文件名
Output:			无
return:			-1 系统中的版本高 0 版本相同 1 设备中的版本高
*************************************************/
function CompareVersion(szFileName)
{
	var xmlDoc=parseXml("../xml/version.xml");
	
	var fvOld = m_PreviewOCX.GetFileVersion(szFileName,"FileVersion");
	var fvNew = xmlDoc.documentElement.getElementsByTagName(szFileName)[0].childNodes[0].nodeValue;
	
	if(szFileName == "hpr.dll")
	{
		var sp = ".";
	}
	else
	{
		var sp = ",";
	}
	var fvSigleOld = fvOld.split(sp);
	var fvSigleNew = fvNew.split(sp);
	
	for(var i = 0;i < 4;i++)
	{
		if(parseInt(fvSigleOld[i]) > parseInt(fvSigleNew[i]))
		{
			return -1;
		}
		
		if(parseInt(fvSigleOld[i]) < parseInt(fvSigleNew[i]))
		{
			return 1;
		}
	}
	return 0;
}
/*************************************************
Function:		getXMLHttpRequest
Description:	创建xmlhttprequest对象
Input:			无			
Output:			无
return:			无				
*************************************************/
function getXMLHttpRequest()    
{
        var xmlHttpRequest = null; 
        if (window.XMLHttpRequest) 
        {
            xmlHttpRequest = new XMLHttpRequest();
        }
        else if (window.ActiveXObject)
        {
        	xmlHttpRequest = new ActiveXObject("Microsoft.XMLHTTP");
        } 
     	return xmlHttpRequest;
} 
/*************************************************
Function:		createxmlDoc
Description:	创建xml DOM对象
Input:			无			
Output:			无
return:			无				
*************************************************/
function createxmlDoc()
{
	var xmlDoc;
	var aVersions = [ "MSXML2.DOMDocument","MSXML2.DOMDocument.5.0",
	"MSXML2.DOMDocument.4.0","MSXML2.DOMDocument.3.0",
	"Microsoft.XmlDom"];
	
	for (var i = 0; i < aVersions.length; i++) 
	{
		try 
		{
			xmlDoc = new ActiveXObject(aVersions[i]);
			break;
		}
		catch (oError)
		{
			xmlDoc = document.implementation.createDocument("", "", null);
			break;
		}
	}
	xmlDoc.async="false";
	return xmlDoc;
}
/*************************************************
Function:		GoAway
Description:	注销用户
Input:			无
Output:			无
return:			无
*************************************************/
function GoAway()
{
	Warning = confirm(contentframe.window.m_szExit);
	if(Warning)
	{
		g_oWebSession.removeItem("userInfo"+m_lHttpPort);
		$.cookie('page',null);
		window.location.href="login.asp";
	}
}
/*************************************************
Function:		get_previoussibling
Description:	获取节点的上一个子节点
Input:			无
Output:			无
return:			无
*************************************************/
function get_previoussibling(n)
{
    var x = n.previousSibling;
    while (x.nodeType!=1)
    {
        x = x.previousSibling;
    }
    return x;
}
/*************************************************
Function:		browseFilePath
Description:	浏览系统文件夹路径
Input:			szId:文本框ID, iSelectMode 打开模式		
Output:			无
return:			无				
*************************************************/
function browseFilePath(szId, iSelectMode)
{
	if(m_PreviewOCX != null)
	{
		var szPost = HWP.OpenFileBrowser(iSelectMode, "");
		if(szPost == "" || szPost == null)
		{
			return;
		}
		else
		{
			if(iSelectMode == 1)
			{
				if(szPost.length > 100)
				{
					alert(getNodeValue('tipsTooLong'));
					return;
				}
			}
			else
			{
				if(szPost.length > 130)
				{
					alert(getNodeValue('tipsTooLong'));
					return;
				}
			}
		
			document.getElementById(szId).value= szPost;
		}
	}
}
/*************************************************
Function:		CreateCalendar
Description:	创建日历
Input:			iType: 0 日志界面日历 1 时间配置界面日历
Output:			无
return:			无
*************************************************/
function CreateCalendar(iType)
{
	var szLanguage = '';
	if(parent.translator.szCurLanguage == 'zh')
	{
		szLanguage = 'zh-cn';
	}
	else
	{
		$.each(parent.translator.languages, function(i) {
			    if (this.value === parent.translator.szCurLanguage) {
				    szLanguage = this.value;
			    }
		});
		if(szLanguage === '') {
			szLanguage = 'en';
		}
	}
	if(iType == 0)
	{
	    WdatePicker({startDate:'%y-%M-%d %h:%m:%s',dateFmt:'yyyy-MM-dd HH:mm:ss',alwaysUseStartDate:false,minDate:'2004-01-01 00:00:00',maxDate:'2037-12-31 23:59:59',readOnly:true,lang:szLanguage,isShowClear:false,isShowToday:false});
	}
	else if(iType == 1)
	{
		WdatePicker({startDate:'%y-%M-%d %h:%m:%s',dateFmt:'yyyy-MM-ddTHH:mm:ss',alwaysUseStartDate:false,minDate:'2004-01-01 00:00:00',maxDate:'2037-12-31 23:59:59',readOnly:true,lang:szLanguage,isShowClear:false,isShowToday:false});
	}else if(iType == 2)
    {
        WdatePicker({startDate:'%y-%M-%d %h:%m:%s',dateFmt:'yyyy-MM-dd HH:mm:ss',alwaysUseStartDate:false,minDate:'2004-01-01 00:00:00',maxDate:'2037-12-31 23:59:59',readOnly:true,lang:szLanguage,isShowClear:false,isShowToday:true});
    }
	else {
		WdatePicker({dateFmt:'HH:mm',alwaysUseStartDate:false,readOnly:true,lang:szLanguage,isShowClear:false,isShowToday:false});
	}
}

/*************************************************
Function:		getNodeValue
Description:	得到节点值
Input:			tagName:元素名
Output:			无
return:			无
*************************************************/
function getNodeValue(tagName)
{
	if (parent != this) { // 父frame包含Translator.js，当前frame包含common.js
		var _translator = parent.translator;
	} else { // 当前节点包含Translator.js和common.js
		var _translator = translator;
	}
	if (_translator.s_lastLanguageXmlDoc !== null) {
		return _translator.translateNodeByLastLxd(tagName);
	}
}

/**********************************
Function:		DayAdd
Description:	日期加天数
Input:			szDay: 要加的日期
				iAdd： 加的天数
Output:			无
return:			返回带天数的日期.
***********************************/
function DayAdd(szDay,iAdd)
{
	var date =  new Date(Date.parse(szDay.replace(/\-/g,'/')));
	var newdate = new Date(date.getTime()+(iAdd*24 * 60 * 60 * 1000));
	
	return newdate.Format("yyyy-MM-dd hh:mm:ss");   
}

// 对Date的扩展，将 Date 转化为指定格式的String
// 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
// 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
// 例子：
// (new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
// (new Date()).Format("yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18
Date.prototype.Format = function (fmt)
{
	var o=
	{
		"M+":this.getMonth()+1,//月份
		"d+":this.getDate(),//日
		"h+":this.getHours(),//小时
		"m+":this.getMinutes(),//分
		"s+":this.getSeconds(),//秒
		"q+":Math.floor((this.getMonth()+3)/3),//季度
		"S":this.getMilliseconds()//毫秒
	};
	if(/(y+)/.test(fmt))
	fmt=fmt.replace(RegExp.$1,(this.getFullYear()+"").substr(4-RegExp.$1.length));
	for(var k in o)
	if(new RegExp("("+k+")").test(fmt))
	fmt=fmt.replace(RegExp.$1,(RegExp.$1.length==1)?(o[k]):(("00"+o[k]).substr((""+o[k]).length)));
	return fmt;
}

/*************************************************
Function:		GetRTSPPort
Description:	获取RTSP端口
Input:			无
Output:			无
return:			无
*************************************************/
function GetRTSPPort()
{
	var iMapRtspPort = $.cookie('rtspport');
	if(iMapRtspPort != null) {
		m_lRtspPort = iMapRtspPort;
	} else {
		$.ajax({
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Streaming/channels",
			async: false,
			beforeSend: function(xhr) {
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			complete: function(xhr, textStatus)
			{
				if(xhr.status == 200)
				{
					var xmlDoc = xhr.responseXML;
					try
					{
						m_lRtspPort = xmlDoc.documentElement.getElementsByTagName('rtspPortNo')[0].childNodes[0].nodeValue;
					}
					catch (e)
					{
						m_lRtspPort = "554"; 
					}
				}
			}
		});
	}
	if(m_lHttp == "https://")
	{
		var szHttpPort = "80";
		//获取HTTP端口
		$.ajax(
		{
			type: "GET",
			url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Security/AAA/adminAccesses",
			async: false,
			timeout: 15000,
			beforeSend: function(xhr)
			{
				xhr.setRequestHeader("If-Modified-Since", "0");
				
			},
			success: function(xmlDoc, textStatus, xhr) 
			{
				if($(xmlDoc).find('id').eq(0).text() == "1")
				{
					szHttpPort = $(xmlDoc).find('portNo').eq(0).text();
				}
			}
		});
		HWP = null;
		HWP = new Plugin(1, m_szHostName, szHttpPort, m_lRtspPort);
	}
	else
	{
		HWP = null;
		HWP = new Plugin(1, m_szHostName, m_lHttpPort, m_lRtspPort);
	}
}
/*************************************************
Function:		GetRTSPPortDyn
Description:	获取RTSP端口
Input:			无
Output:			无
return:			无
*************************************************/
function GetRTSPPortDyn()
{
	$.ajax({
		type: "GET",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ContentMgmt/DynStreaming/channels",
		async: false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr) 
		{
			try
			{
				m_lRtspPort = xmlDoc.documentElement.getElementsByTagName('rtspPortNo')[0].childNodes[0].nodeValue;
			}
			catch (e)
			{
				m_lRtspPort = "554";
			}
		}
	});
}
/*************************************************
Function:		UpdateTips
Description:	更新提示
Input:			无
Output:			无
return:			无
*************************************************/
function UpdateTips()
{
	var bUpdateTips = $.cookie('updateTips');
	var szUpdate = '';
	if(bUpdateTips == 'true')
	{
		if(navigator.platform == "Win32")
		{
			szUpdate = getNodeValue('jsUpdatePlugin');
			Warning =confirm(szUpdate);
			if (Warning)
			{
				window.open("../../codebase/ITCPWebComponents.exe","_self");
			}
			else
			{
				$.cookie('updateTips', 'false');
			}
		}
		else
		{
			szUpdate = getNodeValue('jsUpdateNotWin32');
			setTimeout(function() {alert(szUpdate);},20);
			$.cookie('updateTips', 'false');
		}
	}
}
/*************************************************
Function:		isIPv6Add
Description:	校验是否为有效的IPV6地址
Input:			strInfo:IPV6地址
Output:			true:是 false:否
return:			无
*************************************************/
function  isIPv6Add(strInfo)
{
	  return /:/.test(strInfo) && strInfo.match(/:/g).length<8 && /::/.test(strInfo)?(strInfo.match(/::/g).length==1 && /^::$|^(::)?([\da-f]{1,4}(:|::))*[\da-f]{1,4}(:|::)?$/i.test(strInfo)):/^([\da-f]{1,4}:){7}[\da-f]{1,4}$/i.test(strInfo);
}
/*************************************************
Function:		insertOptions2Select
Description:	往select里插option
Input:			szCapabilitySet: 从设备获取的能力集
                szOptionalSet: 可选能力集
				szIds: 用来翻译的option的Id
				szSelectId: select的Id
Output:			true:是 false:否
return:			无
*************************************************/
function insertOptions2Select(szCapabilitySet, szOptionalSet, szOptionIds, szSelectId) {

    var szSelectObj = $("#"+szSelectId);
    if(!szSelectObj){
        return;
    }
    szSelectObj.empty();

	$.each(szCapabilitySet, function(i, szCapability) {
		var index = $.inArray(szCapability, szOptionalSet);
		if (index !== -1) {
			$("<option id='" + szOptionIds[index] + "' name='" + szOptionIds[index] + "' value='" + szCapability +"'></option>").appendTo("#" + szSelectId);
		}
		else {
			if (szOptionalSet[szOptionalSet.length - 1] === "*") {
				$("<option id='" + szOptionIds[szOptionalSet.length - 1] + "' name='" + szOptionIds[szOptionalSet.length - 1] + "' value='" + szCapability +"'></option>").appendTo("#" + szSelectId);
			}
		}
	});
}

/*************************************************
 Function:        addArtDialog
 Description:     添加对话框
 Input:           contents:对话框内容(支持dom元素)
 				  funConfirm:确认回调函
 				  otherOptions:其他属性
 Output:            无
 return:            无
 *************************************************/
function showArtDialog(contents, funConfirm, otherOptions) {
	//translator.getLanguageXmlDoc(["Main"]);
	//var diaLogOptions = {lock:true, okVal:translator.translateNode(parent.g_lxdMain, "laOK"), cancelVal:translator.translateNode(parent.g_lxdMain, "laCancel"), cancel:function(){return true;}, content:contents, ok:funConfirm};
	//var diaLogOptions = {lock:true, okVal:"确定", cancelVal:"关闭", cancel:function(){return true;}, content:contents, ok:funConfirm};
	var diaLogOptions = {lock:true, content:contents};
	for(var key in otherOptions) {
		diaLogOptions[key] = otherOptions[key];
	}
	$.dialog(diaLogOptions);
}

//日志输出
function _log(content){
	if(window.console && window.console.log){
		window.console.log(content);
	}
}
/*************************************************
  Function:    	CheckPasswordComplexity
  Description:	检查密码复杂度
  Input:        strPwd:传入的参数
  				tipsId:提示信息ID	
				strLimit:对strInfo进行限制的变量，可不传
  Output:      	无
  Return:		bool:true false
*************************************************/
function CheckPasswordComplexity(szPwd, szUser) {
	var iResult = 0;
	szPwd.match(/[a-z]/g) && iResult++;
	szPwd.match(/[A-Z]/g) && (iResult += iResult ? 2 : 1);
	szPwd.match(/[0-9]/g) && iResult++;
	szPwd.match(/[^a-zA-Z0-9]/g) && (iResult += iResult ? 2 : 1);
	if (szPwd.length < 8 || szPwd === szUser || szPwd === szUser.split("").reverse().join("")) {
		iResult = 0;
	}
	iResult && iResult--;
	iResult = iResult > 3 ? 3 : iResult;
	return iResult;
}

/*************************************************
 * Class webSession
 * @author chenxiangzhen
 * @created 2014-04-16
 * @version v1.0
 * @function 工具类，处理web session
 *************************************************/
function webSession () {
	this._bSupportSession = typeof sessionStorage === "object";
	if (!this._bSupportSession) {
		document.documentElement.addBehavior("#default#userdata");
	}
}
/*************************************************
 Function:        getItem
 Description:    获取相应属性值
 Input:          szAttr 属性名
 Output:        无
 return:        属性值
 *************************************************/
webSession.prototype.getItem = function (szAttr) {
	with (this) {
		if (_bSupportSession) {
			return sessionStorage.getItem(szAttr);
		} else {
			with(document.documentElement) {
				try{
					load(szAttr);
					return getAttribute("value");
				}catch (ex){
					return null;
				}
			}
		}
	}
}
/*************************************************
 Function:        setItem
 Description:    设置相应属性值
 Input:          szAttr 属性名, szVal 属性值
 Output:        无
 return:        属性值
 *************************************************/
webSession.prototype.setItem = function (szAttr, szVal) {
	with (this) {
		if (_bSupportSession) {
			return sessionStorage.setItem(szAttr, szVal);
		} else {
			with(document.documentElement) {
				try {
					load(szAttr);
					setAttribute("value", szVal);
					save(szAttr);
					return  getAttribute("value");
				}catch (ex){
					return  null;
				}
			}
		}
	}
}
/*************************************************
 Function:        removeItem
 Description:    删除相应属性值
 Input:          szAttr 属性名
 Output:        无
 return:        无
 *************************************************/
webSession.prototype.removeItem = function (szAttr) {
	with (this) {
		if (_bSupportSession) {
			sessionStorage.removeItem(szAttr);
		} else {
			with(document.documentElement) {
				try{
					load(szAttr);
					expires = new Date(630892799000).toUTCString();
					save(szAttr);
				}
				catch (ex){
				}
			}
		}
	}
}
g_oWebSession = new webSession();

/*************************************************
 Function:        getUNamePWD
 Description:    获取用户名和密码
 Input:          enCodeStr解密前的字符串
 Output:        无
 return:        arrNamePWD数组形式，第一个为用户名，第二个为密码(给出的用户名不带:)
 *************************************************/
webSession.prototype.getUNamePWD = function (enCodeStr) {
    var arrNamePWD = ['',''];
    if (enCodeStr) {
        var _szUsername = Base64.decode(enCodeStr);
        if (_szUsername.charAt(0) === ':') {  //判断是否是摘要认证（用户名是不允许带':'）
            _szUsername = _szUsername.substring(1);
        }
        var iIndex = _szUsername.indexOf(':');
        if (iIndex > 0) {
            arrNamePWD[0] = _szUsername.substring(0, iIndex);
            arrNamePWD[1] = _szUsername.substring(iIndex+1);
        }
    }
    return arrNamePWD;
}