var m_dtStartSearchDate = "";   //开始搜索时间
var m_dtStopSearchDate = "";    //结束搜索时间
var m_szPictureFormat = ".jpg";  //图片的扩展名

var m_szPictureDateSet = new Array();  //图片日期集合
var m_szPictureSizeSet = new Array();   //图片大小集合
var m_szPictureNameSet = new Array();   //图片名字集合
var m_szURISet = new Array();
var m_szTableFileName = new Array();   //单元格中回放文件名


var m_bDownloadPos = 0;      //判断是否已经开始下载
var m_iNowDown = 0;    //正在下载的文件序号
var ClockTime = 0;  //下载时钟	

var m_iCurPictureNumber = 0;  //搜索文件当前页记录数
var m_iHavePictureNumber = 0;  //搜索文件总数
var m_iHavePage = 0; //搜索记录共有几页
var m_iNowPage = 1; //搜索记录当前页
var m_iSearchTimes = 0;
var m_bFirst = true;     

var m_iSelectFile = -1;  //选中的文件序号
var m_iPerNum = 100; //下载文件的记录分页每页显示条数
var m_iDownloadID = -1;

var g_lxdDownload = null;
var g_transStack = null;
var g_iSeledLogTrObj = null; //记录之前选中的行对象
var m_iCurShowPicIndex = 0;
var m_PicPreviewOCX = null;
var m_iSearchId = "";
/*************************************************
Function:		InitPictureDownload
Description:	初始化图片下载
Input:			无			
Output:			无
return:			无				
*************************************************/
function InitPictureDownload()
{
	m_szUserPwdValue = g_oWebSession.getItem("userInfo"+m_lHttpPort);
	if(m_szUserPwdValue == null)
	{
		window.close();
		return;
	}
	window.parent.ChangeMenu(3);
	ChangeLanguage(parent.translator.szCurLanguage);
	var szInfo = translator.translateNode(g_lxdDownload, 'laPlugin');
	
	if(!checkPlugin('0', szInfo, 1, 'snapdraw'))
	{
		return;
	}
    g_transStack = new TransStack();
	m_PreviewOCX=document.getElementById("PreviewActiveX");
	m_PicPreviewOCX = document.getElementById("PicPreviewActiveX");
	
	GetNowTime();
}

/*************************************************
Function:		GetNowTime
Description:	获取当前日期
Input:			无			
Output:			无
return:			无				
*************************************************/
function GetNowTime()
{
	var myDate = new Date();
	var iYear = myDate.getFullYear();        
	var iMon = myDate.getMonth();      
	var iDay = myDate.getDate(); 
	iMon = parseInt(iMon)+1;
	if(iMon <= 9)
	{
		iMon = '0' + iMon;
	}
	var szNowTime = iYear + "-" +  iMon + "-" + iDay + " 00:00:00";
	document.getElementById("begintime").value = szNowTime;
	document.getElementById("endtime").value = iYear + "-" +  iMon + "-" + iDay + " 23:59:59";
}

/*************************************************
Function:		PictureSearch
Description:	图片搜索
Input:			iType:搜索类型,1:非首次搜索	
Output:			无
return:			无				
*************************************************/
function PictureSearch(iType)
{
	var dp = $('#picSearchBtnDiv').prop('disabled');
	if (dp && (iType != 1)) {
		return;
	}
	
	if(iType != 1) {
		m_iSearchId = new UUID();
	}
    $('#picSearchBtnDiv').prop('disabled', true);
	var xmlDoc = new createxmlDoc();
	var Instruction = xmlDoc.createProcessingInstruction("xml","version='1.0' encoding='utf-8'");
	xmlDoc.appendChild(Instruction);
		
	Root = xmlDoc.createElement('CMSearchDescription');
		
	searchID = xmlDoc.createElement('searchID');
	text = xmlDoc.createTextNode(m_iSearchId);
	searchID.appendChild(text);
	Root.appendChild(searchID);
		
	trackList = xmlDoc.createElement('trackIDList');
	track = xmlDoc.createElement('trackID');
	text = xmlDoc.createTextNode('120');
	track.appendChild(text);
	trackList.appendChild(track);
	Root.appendChild(trackList);
	var dtStartTime = "";
	var dtStopTime = "";

    szStarTime = document.getElementById("begintime").value;
   	szStopTime = document.getElementById("endtime").value;
	
	if(Date.parse(szStopTime.replace(/-/g,"/"))-Date.parse(szStarTime.replace(/-/g,"/")) < 0)
	{
		alert(translator.translateNode(g_lxdDownload, 'jsTimeSegmentErrorTips'));
		//return;
		$("#picSearchBtnDiv").prop("disabled",false);

		return;
	}
	
	szStarTime = szStarTime.replace(' ', 'T') + 'Z';
	szStopTime = szStopTime.replace(' ', 'T') + 'Z';
		
		
	timeSpanList = xmlDoc.createElement('timeSpanList');
	timeSpan = xmlDoc.createElement('timeSpan');
		
	startTime = xmlDoc.createElement('startTime');
	text = xmlDoc.createTextNode(szStarTime);
	startTime.appendChild(text);
	timeSpan.appendChild(startTime);
		
	endTime = xmlDoc.createElement('endTime');
	text = xmlDoc.createTextNode(szStopTime);
	endTime.appendChild(text);
	timeSpan.appendChild(endTime);
	
	LaneNumber = xmlDoc.createElement('laneNumber');
	text = xmlDoc.createTextNode($("#laneNumber").val());
	LaneNumber.appendChild(text);
	timeSpan.appendChild(LaneNumber);
	
	CarType = xmlDoc.createElement('carType');
	text = xmlDoc.createTextNode($("#carType").val());
	CarType.appendChild(text);
	timeSpan.appendChild(CarType);
	
	IllegalType = xmlDoc.createElement('illegalType');
	text = xmlDoc.createTextNode($("#illegalType").val());
	IllegalType.appendChild(text);
	timeSpan.appendChild(IllegalType);
	
	/*endTime = xmlDoc.createElement('endTime');
	text = xmlDoc.createTextNode(szStopTime);
	endTime.appendChild(text);
	timeSpan.appendChild(endTime);
	
	endTime = xmlDoc.createElement('endTime');
	text = xmlDoc.createTextNode(szStopTime);
	endTime.appendChild(text);
	timeSpan.appendChild(endTime);*/
	
	timeSpanList.appendChild(timeSpan);
	Root.appendChild(timeSpanList);
	
	contentTypeList =  xmlDoc.createElement('contentTypeList');
	
	contentType = xmlDoc.createElement('contentType');
	text =  xmlDoc.createTextNode("metadata");
	contentType.appendChild(text);
	contentTypeList.appendChild(contentType);
	Root.appendChild(contentTypeList);
		
	maxResults = xmlDoc.createElement('maxResults');
	text = xmlDoc.createTextNode("40");//暂定一次返回40条
	maxResults.appendChild(text);
	Root.appendChild(maxResults);
		
	searchResultsPosition = xmlDoc.createElement('searchResultPostion');
	text = xmlDoc.createTextNode('0');
	searchResultsPosition.appendChild(text);
	Root.appendChild(searchResultsPosition);
		
	metadataList = xmlDoc.createElement('metadataList');
	metadataDescriptor = xmlDoc.createElement('metadataDescriptor');
	text = xmlDoc.createTextNode("//recordType.meta.hikvision.com/"+$("#PictureType").val());
	metadataDescriptor.appendChild(text);
	metadataList.appendChild(metadataDescriptor);
	Root.appendChild(metadataList);
		
	xmlDoc.appendChild(Root);
	m_oSearchXml = xmlDoc;
	
	if(1 == iType)
	{
		m_oSearchXml.documentElement.getElementsByTagName('searchResultPostion')[0].childNodes[0].nodeValue = 40 * m_iSearchTimes;
		xmlDoc = m_oSearchXml;
	}else
	{
		m_szPictureDateSet.length = 0;
    	m_szPictureSizeSet.length = 0;
    	m_szPictureNameSet.length = 0;
    	m_szURISet.length = 0;	
		var iRowNum = document.getElementById("PictureTableList").rows.length;
		for(var i = 1; i < iRowNum; i++)
    	{
			document.getElementById("PictureTableList").deleteRow(1);
   	    }
		m_iHavePictureNumber = 0;
		m_bFirst = true;
	}
	
	$("#PicturePage").css("text-align", "left");
	$("#PicturePage").html(translator.translateNode(g_lxdDownload, 'SearchingTips'));
	
	$.ajax({
		type: "POST",
		url: m_lHttp+m_szHostName+":"+m_lHttpPort+"/PSIA/ContentMgmt/search/",
		async: true,
		timeout: 15000,
		processData: false,
		data: xmlDoc,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		complete: function(xhr, textStatus)
		{
			if(403 == xhr.status)
			{
				m_iSearchTimes = 0;
				m_oSearchXml = null;
                document.getElementById("PicturePage").innerHTML = translator.translateNode(g_lxdDownload, 'TotalTips') + "0" +  translator.translateNode(g_lxdDownload, 'TiaoTips') + "&nbsp;&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;'>" + translator.translateNode(g_lxdDownload, 'jsFirstPageTips') + "</span>&nbsp;&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;'>" + translator.translateNode(g_lxdDownload, 'jsPrevPageTips') + "</span>&nbsp;"+ "0/0" +"&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;'>" + translator.translateNode(g_lxdDownload, 'jsNextPageTips') + "</span>&nbsp;&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;'>" + translator.translateNode(g_lxdDownload, 'jsLastPageTips') + "</span>&nbsp;&nbsp;";
                $("#PicturePage").css("text-align", "right");
                alert(parent.translator.translateNode(g_lxdDownload, 'jsNoOperationRight'));
                $('#picSearchBtnDiv').prop('disabled', false);
			}
			else if(200 == xhr.status)
			{
				var xmlDoc = xhr.responseXML;
				var szResXml = xhr.responseText;
				
				if("MORE" == $(xmlDoc).find('responseStatusStrg').eq(0).text())
				{
					for(var i = 0; i < $(xmlDoc).find('searchMatchItem').length; i++)
					{
						var szPictureDate = $(xmlDoc).find('endTime').eq(i).text();
						m_szPictureDateSet.push((szPictureDate.replace('T', ' ')).replace('Z', ''));
						var szPlaybackURI = $(xmlDoc).find('playbackURI').eq(i).text();
						m_szURISet.push(szPlaybackURI);
						var szFileName = szPlaybackURI.substring(szPlaybackURI.indexOf("name=") + 5, szPlaybackURI.indexOf("&size="));
						var szFileSize = szPlaybackURI.substring(szPlaybackURI.indexOf("size=") + 5, szPlaybackURI.length);
						m_szPictureNameSet.push(szFileName);
						m_szPictureSizeSet.push(szFileSize);
					}
					m_iSearchTimes++;
					
					PictureSearch(1);
					
					if(m_bFirst && m_szPictureNameSet.length >= m_iPerNum)
					{
						m_iNowPage = 1 ;
                        m_iSelectFile = -1
						for(var m = 0 ; m < m_iPerNum ; m ++)
						{
							InsertPicture((m+1), m_szPictureNameSet[m], m_szPictureDateSet[m], m_szPictureSizeSet[m]); 
						}
						m_iCurPictureNumber = m_iPerNum; 
						m_bFirst = false;
					}
				}
				else if("OK" == $(xmlDoc).find('responseStatusStrg').eq(0).text())
				{
					m_iSearchTimes = 0;
					m_oSearchXml = null;
					for(var i = 0; i < $(xmlDoc).find('searchMatchItem').length; i++)
					{
						var szPictureDate = $(xmlDoc).find('endTime').eq(i).text();
						m_szPictureDateSet.push((szPictureDate.replace('T', ' ')).replace('Z', ''));
						var szPlaybackURI = $(xmlDoc).find('playbackURI').eq(i).text();
						m_szURISet.push(szPlaybackURI);
						var szFileName = szPlaybackURI.substring(szPlaybackURI.indexOf("name=") + 5, szPlaybackURI.indexOf("&size="));
						var szFileSize = szPlaybackURI.substring(szPlaybackURI.indexOf("size=") + 5, szPlaybackURI.length);
						m_szPictureNameSet.push(szFileName);
						m_szPictureSizeSet.push(szFileSize);
					}
					
					m_iHavePictureNumber = m_szPictureNameSet.length;
					
					if(m_iHavePictureNumber % m_iPerNum ==0 )
					{
						 m_iHavePage = parseInt(m_iHavePictureNumber/m_iPerNum);
					}
					else
					{ 
						 m_iHavePage = parseInt(m_iHavePictureNumber/m_iPerNum)+1;
					}
					
					if(m_bFirst)
					{
						m_iNowPage = 1 ;
                        m_iSelectFile = -1
						if(m_iHavePictureNumber > m_iPerNum)
						{
							for(var m = 0 ; m < m_iPerNum ; m ++)
							{
								InsertPicture((m+1), m_szPictureNameSet[m], m_szPictureDateSet[m], m_szPictureSizeSet[m]);  
							}
							m_iCurPictureNumber = m_iPerNum; 
						}
						else
						{
							for(var m = 0 ; m < m_iHavePictureNumber ; m ++)
							{
								InsertPicture((m+1), m_szPictureNameSet[m], m_szPictureDateSet[m], m_szPictureSizeSet[m]);  
							}
							m_iCurPictureNumber = m_iHavePictureNumber; 
						}
						m_bFirst = false;
					}
					
					if(m_szPictureNameSet.length > 0)
					{
						document.getElementById("PicturePage").innerHTML = translator.translateNode(g_lxdDownload, 'TotalTips') + m_iHavePictureNumber +  translator.translateNode(g_lxdDownload, 'TiaoTips') + "&nbsp;&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;' onClick='FirstPage()'>" + translator.translateNode(g_lxdDownload, 'jsFirstPageTips') + "</span>&nbsp;&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;' onClick='LastPage()'>" + translator.translateNode(g_lxdDownload, 'jsPrevPageTips') + "</span>&nbsp;"+ m_iNowPage+"/"+ m_iHavePage +"&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;' onClick='NextPage()'>" + translator.translateNode(g_lxdDownload, 'jsNextPageTips') + "</span>&nbsp;&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;' onClick='AfterPage()'>" + translator.translateNode(g_lxdDownload, 'jsLastPageTips') + "</span>&nbsp;&nbsp;";
					}else
					{
						document.getElementById("PicturePage").innerHTML = translator.translateNode(g_lxdDownload, 'TotalTips') + "0" +  translator.translateNode(g_lxdDownload, 'TiaoTips') + "&nbsp;&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;'>" + translator.translateNode(g_lxdDownload, 'jsFirstPageTips') + "</span>&nbsp;&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;'>" + translator.translateNode(g_lxdDownload, 'jsPrevPageTips') + "</span>&nbsp;"+ "0/0" +"&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;'>" + translator.translateNode(g_lxdDownload, 'jsNextPageTips') + "</span>&nbsp;&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;'>" + translator.translateNode(g_lxdDownload, 'jsLastPageTips') + "</span>&nbsp;&nbsp;";
					}
                    setTimeout( function () {
                        alert(parent.translator.translateNode(g_lxdDownload, 'szSearchPicTips1'));
                        $('#picSearchBtnDiv').prop('disabled', false);
                    }, 1);
					$("#PicturePage").css("text-align", "right");
					$('#divPictureSearchTips').html('');
				    $('#divPictureSearchTips').hide();
				}
				else if("NO MATCHES" == $(xmlDoc).find('responseStatusStrg').eq(0).text())
				{
					m_iSearchTimes = 0;
					m_oSearchXml = null;
					showTips("", translator.translateNode(g_lxdDownload, 'jsNoPictureTip'));
					document.getElementById("PicturePage").innerHTML = translator.translateNode(g_lxdDownload, 'TotalTips') + "0" +  translator.translateNode(g_lxdDownload, 'TiaoTips') + "&nbsp;&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;'>" + translator.translateNode(g_lxdDownload, 'jsFirstPageTips') + "</span>&nbsp;&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;'>" + translator.translateNode(g_lxdDownload, 'jsPrevPageTips') + "</span>&nbsp;"+ "0/0" +"&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;'>" + translator.translateNode(g_lxdDownload, 'jsNextPageTips') + "</span>&nbsp;&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;'>" + translator.translateNode(g_lxdDownload, 'jsLastPageTips') + "</span>&nbsp;&nbsp;";
				    $("#PicturePage").css("text-align", "right");

				    $('#picSearchBtnDiv').prop('disabled', false);
				}
			}else{
				document.getElementById("PicturePage").innerHTML = translator.translateNode(g_lxdDownload, 'TotalTips') + "0" +  translator.translateNode(g_lxdDownload, 'TiaoTips') + "&nbsp;&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;'>" + translator.translateNode(g_lxdDownload, 'jsFirstPageTips') + "</span>&nbsp;&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;'>" + translator.translateNode(g_lxdDownload, 'jsPrevPageTips') + "</span>&nbsp;"+ "0/0" +"&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;'>" + translator.translateNode(g_lxdDownload, 'jsNextPageTips') + "</span>&nbsp;&nbsp;<span style='cursor:pointer; border-bottom:1px solid #000;'>" + translator.translateNode(g_lxdDownload, 'jsLastPageTips') + "</span>&nbsp;&nbsp;";
				$("#PicturePage").css("text-align", "right");
				
				m_iSearchTimes = 0;
				m_oSearchXml = null;
                alert(parent.translator.translateNode(g_lxdDownload, 'szSearchPicTips3'));
				showTips('', translator.translateNode(g_lxdDownload, 'jsNoPictureTip'));

				$('#picSearchBtnDiv').prop('disabled', false);
				return ;
			}
		}
	});
}


/*************************************************
Function:		DeleteFile
Description:	删除List中的所有文件条目
Input:			无			
Output:			无
return:			无				
*************************************************/
function DeleteFile()
{
    if(m_iCurPictureNumber == 0)
	{
	    return;
    }
	for(var i = 0; i < m_iCurPictureNumber; i++)
    {
	    m_szTableFileName[i] = "";
	    document.getElementById("PictureTableList").deleteRow(1);
	}
}
/*************************************************
Function:		NextPage
Description:	List下一页
Input:			无			
Output:			无
return:			无				
*************************************************/
function NextPage()
{
	if(m_iNowPage == m_iHavePage  || m_bDownloadPos == 1)
	{
	 	return;
	}
	DeleteFile();
	m_iNowPage ++ ; 
	if(m_iNowPage == m_iHavePage)
	{
		m_iCurPictureNumber = m_iHavePictureNumber - m_iPerNum*(m_iNowPage - 1) ;
		for(var m = m_iPerNum*(m_iNowPage-1) ; m < m_iHavePictureNumber ; m ++)
		{
			InsertPicture((m+1), m_szPictureNameSet[m], m_szPictureDateSet[m], m_szPictureSizeSet[m]); 
		}
	}
	else
	{
		m_iCurPictureNumber = m_iPerNum ;
		for(var m = m_iPerNum*(m_iNowPage-1) ; m < m_iPerNum*m_iNowPage ; m ++)
		{
			InsertPicture((m+1), m_szPictureNameSet[m], m_szPictureDateSet[m], m_szPictureSizeSet[m]); 
		}
	}
	//m_iSelectFile = m_iPerNum*(m_iNowPage-1) + 1;
	m_iSelectFile = -1;
	document.getElementById("SelectAll").checked = false;
	document.getElementById("PicturePage").innerHTML =translator.translateNode(g_lxdDownload, "TotalTips") + m_iHavePictureNumber +translator.translateNode(g_lxdDownload, "TiaoTips")+"&nbsp;&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='FirstPage()'>"+translator.translateNode(g_lxdDownload, "jsFirstPageTips")+"</span>&nbsp;&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='LastPage()'>"+translator.translateNode(g_lxdDownload, "jsPrevPageTips")+"</span>&nbsp;"+ m_iNowPage+"/"+ m_iHavePage +"&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='NextPage()'>"+translator.translateNode(g_lxdDownload, "jsNextPageTips")+"</span>&nbsp;&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='AfterPage()'>"+translator.translateNode(g_lxdDownload, "jsLastPageTips")+"</span>&nbsp;&nbsp;";
}
/*************************************************
Function:		LastPage
Description:	List上一页
Input:			无			
Output:			无
return:			无				
*************************************************/
function LastPage()
{
	if(m_iNowPage == 1  || m_bDownloadPos == 1)
	{
		return ;
	}
	DeleteFile();
	m_iNowPage -- ; 
	for(var m = m_iPerNum*(m_iNowPage-1) ; m < m_iPerNum*m_iNowPage ; m ++)
	{
		InsertPicture((m+1), m_szPictureNameSet[m], m_szPictureDateSet[m], m_szPictureSizeSet[m]); 
	}
	m_iCurPictureNumber = m_iPerNum ;
	//m_iSelectFile = m_iPerNum*(m_iNowPage-1) + 1;
	m_iSelectFile = -1;
	document.getElementById("SelectAll").checked = false;
	document.getElementById("PicturePage").innerHTML =translator.translateNode(g_lxdDownload, "TotalTips") + m_iHavePictureNumber +translator.translateNode(g_lxdDownload, "TiaoTips")+"&nbsp;&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='FirstPage()'>"+translator.translateNode(g_lxdDownload, "jsFirstPageTips")+"</span>&nbsp;&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='LastPage()'>"+translator.translateNode(g_lxdDownload, "jsPrevPageTips")+"</span>&nbsp;"+ m_iNowPage+"/"+ m_iHavePage +"&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='NextPage()'>"+translator.translateNode(g_lxdDownload, "jsNextPageTips")+"</span>&nbsp;&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='AfterPage()'>"+translator.translateNode(g_lxdDownload, "jsLastPageTips")+"</span>&nbsp;&nbsp;";
}
/*************************************************
Function:		FirstPage
Description:	List首页
Input:			无			
Output:			无
return:			无				
*************************************************/
function FirstPage()
{
	if(1 == m_iNowPage  || 1 == m_bDownloadPos)
	{
		return ;
	}
	DeleteFile();
	m_iNowPage = 1 ; 
	for(var m = 0 ; m < m_iPerNum ; m ++)
	{
		InsertPicture((m+1), m_szPictureNameSet[m], m_szPictureDateSet[m], m_szPictureSizeSet[m]); 
	}
	m_iCurPictureNumber = m_iPerNum; 
	//m_iSelectFile = m_iPerNum*(m_iNowPage-1) + 1;
	m_iSelectFile = -1;
	document.getElementById("SelectAll").checked = false;
	document.getElementById("PicturePage").innerHTML =translator.translateNode(g_lxdDownload, "TotalTips") + m_iHavePictureNumber +translator.translateNode(g_lxdDownload, "TiaoTips")+"&nbsp;&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='FirstPage()'>"+translator.translateNode(g_lxdDownload, "jsFirstPageTips")+"</span>&nbsp;&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='LastPage()'>"+translator.translateNode(g_lxdDownload, "jsPrevPageTips")+"</span>&nbsp;"+ m_iNowPage+"/"+ m_iHavePage +"&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='NextPage()'>"+translator.translateNode(g_lxdDownload, "jsNextPageTips")+"</span>&nbsp;&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='AfterPage()'>"+translator.translateNode(g_lxdDownload, "jsLastPageTips")+"</span>&nbsp;&nbsp;";
}
/*************************************************
Function:		AfterPage
Description:	List末页
Input:			无			
Output:			无
return:			无				
*************************************************/
function AfterPage()
{
	if(m_iNowPage == m_iHavePage || 1 == m_bDownloadPos)
	{
		return ;
	}
	DeleteFile();
	m_iNowPage = m_iHavePage ; 
	for(var m = (m_iHavePage-1)*m_iPerNum ; m < m_iHavePictureNumber ; m ++)
	{
		InsertPicture((m+1), m_szPictureNameSet[m], m_szPictureDateSet[m], m_szPictureSizeSet[m]);  
	}
	m_iCurPictureNumber = m_iHavePictureNumber - (m_iHavePage-1)*m_iPerNum ;
	//m_iSelectFile = m_iPerNum*(m_iNowPage-1) + 1;
	m_iSelectFile = -1;
	document.getElementById("SelectAll").checked = false;
	document.getElementById("PicturePage").innerHTML =translator.translateNode(g_lxdDownload, "TotalTips") + m_iHavePictureNumber +translator.translateNode(g_lxdDownload, "TiaoTips")+"&nbsp;&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='FirstPage()'>"+translator.translateNode(g_lxdDownload, "jsFirstPageTips")+"</span>&nbsp;&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='LastPage()'>"+translator.translateNode(g_lxdDownload, "jsPrevPageTips")+"</span>&nbsp;"+ m_iNowPage+"/"+ m_iHavePage +"&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='NextPage()'>"+translator.translateNode(g_lxdDownload, "jsNextPageTips")+"</span>&nbsp;&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='AfterPage()'>"+translator.translateNode(g_lxdDownload, "jsLastPageTips")+"</span>&nbsp;&nbsp;";
}


/*************************************************
Function:		InsertPicture
Description:	插入图片条目信息到List中
Input:			iNo: 图片序号	
                strPictureName b : 图片名
				strPictureDate : 图片记录时间
				iPictureSize e : 图片大小			
Output:			无
return:			无				
*************************************************/
function InsertPicture(iNo, strPictureName, strPictureDate, iPictureSize)
{
	var iPictureSizeKB  = parseInt(iPictureSize/1024);
	var ObjTr;
	var ObjTd;
	ObjTr = document.getElementById("PictureTableList").insertRow(document.getElementById("PictureTableList").rows.length);
	ObjTr.style.height="20px";
	ObjTr.style.color="#39414A";
	ObjTr.style.cursor="pointer";
	ObjTr.align = "center"; 
	$(ObjTr).bind('click', {iIndex:iNo}, function(event)
	{
		var i = parseInt(event.data.iIndex)
	    SelectFile(i);
	});
	
	for(j = 0;j < document.getElementById("PictureTableList").rows[0].cells.length;j++) 
	{  
		ObjTd = ObjTr.insertCell(j); 
		ObjTd.style.color="#39414A"; 
		ObjTd.align = "center";  
		if((iNo%2)==0)
		{
			ObjTd.bgColor="#f6f6f6" ;
		}
		else
		{
			ObjTd.bgColor="#ebebeb" ;
		} 
		switch(j) 
		{
			case 0:
				ObjTd.innerHTML = "<div><input name='box"+iNo+"' id='box"+iNo+"' type='checkbox' value='0' onClick='CheckAll()'></div>";
				ObjTd.id = "PictureA"+iNo;
				ObjTd.width = "50px";
				break;
			case 1:
				ObjTd.innerHTML = iNo;
				ObjTd.id = "PictureB"+iNo;
				ObjTd.width = "50px";
				break;
			case 2:
				ObjTd.innerHTML = strPictureName;
				ObjTd.id = "PictureC"+strPictureName;
				ObjTd.width = "250px";
				break;				   
			case 3:	               
				ObjTd.innerHTML = strPictureDate;
				ObjTd.id = "PictureD"+iNo;
				ObjTd.width = "150px";
				break;		
			case 4:
			   if(iPictureSizeKB==0)
			   {
					ObjTd.innerHTML = "1 KB";
					ObjTd.id = "PictureE"+iNo;
					 ObjTd.width = "80px";
					break;
			   }
			   else
			   {
					ObjTd.innerHTML = iPictureSizeKB +" KB";
					ObjTd.id = "PictureE"+iNo;
					ObjTd.width = "80px";
					break;
			   }
			case 5:
			   ObjTd.innerHTML = '<img src="../images/log/pic-preview.png"/>';
			   $(ObjTd).bind('click', {iIndex:iNo}, function(event)
			   {
					var i = parseInt(event.data.iIndex)
					ShowPicture(i,0);
			   });
			   ObjTd.id = "Preview"+ iNo;
			   ObjTd.align = "center";
			   ObjTd.style.cursor = "pointer";
			   ObjTd.width = "50px";
			   break;
			case 6:
			   ObjTd.id = "downProcess"+iNo;  
			   ObjTd.width = "80px";
			   break;
			default:
			   break; 		
	   }
	}  
	m_szTableFileName[iNo-1] = strPictureName;
}

function reBuildPicTable(data){
	var arr = [
			'<div class="picleft"><div id="pic_plugin" class="picviewplugin"></div></div>',
        	'<div class="picright" id="dvTriggerParam">',

			'<table id="taDetailedInfo" border="0" cellspacing="0" cellpadding="0" class="detailedinfotable">',
			    '<tbody><tr>'+
                    '<td class="rowheader"><label name="laNamber">序号</label></td>',
                    '<td id="tdNamberValue" class="detailedinfotd"></td>',
                '</tr>',
                '<tr>',
                    '<td class="rowheader"><label name="laTime">时间</label></td>',
                    '<td id="tdTimeValue" class="detailedinfotd"></td>',
                '</tr>',
                '<tr>',
                    '<td class="rowheader"><label name="lalaneNumber">车道号</label></td>',
                    '<td id="tdlaneNumberValue" class="detailedinfotd"></td>',
                '</tr>',
                '<tr>',
                    '<td class="rowheader"><label name="laplateNumber">车牌号</label></td>',
                    '<td id="tdplateNumberValue" class="detailedinfotd" style="font-size: 14px; font-weight: 600; "></td>',
                '</tr>',
				'<tr>',
                    '<td class="rowheader"><label name="laplateColor">车牌颜色</label></td>',
                    '<td id="tdplateColorValue" class="detailedinfotd"></td>',
                '</tr>',
                '<tr>',
                    '<td class="rowheader"><label name="laillegalType">违章信息</label></td>',
                    '<td id="tdillegalTypeValue" class="detailedinfotd"></td>',
                '</tr>',
				'<tr>',
                    '<td class="rowheader"><label name="lacarType">车辆类型</label></td>',
                    '<td id="tdcarTypeValue" class="detailedinfotd"></td>',
                '</tr>',
                '<tr>',
                    '<td class="rowheader"><label name="laCarLogo">车标</label></td>',
                    '<td id="tdcarLogoValue" class="detailedinfotd"></td>',
                '</tr>'
          	];
                
    for (var i = 0; i < 7; i++) {
    	arr.push('<tr>' + 
            '<td class="rowheader">&nbsp;</td>'+
            '<td id="detailRow'+(i+1)+'" class="detailedinfotd"></td>'+
        '</tr>');
    };
       
    arr.push('</tbody></table></div><div class="clear"></div>');

    $('#showPicWrapper').html(arr.join(''));
}
/*************************************************
Function:		ShowPicture
Description:	显示图片
Input:			iIndex: 图片序号	
Output:			无
return:			无				
*************************************************/
function ShowPicture(iIndex, iType) {
	if(iType == 0) {
		reBuildPicTable();
		
		if (!g_bIsIE) {
			$("#pic_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='PicPreviewActiveX' width='100%' height='100%' name='PicPreviewActiveX' align='center' wndtype='1' playmode='snapdraw'>");
		} else {
		    $("#pic_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='PicPreviewActiveX' width='100%' height='100%' name='PicPreviewActiveX' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
		}
	}
	m_PicPreviewOCX = document.getElementById("PicPreviewActiveX");
	m_iCurShowPicIndex = iIndex;
	iIndex = parseInt(iIndex) - 1;
    $("#PictureShowDiv").modal( );
	//调用插件显示图片接口
	var szDownXml = '<?xml version="1.0"?><downloadRequest version="1.0" xmlns="http://urn:selfextension:psiaext-ver10-xsd"><playbackURI>rtsp://'+m_szHostName+'/Streaming/tracks/120?starttime='+m_szPictureDateSet[iIndex].replace(" ", "T")+'Z&amp;endtime='+m_szPictureDateSet[iIndex].replace(" ", "T")+'Z&amp;name='+m_szPictureNameSet[iIndex]+'&amp;size='+m_szPictureSizeSet[iIndex]+'</playbackURI></downloadRequest>';
    var iDownloadID = -1;
	try {
		iDownloadID = m_PicPreviewOCX.HWP_StartSnapPicDownLoad(m_lHttp+m_szHostName+":"+m_lHttpPort+"/PSIA/Custom/SelfExt/ContentMgmt/download", m_szUserPwdValue, m_szPictureNameSet[iIndex] + m_szPictureFormat, szDownXml, "viewpic");
        //将关闭按钮设置不可用
        $('#CloseBtn').prop('disabled', true);
	} catch(e) {
		iDownloadID = -1;
        $('#CloseBtn').prop('disabled', false);
	}
    if(iDownloadID == -1){
        // $("#pic_plugin").html("");
        // $.modal.impl.close();
        // alert(getNodeValue('jsPreviewFail'));
        return;
    }

	//获取图片详细信息
	$.ajax({
		type: "POST",
		url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/PictureInformation",
		async: false,
		data: szDownXml,
		processData: false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success: function(xmlDoc, textStatus, xhr){
			
            $("#tdNamberValue").html(iIndex+1);
			$("#tdTimeValue").html(m_szPictureDateSet[iIndex]);
			$("#tdlaneNumberValue").html($(xmlDoc).find("laneNumber").eq(0).text());
			$("#tdplateNumberValue").html($(xmlDoc).find("plateNumber").eq(0).text());
			$("#tdplateColorValue").html(getNodeValue($(xmlDoc).find("plateColor").eq(0).text()));
			if($(xmlDoc).find("plateColor").eq(0).text() == "blue") {
				$("#tdplateNumberValue").css("color", "#2662DF");
			} else if($(xmlDoc).find("plateColor").eq(0).text() == "green") {
				$("#tdplateNumberValue").css("color", "#00B050");
			} else if($(xmlDoc).find("plateColor").eq(0).text() == "yellow") {
				$("#tdplateNumberValue").css("color", "#ffff00");
			} else if($(xmlDoc).find("plateColor").eq(0).text() == "white") {
				$("#tdplateNumberValue").css("color", "#ffffff");
			} else {
				$("#tdplateNumberValue").css("color", "#000000");
			}
			$("#tdillegalTypeValue").html(getNodeValue($(xmlDoc).find("illegalType").eq(0).text()+"IllegalType"));
			$("#tdcarTypeValue").html(getNodeValue($(xmlDoc).find("carType").eq(0).text()+"CarType"));
			$("#tdcarLogoValue").html(getNodeValue($(xmlDoc).find("carLogo").eq(0).text()+"Logo"));
		}
	});
}
/*************************************************
Function:		ShowPrevPicture
Description:	显示前一张图片
Input:			无	
Output:			无
return:			无				
*************************************************/
function ShowPrevPicture() {
	if(m_iCurShowPicIndex == 1) {
		alert(getNodeValue("LoadImagePreFist"));
		return;
	}
	var iIndex = parseInt(m_iCurShowPicIndex) - 1;
	if(iIndex < (m_iNowPage-1)*m_iPerNum) {
		LastPage();
	}
	SelectFile(iIndex);
	ShowPicture(iIndex,1);
}
/*************************************************
Function:		ShowNextPicture
Description:	显示下一张图片
Input:			无
Output:			无
return:			无				
*************************************************/
function ShowNextPicture() {
	if(m_iCurShowPicIndex == m_iHavePictureNumber) {
		alert(getNodeValue("LoadImageFinish"));
		return;
	}
	var iIndex = parseInt(m_iCurShowPicIndex) + 1;
	
	if(iIndex > m_iNowPage*m_iPerNum) {
		NextPage();
	}
	SelectFile(iIndex);
	ShowPicture(iIndex,1);
}
/*************************************************
Function:		SelectFile
Description:	选中某个回放文件
Input:			无			
Output:			无
return:			无				
*************************************************/
function SelectFile(iIndex)
{
	if(1 == m_bDownloadPos){
       	return;
   	}
	if(m_iSelectFile == iIndex){
		return;
	}
	var oSelObj = document.getElementById("PictureTableList").rows[iIndex - (m_iNowPage-1)*m_iPerNum];
	for(j = 0;j < oSelObj.cells.length;j++)
    {
		oSelObj.cells[j].style.color = "#ffffff";
		oSelObj.cells[j].style.backgroundColor = "#762727";
	}
	if(m_iSelectFile != -1)
	{
		oSelObj = document.getElementById("PictureTableList").rows[m_iSelectFile - (m_iNowPage-1)*m_iPerNum];
		if(m_iSelectFile%2 == 0)
		{
			for(i = 0;i < oSelObj.cells.length;i++) 
			{
				oSelObj.cells[i].style.color = "#39414A";
				oSelObj.cells[i].style.backgroundColor = "#f6f6f6";
			}
		}
		else
		{
			for(i = 0;i < oSelObj.cells.length;i++) 
			{
				oSelObj.cells[i].style.color = "#39414A";
				oSelObj.cells[i].style.backgroundColor = "#ebebeb";
			}
		}
	}
	m_iSelectFile = iIndex;	
	m_szNewName = m_szTableFileName[i-1];
}
/*************************************************
Function:		CheckAll
Description:	勾选其中一个checkbox后判断是否已经全选
Input:			无			
Output:			无
return:			无				
*************************************************/
function CheckAll()
{
	var iHaveSelect = 0; //已经选中的checkbox数目
	for(var i=(m_iNowPage - 1)*m_iPerNum;i<((m_iNowPage - 1)*m_iPerNum + m_iCurPictureNumber);i++)
    { 
	   	if((document.getElementById("box"+(i+1)).checked) == true)
	   	{
			iHaveSelect ++;
	   	} 
   	}
	if(iHaveSelect == m_iCurPictureNumber)
	{
		document.getElementById("SelectAll").checked = true;
	}
	else
	{
		document.getElementById("SelectAll").checked = false;
	}
}

/*************************************************
Function:		SelectAllFile
Description:	选中所有回放文件
Input:			无			
Output:			无
return:			无				
*************************************************/
function SelectAllFile()
{
    var bAll = document.getElementById("SelectAll").checked;
	if(bAll)
	{	
	    for(var i=(m_iNowPage - 1)*m_iPerNum;i<((m_iNowPage - 1)*m_iPerNum + m_iCurPictureNumber); i++)
    	{  
        	document.getElementById("box"+(i+1)).checked = true;
    	}
	}
	else
	{
	    for(var i=(m_iNowPage - 1)*m_iPerNum;i<((m_iNowPage - 1)*m_iPerNum + m_iCurPictureNumber); i++)
    	{  
        	document.getElementById("box"+(i+1)).checked = false;
    	}
	}
}

/*************************************************
Function:		PictureDownload
Description:	图片下载
Input:			无			
Output:			无
return:			无				
*************************************************/
function PictureDownload()
{
	Tips1 = translator.translateNode(g_lxdDownload, "jsTips1");
	Tips2 = translator.translateNode(g_lxdDownload, "jsTips2");
	var iSelectFile = 0; //是否有选中文件
	var iFailNum = 0;    //文件下载失败的数量
//    var iCount = 0;  //记录下载失败次数
	if(m_iDownloadID != -1)
	{
		Warning=confirm(Tips1);
		if(Warning)
		{
			if(0 == m_PreviewOCX.HWP_StopDownload(m_iDownloadID))
			{
				m_iDownloadID = -1;
				for(var k = (m_iNowPage - 1)*m_iPerNum; k< ((m_iNowPage - 1)*m_iPerNum + m_iCurPictureNumber);k++)
				{ 
					document.getElementById("box"+(k+1)).disabled="";
				}
				document.getElementById("SelectAll").disabled="";
				clearInterval(ClockTime);
				$("#laExportPicList").html(translator.translateNode(g_lxdDownload, "laExportPicList"));
			}
			return ;
		}
		else
		{
			return;
		}
	} else {
		for(var i = 0; i < m_iCurPictureNumber; i++) {  //清除前次下载的下载进度
	        $("#downProcess"+ (i + 1)).html("");
	    }
	}
	for(var i=(m_iNowPage - 1)*m_iPerNum;i<((m_iNowPage - 1)*m_iPerNum + m_iCurPictureNumber);i++)
	{ 
		if((document.getElementById("box"+(i+1)).checked) == true)
		{
			m_iNowDown = i;
			var szDownXml = '<?xml version="1.0"?><downloadRequest version="1.0" xmlns="http://urn:selfextension:psiaext-ver10-xsd"><playbackURI>rtsp://'+m_szHostName+'/Streaming/tracks/120?starttime='+m_szPictureDateSet[m_iNowDown].replace(" ", "T")+'Z&amp;endtime='+m_szPictureDateSet[m_iNowDown].replace(" ", "T")+'Z&amp;name='+m_szPictureNameSet[m_iNowDown]+'&amp;size='+m_szPictureSizeSet[m_iNowDown]+'</playbackURI></downloadRequest>'
 
 			try
			{
				m_iDownloadID = m_PreviewOCX.HWP_StartDownloadEx(m_lHttp+m_szHostName+":"+m_lHttpPort+"/PSIA/Custom/SelfExt/ContentMgmt/download", m_szUserPwdValue, m_szPictureNameSet[m_iNowDown] + m_szPictureFormat, szDownXml, "snapmachine");
			}catch(e)
			{
				m_iDownloadID = -1;
			}
			
			if(m_iDownloadID < 0)
			{
				var iErrorValue =  m_PreviewOCX.HWP_GetLastError();
				iSelectFile++;
				iFailNum++;

                if(33 == iErrorValue){ //磁盘满，无法导出.
                    alert(getNodeValue('jsDaskFull'));
                    $("#laExportPicList").html(translator.translateNode(g_lxdDownload, "laExportPicList"));
                    break;
                }
				if(34 == iErrorValue)
				{ // 多浏览器待测，wuyang
					var cbFunc = function() { $("#downProcess"+(arguments.callee.i+1)).html(translator.translateNode(g_lxdDownload, "Downloaded")); };
					cbFunc.i = i;
					g_transStack.push(cbFunc, true);
				}
                if(16 == iErrorValue){ //网络中断，参数返回.
                    alert(getNodeValue("jsNetShutDown"));
                    break;
                }
				else
				{
					var cbFunc = function() { $("#downProcess"+(arguments.callee.i+1)).html(translator.translateNode(g_lxdDownload, "jsDownloadFailed")); };
					cbFunc.i = i;
					g_transStack.push(cbFunc, true);
				}
				continue;
			}   
			//DownTiao();
			if(ClockTime)
			{
				clearInterval(ClockTime);
				ClockTime = 0;
			}
			ClockTime = setInterval("DownProcess()", 1000);
			iSelectFile++;
			//alert(m_szTableFileName[i])
			$("#laExportPicList").html(translator.translateNode(g_lxdDownload, "laStopExportPic"));
			break ;
		} 
	}
	if(iSelectFile == 0)
	{
		alert(Tips2);
		return ;
	}
	if(iSelectFile == iFailNum)
	{
		return;
	}
	for(var j=(m_iNowPage - 1)*m_iPerNum;j<((m_iNowPage - 1)*m_iPerNum + m_iCurPictureNumber);j++)
	{ 
		document.getElementById("box"+(j+1)).disabled="disabled";
	}
	document.getElementById("SelectAll").disabled="disabled";
}

/*************************************************
Function:		DownProcess
Description:	下载进度
Input:			无			
Output:			无
return:			无				
*************************************************/
function DownProcess()
{
	if(m_iDownloadID < 0)
	{
		return;
	}
	var szAreaNameInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
	var iStatus = m_PreviewOCX.HWP_GetDownloadStatus(m_iDownloadID);
	if(0 == iStatus)
	{
		var iProcess = m_PreviewOCX.HWP_GetDownloadProgress(m_iDownloadID);
		if(iProcess < 0)
		{
			clearInterval(ClockTime);
			ClockTime = 0;
			//alert(translator.translateNode(g_lxdDownload, 'tipsGetProgress'));
			return;
		}
		else if(iProcess < 100)
		{
			$("#downProcess"+(m_iNowDown+1)).html(iProcess + "%");
			/*$("#upgradeProcess").width(parseInt(iProcess * $("#ServerUping").width() / 100));*/
		}
		else
		{
			$("#downProcess"+(m_iNowDown+1)).html(translator.translateNode(g_lxdDownload, "Downloaded"));
			m_PreviewOCX.HWP_StopDownload(m_iDownloadID);
			m_iDownloadID = -1;
			clearInterval(ClockTime);
			ClockTime = 0;
			$("#DownloadBtn").val(translator.translateNode(g_lxdDownload, "DownloadBtn"));
			for(var i=m_iNowDown+1;i<((m_iNowPage - 1)*m_iPerNum + m_iCurPictureNumber);i++)
			{ 
				if((document.getElementById("box"+(i+1)).checked) == true)
				{
					m_iNowDown = i;
					var szDownXml = '<?xml version="1.0"?><downloadRequest version="1.0" xmlns="http://urn:selfextension:psiaext-ver10-xsd"><playbackURI>rtsp://'+m_szHostName+'/Streaming/tracks/120?starttime='+m_szPictureDateSet[m_iNowDown].replace(" ", "T")+'Z&amp;endtime='+m_szPictureDateSet[m_iNowDown].replace(" ", "T")+'Z&amp;name='+m_szPictureNameSet[m_iNowDown]+'&amp;size='+m_szPictureSizeSet[m_iNowDown]+'</playbackURI></downloadRequest>'
		 
					m_iDownloadID = m_PreviewOCX.HWP_StartDownloadEx(m_lHttp+m_szHostName+":"+m_lHttpPort+"/PSIA/Custom/SelfExt/ContentMgmt/download", m_szUserPwdValue, m_szPictureNameSet[m_iNowDown] + m_szPictureFormat , szDownXml, "snapmachine");
					
					if(m_iDownloadID < 0)
					{
						var iErrorValue =  m_PreviewOCX.HWP_GetLastError();
                        if(33 == iErrorValue){ //磁盘满，无法导出.
                            $("#laExportPicList").html(translator.translateNode(g_lxdDownload, "laExportPicList"));
                            var cbFunc = function(){ $("#downProcess"+(arguments.callee.i+1)).html(''); };
                            cbFunc.i = i;
                            g_transStack.push(cbFunc, true);
                            alert(getNodeValue('jsDaskFull'));
                            break;
                        }
                        if(34 == iErrorValue)
                        { // 多浏览器待测，wuyang
                            var cbFunc = function() { $("#downProcess"+(arguments.callee.i+1)).html(translator.translateNode(g_lxdDownload, "Downloaded")); };
                            cbFunc.i = i;
                            g_transStack.push(cbFunc, true);
                        }if(16 == iErrorValue){ //网络中断，参数返回.
                            alert(getNodeValue("jsNetShutDown"));
                            break;
                        }
						else
						{
							var cbFunc = function() { $("#downProcess"+(arguments.callee.i+1)).html(translator.translateNode(g_lxdDownload, "jsDownloadFailed")); };
							cbFunc.i = i;
							g_transStack.push(cbFunc, true);
						}
						continue;
					}   
					if(ClockTime)
					{
						clearInterval(ClockTime);
						ClockTime = 0;
					}
					ClockTime = setInterval("DownProcess()", 1000);
					$("#laExportPicList").html(translator.translateNode(g_lxdDownload, "laStopExportPic"));
					return;
				} 
			}
			for(var j=(m_iNowPage - 1)*m_iPerNum;j<((m_iNowPage - 1)*m_iPerNum + m_iCurPictureNumber); j++)
    		{ 
	   			document.getElementById("box"+(j+1)).disabled="";
			}
			document.getElementById("SelectAll").disabled="";
			$("#laExportPicList").html(translator.translateNode(g_lxdDownload, "laExportPicList"));
		}
	}
	else
	{
		clearInterval(ClockTime);
		m_PreviewOCX.HWP_StopDownload(m_iDownloadID);
		m_iDownloadID = -1;
		$("#downProcess"+(m_iNowDown+1)).html(translator.translateNode(g_lxdDownload, "jsDownloadFailed"));
		//alert(translator.translateNode(g_lxdDownload, 'tipsGetStatus'));
		for(var j=(m_iNowPage - 1)*m_iPerNum;j<((m_iNowPage - 1)*m_iPerNum + m_iCurPictureNumber); j++)
		{ 
			document.getElementById("box"+(j+1)).disabled="";
		}
		document.getElementById("all").disabled="";
		$("#laExportPicList").html(translator.translateNode(g_lxdDownload, "laExportPicList"));
		return;
	}
}

/*************************************************
Function:		showTips
Description:	显示提示语
Input:			title:标题
				strTips: 提示语
Output:			无
return:			无
*************************************************/
var g_iShowTipsTimer;
function showTips(title, strTips)
{
//    alert(parent.translator.translateNode(g_lxdDownload, 'szSearchPicTips1'));
    $('#picSearchBtnDiv').prop('disabled', false);
	$('#laPictureSearchTips').html(strTips);
	$('#divPictureSearchTips').show();
	clearTimeout(g_iShowTipsTimer);
	g_iShowTipsTimer = setTimeout(function()
			   {
				   $('#laPictureSearchTips').html('');
				   $('#divPictureSearchTips').hide(); 
			   },  5000);
}

/*************************************************
Function:		ChangeLan
Description:	改变页面语言
Input:			无
Output:			无
return:			无
*************************************************/
function ChangeLanguage(lan)
{
	g_lxdDownload = parent.translator.getLanguageXmlDoc("Download", lan);
	parent.translator.appendLanguageXmlDoc(g_lxdDownload, parent.g_lxdMain);
	parent.translator.translatePage(g_lxdDownload, document);
	
	window.parent.document.title = parent.translator.translateNode(g_lxdDownload, 'picturetitle');
	m_szExit = parent.translator.translateNode(g_lxdDownload, 'exit');
	
	if(m_iHavePictureNumber > 0) {
		document.getElementById("PicturePage").innerHTML = parent.translator.translateNode(g_lxdDownload, "TotalTips") + m_iHavePictureNumber + parent.translator.translateNode(g_lxdDownload, "TiaoTips")+"&nbsp;&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='FirstPage()'>"+ parent.translator.translateNode(g_lxdDownload, "jsFirstPageTips")+"</span>&nbsp;&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='LastPage()'>"+ parent.translator.translateNode(g_lxdDownload, "jsPrevPageTips")+"</span>&nbsp;"+ m_iNowPage+"/"+ m_iHavePage +"&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='NextPage()'>"+ parent.translator.translateNode(g_lxdDownload, "jsNextPageTips")+"</span>&nbsp;&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' onClick='AfterPage()'>"+ parent.translator.translateNode(g_lxdDownload, "jsLastPageTips")+"</span>&nbsp;&nbsp;";
	} else {
		document.getElementById("PicturePage").innerHTML = parent.translator.translateNode(g_lxdDownload,'TotalTips') + "0" + parent.translator.translateNode(g_lxdDownload,'TiaoTips') + "&nbsp;&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' >" + parent.translator.translateNode(g_lxdDownload,'jsFirstPageTips') + "</span>&nbsp;&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' >" + getNodeValue('jsPrevPageTips') + "</span>&nbsp;"+ "0/0" +"&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;'  >" + parent.translator.translateNode(g_lxdDownload,'jsNextPageTips') + "</span>&nbsp;&nbsp;<span style='cursor:pointer;border-bottom:1px solid #000;' >" + parent.translator.translateNode(g_lxdDownload,'jsLastPageTips') + "</span>&nbsp;&nbsp;";
	}
	if($('#divPictureSearchTips').css('display') != 'none') {
	    g_transStack.translate();
	}
	if(m_iDownloadID == -1) {
		$("#DownloadBtn").val(parent.translator.translateNode(g_lxdDownload, "DownloadBtn"));
	} else {
		$("#DownloadBtn").val(parent.translator.translateNode(g_lxdDownload, "stop"));
	}
}
/*************************************************
Function:		PluginEventHandler
Description:	图片回放事件响应
Input:			iEventType 事件类型, iParam1 参数1, iParam2 保留
Output:			无
return:			无
*************************************************/
function PluginEventHandler(iEventType, iParam1, iParam2) {
	if(66 == iEventType) {
		if(0 == iParam1){
			//调用插件显示图片接口
			var iRet = m_PicPreviewOCX.HWP_SnapLoadImage("Snaptest.jgp");
			if(iRet == -1) {
				alert(getNodeValue("LoadImageFailed"));
			}
		} else {
			alert(getNodeValue("jsDownloadFailed"));	
		}
		$('#CloseBtn').prop('disabled', false);
	}
    if(21 == iEventType) { //磁盘已满[默认小于等于1G时]  这里处理，停止图片下载

        m_PreviewOCX.HWP_StopDownload(m_iDownloadID);
    }
}
function CloseShowPicture() {
    $("#pic_plugin").html("");
    $('#taDetailedInfo').html('');
	$.modal.impl.close();

}