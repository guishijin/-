var m_bSupportIPC = true;
var m_bSupportZerochan = true;
var m_bSupportHoliday = true;                   //是否支持假日配置
var m_bSupportDisk = true;
var m_bIsSupportFrontPara = true;
var m_bSupportRecord = true;
var g_bSupportSNMP = false;
var g_bSupportQoS = false;
var g_bSupport8021x = false;
var g_bSupportCapturePlan = false;
var g_bSupportWIFI = false;       //是否支持WIFI
var g_bSupportTeleCtrl = false;   //是否支持遥控器
var g_bSupportWLS = false;        //是否支持无线门磁
var g_bSupportPIR = false;        //是否支持PIR
var g_bSupport485 = false;      //是否支持485
var g_bSupport232 = false;      //是否支持232
var g_bSupportCH = false;       //是否支持呼救报警
var g_bSupportDDNS = false;
var g_bSupportPPPOE = false;
var g_bSupportSyncPower = false;
var g_bSupport28181 = false;  //是否支持28181
var g_oCurrentTab = null;
var g_oMenu = null; // 菜单对象
var syncTime = 15000;

//2014.12.10 yqw 新添加能力集控制 begin 
var g_bSupportTrafficParam=null;
var g_bSupportFTP=null;
var g_bSupportCloudStorage=null;
var g_bSupportITCPicOSD=null;
var g_bSupportITCMergePicOSD=null;
var g_bSupportImageMerge=null;
var g_bSupportLightCorrect=null;
var g_bSupportcapResInfo=null;
var g_bSupportIlleagalDictionary=null;
//end

var g_bGetSysCab = false; //是否已经获取系统设置的能力
var g_bGetNetCab = false; //是否已经获取网络参数的能力
var g_bGetEventCab = false; //是否已经获取事件的能力
var g_bSupportEntrance = false;  //是否支持ITC出入口，包含黑白名单
var g_bSupportEhome=false;//是否已经获得Ehome协议的能力
var g_bSupportGPS=false;//是否已经获取支持GPS功能的能力
var g_bSupportOtherParam=false;

// 此对象用来优化基本设置与高级设置菜单之间切换的速度
// 还需进一步测试，wuyang
var g_menuRecorder = {
	szCurMenu: "LocalConfig",
	szCurMainMenu: null,
	szLastMenu: null,
	szLastMainMenu: null
}

var g_lxdParamConfig = null; // ParamConfig.xml

$.ajaxSetup({timeout: 15000});  //默认超时时间为15秒

function autoResizeIframe()
{
//     if($("#EditAreaContent").height() > 569)
//     {
//         setTimeout(function() {
//             var iHeight = $("#EditAreaContent").height();
//             window.parent.document.getElementById('content').style.height = iHeight + 86 + "px";
//             window.parent.document.getElementById('contentframe').style.height = iHeight + 50 + "px";
//             $("#menu").height(iHeight);
//         }, 50);
//     }
//     else
//     {
//         window.parent.document.getElementById('content').style.height = 655 + "px";
//         window.parent.document.getElementById('contentframe').style.height =  619 + "px";
//         $("#menu").height(569);
//     }
}

/*************************************************
 Function:		autoCountAllDivHeight
 Description:	自动计算主显示区所有div的高度并赋值。
 Input:			divHeights 所有div高度，为字符串或数组, example : ['#a','.b']; "#a".
 Output:		无。
 return:	    无
 *************************************************/
function autoCountAllDivHeight(divArrs)
{
    var heights = 0;
    $.each(divArrs, function(i,divArr){
        heights += $(divArr).height();
    });
    $("#EditAreaContent").height(heights + 30);
}


/*************************************************
Function:		InitInterConfigface
Description:	初始化配置页面
Input:			无
				无
Output:			无
return:			无				
*************************************************/
function InitInterConfigface()
{
	//记录菜单cookie置为空
	$.cookie('page',null);
	m_strIp = m_szHostName;
	
	m_szUserPwdValue = g_oWebSession.getItem("userInfo"+m_lHttpPort);
	if(m_szUserPwdValue == null)
	{
		window.parent.location.href="login.asp";
		return;
	}
	m_strUserName = Base64.decode(m_szUserPwdValue).split(":")[0];
	m_strPassword = Base64.decode(m_szUserPwdValue).split(":")[1];
	
	window.parent.document.getElementById("curruser").innerHTML = m_strUserName;
	window.parent.document.getElementById("curruser").title = m_strUserName;

    if(!parent.g_bIsSupportCustomInterface){  //自定义接口显示判断，根据能力集判断.
        document.getElementById('aCustomInterface').style.display = 'none';
    }

	//选中菜单
	window.parent.ChangeMenu(5);
	
	GetRTSPPort();
	GetNetworkVersion();    //获取设备支持的协议版本
	
	//合并语言资源
	ChangeLanguage(parent.translator.szCurLanguage, false);
	
	isSupportSyncPower();
	//无线报警和PIR报警
	if(!window.parent.g_bIsIPDome)
	{
		isSupportWLSensors();
		isSupportPIR();
		isSupportCallHelp();
	}

	//初始化菜单树
	g_oMenu = $("#menu").Menu({defaultCur : "2_0"});
}
/*************************************************
  Function:    	showmenuconfig
  Description:	树中节点选择并跳转不同页面
  Input:        szMenu:子菜单名
  				iMode:0获取 1设置
  				szMainMenu:主菜单名
  Output:      	无
  Return:		无
*************************************************/
function showmenuconfig(szMenu, iMode, szMainMenu)
{
	if (iMode == 0)
	{
		g_menuRecorder.szCurMenu = szMenu;
		g_menuRecorder.szCurMainMenu = szMainMenu;
		if(g_menuRecorder.szLastMenu !== szMenu) {
			HWP.Stop(0);
		}
        $("#spanCommendParam").hide();

        $('#contentright2').hide();
		$('#contentright').show();
	
		$('#SaveConfigBtn').show();

		// setTimeout(function(){
		// 	$("#SaveConfigBtn").show();
		// }, 1000);

		$('#SetResultTips').html('');
		
		ia(VideoParam).setUninited();  // 避免快速切换页面的时候，图像参数保存的问题。
	}

	switch ((iMode == 0) ? (szMenu + ":get") : (g_menuRecorder.szCurMenu + ":set"))
	{
		case "DeviceStatus:get":
		{
			if (g_menuRecorder.szLastMenu === szMenu) {
				g_menuRecorder.szLastMainMenu = szMainMenu;
				return;
			}
			HWP.destory();
			$.ajax({
				url: "params/DeviceStatus.asp",
				type: "GET",
				dataType: "html",
				error: function() {
					showmenuconfig(szMenu, iMode, szMainMenu);
				},
				success: function(msg) {
					$("#EditAreaContent").html(msg);
					g_oCurrentTab = $(".tabs").tabs(".pane", {markCurrent: false});
					g_menuRecorder.szLastMenu = szMenu;
					g_menuRecorder.szLastMainMenu = szMainMenu;
				}
			});
			break;
		}
		case "LocalConfig:get":
		{
			if (g_menuRecorder.szLastMenu === szMenu) {
				g_menuRecorder.szLastMainMenu = szMainMenu;
				return;
			}
			HWP.destory();
			$.ajax({
				url: "params/LocalConfig.asp",
				type: "GET",
				dataType: "html",
				error: function() {
					showmenuconfig(szMenu, iMode, szMainMenu);
				},
				success: function(msg) {
					$("#EditAreaContent").html(msg);
					g_oCurrentTab = $(".tabs").tabs(".pane", {markCurrent: false});
					pr(LocalConfig).initCSS();
					g_menuRecorder.szLastMenu = szMenu;
					g_menuRecorder.szLastMainMenu = szMainMenu;
				}
			});
			break;
		}
		case "LocalConfig:set":
		{
			ia(LocalConfig).submit();
			break;
		}
        case "SystemMaintain:get":
        {
            if (g_menuRecorder.szLastMenu === szMenu)
            {
                g_menuRecorder.szLastMainMenu = szMainMenu;
                return;
            }
            HWP.destory();
            $.ajax({
                url: "params/DeviceMaintain.asp",
                type: "GET",
                dataType: "html",
                error: function() {
                    showmenuconfig(szMenu, iMode, szMainMenu);
                },
                success: function(msg) {
                    $("#EditAreaContent").html(msg);

                    pr(Maintain).initCSS();

                    g_oCurrentTab = $("#tabSystemMaintain").tabs(".pane",{remember : false});

                    System.tabs = g_oCurrentTab;
                    g_menuRecorder.szLastMenu = szMenu;
                    g_menuRecorder.szLastMainMenu = szMainMenu;
                }
            });
            break;
        }
        case "CustomInterface:get":
        {
            if (g_menuRecorder.szLastMenu === szMenu)
            {
                g_menuRecorder.szLastMainMenu = szMainMenu;
                return;
            }
            HWP.destory();
            $.ajax({
                url: "params/CustomInterface.asp",
                type: "GET",
                dataType: "html",
                error: function() {
                    showmenuconfig(szMenu, iMode, szMainMenu);
                },
                success: function(msg) {
                    $("#EditAreaContent").html(msg);

                    g_oCurrentTab = $("#tabCustomInterfaceSystem").tabs(".pane",{remember : false});

                    System.tabs = g_oCurrentTab;
                    g_menuRecorder.szLastMenu = szMenu;
                    g_menuRecorder.szLastMainMenu = szMainMenu;
                }
            });
            break;
        }
        case "CustomInterface:set":{
            ia(TransparentChannel).submit();
            break;
        }
		case "System:get":
		{
			if (g_menuRecorder.szLastMenu === szMenu)
			{
				g_oCurrentTab.showTabs(1);
				g_menuRecorder.szLastMainMenu = szMainMenu;
				return;
			}
			HWP.destory();
			$.ajax({
				url: "params/System.asp",
				type: "GET",
				dataType: "html",
				error: function() {
					showmenuconfig(szMenu, iMode, szMainMenu);
				},
				success: function(msg) {
					$("#EditAreaContent").html(msg);
					if(!g_bGetSysCab)//获取系统设置能力
					{
						g_bGetSysCab = true;
						if(!window.parent.g_bIsIPDome)
						{
							isSupportTeleCtrl();
						}
						isSupport232And485();
						isSupportDDNS();
						isSupport28181();
						isSupportEhome();
						isSupportTrafficParam();
						isSupportcapIllegalDictionary();
					}
					pr(DeviceInfo).initCSS();
					pr(SnapSetup).initCSS();
					pr(SnapSetup).initSlider();
					pr(TimeSettings).initCSS();
					pr(Maintain).initCSS();
					g_oCurrentTab = $("#tabSystem").tabs(".pane",{remember : false});

                    if(!parent.g_bIsSupportDoubleNetwork){
                        g_oCurrentTab.hideTab(3);
                    }else{
                        g_oCurrentTab.hideTab(4);
                    }
					if (!g_bSupport28181) {
						g_oCurrentTab.hideTab(9);
					}
					if(!g_bSupportDDNS)
					{
						g_oCurrentTab.hideTab(6);
					} else {
						g_oCurrentTab.showTab(6);
					}
					if(!g_bSupportEhome){
						g_oCurrentTab.hideTab(11);
					}
					if(!g_bSupportTrafficParam){
						g_oCurrentTab.hideTab(8);
					}
					if(!g_bSupportIlleagalDictionary){
						g_oCurrentTab.hideTab(12);
					}
					System.tabs = g_oCurrentTab;
					g_menuRecorder.szLastMenu = szMenu;
					g_menuRecorder.szLastMainMenu = szMainMenu;
				}
			});
			break;
		}
		case "System:set":
		{
			switch (g_oCurrentTab.curTab)
			{
				case 0:
					ia(DeviceInfo).submit();
					break;
				case 1: //架设参数
					ia(SnapSetup).submit();
					break;
				case 2: // 串口参数
					ia(PortParam).submit();
					break;
				case 3: //网口参数
				 	ia(NetworkParam).submit();
					break;
                case 4: //单网口参数(TCP/IP)
                    SetNetBasicInfo();
                    break;
                case 5: //端口(Port)
                    setPortInfo();
                    break;
				case 6:
					SetDDNSInfo();
					break;
				case 7:// 时间设置
					ia(TimeSettings).submit();
					break;
                case 8:// 交通采集参数
                    ia(TrafficParam).submit();
                    break;
				case 9:
					ia(Cfg28181).SetCfg28181();
					break;
				case 10:
					ia(Service).submit();
					break;
				case 11:
					ia(EHOME).submit();
					break;
				case 12:
					ia(IllegalDictionary).submit();
					break;
				default:
					break;
			}
			
			break;
		}
		case "Network:get":
		{
			if (g_menuRecorder.szLastMenu === szMenu) {
				if (szMainMenu === "BaseConfig") 
				{
					Network.tabs.hideTabs([2, 3, 4, 5, 6, 7, 8]);
				} 
				else 
				{
					if(g_bSupportDDNS)
					{
						Network.tabs.showTab(2);
					}
					if(g_bSupportPPPOE)
					{
						Network.tabs.showTab(3);
					}
					
					if(g_bSupportSNMP)
					{
						Network.tabs.showTab(4);
					}
					
					if(g_bSupport8021x)
					{
						Network.tabs.showTab(5);
					}
					
					if(g_bSupportQoS)
					{
						Network.tabs.showTab(6);
					}
					
					Network.tabs.showTab(7);
					if(g_bSupportWIFI)
					{
						Network.tabs.showTab(8);
					}
				}
				g_menuRecorder.szLastMainMenu = szMainMenu;
				return;
			}
			HWP.destory();
			$.ajax({
				url: "params/Network.asp",
				type: "GET",
				dataType: "html",
				error: function() {
					showmenuconfig(szMenu, iMode, szMainMenu);
				},
				success: function(msg) 
				{
					$("#EditAreaContent").html(msg);
					if(!g_bGetNetCab)//获取网络参数能力
					{
						g_bGetNetCab = true;
						//是否支持高级网络参数
						isSupportQoS();
						isSupportSNMP();
						isSupportWIFI();
						isSupportDDNS();
						isSupportPPPOE();
						if(!g_bSupportWIFI){
							isSupport8021x();
						}
					}
					if (szMainMenu === "BaseConfig") 
					{
						Network.tabs = $("#tabNetwork").tabs(".pane", {remember: false, hideIndexes:[2, 3, 4, 5, 6, 7, 8]});
					} 
					else 
					{
						Network.tabs = $("#tabNetwork").tabs(".pane",{remember : false});
						if(!g_bSupportDDNS)
						{
							Network.tabs.hideTab(2);
						}
						if(!g_bSupportPPPOE)
						{
							Network.tabs.hideTab(3);
						}
						if(!g_bSupportSNMP)
						{
							Network.tabs.hideTab(4);
						}
						
						if(!g_bSupport8021x)
						{
							Network.tabs.hideTab(5);
						}
						
						if(!g_bSupportQoS)
						{
							Network.tabs.hideTab(6);
						}
						
						Network.tabs.showTab(7);
						if(!g_bSupportWIFI)
						{
							Network.tabs.hideTab(8);
						}
					}			
					
					g_menuRecorder.szLastMenu = szMenu;
					g_menuRecorder.szLastMainMenu = szMainMenu;
					initNetwork();
				}
			});
			break;
		}
		case "Network:set":
		{
			switch (Network.tabs.curTab)
			{
				case 0:
					SetNetBasicInfo();
					break;
				/*case 1:
				    setPortInfo();
					break;*/
				case 2: 
				    SetDDNSInfo();
					break;
				case 3: 
				    SetPPPOEInfo();
					break;
				case 4: 
				    SetSNMPInfo();
					break;
				case 5: 
				    Set8021x();
					break;	
				case 6: 
				    SetQoSInfo();
					break;
				case 8:
					setWIFI();
					break;				
				default:
					break;
			}			
			break;
		}
		case "AudioAndVideo:get":
		{
			if (g_menuRecorder.szLastMenu === szMenu) {
				g_menuRecorder.szLastMainMenu = szMainMenu;
				return;
			}
			HWP.destory();
			$.ajax({
				url: "params/AudioAndVideo.asp",
				type: "GET",
				dataType: "html",
				error: function() {
					showmenuconfig(szMenu, iMode, szMainMenu);
				},
				success: function(msg) {
					$("#EditAreaContent").html(msg);
					AudioAndVideo.tabs = $("#tabAudioAndVideo").tabs(".pane",{remember : false});
					if(!parent.g_bIsSupportAudio)
					{
						AudioAndVideo.tabs.hideTab(1);
					}
					g_menuRecorder.szLastMenu = szMenu;
					g_menuRecorder.szLastMainMenu = szMainMenu;
				}
			});
			break;
		}
		case "AudioAndVideo:set":
		{
			switch (AudioAndVideo.tabs.curTab)
			{
				case 0:
				    SetVideoInfo();
					break;
				case 1:
				    setAudioInfo();
					break;
				default:
					break;
			}				
			break;
		}
		case "VideoSettings:get":
		{
			if (g_menuRecorder.szLastMenu === szMenu) {
				g_menuRecorder.szLastMainMenu = szMainMenu;
				return;
			}
			HWP.destory();
			$.ajax({
				url: "params/VideoSettings.asp",
				type: "GET",
				dataType: "html",
				error: function() {
					showmenuconfig(szMenu, iMode, szMainMenu);
				},
				success: function(msg) {
					$("#EditAreaContent").html(msg);

                    $('.iColorPicker').focus(function(){
                        jQuery("#iColorPicker").fadeOut();
                    });
                    iColorPicker();

					m_iPicinform = 1; // 全局变量
					HWP.wnds[0].isPlaying = false;
					
					//VideoSettings.tabs = $("#tabVideoSettings").tabs(".pane", {remember : false, beforeLeave:VideoSettings.beforeLeave});
					VideoSettings.tabs = $("#tabVideoSettings").tabs(".pane", {remember : false,defaultCur: 1});
					isSupportITCOicOSD();
					isSupportITCMergePicOSD();
					if(!g_bSupportITCPicOSD){
						VideoSettings.tabs.hideTab(0);
					}
					if(!g_bSupportITCMergePicOSD){
						VideoSettings.tabs.hideTab(2);
					}
					pr(OSDSettings).initCSS();
					g_menuRecorder.szLastMenu = szMenu;
					g_menuRecorder.szLastMainMenu = szMainMenu;
					
				}
			});
			break;
		}
		case "VideoSettings:set":
		{
			switch (VideoSettings.tabs.curTab)
			{
				case 0:
                    ia(SnapOverlay).submit(0);
                    //setITCPicOSDType(0);
					break;
				case 1:
                    ia(OSDSettings).submit();
					break;
				case 2:
                    ia(SnapOverlay).submit(1);
                    //setITCPicOSDType(1);
					break;
				default:
					break;
			}
			break;
		}
		case "User:get":
		{
			if (g_menuRecorder.szLastMenu === szMenu) {
				if (szMainMenu === "BaseConfig") 
				{
					g_oCurrentTab.hideTabs([1]);
				} 
				else 
				{
					g_oCurrentTab.showTabs([1]);
				}
				g_menuRecorder.szLastMainMenu = szMainMenu;
				return;
			}
			HWP.destory();
			$.ajax({
				url: "params/User.asp",
				type: "GET",
				dataType: "html",
				error: function() {
					showmenuconfig(szMenu, iMode, szMainMenu);
				},
				success: function(msg) {
					$("#EditAreaContent").html(msg);
					$.ajax({ 
						url: "params/userlist.asp",
						type: "GET",
						dataType:"html",
						success:function(szMsg)
						{
							$("#UserPage").html(szMsg);
							if (szMainMenu === "BaseConfig") 
							{
								g_oCurrentTab = $(".tabs").tabs(".pane", {remember : false, hideIndexes:[1]});
							}
							else
							{
								g_oCurrentTab = $(".tabs").tabs(".pane",{remember : false});
							}
						}
					});
					g_menuRecorder.szLastMenu = szMenu;
					g_menuRecorder.szLastMainMenu = szMainMenu;
				}
			});
			break;
		}
		case "User:set":
		{
			switch (g_oCurrentTab.curTab)
			{
				case 1:
					ia(RTSPAuth).setRTSPAuthInfo();
					break;
				default:
					break;
			}
			break;
		}
		case "SnapParam:get":
		{
			if (g_menuRecorder.szLastMenu === szMenu) {
				/*if(!g_bSupportSyncPower)
				{
					SnapParam.tabs.hideTab(2);
				}*/
				g_menuRecorder.szLastMainMenu = szMainMenu;
				return;
			}
			HWP.destory();
			$.ajax({
				url: "params/SnapParam.asp",
				type: "GET",
				dataType: "html",
				error: function() {
					showmenuconfig(szMenu, iMode, szMainMenu);
				},
				success: function(msg) 
				{
                    $("#EditAreaContent").html(msg);
                    pr(BaseVideoSettings).initCSS();

					SnapParamInitSlider();

					var compTypes = getCompressTypes();
					generateCompressTypeTip('oneMergeType', 3, compTypes[1]);
					generateCompressTypeTip('twoMergeType', 3, compTypes[2]);
					generateCompressTypeTip('threeMergeType', 5, compTypes[3]);
					$('#oneMergeTypeStr').focus(compTypeFocus('oneMergeType'));
					$('#twoMergeTypeStr').focus(compTypeFocus('twoMergeType'));
					$('#threeMergeTypeStr').focus(compTypeFocus('threeMergeType'));
					SnapParam.tabs = $("#tabSnapParam").tabs(".pane", {remember : false,defaultCur: 0});
					isSupportEntrance();
					if(!g_bSupportEntrance)
					{
						SnapParam.tabs.hideTab(6);
                        SnapParam.tabs.hideTab(7);
					}
					isSupportGPS();
					if(!g_bSupportGPS){
						SnapParam.tabs.hideTab(8);
					}
					
					isSupportImageMerge();
					if(!g_bSupportImageMerge){
						SnapParam.tabs.hideTab(4);
					}

					isSupportOtherParam();
					if(!g_bSupportOtherParam){
						SnapParam.tabs.hideTab(10)
					}

					g_menuRecorder.szLastMenu = szMenu;
					g_menuRecorder.szLastMainMenu = szMainMenu;
				}
			});
			break;
		}
		case "SnapParam:set":
		{
			switch (SnapParam.tabs.curTab)
			{
				case 0:
                    ia(PlateParam).submit();
			        break;
				case 1:
                    ia(IOSetting).submit();
					break;
				case 2:
                    ia(BaseVideoSettings).submit();
                    break;
				case 3:
                    ia(SyncLight).submit();
					break;
				case 4:
                    //ia(JPEGQuality).submit();
				    ia(ImageMerge).submit();
					break;
				case 5:
				   // ia(SnapSetup).submit();
                    ia(CabinetParam).submit();
					break;
				case 6:
				    ia(ITCInletOutletPort).submit();
				case 8:
					ia(GPSParam).submit();
					break;
				case 9:
					ia(CarFeatureParam).submit();
					break;
				case 10:
					ia(OtherParam).submit();
					break;
			    default:
					break;
			}
			break;
		}

		case "VideoParam:get":
		{
			if (g_menuRecorder.szLastMenu === szMenu) {
				/*if(!g_bSupportSyncPower)
				{
					SnapParam.tabs.hideTab(2);
				}*/
				g_menuRecorder.szLastMainMenu = szMainMenu;
				return;
			}
			HWP.destory();
			$.ajax({
				url: "params/VideoParam.asp",
				type: "GET",
				dataType: "html",
				error: function() {
					showmenuconfig(szMenu, iMode, szMainMenu);
				},
				success: function(msg) 
				{
                    $("#EditAreaContent").html(msg);
                    
                    ia(VideoParam).init();

                    // VideoParam.tabs=$("#tabVideoParam").tabs(".pane", {remember : false,defaultCur: 0});

                    // isSupportLightCorrect();
                    // if(!g_bSupportLightCorrect){
                    // 	VideoParam.tabs.hideTab(6);
                    // }

					g_menuRecorder.szLastMenu = szMenu;
					g_menuRecorder.szLastMainMenu = szMainMenu;
				}
			});
			break;
		}

		case "VideoParam:set":
		{
			switch (ia(VideoParam).tabs.curTab)
			{
				case 0:
                    ia(MultiShut).submit();
			        break;

			    case 5:
			    	ia(ITCImageIcrE).submit();
			    	break;
			    	
			    case 6:
			    	ia(LightCorParam).submit();
			    	break;
			}
			break;
		}

		case "TriggerMode:get":
		{
			$("#spanCommendParam").show();
			if (g_menuRecorder.szLastMenu === szMenu) {
				g_menuRecorder.szLastMainMenu = szMainMenu;
				return;
			}
			HWP.destory();

			g_menuRecorder.szLastMenu = szMenu;
			g_menuRecorder.szLastMainMenu = szMainMenu;

			TriggerModeExt.getSupportedTriggerModes();
			TriggerModeExt.changeTriggerModeType();
			
			break;
		}
		case "TriggerMode:set":
		{
			ia(TriggerMode).submit();
			break;
		}
		case "Event:get":
		{
			if (g_menuRecorder.szLastMenu === szMenu) {
				g_menuRecorder.szLastMainMenu = szMainMenu;
				return;
			}
			HWP.destory();
			$.ajax({
				url: "params/Event.asp",
				type: "GET",
				dataType: "html",
				error: function() {
					showmenuconfig(szMenu, iMode, szMainMenu);
				},
				success: function(msg) 
				{
					$("#EditAreaContent").html(msg);
					Event.tabs = $("#tabEvent").tabs(".pane", {remember : false, defaultCur: 0});
					g_menuRecorder.szLastMenu = szMenu;
					g_menuRecorder.szLastMainMenu = szMainMenu;
				}
			});
			break;
		}
		case "Event:set":
		{
			switch (Event.tabs.curTab)
			{
				case 0:
				    SaveExceptionInfo();
					break;
				default:
					break;
			}
			break;
		}
		case "Storage:get":
		{
			if (g_menuRecorder.szLastMenu === szMenu) {
				g_menuRecorder.szLastMainMenu = szMainMenu;
				return;
			}
			HWP.destory();
			$.ajax({
				url: "params/Storage.asp",
				type: "GET",
				dataType: "html",
				error: function() {
					showmenuconfig(szMenu, iMode, szMainMenu);
				},
				success: function(msg) {
					$("#EditAreaContent").html(msg);
					initStorage();    //初始化存储页面相关信息
					g_oCurrentTab = $("#tabStorage").tabs(".pane",{remember : false});

					isSupportFTP();
					if(!g_bSupportFTP){
						g_oCurrentTab.hideTab(5);
					}

					isSupportCloudStorage();
					if(!g_bSupportCloudStorage){
						g_oCurrentTab.hideTab(6);
					}

                    if(!parent.g_bIsSupportRecordPlan){
                        g_oCurrentTab.hideTab(3);
                    }

                    isSupportcapResInfo();
                    if(!g_bSupportcapResInfo){
                    	g_oCurrentTab.hideTab(1);
                    }
					g_menuRecorder.szLastMenu = szMenu;
					g_menuRecorder.szLastMainMenu = szMainMenu;
				}
			});
			break;
		}
		case "Storage:set":
		{
			switch (g_oCurrentTab.curTab)
			{
				case 0:
                    SetVideoInfo();
					break;
				case 1:
                    ia(SnapResolution).submit();
                    break;
                    	
				case 2:
                    ia(Roi).setROIInfo();
                    break;
				case 3:
                    SetRecordPlanInfo();
					break;
				case 4:
                    SetSDCardInfo();
					break;
                case 5:
                    SetFTPInfo();
                    break;
			    case 6:
				    SetCloudComputingInfo();
                default:
					break;
			}
			break;
		}
		case "PtzCfg:get":
		{
			if (g_menuRecorder.szLastMenu === szMenu) {
				g_menuRecorder.szLastMainMenu = szMainMenu;
				return;
			}
			HWP.destory();
			$.ajax({
				url: "params/ptzCfg.asp",
				type: "GET",
				dataType: "html",
				error: function() {
					showmenuconfig("PtzCfg",0,"AdvanceConfig");
				},
				success: function(msg) {
					$("#EditAreaContent").html(msg);
					initPtzCfg();
					g_oCurrentTab = $("#tabPtz").tabs(".pane", {remember : false, defaultCur: 0, beforeLeave:function(){$("#SetResultTips").empty();}});
					g_menuRecorder.szLastMenu = szMenu;
					g_menuRecorder.szLastMainMenu = szMainMenu;
				}
			});
			break;
		}
		case "PtzCfg:set":
		{
			switch (g_oCurrentTab.curTab)
			{
				case 0:
					setPtzBasic();
					break;
				case 1:
					setLimitInfo();
					break;
				case 2:
					break;
				case 3:
					setParkAction();
					break;
				case 4:
					savePrivacyMask();
					break;
				case 5:
					setBasicTimeTasks();
					break;
				case 6:
					clearCfg();
					break;
				default:
					break;
			}
			break;
		}	
		default:
		{
			break;
		}
	}//switch end
}

/*************************************************
Function:		ChangeLanguage
Description:	改变页面语言
Input:			lan: 语言
				bCallback: 是否执行翻译回调  默认执行
Output:			无
return:			无				
*************************************************/
var g_transStack = new parent.TransStack();
function ChangeLanguage(lan, bCallback)
{
	if (arguments.length < 2)
	{
		bCallback = true;
	}
	var lxd = parent.translator.getLanguageXmlDoc("ParamConfig", lan);
	ChangeVariableLanguage(parent.translator.appendLanguageXmlDoc($(lxd.cloneNode(true)).children("ParamConfig")[0], parent.g_lxdMain)); // 改变配置页面全局变量语言
	g_lxdParamConfig = parent.translator.appendLanguageXmlDoc($(lxd).children("Common")[0], parent.g_lxdMain);
	parent.document.title = parent.translator.translateNode(g_lxdParamConfig, 'laparamCfg');	
	$("#CommendParamBtn").val(parent.translator.translateNode(g_lxdParamConfig, 'CommendParamBtn'));
	$("#SaveConfigBtn").val(parent.translator.translateNode(g_lxdParamConfig, 'laSaveBtn'));
	if (bCallback)
	{
		g_transStack.translate();
	}
}

/*************************************************
Function:		ChangeVariableLanguage
Description:	改变配置页面全局变量语言
Input:          lxd：LanguageXmlDoc
Output:			无
return:			无				
*************************************************/
function ChangeVariableLanguage(lxd)
{
    m_szSuccess1 = parent.translator.translateNode(lxd, 'Success1');   	 //成功
    m_szSuccess2 = parent.translator.translateNode(lxd, 'Success2');       //成功需重启
    m_szSuccess3 = parent.translator.translateNode(lxd, 'DeleteSuccTips');  	 //成功
    m_szSuccess4 = parent.translator.translateNode(lxd, 'Success4');       //成功需重启
    m_szSuccess5 = parent.translator.translateNode(lxd, 'Success5');       //成功需重启 

    m_szError1 = parent.translator.translateNode(lxd, 'Error1'); 			 //设置失败
    m_szError2 = parent.translator.translateNode(lxd, 'Error2');   		 //获取失败
    m_szError3 = parent.translator.translateNode(lxd, 'Error3');       	 //无效的XML内容
    m_szError4 = parent.translator.translateNode(lxd, 'Error4');   		 //无效的XML格式
    m_szError5 = parent.translator.translateNode(lxd, 'Error5');   		 //无效的操作
    m_szError6 = parent.translator.translateNode(lxd, 'Error6');   		 //设备错误
    m_szError7 = parent.translator.translateNode(lxd, 'Error7');   		 //设备忙
    m_szError8 = parent.translator.translateNode(lxd, 'jsNoOperationRight');  //无权限
    m_szError9 = parent.translator.translateNode(lxd, 'jsNetworkAbnormal');   		 //网络异常
    m_szError10 = parent.translator.translateNode(lxd, 'Error10');
    m_szError11 = parent.translator.translateNode(lxd, 'Error11');   		 //用户名密码错误
    m_szError12 = parent.translator.translateNode(lxd, 'Error12');  		 //方法不允许
    m_szError13 = parent.translator.translateNode(lxd, 'Error13');  		 //参数错误
    m_szError14 = parent.translator.translateNode(lxd, 'Error14');
    m_szError400 = parent.translator.translateNode(lxd, 'Error400');  	 //网络中断或异常
    m_szError44 = parent.translator.translateNode(lxd, 'Error44');   		 //参数失败
    m_szError55 = parent.translator.translateNode(lxd, 'Error55');
	m_szError66 = parent.translator.translateNode(lxd, 'Error66');
	m_szError77 = parent.translator.translateNode(lxd, 'Error77');

    m_szAsk = parent.translator.translateNode(lxd, 'Ask'); 				 //询问信息
    m_szAsk1 = parent.translator.translateNode(lxd, 'Ask1');				 //删除用户询问信息
	m_szRestartAsk = parent.translator.translateNode(lxd, 'RestartTips');
    m_szRestartSuccess = parent.translator.translateNode(lxd, 'RestartSuccessTips');
    m_szRestartFailed = parent.translator.translateNode(lxd, 'RestartFailedTips');
	m_szExit = parent.translator.translateNode(lxd, 'exit');
}
/*************************************************
Function:		isSupportQoS
Description:	是否支持QoS
Input:          无
Output:			无
return:			无				
*************************************************/
function isSupportQoS()
{
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces/1/qos/dscp";
	$.ajax(
	{
		type: "GET",
		url: szURL,
		async: false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success:function()
		{
			g_bSupportQoS = true;
			if(Network.tabs != null  && g_menuRecorder.szCurMainMenu == 'AdvanceConfig')
			{
				Network.tabs.showTab(6);
			}
		},
		error:function()
		{
			g_bSupportQoS = false;
			if(Network.tabs != null)
			{
				Network.tabs.hideTab(6);
			}
		}
	});
}
/*************************************************
Function:		isSupportDDNS
Description:	是否支持DDNS
Input:          无
Output:			无
return:			无				
*************************************************/
function isSupportDDNS()
{
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/DDNS/1";
	$.ajax(
	{
		type: "GET",
		url: szURL,
		async: false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success:function()
		{
			g_bSupportDDNS = true;
			if(Network.tabs != null  && g_menuRecorder.szCurMainMenu == 'AdvanceConfig')
			{
				Network.tabs.showTab(2);
			}
		},
		error:function()
		{
			g_bSupportDDNS = false;
			if(Network.tabs != null)
			{
				Network.tabs.hideTab(2);
			}
		}
	});
}

/*************************************************
Function:		isSupportPPPOE
Description:	是否支持PPPOE
Input:          无
Output:			无
return:			无				
*************************************************/
function isSupportPPPOE()
{
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/PPPoE";
	$.ajax(
	{
		type: "GET",
		url: szURL,
		async: false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success:function()
		{
			g_bSupportPPPOE = true;
			if(Network.tabs != null  && g_menuRecorder.szCurMainMenu == 'AdvanceConfig')
			{
				Network.tabs.showTab(3);
			}
		},
		error:function()
		{
			g_bSupportPPPOE = false;
			if(Network.tabs != null)
			{
				Network.tabs.hideTab(3);
			}
		}
	});
}

/*************************************************
Function:		isSupport8021x
Description:	是否支持8021x
Input:          无
Output:			无
return:			无				
*************************************************/
function isSupport8021x()
{
	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces/1/ieee802.1x";
	$.ajax(
	{
		type: "GET",
		url: szURL,
		async: false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success:function()
		{
			g_bSupport8021x = true;
			if(Network.tabs != null  && g_menuRecorder.szCurMainMenu == 'AdvanceConfig')
			{
				Network.tabs.showTab(5);
			}
		},
		error:function()
		{
			g_bSupport8021x = false;
			if(Network.tabs != null)
			{
				Network.tabs.hideTab(5);
			}
		}
	});
}
/*************************************************
Function:		isSupportSNMP
Description:	是否支持SNMP
Input:          无
Output:			无
return:			无				
*************************************************/
function isSupportSNMP()
{
	$.ajax(
	{
		type: "GET",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces/1/snmp",
		async: false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success:function()
		{
			g_bSupportSNMP = true;
			if(Network.tabs != null  && g_menuRecorder.szCurMainMenu == 'AdvanceConfig')
			{
				Network.tabs.showTab(4);
			}
		},
		error:function()
		{
			g_bSupportSNMP = false;
			if(Network.tabs != null)
			{
				Network.tabs.hideTab(4);
			}
		}
	});
}
/*************************************************
Function:		isSupportCapturePlan
Description:	是否支持抓图配置
Input:          无
Output:			无
return:			无				
*************************************************/
function isSupportCapturePlan()
{
	$.ajax(
	{
		type: "GET",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Snapshot/channels/1",
		timeout: 15000,
		async: false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success:function()
		{
			g_bSupportCapturePlan = true;
			if(Event.tabs != null)
			{
				Event.tabs.showTab(7);
			}
		},
		error:function()
		{
			g_bSupportCapturePlan = false;
			if(Event.tabs != null)
			{
				Event.tabs.hideTab(7);
			}
		}
	});
}
/*************************************************
Function:		isSupportWIFI
Description:	是否支持WIFI配置
Input:          无
Output:			无
return:			无				
*************************************************/
function isSupportWIFI()
{
	$.ajax(
	{
		type: "GET",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Network/interfaces/2/wireless",
		timeout: 15000,
		async: false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		success:function()
		{
			g_bSupportWIFI = true;
			/*if(Network.tabs != null  && g_menuRecorder.szCurMainMenu == 'AdvanceConfig')
			{
				Network.tabs.showTab(8);
			}*/
		},
		error:function()
		{
			g_bSupportWIFI = false;
			/*if(Network.tabs != null)
			{
				Network.tabs.hideTab(8);
			}*/
		}
	});
}
/*************************************************
Function:		isSupportTeleCtrl
Description:	是否支持遥控器
Input:          无
Output:			无
return:			无				
*************************************************/
function isSupportTeleCtrl()
{
	$.ajax(
	{
		type:"GET",
		url:m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/Telecontrol",
		async:false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");  
			
		},
		success:function()
		{
			g_bSupportTeleCtrl = true;
			if(System.tabs != null  && g_menuRecorder.szCurMainMenu == 'AdvanceConfig')
			{
				System.tabs.showTab(5);
			}
		},
		error:function()
		{
			g_bSupportTeleCtrl = false;
			if(System.tabs != null)
			{
				System.tabs.hideTab(5);
			}
		}
	});	
}
/*************************************************
Function:		isSupportWLSensors
Description:	是否支持无线报警
Input:          无
Output:			无
return:			无				
*************************************************/
function isSupportWLSensors()
{
	$.ajax(
	{
		type:"GET",
		url:m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/WLSensors",
		async:false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");  
			
		},
		success:function()
		{
			g_bSupportWLS = true;
		},
		error:function()
		{
			g_bSupportWLS = false;
		}
	});	
}
/*************************************************
Function:		isSupportPIR
Description:	是否支持PIR报警
Input:          无
Output:			无
return:			无				
*************************************************/
function isSupportPIR()
{
	$.ajax(
	{
		type: "GET",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/PIR",
		beforeSend: function(xhr) 
		{
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		async:false,
		success: function(xmlDoc, textStatus, xhr)
		{
			g_bSupportPIR = true;
		},
		error: function(xhr, textStatus, errorThrown)
		{
			g_bSupportPIR = false;
		}
	});
}
/*************************************************
Function:		isSupport232
Description:	是否支持232和485配置
Input:          无
Output:			无
return:			无				
*************************************************/
function isSupport232And485()
{
	$.ajax(
	{
		type: "GET",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/System/Serial/ports",
		beforeSend: function(xhr) 
		{
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		async:false,
		success: function(xmlDoc, textStatus, xhr)
		{
			var oSerialPorts = $(xmlDoc).find("SerialPort");
			var szIdSet = [];
			for(var i = 0; i < oSerialPorts.length; i++)
			{
				szIdSet.push(oSerialPorts.eq(i).find("serialPortType").eq(0).text());
			}
			if($.inArray("RS485", szIdSet) < 0)
			{
				g_bSupport485 = false;
			}
			else
			{
				g_bSupport485 = true;
			}
			if($.inArray("RS232", szIdSet) < 0)
			{
				g_bSupport232 = false;
			}
			else
			{
				g_bSupport232 = true;
			}
			if(System.tabs != null && g_menuRecorder.szCurMainMenu == 'AdvanceConfig')
			{
				if(g_bSupport485)
				{
					System.tabs.showTab(4);
				}
				if(g_bSupport232)
				{
					System.tabs.showTab(3);
				}
			}
		},
		error: function(xhr, textStatus, errorThrown)
		{
			g_bSupport232 = false;
			g_bSupport485 = false;
			if(System.tabs != null)
			{
				System.tabs.hideTabs([3,4]);
			}
		}
	});
}
/*************************************************
Function:		isSupportCallHelp
Description:	是否支持呼救报警
Input:          无
Output:			无
return:			无				
*************************************************/
function isSupportCallHelp()
{
	$.ajax(
	{
		type: "GET",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/callhelp",
		beforeSend: function(xhr) 
		{
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		async:false,
		success: function(xmlDoc, textStatus, xhr)
		{
			g_bSupportCH = true;
		},
		error: function(xhr, textStatus, errorThrown)
		{
			g_bSupportCH = false;
		}
	});
}
/*************************************************
Function:		isSupportSyncPower
Description:	是否支持信号灯同步
Input:          无
Output:			无
return:			无				
*************************************************/
function isSupportSyncPower()
{
	$.ajax(
	{
		type: "GET",
		url: m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/SyncPower",
		beforeSend: function(xhr) 
		{
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		async:false,
		success: function(xmlDoc, textStatus, xhr)
		{
			g_bSupportSyncPower = true;
		},
		error: function(xhr, textStatus, errorThrown)
		{
			g_bSupportSyncPower = false;
		}
	});
}
/*************************************************
 Function:       isSupport28181
 Description:    是否支持28181配置
 Input:          无
 Output:         无
 return:         无
 *************************************************/
function isSupport28181() {
	$.ajax({
		type:"GET",
		url:m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/SIP",
		beforeSend:function (xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		async:false,
		success:function (xmlDoc, textStatus, xhr) {
			g_bSupport28181 = true;
		},
		error:function (xhr, textStatus, errorThrown) {
			g_bSupport28181 = false;
		}
	});
}
/*************************************************
 Function:       isSupportEntrance
 Description:    是否支持ITC输出口配置
 Input:          无
 Output:         无
 return:         无
 *************************************************/
function isSupportEntrance() {
	$.ajax({
		type:"GET",
		url:m_lHttp + m_strIp + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/Entrance/capabilities",
		beforeSend:function (xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");
			
		},
		async:false,
		success:function (xmlDoc, textStatus, xhr) {
			if($(xmlDoc).find("supportEntrance").eq(0).text()=="true"){
				g_bSupportEntrance = true;
				
				var supportBarrierGateNum = $(xmlDoc).find("supportBarrierGateNum").eq(0).text()
				if(supportRelayNum != 0){
                    $("#laneNum_tr").show();
                    $("#laneNum").show();
                    $("#laneNum").empty();
                    for(var i = 1; i <= supportBarrierGateNum; i++) {
                        $("<option value='" + i + "'>" + i + "</option>").appendTo("#laneNum");
                    }
				}
				else { $("#relayNum_tr").hide(); }
				
				var supportRelayNum = $(xmlDoc).find("supportRelayNum").eq(0).text()
				if(supportRelayNum != 0){
                    $("#relayNum_tr").show();
                    $("#relayNum").show();
                    $("#relayNum").empty();
                    for(var i = 1; i <= supportRelayNum; i++) {
                        $("<option value='" + i + "'>" + i + "</option>").appendTo("#relayNum");
                    }
				}
				else { $("#relayNum_tr").hide(); }
				
				var supportAlarmINNum = $(xmlDoc).find("supportAlarmINNum").eq(0).text();
				if(supportAlarmINNum != 0){
                    $("#IOAlarmNum_tr").show();
                    $("#IOAlarmNum").show();
                    $("#IOAlarmNum").empty();
                    for(var i = 1; i <= supportAlarmINNum; i++) {
                        $("<option value='" + i + "'>" + i + "</option>").appendTo("#IOAlarmNum");
                    }
				}
				else { $("#IOAlarmNum_tr").hide(); }
			}
			if($(xmlDoc).find("supportEntrance").eq(0).text()=="false"){
				g_bSupportEntrance = false;
			}
		},
		error:function (xhr, textStatus, errorThrown) {
			g_bSupportEntrance = false;
		}
	});
}

//是否支持交通采集参数
function isSupportTrafficParam(){
	$.ajax({
		type:"GET",
		url:m_lHttp + m_szHostName + ":" + m_lHttpPort +"/PSIA/Custom/SelfExt/ITC/trafficParam/capabilities",
		async:false,
		timeout:15000,
		dataType:"text",
		beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success:function(xmlDoc,textStatus,xhr){
        	var $xml=$(parseXmlFromStr(xmlDoc));
        	if("true"==$xml.find("enable").eq(0).text()){
        		g_bSupportTrafficParam=true;
        	}else{
        		g_bSupportTrafficParam=false;
        	}
        },
        error:function(xhr){
        	g_bSupportTrafficParam=false;
        }
	});
}

//网络存储FTP能力集
function isSupportFTP(){
	$.ajax({
		type:"GET",
		url:m_lHttp + m_szHostName + ":" + m_lHttpPort +"/PSIA/Custom/SelfExt/ftp/capabilities",
		async:false,
		timeout:15000,
		dataType:"text",
		beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success:function(xmlDoc,textStatus,xhr){
        	var $xml=$(parseXmlFromStr(xmlDoc));
        	if("true"==$xml.find("enable").eq(0).text()){
        		g_bSupportFTP=true;
        	}else{
        		g_bSupportFTP=false;
        	}
        },
        error:function(xhr){
        	g_bSupportFTP=false;
        }
	});
}
//云存储能力集
function isSupportCloudStorage(){
	$.ajax({
		type:"GET",
		url:m_lHttp + m_szHostName + ":" + m_lHttpPort +"/PSIA/Custom/SelfExt/CloudStorageInfo/capabilities",
		async:false,
		timeout:15000,
		dataType:"text",
		beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success:function(xmlDoc,textStatus,xhr){
        	var $xml=$(parseXmlFromStr(xmlDoc));
        	if("true"==$xml.find("enable").eq(0).text()){
        		g_bSupportCloudStorage=true;
        	}else{
        		g_bSupportCloudStorage=false;
        	}
        },
        error:function(xhr){
        	g_bSupportCloudStorage=false;
        }
	});
}

//抓图叠加设置能力集
function isSupportITCOicOSD(){
	$.ajax({
		type:"GET",
		url:m_lHttp + m_szHostName + ":" + m_lHttpPort +"/PSIA/Custom/SelfExt/Snapshot/channels/1/ITCPicOSD/capabilities",
		async:false,
		timeout:15000,
		dataType:"text",
		beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success:function(xmlDoc,textStatus,xhr){
        	var $xml=$(parseXmlFromStr(xmlDoc));
        	if("true"==$xml.find("enable").eq(0).text()){
        		g_bSupportITCPicOSD=true;
        	}else{
        		g_bSupportITCPicOSD=false;
        	}
        },
        error:function(xhr){
        	g_bSupportITCPicOSD=false;
        }
	});
}

//合成图叠加设置能力集
function isSupportITCMergePicOSD(){
	$.ajax({
		type:"GET",
		url:m_lHttp + m_szHostName + ":" + m_lHttpPort +"/PSIA/Custom/SelfExt/Snapshot/channels/1/ITCMergePicOSD/capabilities",
		async:false,
		timeout:15000,
		dataType:"text",
		beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success:function(xmlDoc,textStatus,xhr){
        	var $xml=$(parseXmlFromStr(xmlDoc));
        	if("true"==$xml.find("enable").eq(0).text()){
        		g_bSupportITCMergePicOSD=true;
        	}else{
        		g_bSupportITCMergePicOSD=false;
        	}
        },
        error:function(xhr){
        	g_bSupportITCMergePicOSD=false;
        }
	});
}

//图片合成能力集
function isSupportImageMerge(){
	$.ajax({
		type:"GET",
		url:m_lHttp + m_szHostName + ":" + m_lHttpPort +"/PSIA/Custom/SelfExt/ITC/ImageMerge/capabilities",
		async:false,
		timeout:15000,
		dataType:"text",
		beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success:function(xmlDoc,textStatus,xhr){
        	var $xml=$(parseXmlFromStr(xmlDoc));
        	if("true"==$xml.find("enable").eq(0).text()){
        		g_bSupportImageMerge=true;
        	}else{
        		g_bSupportImageMerge=false;
        	}
        },
        error:function(xhr){
        	g_bSupportImageMerge=false;
        }
	});
}

//信号灯校正能力集
function isSupportLightCorrect(){
	$.ajax({
		type:"GET",
		url:m_lHttp + m_szHostName + ":" + m_lHttpPort +"/PSIA/Custom/SelfExt/ITC/lightCorrect/capabilities",
		async:false,
		timeout:15000,
		dataType:"text",
		beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success:function(xmlDoc,textStatus,xhr){
        	var $xml=$(parseXmlFromStr(xmlDoc));
        	if("true"==$xml.find("enable").eq(0).text()){
        		g_bSupportLightCorrect=true;
        	}else{
        		g_bSupportLightCorrect=false;
        	}
        },
        error:function(xhr){
        	g_bSupportLightCorrect=false;
        }
	});
}

//图片编码能力集
function isSupportcapResInfo(){
	$.ajax({
		type:"GET",
		url:m_lHttp + m_szHostName + ":" + m_lHttpPort +"/PSIA/Custom/SelfExt/Snapshot/channels/1/capabilities",
		async:false,
		timeout:15000,
		dataType:"text",
		beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success:function(xmlDoc,textStatus,xhr){
        	var $xml=$(parseXmlFromStr(xmlDoc));
        	if("true"==$xml.find("enable").eq(0).text()){
        		g_bSupportcapResInfo=true;
        	}else{
        		g_bSupportcapResInfo=false;
        	}
        },
        error:function(xhr){
        	g_bSupportcapResInfo=false;
        }
	});
}
//违法字典能力集
function isSupportcapIllegalDictionary(){
	$.ajax({
		type:"GET",
		url:m_lHttp + m_szHostName + ":" + m_lHttpPort +"/PSIA/Custom/SelfExt/IllegalDictionary/capabilities",
		async:false,
		timeout:15000,
		dataType:"text",
		beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
        },
        success:function(xmlDoc,textStatus,xhr){
        	var $xml=$(parseXmlFromStr(xmlDoc));
        	if("true"==$xml.find("enable").eq(0).text()){
        		g_bSupportIlleagalDictionary=true;
        	}else{
        		g_bSupportIlleagalDictionary=false;
        	}
        },
        error:function(xhr){
        	g_bSupportIlleagalDictionary=false;
        }
	});
}

function isSupportOtherParam(){
    $.ajax({
        url:m_lHttp+m_szHostName+":"+m_lHttpPort+"/PSIA/Custom/SelfExt/ITC/other/capabilities",
        type:"GET",
        async:false,
        timeout:syncTime,
        dataType: 'text',
        beforeSend:function(xhr){
            xhr.setRequestHeader("If-Modified-Since","0");
        },
        success: function(xmlDoc, textStatus, xhr)
        {
        	if ($(parseXmlFromStr(xmlDoc)).find('enable').eq(0).text() == 'true') {
        		g_bSupportOtherParam = true;
        	}else{
        		g_bSupportOtherParam = false;
        	}
        },
        error: function(){
        	g_bSupportOtherParam = false;
        }

    });
}

/*************************************************
Function:isSupportEhome
Description:是否支持Ehome协议
Input:          无
Output:         无
Return:         无
*************************************************/
function isSupportEhome(){
	$.ajax({
        type: "GET",
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/EHOME/capabilities",
        async: false,
        timeout: 15000,
        success: function(xmlDoc, textStatus, xhr)
        {
        	if ($(xmlDoc).find('ehomeSupport').eq(0).text() == 'true') {
        		g_bSupportEhome = true;
        	}else{
        		g_bSupportEhome = false;
        	}
        },
        error: function(){
        	g_bSupportEhome = false;
        }
    });
}


/*************************************************
Function:isSupportGPS
Description:是否支持GPS功能
Input:          无
Output:         无
Return:         无
*************************************************/
function isSupportGPS(){
	$.ajax({
        type: "GET",
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/gpsparam/capabilities",
        async: false,
        timeout: 15000,
        success: function(xmlDoc, textStatus, xhr)
        {
        	if ($(xmlDoc).find('gpsSupport').eq(0).text() == 'true') {
        		g_bSupportGPS = true;
        	}else{
        		g_bSupportGPS = false;
        	}
        },
        error: function(){
        	g_bSupportGPS = false;
        }
    });
}