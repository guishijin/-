var global_config = {
	web_version: "3.1.3.160224",
	plugin_version: "3.0.5.22"
}