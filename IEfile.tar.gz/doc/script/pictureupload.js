var g_lxdPicUpload = null;
var g_transStack = null;

var m_iAlarmNum = 0;
var m_iSelectFile = -1;
var m_szTablePicFile = new Array();   //单元格中回放文件名
var m_szTablePlateFile = new Array();
var m_szTableMainFaceFile=new Array();
var m_szTableViceFaceFile=new Array();
var m_szPlateNumber = new Array();
var m_iAlarmStatus = -1;
var HWP2 = null;
var sz_snapXML = null;
var enableUseRuler = true;
var trafficLightEnable = false;
var m_snapResolutionWidth = 2048;
var m_snapResolutionHeight = 1536;
/*************************************************
 Function:		InitPicUpload
 Description:	初始化图片上传
 Input:			无
 Output:		无
 return:		无
 *************************************************/
function InitPicUpload() {
    m_oParent = window.opener;
    g_transStack = new TransStack();
    ChangeLan();
    if(g_oWebSession.getItem("userInfo"+m_lHttpPort) == null)
    {
        window.parent.location.href="doc/page/login.asp";
        return;
    }
    //display ip address
    //$("#ipaddr").html(m_szHostName);
    m_szUserPwdValue = g_oWebSession.getItem("userInfo"+m_lHttpPort);

    loadPagePlugin();
    startAlarmChan(1);
    getSnapResolutionInfo();
    $("#platenum").html(getNodeValue("PlateNumUnknown"));  //无车牌.
    GetAlarmLightTypeInfo();
    if(trafficLightEnable){
        $('#lightMainContentDiv').hide();
        $('#trafficContentDiv').show();

        judgeLightStatus('trafficLightOne','0', 991);
        judgeLightStatus('trafficLightTwo','0', 991);
        judgeLightStatus('trafficLightThree','0', 991);

    }else{
        $('#lightMainContentDiv').show();
        $('#trafficContentDiv').hide();

        judgeLightStatus('picLightOne','0',990);
        judgeLightStatus('picLightTwo','0',990);
        judgeLightStatus('picLightThree','0',990);
        judgeLightStatus('picLightFour','0',990);
    }

}
/*************************************************
 Function:		loadPagePlugin
 Description:	加载页面所需控件
 Input:			无
 Output:		无
 return:		无
 *************************************************/
function loadPagePlugin()
{
    var szInfo = translator.translateNode(g_lxdPicUpload, 'laPlugin');
    if( !checkPlugins('1', getNodeValue("laPluginNotSetUp"), 1, 'snapdraw', "picture_plugin", "PicPreviewActiveX") || !checkPlugins('1', getNodeValue("laPluginNotSetUp"), 1, 'snapdraw', "popImage_plugin", "ImgZoomActiveX")) {
        return;
    }
    if(!CompareFileVersion("PicPreviewActiveX")) {
        UpdateTips();
    }

    if (!g_bIsIE) {
        $("#plate_plugin").html("<embed type='application/hwitcp-webvideo-plugin' id='PlatePreviewActiveX' width='100%' height='100%' name='PlatePreviewActiveX' align='center' wndtype='1' playmode='snapdraw'>");
    } else {
        $("#plate_plugin").html("<object classid='clsid:8C1A66F8-F28E-43fb-AF78-11D3163E6635' codebase='' standby='Waiting...' id='PlatePreviewActiveX' width='100%' height='100%' name='PlatePreviewActiveX' align='center' ><param name='wndtype' value='1'><param name='playmode' value='snapdraw'></object>");
    }

    HWP2 = $("#ImgZoomActiveX")[0];

    EnableImgZoomCallBack();  //hwp启用鼠标回调
    EnableImgZoom();          //hwp启用图片放大显示
}

//0-关闭鼠标滑动电子放大回调(鼠标操作插件)，1-启用鼠标电子放大回调(鼠标操作插件)
// 2-关闭图片放大功能(图片放大插件), 3-开启电子放大功能(图片放大插件用)
//启用图片放大信息回调
function EnableImgZoomCallBack() {
    $("#PicPreviewActiveX")[0].HWP_EnableImgZoom(0, 1);  //针对鼠标移动插件
}

//启用图片放大
function EnableImgZoom() {
    HWP2.HWP_EnableImgZoom(0, 3);  //针对显示图片放大的插件
}
/*************************************************
 Function:		ChangeLan
 Description:	改变页面语言
 Input:			无
 Output:		无
 return:		无
 *************************************************/
function ChangeLan()
{
    g_lxdPicUpload = translator.getLanguageXmlDoc("PicUpload", $.cookie('language'));
    var lxd = translator.getLanguageXmlDoc("Main", $.cookie('language'));
    var _lxdMain = $(lxd).children("Common")[0];
    translator.appendLanguageXmlDoc(g_lxdPicUpload, _lxdMain);
    translator.translatePage(g_lxdPicUpload, document);
    document.title = translator.translateNode(g_lxdPicUpload, "title");
}
/*************************************************
 Function:		startAlarmChan
 Description:	布防
 Input:			iType: 1 一级布防  2 二级布防  0 撤防
 Output:		无
 return:		无
 *************************************************/
function startAlarmChan(iType)
{
    var szSuccessState = "<img src='../images/config/smile.png' class='verticalmiddle'>&nbsp;";
    var szErrorState = "<img src='../images/config/error.png' class='verticalmiddle'>&nbsp;";

    var previewOCX = $("#PicPreviewActiveX")[0];
    if(iType == 0) {
        previewOCX.HWP_StopAlarmChan();
        m_iAlarmStatus = 0;
        $("#spLinkStatus").html(szSuccessState + getNodeValue("launlinkSucc"));
    } else {
        if(m_iAlarmStatus == 1 || m_iAlarmStatus == 2) {
            previewOCX.HWP_StopAlarmChan();
        }
        var szXml = '<?xml version="1.0"?><UploadPic version="1.0" xmlns="http://urn:selfextension:psiaext-ver10-xsd"><UploadPicPriority>' + iType + '</UploadPicPriority></UploadPic>';
        var szURL = m_lHttp+m_szHostName+":"+m_lHttpPort+"/PSIA/Custom/SelfExt/ITC/UploadPic";
        var iRet = previewOCX.HWP_StartAlarmChan(szURL, m_szUserPwdValue, szXml);
        if(iRet < 0){
            m_iAlarmStatus = 0;
            $("#spLinkStatus").html(szErrorState + getNodeValue("lalinkFail"));
        } else {
            m_iAlarmStatus = iType;
            $("#spLinkStatus").html(szSuccessState + getNodeValue("lapicLinkStatus1"));
        }
    }
}

function SelectPicFile(event){

    event = event?event:(window.event?window.event:null);
    var ObjTable = event.srcElement?event.srcElement:event.target;
    if(ObjTable.tagName == "TD")
    {
        while(ObjTable.tagName != "TR")
        {
            ObjTable = ObjTable.parentNode;
        }
        var curTRObj = ObjTable.childNodes[0];
        var curentOjbId = ObjTable.childNodes[0].id.split('PictureA')[1];

        SelectFile(curentOjbId);
    }
}
/*************************************************
 Function:		InsertPicture
 Description:	插入图片条目信息到List中
 Input:			iNo: 图片序号
 strPictureName  : 图片名
 strPictureDate : 图片记录时间
 iPictureSize  : 图片大小
 Output:			无
 return:			无
 *************************************************/
function InsertPicture(iNo, strPictureTime, iLaneNo, strPlateColor, strPlateNum, iSpeed, strIllInfo, strCarIndex, strPictureName)
{
    var ObjTr;
    var ObjTd;
    var curRowNum = document.getElementById("PictureTableList").rows.length;
    ObjTr = document.getElementById("PictureTableList").insertRow(0);
    ObjTr.style.height="20px";
    ObjTr.style.color="#39414A";
    ObjTr.style.cursor="pointer";
    ObjTr.align = "center";
    /*$(ObjTr).bind('click', {iIndex:iNo}, function(event) {
        var i = parseInt(event.data.iIndex)
        SelectFile(i);
    });*/

    for(j = 0;j < document.getElementById("PictureTableList").rows[curRowNum].cells.length;j++) {
        ObjTd = ObjTr.insertCell(j);
        ObjTd.style.color="#39414A";
        ObjTd.align = "center";
        if((iNo%2)==0) {
            ObjTd.bgColor="#f6f6f6" ;
        } else {
            ObjTd.bgColor="#ebebeb" ;
        }
        switch(j) {
            case 0:
                ObjTd.innerHTML = iNo;
                ObjTd.id = "PictureA"+iNo;
                ObjTd.width = "50px";
                break;
            case 1:
                ObjTd.innerHTML = strPictureTime;
                ObjTd.id = "PictureB"+iNo;
                ObjTd.width = "130px";
                break;
            case 2:
                ObjTd.innerHTML = iLaneNo;
                ObjTd.id = "PictureC"+iNo;
                ObjTd.width = "50px";
                break;
            case 3:
                ObjTd.innerHTML = getNodeValue(strPlateColor);
                ObjTd.id = "PictureD"+iNo;
                ObjTd.width = "100px";
                break;
            case 4:
                ObjTd.innerHTML = strPlateNum;
                ObjTd.id = "PictureE"+iNo;
                ObjTd.width = "100px";
                break;
            case 5:
                ObjTd.innerHTML = iSpeed;
                ObjTd.id = "PictureF"+iNo;
                ObjTd.width = "100px";
                break;
            case 6:
                ObjTd.innerHTML = strIllInfo;
                ObjTd.id = "PictureG"+iNo;
                ObjTd.width = "100px";
                break;
            case 7:
                ObjTd.innerHTML = strCarIndex;
                ObjTd.id = "PictureH"+iNo;
                ObjTd.width = "100px";
                break;
            case 8:
                ObjTd.innerHTML = strPictureName;
                ObjTd.id = "PictureI"+iNo;
                ObjTd.width = "270px";
                break;

            default:
                break;
        }
    }
}
/*************************************************
 Function:		GetNowTime
 Description:	获取当前日期
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function GetNowDate()
{
    var myDate = new Date();
    var iYear = myDate.getFullYear();
    var iMon = myDate.getMonth();
    var iDay = myDate.getDate();
    iMon = parseInt(iMon)+1;
    if(iMon <= 9) {
        iMon = '0' + iMon;
    }
    if(iDay <= 9) {
        iDay = '0' + iDay;
    }
    var szNowTime = iYear + iMon + iDay;
    return szNowTime;
}
/*************************************************
 Function:		UploadAlarmInfo
 Description:	获取布防上传信息
 Input:			AlarmInfoXml:上传的图片信息
 Output:			无
 return:			无
 *************************************************/
function UploadAlarmInfo(AlarmInfoXml)
{
    if(m_iAlarmNum >= 200) {
        m_iAlarmNum = 0;
        m_szTablePicFile.length = 0;
        m_szTablePlateFile.length = 0;
        m_szTableMainFaceFile.length=0;
        m_szTableViceFaceFile.length=0;
        m_szPlateNumber.length = 0;
        var RowNum = document.getElementById("PictureTableList").rows.length;
        for(var i = 1; i < RowNum; i++)
        {
            document.getElementById("PictureTableList").deleteRow(0);
        }

        m_iSelectFile = -1;
    }
    m_iAlarmNum++;
    var strPlateFile = "";
    var strPictureName = "";
    var strMainFaceFile="";
    var strViceFaceFile="";
    var xmlDoc = parseXmlFromStr(AlarmInfoXml);
    var strPictureTime = $(xmlDoc).find("picTime").eq(0).text();
    var iLaneNo = $(xmlDoc).find("picDriveChan").eq(0).text();
    var strPlateColor = $(xmlDoc).find("plateColor").eq(0).text();
    var strPlateNum = $(xmlDoc).find("picLicense").eq(0).text();
    var strCarIndex = $(xmlDoc).find("picCarIndex").eq(0).text();
    var iSpeed = $(xmlDoc).find("picSpeed").eq(0).text();
    var strIllInfo = getNodeValue($(xmlDoc).find("picErrorType").eq(0).text());
    strPictureName = $(xmlDoc).find("picFile").eq(0).text();
    strPlateFile = $(xmlDoc).find("plateFile").eq(0).text();
    strMainFaceFile=$(xmlDoc).find("mainFacePicFile").eq(0).text();
    strViceFaceFile=$(xmlDoc).find("viceFacePicFile").eq(0).text();

    var previewOCX = $("#PicPreviewActiveX")[0]; //加载场景图片
    var szPathInfo = previewOCX.HWP_GetLocalConfig();

    var xmlDoc = parseXmlFromStr(szPathInfo);
    var SnapScenePicPath = $(xmlDoc).find("SnapScenePicPath").eq(0).text();

    strPictureName = SnapScenePicPath + "\\" + strIllInfo + "\\" + strPictureTime.substring(0,8) + "\\" + strPictureName;
    if(strPlateFile != "") {
        strPlateFile = SnapScenePicPath + "\\" + strIllInfo + "\\" + strPictureTime.substring(0,8) + "\\" + strPlateFile;
    }
    if(strMainFaceFile!=""){
        strMainFaceFile=SnapScenePicPath + "\\" + strIllInfo + "\\" + strPictureTime.substring(0,8) + "\\" + strMainFaceFile;
    }
    if(strViceFaceFile!=""){
        strViceFaceFile=SnapScenePicPath + "\\" + strIllInfo + "\\" + strPictureTime.substring(0,8) + "\\" + strViceFaceFile;
    }
    InsertPicture(m_iAlarmNum, strPictureTime, iLaneNo, strPlateColor, strPlateNum, iSpeed, strIllInfo, strCarIndex, strPictureName);

    m_szTablePicFile.push(strPictureName);
    m_szTablePlateFile.push(strPlateFile);
    m_szTableMainFaceFile.push(strMainFaceFile);
    m_szTableViceFaceFile.push(strViceFaceFile);
    m_szPlateNumber.push(strPlateNum);

    if(enableUseRuler){
        previewOCX.HWP_SnapLoadImage(strPictureName);

        HWP2.HWP_SnapLoadImage(strPictureName);  //图片放大插件

        var plateOCX = $("#PlatePreviewActiveX")[0]; //加载车牌图片
        plateOCX.HWP_SnapLoadImage(strPlateFile);

        // var mainFaceOCX=$("#PlatePreviewActiveX")[0]; //加载人脸子图主驾驶图
        // mainFaceOCX.HWP_SnapLoadImage(strMainFaceFile);

        // var viceFaceOCX=$("#PlatePreviewActiveX")[0]; //加载人脸子图副驾驶图
        // viceFaceOCX.HWP_SnapLoadImage(strViceFaceFile);
    }

    $("#platenum").html(strPlateNum);
}

/*************************************************
 Function:		ClosePicUpload
 Description:	撤防
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function ClosePicUpload(){
    var previewOCX = $("#PicPreviewActiveX")[0];
    previewOCX.HWP_StopAlarmChan();
}
/*************************************************
 Function:		OpenPicPath
 Description:	打开图片文件夹
 Input:			无
 Output:		无
 return:		无
 *************************************************/
function OpenPicPath() {
    var previewOCX = $("#PicPreviewActiveX")[0];
    var szPathInfo = previewOCX.HWP_GetLocalConfig();
    var xmlDoc = parseXmlFromStr(szPathInfo);
    var szLocalPath = $(xmlDoc).find("SnapScenePicPath").eq(0).text();
    if(previewOCX.HWP_OpenDirectory(szLocalPath) != 0){
        alert(getNodeValue("OpenFilePathFailed"));
    }
}

/*
 Function:    	HWP_EnableRuler
 Description: 	启用标尺
 Input:			lWndNum   窗口号
 lXnum 横坐标分几个刻度
 lVideoWidth 实际视频图像宽度
 lVideoHeight 实际视频图像高度
 Output:         无
 Return:			-1-失败，0-成功
 */
function EnableRuler() {
    try{
        var previewOCX = $("#PicPreviewActiveX")[0];
        var iRet = previewOCX.HWP_EnableRuler(0, 16, m_snapResolutionWidth, m_snapResolutionHeight);
        enableUseRuler = false;
    }
    catch(e){
    }
}

function EnableDrawRect () {
    try{
        var ocx = $("#PicPreviewActiveX")[0];
        var szInfo3 = "<?xml version='1.0' encoding='utf-8'?>"+
                        "<SnapPolygonList><SnapPolygon><id>1111</id>"+
                                "<polygonType>0</polygonType>"+
                                "<showRectPx>true</showRectPx><tips></tips><isClosed>false</isClosed>"+
                                "<color><r>255</r><g>255</g><b>0</b></color><pointList/>"+
                        "</SnapPolygon></SnapPolygonList>";
        
        ocx.HWP_SetSnapPolygonInfo(szInfo3)
        ocx.HWP_SetSnapDrawMode(0, 1);
    }catch(e){

    }
    
}

function DisableDrawRect () {
    try{
        var ocx = $("#PicPreviewActiveX")[0];
        ocx.HWP_ClearSnapInfo(0);
    }catch(e){

    }
}

function DisableRuler() {
    try{
        if(!enableUseRuler){
            var previewOCX = $("#PicPreviewActiveX")[0];
            var iRet = previewOCX.HWP_DisableRuler(0);
            enableUseRuler = true;
        }
    }
    catch(e){
    }
}
/*************************************************
 Function:		SelectFile
 Description:	选中某个回放文件
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function SelectFile(iIndex)
{
    if(m_iSelectFile == iIndex){
        return;
    }
    var oSelObj = document.getElementById("PictureTableList").rows[m_iAlarmNum - iIndex];
    for(j = 0;j < oSelObj.cells.length;j++){
        oSelObj.cells[j].style.color = "#ffffff";
        oSelObj.cells[j].style.backgroundColor = "#762727";
    }
    if(m_iSelectFile != -1) {
        oSelObj = document.getElementById("PictureTableList").rows[m_iAlarmNum - m_iSelectFile];
        if(m_iSelectFile%2 == 0){
            for(i = 0;i < oSelObj.cells.length;i++){
                oSelObj.cells[i].style.color = "#39414A";
                oSelObj.cells[i].style.backgroundColor = "#f6f6f6";
            }
        } else {
            for(i = 0;i < oSelObj.cells.length;i++){
                oSelObj.cells[i].style.color = "#39414A";
                oSelObj.cells[i].style.backgroundColor = "#ebebeb";
            }
        }
    }
    m_iSelectFile = iIndex;
    var previewOCX = $("#PicPreviewActiveX")[0]; //加载场景图片
    previewOCX.HWP_SnapLoadImage(m_szTablePicFile[m_iSelectFile-1]);

    HWP2.HWP_SnapLoadImage(m_szTablePicFile[m_iSelectFile-1]);

    var plateOCX = $("#PlatePreviewActiveX")[0]; //加载车牌图片
    plateOCX.HWP_SnapLoadImage(m_szTablePlateFile[m_iSelectFile-1]);

    // var mainFaceOCX=$("#PlatePreviewActiveX")[0]; //加载人脸子图主驾驶图片,方式与车牌图片类似
    // mainFaceOCX.HWP_SnapLoadImage(m_szTableMainFaceFile[m_iSelectFile-1]);

    // var viceFaceOCX=$("#PlatePreviewActiveX")[0]; //加载人脸子图副驾驶图片,方式与车牌图片类似
    // viceFaceOCX.HWP_SnapLoadImage(m_szTableViceFaceFile[m_iSelectFile-1]);

    $("#platenum").html(m_szPlateNumber[m_iSelectFile-1]);
}
/*************************************************
 Function:		PluginEventHandler
 Description:	回放事件响应
 Input:			iEventType 事件类型, iParam1 参数1, iParam2 保留
 Output:			无
 return:			无
 *************************************************/

function PluginEventHandler(iEventType, iParam1, iParam2) {
    if(4 == iEventType) {
        var szTipsInfo = "<img src='../images/config/tips.png' class='verticalmiddle'>&nbsp;";
        $("#spLinkStatus").html(szTipsInfo + getNodeValue("lapicLinkConnecting"));
    } else if(5 == iEventType){
        var szSuccessState = "<img src='../images/config/smile.png' class='verticalmiddle'>&nbsp;";
        $("#spLinkStatus").html(szSuccessState + getNodeValue("lapicLinkStatus1"));
    } else if(6 == iEventType){
        var szErrorState = "<img src='../images/config/error.png' class='verticalmiddle'>&nbsp;";
        $("#spLinkStatus").html(szErrorState + getNodeValue("lalinkFail"));
        m_iAlarmStatus = 0;
    }
    if(21 == iEventType) {  //磁盘已满[默认小于等于1G时]  这里处理，例如停止布防，停止图片下载
		var szErrorState = "<img src='../images/config/error.png' class='verticalmiddle'>&nbsp;";
        $("#spLinkStatus").html(szErrorState + getNodeValue("lalinkStop"));
        m_iAlarmStatus = 0;
        var previewOCX = $("#PicPreviewActiveX")[0];
        previewOCX.HWP_StopAlarmChan(); //撤防
        m_iAlarmStatus = 0;

    }
}

/*************************************************
 Function:		UploadLightsInfo
 Description:	获取红绿灯上传信息
 Input:			无
 Output:			无
 return:			无
 *************************************************/
function UploadLightsInfo(InfoXml){
    var xmlDoc = parseXmlFromStr(InfoXml);
    var lightType = $(xmlDoc).find("lightType").eq(0).text();

    if(lightType == 990){  //车道交通灯

        var lightType0 = $(xmlDoc).find("lightType0").eq(0).text();
        var lightType1 = $(xmlDoc).find("lightType1").eq(0).text();
        var lightType2 = $(xmlDoc).find("lightType2").eq(0).text();
        var lightType3 = $(xmlDoc).find("lightType3").eq(0).text();

        $('#lightMainContentDiv').show();
        $('#trafficContentDiv').hide();
        judgeLightStatus('picLightOne',lightType0,990);
        judgeLightStatus('picLightTwo',lightType1,990);
        judgeLightStatus('picLightThree',lightType2,990);
        judgeLightStatus('picLightFour',lightType3,990);
    }else if(lightType == 991){  //方向灯

        var leftLight = $(xmlDoc).find("leftLight").eq(0).text();
        var straightLight = $(xmlDoc).find("straightLight").eq(0).text();
        var rightLight = $(xmlDoc).find("rightLight").eq(0).text();

        $('#lightMainContentDiv').hide();
        $('#trafficContentDiv').show();
        judgeLightStatus('trafficLightOne',leftLight, 991);
        judgeLightStatus('trafficLightTwo',straightLight, 991);
        judgeLightStatus('trafficLightThree',rightLight, 991);
    }
}

/*************************************************
 Function:		judgeLightStatus
 Description:  上传红绿灯公共方法。 本方法使用于 990(车道交通灯) 和991(方向灯).
 Input:	    picLightDiv  车道DivID
            lightData   红绿灯状态,一般为:0~4
            lightType   红绿灯类型。包含 990和991
 Output:			无
 return:			无
 *************************************************/
function judgeLightStatus(picLightDiv, lightData, lightType){

    var infoImg = "";
    if(lightType == 990){

        if(lightData == 0 || lightData == 4){
            infoImg = getNodeValue("noneSetUpLight");
        }else if( lightData == 1){
            infoImg = "<img src='../images/picUpload/redLight.png' align='center'/>";
        }else if(lightData == 2){
            infoImg = "<img src='../images/picUpload/greenLight.png' align='center'/>";
        }else if(lightData == 3){
            infoImg = "<img src='../images/picUpload/yellowLight.png' align='center'/>";
        }
    }else if(lightType == 991){

        if(lightData == 0 || lightData == 4){

            if(picLightDiv == 'trafficLightOne'){
                infoImg = "<img src='../images/picUpload/left-none.png' align='center'/>";
            }else if(picLightDiv == 'trafficLightTwo'){
                infoImg = "<img src='../images/picUpload/front-none.png' align='center'/>";
            }else if(picLightDiv == 'trafficLightThree'){
                infoImg = "<img src='../images/picUpload/right-none.png' align='center'/>";
            }

        }else if( lightData == 1){

            if(picLightDiv == 'trafficLightOne'){
                infoImg = "<img src='../images/picUpload/left-red.png' align='center'/>";
            }else if(picLightDiv == 'trafficLightTwo'){
                infoImg = "<img src='../images/picUpload/front-red.png' align='center'/>";
            }else if(picLightDiv == 'trafficLightThree'){
                infoImg = "<img src='../images/picUpload/right-red.png' align='center'/>";
            }

        }else if(lightData == 2){

            if(picLightDiv == 'trafficLightOne'){
                infoImg = "<img src='../images/picUpload/left_green.png' align='center'/>";
            }else if(picLightDiv == 'trafficLightTwo'){
                infoImg = "<img src='../images/picUpload/front-green.png' align='center'/>";
            }else if(picLightDiv == 'trafficLightThree'){
                infoImg = "<img src='../images/picUpload/right-green.png' align='center'/>";
            }

        }else if(lightData == 3){

            if(picLightDiv == 'trafficLightOne'){
                infoImg = "<img src='../images/picUpload/left-yellow.png' align='center'/>";
            }else if(picLightDiv == 'trafficLightTwo'){
                infoImg = "<img src='../images/picUpload/front-yellow.png' align='center'/>";
            }else if(picLightDiv == 'trafficLightThree'){
                infoImg = "<img src='../images/picUpload/right-yellow.png' align='center'/>";
            }
        }
    }

    if(typeof(lightData) !="undefined" && lightData != null && lightData != ''){
        $('#' + picLightDiv).html(infoImg);
    }else{
        $('#' + picLightDiv).parent('.picLightSet').css("display","none");
    }
}

/*************************************************
 Function:		UploadTrafficCollect
 Description:	上传交通统计信息
 Input:		InfoXml 控件返回的xml数据。
 Output:			无
 return:			无
 *************************************************/
function UploadTrafficCollect (InfoXml){

    var xmlDoc = parseXmlFromStr(InfoXml);
    var startTime = "";
    startTime = $(xmlDoc).find("startTime").eq(0).text();
    if($(xmlDoc).find("Road").length > 0){

        var iNum = $(xmlDoc).find("Road").length;

        var TLength = 0;
        try{
            TLength = document.getElementById("trafficList").rows.length;
        }
        catch(e){
            TLength = 0;
        }
        if(TLength > 100){
            for(var i = (101 - iNum); i < TLength; i++){
                document.getElementById("trafficList").deleteRow(101 - iNum);
            }
        }

        /*if(TLength > 10){
            for(var i = (11 - iNum); i < TLength; i++){
                document.getElementById("trafficList").deleteRow(11 - iNum);
            }
        }*/

        for(var i = (iNum-1); i >= 0; i--){

            var roadId =  $(xmlDoc).find("roadId").eq(i).text();
            var CarFlux =  $(xmlDoc).find("CarFlux").eq(i).text();
            var AverOccpancy = $(xmlDoc).find("AverOccpancy").eq(i).text();
            var AverSpeed = $(xmlDoc).find("AverSpeed").eq(i).text();
            var AverCarDis = $(xmlDoc).find("AverCarDis").eq(i).text();
            insertTrafficFetchList(startTime, roadId, CarFlux, AverOccpancy, AverSpeed, AverCarDis);
        }
    }
}

function insertTrafficFetchList(startTime, roadId, CarFlux, AverOccpancy, AverSpeed, AverCarDis){

    var ObjTr;
    var ObjTd;

    ObjTr = document.getElementById("trafficList").insertRow(1);    //document.getElementById("trafficList").rows.length
    ObjTr.style.height = 22 + 'px';
    ObjTr.style.cursor = "pointer";

    for(var j = 0; j < document.getElementById('trafficList').rows[0].cells.length; j++){
        ObjTd = ObjTr.insertCell(j);
        $(ObjTd).css({border:"1px solid #d7d7d7",background:"#ffffff",padding:"0 0 0 5px"});
        switch(j)
        {
            case 0:
                ObjTd.innerHTML = startTime;
                ObjTd.id = "startTime_"+ j + "_"+ roadId;
                ObjTd.style.color = "#39414A";
                break;
            case 1:
                ObjTd.innerHTML = roadId;
                ObjTd.id = "roadId_"+ j + "_"+ roadId;
                ObjTd.style.color = "#39414A";
                break;
            case 2:
                ObjTd.innerHTML = CarFlux;
                ObjTd.id = "CarFlux_"+ j + "_"+ roadId;
                ObjTd.style.color = "#39414A";
                break;
            case 3:
                ObjTd.innerHTML = AverOccpancy;
                ObjTd.id = "AverOccpancy_"+ j + "_"+ roadId;
                ObjTd.style.color = "#39414A";
                break;
            case 4:
                ObjTd.innerHTML = AverSpeed;
                ObjTd.id = "AverSpeed_"+ j + "_"+ roadId;
                ObjTd.style.color = "#39414A";
                break;
            case 5:
                ObjTd.innerHTML = AverCarDis;
                ObjTd.id = "AverCarDis_"+ j + "_"+ roadId;
                ObjTd.style.color = "#39414A";
                break;
            default:
                break;
        }
    }
}


function getSnapResolutionInfo(){

    $.ajax({
        type: "GET",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ITC/ITCStatus",
        async: false,
        timeout: 15000,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {

            m_snapResolutionWidth = parseInt($(xmlDoc).find("snapResolutionWidth").eq(0).text(),10);
            m_snapResolutionHeight = parseInt($(xmlDoc).find("snapResolutionHeight").eq(0).text(),10);
        }
    });
}

var snapCountInfo = "";
var snapLaneNumberInfo = "";
var snapWaitTimeInfo = "";
var capEnableInfo = "false";
var snapIntervalLength = 0;
var snapInterval = new Array();

function getContinueCapInfo(){

    $.ajax({
        type: "GET",
        url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ContentMgmt/continueCap",
        async: false,
        timeout: 15000,
        beforeSend: function(xhr) {
            xhr.setRequestHeader("If-Modified-Since", "0");
            
        },
        success: function(xmlDoc, textStatus, xhr) {
            capEnableInfo = $(xmlDoc).find('capEnable').eq(0).text();
            snapLaneNumberInfo = $(xmlDoc).find('relatedDriveWay').eq(0).text();
            snapCountInfo = $(xmlDoc).find('snapTimes').eq(0).text();
            snapWaitTimeInfo = $(xmlDoc).find('waitTime').eq(0).text();
			
            snapIntervalLength = $(xmlDoc).find('IntervalList').eq(0).find('Interval').length;
            for(var i=0; i < snapIntervalLength; i++ ){
                snapInterval[i] = parseInt($(xmlDoc).find('IntervalList').eq(0).find('Interval').eq(i).text());
            }
        }
    });
}

function showSnapAdvanceSetting(){
	
    $('#snapAdvanceSettingDiv').modal();

    getContinueCapInfo();
    $('#laneNumber_upload').val(snapLaneNumberInfo);
    $('#lasnapCount_upload').val(snapCountInfo);
    $('#waitTime_upload').val(snapWaitTimeInfo);

    for(var i=0; i< snapIntervalLength; i++){
        $('#Interval' + (i+1)).val(snapInterval[i]);
    }
	capEnableInfo=false;
}

function saveSnapSetting(){

    if(!CheackServerIDIntNum($('#waitTime_upload').val(), 'spanwaitTimeTips','',0,2000)) {
        $("#waitTime_upload").focus();
        return;
    }
    for(var i=0; i < snapIntervalLength; i++){
        if(!CheackServerIDIntNum($('#Interval'+(i + 1)).val(), 'spanintervalTips','',0,10000)) {
            $('#Interval'+(i + 1)).focus();
            return;
        }
    }

    snapCountInfo = $('#lasnapCount_upload').val();
    snapLaneNumberInfo = $('#laneNumber_upload').val();
    snapWaitTimeInfo =  $('#waitTime_upload').val();
    for(var i = 0; i < snapIntervalLength; i++){
        snapInterval[i] = $('#Interval'+(i + 1)).val();
    }

    sz_snapXML = null;

    sz_snapXML =  '<?xml version="1.0"?><continueCapCmd>';
	sz_snapXML +=  '<capEnable>' + capEnableInfo + '</capEnable>'; //既配置又连拍标记字段
    sz_snapXML += '<snapTimes>' + snapCountInfo  + '</snapTimes>';  //抓拍张数
    sz_snapXML +=  '<relatedDriveWay>' + snapLaneNumberInfo + '</relatedDriveWay>'; //关联车道
    sz_snapXML +=  '<waitTime>' + snapWaitTimeInfo + '</waitTime><IntervalList>'; //连拍等待时间ms	
    sz_snapXML +=  '<Interval><value>' + snapInterval[0] + '</value></Interval><Interval><value>' + snapInterval[1] + '</value></Interval><Interval><value>' + snapInterval[2] + '</value></Interval><Interval><value>' + snapInterval[3] + '</value></Interval></IntervalList></continueCapCmd>'; //连拍间隔ms

    $.modal.impl.close();
	//判断是否已经布防成功
    if (m_iAlarmStatus == 1 || m_iAlarmStatus == 2) {
        //直接发送psia协议请求即可
        var xmlDoc = parseXmlFromStr(sz_snapXML);
        $.ajax({
            type: "PUT",
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ContentMgmt/continueCap",
            processData: false,
            data: xmlDoc,
            complete:function(xhr, textStatus) {
                if(xhr.status == 403) {  //无权限
                    alert(getNodeValue('jsNoOperationRight'));
                }(xhr);
            }
        });

    } else {  //若未布放，提示先布防或者直接返回不处理，//测试就先启用布放-2级吧
        alert(getNodeValue('lalinkStatus'));
    }
}

function closeSnapSetting(){
    $.modal.impl.close();
}

//手动抓拍
/*************************************************
 Function:		startManualCap
 Description:	手动抓拍功能。
 Input:		        无
 Output:			无
 return:			无
 *************************************************/
function startManualCap() {

    var szSuccessState = "<img src='../images/config/smile.png' class='verticalmiddle'>&nbsp;";
    var szErrorState = "<img src='../images/config/error.png' class='verticalmiddle'>&nbsp;";

    var previewOCX = $("#PicPreviewActiveX")[0];
    if (previewOCX == null) {
        return;
    }

    var szURL = m_lHttp+m_szHostName+":"+m_lHttpPort+"/PSIA/Custom/SelfExt/ContentMgmt/manualCap";
    var iRet = previewOCX.HWP_StartAlarmChan(szURL, m_szUserPwdValue, "manualCap");
    if(iRet < 0){
        $("#spLinkStatus").html(szErrorState + getNodeValue('startUpSnapManualFail'));
    } else {
        $("#spLinkStatus").html(szSuccessState + getNodeValue('startUpSnapManualSuccess'));
    }
}

//手动连拍多张
/*************************************************
 Function:		startManualMoreCap
 Description:	连抓N张图片功能。
 Input:		        无
 Output:			无
 return:			无
 *************************************************/
function startManualMoreCap() {
   // if(sz_snapXML == null || sz_snapXML == ''){
        getContinueCapInfo();
		capEnableInfo=true;
        sz_snapXML =  '<?xml version="1.0"?><continueCapCmd>';
		sz_snapXML +=  '<capEnable>' + capEnableInfo + '</capEnable>'; //既配置又连拍标记字段 
        sz_snapXML += '<snapTimes>' + snapCountInfo  + '</snapTimes>';  //抓拍张数
        sz_snapXML +=  '<relatedDriveWay>' + snapLaneNumberInfo + '</relatedDriveWay>'; //关联车道
        sz_snapXML +=  '<waitTime>' + snapWaitTimeInfo + '</waitTime><IntervalList>'; //连拍等待时间ms
        sz_snapXML +=  '<Interval><value>' + snapInterval[0] + '</value></Interval><Interval><value>' + snapInterval[1] + '</value></Interval><Interval><value>' + snapInterval[2] + '</value></Interval><Interval><value>' + snapInterval[3] + '</value></Interval></IntervalList></continueCapCmd>'; //连拍间隔ms

//        alert(getNodeValue('setSnapPicInfo'));
//        return;
    //}
    //判断是否已经布防成功
    if (m_iAlarmStatus == 1 || m_iAlarmStatus == 2) {
        //直接发送psia协议请求即可
        var xmlDoc = parseXmlFromStr(sz_snapXML);
        $.ajax({
            type: "PUT",
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/SelfExt/ContentMgmt/continueCap",
            processData: false,
            data: xmlDoc,
            complete:function(xhr, textStatus) {
                if(xhr.status == 403) {  //无权限
                    alert(getNodeValue('jsNoOperationRight'));
                }(xhr);
            }
        });

    } else {  //若未布放，提示先布防或者直接返回不处理，//测试就先启用布放-2级吧
        alert(getNodeValue('lalinkStatus'));
    }
}

function GetImgZoomInfo(InfoXml) {
    var iRet = HWP2.HWP_SetImgZoomInfo(0, InfoXml);
}

function GetAlarmLightTypeInfo(){
    $.ajax(
        {
            type: "GET",
            beforeSend: function(xhr) {
                xhr.setRequestHeader("If-Modified-Since", "0");
                
            },
            url: m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/System/deviceInfo",
            async: false,
            timeout: 15000,
            success: function(xmlDoc, textStatus, xhr)
            {
                var triggerModeType = $(xmlDoc).find('workMode').eq(0).text();
                if(triggerModeType == '2'){
                    trafficLightEnable = true;
                }
            }
        });
}