/*****************************************************
 FileName: tabs
 Description: 标签页插件
 Author: Chenxiangzhen
 Date: 2011.12.13
 *****************************************************/
(function ($) {
	$.fn.tabs = function (paneSelector, opt) {
		opt = jQuery.extend({
			tabs:"a",
			current:"current",
			markCurrent:true,
			defaultCur:0, // 初始标签页
			beforeLeave:null, // 标签页切换前被回调
			hideIndexes:null    // 隐藏的标签页
			, selectChanged: null   // 选中
		}, opt);

		var container = this;

		$.extend(this, {
			curTab:opt.defaultCur,
			tabs:$(this).find(opt.tabs),
			panes:$(paneSelector),
			showTab:function (iIndex) {
				this.tabs.eq(iIndex).parent().removeClass("hideBorder");
				this.tabs.eq(iIndex).show();
				return this;
			},
			isShown: function (iIndex) {
				if (this.tabs.eq(iIndex).is(":hidden")) {
					return false;
				};	
				return true;
			},
			hideTab:function (iIndex) {
				if (iIndex == this.curTab) {
					this.selectTab(opt.defaultCur);
				}
				this.tabs.eq(iIndex).parent().addClass("hideBorder");
				this.tabs.eq(iIndex).hide();
				return this;
			},
			showTabs:function (iIndexes) {
				$.each(iIndexes, function (i, n) {
					container.showTab(n);
				});
				return this;
			},
			hideTabs:function (iIndexes) {
				$.each(iIndexes, function (i, n) {
					container.hideTab(n);
				});
				return this;
			},
			selectCurTab: function(iIndex){
				this.selectTab(this.curTab);
			},
			selectTab:function (iIndex) {
				this.tabs.eq(iIndex).click();
				if (opt.tabs == "a") {
					window.location.href = this.tabs[iIndex].href;
				}
				return this;
			},
			selectCurrentOrFirstTab: function(selOpt){
				var iCurTab = opt.defaultCur;
				try {
					iCurTab = parseInt($.cookie(encodeURIComponent($(container)[0].id) + "_curTab"));
					if (!isNaN(iCurTab)) {
						if (!this.isShown(iCurTab)) {
							iCurTab = opt.defaultCur;
						}
					}else{
						iCurTab = opt.defaultCur;
					}
				} catch (e) {}

				if (!this.isShown(iCurTab)) {
					this.tabs.each(function(i, n){
						if ($(n).is(":visible")) {
							iCurTab = i;
							return false;
						};
					});
				}

				if (selOpt && selOpt.shouldNotTriggerClick(iCurTab)) {

				}else{
					this.selectTab(iCurTab);	
				}
			},

			selectFirstTabWhenNoSelected: function () {
				var _first = null;
				var found = false;
				this.tabs.each(function(i, n){
					if (!_first && $(n).is(":visible")) {
						_first = i;
					};
					if ($(n).is(":visible") && $(n).is(".current")) {
						found = true;
						return false;
					};
				});
				if (!found && _first != null) {
					this.selectTab(_first);
				};
			},
			tabsExtend:function (imode) { //由于过长所以需要增加高度和改变选中样式 0-旧样式 1-新样式
				if (imode == 2) {
					container.tabs.removeClass(opt.current);
					opt.current = "currentExt";
					this.tabs.eq(container.curTab).addClass(opt.current);
					container.removeClass('increaseHeigh').addClass('increase2Heigh');
				} else if (imode == 1) {
					container.tabs.removeClass(opt.current);
					opt.current = "currentExt";
					this.tabs.eq(container.curTab).addClass(opt.current);
					container.removeClass('increase2Heigh').addClass('increaseHeigh');
				} else {
					container.tabs.removeClass(opt.current);
					opt.current = "current";
					this.tabs.eq(container.curTab).addClass(opt.current);
					container.removeClass('increaseHeigh').removeClass('increase2Heigh');
				}
			}
		});

		var bFirst = true;
		var m_tabsAllWidth = 0;
		this.tabs.each(function (i) {
			$(this).unbind("click").bind("click", function (event) {
				if (!bFirst && i == container.curTab) {
					event.preventDefault();
					return;
				}
				if (!bFirst && opt.beforeLeave !== null) {
					opt.beforeLeave(container.curTab);
				}
				container.tabs.removeClass(opt.current);
				$(this).addClass(opt.current);
				container.panes.hide();
				container.showTab(i);
				container.panes.eq(i).show();
				container.curTab = i;

				if (opt.selectChanged !== null) {
					opt.selectChanged(i, container.panes.eq(i));
				};	
				if (opt.markCurrent) {
					try {
						$.cookie(encodeURIComponent($(container)[0].id) + "_curTab", i);
					} catch (e) {
					}
				}
			});

		});

		if (opt.hideIndexes instanceof Array) {
			$.each(opt.hideIndexes, function (i, n) {
				container.hideTab(n);
			});
		}

		//显示上次选中的tab
		if (opt.markCurrent) {
			try {
				var iCurTab = parseInt($.cookie(encodeURIComponent($(container)[0].id) + "_curTab"));
				if (!isNaN(iCurTab)) {
					if (opt.hideIndexes instanceof Array) {
						if ($.inArray(iCurTab, opt.hideIndexes) != -1) {
							iCurTab = opt.defaultCur;
						}
					}
					this.selectTab(iCurTab);
				} else {
					this.selectTab(opt.defaultCur);
				}
			} catch (e) {
				this.selectTab(opt.defaultCur);
			}
		} else {
			this.selectTab(opt.defaultCur);
		}	
		
		
		bFirst = false;
		return this;
	};
})(jQuery);