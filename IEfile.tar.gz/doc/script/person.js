
var m_bFirst = true;     

/*************************************************
Function:		InitPictureDownload
Description:	初始化图片下载
Input:			无			
Output:			无
return:			无				
*************************************************/
function InitPersonDownload()
{
	m_szUserPwdValue = g_oWebSession.getItem("userInfo"+m_lHttpPort);
	if(m_szUserPwdValue == null)
	{
		window.close();
		return;
	}
	window.parent.ChangeMenu(6);
	ChangeLanguage(parent.translator.szCurLanguage);
	var szInfo = translator.translateNode(g_lxdDownload, 'laPlugin');
	
	if(!checkPlugin('0', szInfo, 1, 'snapdraw'))
	{
		return;
	}
    g_transStack = new TransStack();
	m_PreviewOCX=document.getElementById("PreviewActiveX");
	m_PicPreviewOCX = document.getElementById("PicPreviewActiveX");
	
	GetNowTime();
}

/*************************************************
Function:		GetNowTime
Description:	获取当前日期
Input:			无			
Output:			无
return:			无				
*************************************************/
function GetNowTime()
{
	var myDate = new Date();
	var iYear = myDate.getFullYear();        
	var iMon = myDate.getMonth();      
	var iDay = myDate.getDate(); 
	iMon = parseInt(iMon)+1;
	if(iMon <= 9)
	{
		iMon = '0' + iMon;
	}
	var szNowTime = iYear + "-" +  iMon + "-" + iDay + " 00:00:00";
	document.getElementById("begintime").value = szNowTime;
	document.getElementById("endtime").value = iYear + "-" +  iMon + "-" + iDay + " 23:59:59";
}


/*************************************************
Function:		ChangeLan
Description:	改变页面语言
Input:			无
Output:			无
return:			无
*************************************************/
function ChangeLanguage(lan)
{
	g_lxdDownload = parent.translator.getLanguageXmlDoc("Download", lan);
	parent.translator.appendLanguageXmlDoc(g_lxdDownload, parent.g_lxdMain);
	parent.translator.translatePage(g_lxdDownload, document);
	
	//window.parent.document.title = parent.translator.translateNode(g_lxdDownload, 'picturetitle');
    window.parent.document.title = parent.translator.translateNode(g_lxdDownload, 'persontitle');
	m_szExit = parent.translator.translateNode(g_lxdDownload, 'exit');
	
	if($('#divPictureSearchTips').css('display') != 'none') {
	    g_transStack.translate();
	}
	
}
/*************************************************
Function:		PluginEventHandler
Description:	图片回放事件响应
Input:			iEventType 事件类型, iParam1 参数1, iParam2 保留
Output:			无
return:			无
*************************************************/
function PluginEventHandler(iEventType, iParam1, iParam2) {
	
}

$(function () {
	$('#searchType').change(function () {
		var v = $('#searchType').val();
		if (v == '2' || v == '1') {
			$('#displayType').html('<option value="pie">饼图</option>');
		}else{
			$('#displayType').html('<option value="bar">柱状图</option><option value="line">折线图</option>');
		}
	});
	$('#searchType').change();
})

function PersonSearch () {
	$("#chartHolder").html('');
	
	var type = $('#displayType').val();

	var searchType = $("#searchType").val();
	if (searchType == '1') {   // 性别
		searchGender();
	}else if (searchType == '2') {  // 年龄段
		searchAge();
	}else if (searchType == '3') {  //抓拍人数
		searchPerson();
	}
	
	var strHtml="<div id='tip' class='ac-tooltip'>";
		strHtml+= "<span>时间：<span class='ac-title'></span></span>";
		strHtml+="<table>";
		strHtml+="<tbody class='ac-list'></tbody>";
		strHtml+="</table>";
	    strHtml+="</div>";
	$("#dvTip").html(strHtml);
}

function searchPerson () {
	searchData().done(function (data) {
		var valuesx = [];
		var valuesy = [];

		for (var i = 0; i < 24; i++) {
			if ($(data).find('hour'+i).length) {
				valuesx.push(i);
				valuesy.push(parseInt($(data).find('hour'+i).text(), 10))
			};
		};

		var displayType = $('#displayType').val();
		if (displayType == 'line') {
			generateLine({
				title: "人数统计",
				valuesx: valuesx,
				valuesy: valuesy
			});
		}else{
			generateBar({
				title: "人数统计",
				valuesx: valuesx,
				valuesy: valuesy
			});
		}
		

	}).fail(function () {
		alert("查询失败！");
	});
}


function searchAge () {
	searchData().done(function (data) {
		var child = $(data).find('child').text();
		child = parseInt(child, 10);
		var young = $(data).find('young').text();
		young = parseInt(young, 10);
		var middle = $(data).find('middle').text();
		middle = parseInt(middle, 10);
		var old = $(data).find('old').text();
		old = parseInt(old, 10);
		
		generatePie({
			title: '年龄分布',
			data: [
				["儿童", child],
				["青年", young],
				["中年人", middle],
				["老年人", old]
			],
			total: child+young+middle+old
		});

	}).fail(function () {
		alert("查询失败！");
	});
}

function searchGender() {
	searchData().done(function (data) {
		var male = $(data).find('male').text();
		var female =  $(data).find('female').text();

		male = parseInt(male, 10);
		female = parseInt(female, 10);

		generatePie({
			title: '性别分布',
			data: [
				["男", male],
				["女", female]
			]
		});

	}).fail(function () {
		alert("查询失败！");
	});
}

function searchData() {
	var obj = {
		fdQueryDescription: {
			queryType: $("#searchType").val(),
			startDate: $("#begintime").val().replace(" ", "T") + "Z",
			endDate: $("#endtime").val().replace(" ", "T") + "Z",
		}
	}

	var xml = x2js.json2xml_str(obj);

	var szURL = m_lHttp + m_szHostName + ":" + m_lHttpPort + "/PSIA/Custom/selfext/itc/facedetect/query";
	return $.ajax({
		data: xml,
		type: 'POST',
		url: szURL,
		datatype: 'xml',
		processData: false,
		beforeSend: function(xhr) {
			xhr.setRequestHeader("If-Modified-Since", "0");  
		}
	});
}

function generatePie (opts) {
	var title = opts.title;
	var data = opts.data;

	var chart = new AChart({
          id : 'chartHolder',
          height : 350,
          forceFit : true,
          title : {
            text : title
          },
         
          legend : null ,//不显示图例
          seriesOptions : { //设置多个序列共同的属性
            pieCfg : {
              allowPointSelect : true,
              labels : {
                distance : 30,
                label : {
                  //文本信息可以在此配置
                },
                renderer : function(value,item){ //格式化文本
                  return value + ' ' + (item.point.percent * 100).toFixed(1)  + 
                  			'%，('+item.point.value+'人)';
                }
              }
            }
          },
          tooltip : {
            pointRenderer : function(point){
            	return point.value + "，占比 "+(point.percent * 100).toFixed(1)+ '%';
            }
          },
          series : [{
              type: 'pie',
              name: '人数',
         //      legend : {
         //        position : 'right'
     		  // },

              data: data
          }]
        });
 
        chart.render();
}

function generateLine (opts) {
	var valuesx = opts.valuesx;
	var valuesy = opts.valuesy;

	var chart = new AChart({
      id : 'chartHolder', 
      width : 950,
      height : 500,
      forceFit : true,
      plotCfg : {
        margin : [50,50,80] 
      },
      title : {
        text : opts.title || ""
      },
      xAxis : {
        categories : valuesx
      },
      yAxis : {
        title : {
          text : '人数',
          rotate : -90
        }
      },
      tooltip : {
        valueSuffix : '',
        custom : true, //自定义tooltip
        html : '#tip',//自定义tooltip的 模板或者 #id
     //    //customFollow : false, //自定义tooltip不跟随移动
    	// triggerEvent : 'click', //点击触发显示tip
        shared : true, //是否多个数据序列共同显示信息
        formatter : function (item,index) {
          return AChart.Util.substitute('<tr><td>'+index+'</td><td>{name}</td><td style="color:{color}">{value}</td></tr>',item);
        },
        crosshairs : true //是否出现基准线
      },
      series : [{
        name: '人数',
        data: valuesy,
        markers : {
          marker : {
            stroke : '#4dceff',
            'stroke-width' : 0,
            fill : '#4dceff',
            radius : 4
          }
        }
      }]
    });

    chart.render();
}

function generateBar (opts) {
	var chart = new AChart({
      id : 'chartHolder',
      forceFit: true,
      height : 500,
      title : {
        text : opts.title || "",
        'font-size' : '16px'
      },
      xAxis : {
        categories: opts.valuesx,
        position : 'bottom', //x轴居左
        labels : {
          label : {
            'text-anchor' : 'center',
            x : 0,
            y : 15
          }
        }
      },
      yAxis : {
        position : 'left',
        min : 0,
        title : {
          text : '人数',
          rotate : -90
        }
      },
      tooltip : {
        shared : true,
        custom : true, //自定义tooltip
        html : '#tip'//自定义tooltip的 模板或者 #id
      },
      seriesOptions : {
          columnCfg : {

          }
      },
      series: [ {
              name: '人数',
              data: opts.valuesy
          }]
    });

    chart.render();
}